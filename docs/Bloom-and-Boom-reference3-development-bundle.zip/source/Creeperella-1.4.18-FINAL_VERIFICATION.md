# Creeperella 1.4.18 Final Verification

## Scope
Cat rest grounding and tail-life pass only. The 1.4.17 locomotion IK, grounded Sit 2, and approved upright SIDE_LIE body/leg solve are regression-locked.

## Deterministic ground QA
Fixed reference: standing Cat paw-bottom Y from the real model hierarchy.

- SIT: front paw deltas ~0.0023; rear paw deltas ~0.1050.
- SIT 2: front ~0.1018; rear ~0.1090 (unchanged from 1.4.17).
- LOAF: front ~0.0971; rear ~0.1005.
- SIDE_LIE: whole-pose ground delta ~0.1000 across all four approved variants; body/leg method unchanged.
- SPRAWL: whole-pose delta ~0.0580; forepaws ~0.1086; hind paws ~0.0944. Straight front lower segments remain above the floor.

## Tail QA
Pose-aware ambient tail life is always-on during rest, with root amplitude lower than tip amplitude. Across sampled variants/times/entity phases, minimum tail-floor clearance remained:
- SIT > 6.06 model units
- SIT 2 > 2.69
- LOAF > 10.27
- SIDE_LIE > 1.51
- SPRAWL > 1.38

Personality TAIL_WAG continues to layer on top. LOAF curl mirrors by variant. SIDE_LIE static tail placement remains the approved pose.

## Regression tests completed
- `tools/test_cat_rest_pose_polish.py` PASS
- `tools/test_cat_horse_rest_ground.py` PASS
- `tools/test_cat_behavior_contract.py` PASS
- `tools/audit_cat_bedrock_port.py` PASS
- `tools/audit_model_generation_determinism.py` PASS
- `tools/audit_source_pack_completeness.py` PASS (45/45)
- `tools/test_pie_animation_formula_parity.py` PASS (712 samples)
- `tools/test_cherry_animation_formula_parity.py` PASS (235 samples)

`tools/test_cat_secondary_motion.py` exceeded this runtime's execution window when rerun; do not claim that heavyweight test completed. Locomotion IK itself is byte-for-byte regression-locked to the 1.4.17 snapshot.

## Build gate
No Gradle executable or wrapper is present in this runtime, so no fresh ForgeGradle compile/remap or production JAR is claimed here. Full source + deterministic QA are the deliverables for this pass.

## Visual provenance
All QA images/GIFs are deterministic renders from the checked-in Cat model, texture, hierarchy and runtime-equivalent pose math. No generative image model was used.
