# Bloom & Boom

## Reference3 development checkpoint · 7 October 2026

Minecraft 1.20.1 / Forge 47.4.23 / Java 17. The historical internal registry ID remains `creeperella` for save compatibility. The official project name is **Bloom & Boom**.

This candidate refines Mariglow, Verdalia and Nacrella against the approved clean Froglight references: curved shaded petals, fuller roof coverage, twelve hanging chains, Pie-driven jewel eyes, translucent lantern glass and brighter vanilla-derived material panels. Cat assets and animation remain protected. The original Pie chest and animation are intentionally retained as requested.

**Exact concept-art fidelity and release readiness are not accepted.** See `qa/reference3/README.md` for the current checkpoint and its distinct static, native-development and packaged-server gates. Historical receipts below describe their own checkpoints only. The source/binary bundle is private; publication awaits explicit sharing approval.

Build with Java 17 and Gradle 8.8: `gradle build`. `--offline` requires an already populated compatible cache. No wrapper, Minecraft binary, dependency cache or user world is bundled.

---

> **1.5.2 Boomshroom texture polish:** Boomshroom keeps the exact authorized Creeper Overhaul mushroom cap, but her Cherry-family body is now a clean textured ivory/white stalk with **no red facial markings**. The supplied Creeper Overhaul Mushroom Creeper atlas is sampled directly for its foot-to-root luminance language, translated into a low-chroma irregular gray ground-stain that wicks upward from the feet while leaving the stalk overwhelmingly white. Her body/face emissive is intentionally transparent; only the separate exact cap glow remains.

> **1.5.0 Boomshroom — Mushroom Fields native release:** Boomshroom joins the active family as the sixth current Creeperella: a separately authored cream/ivory fungal body built from Cherry Creeper's proven feminine rig and animation language, topped by the user-authorized Creeper Overhaul Mushroom Creeper cap as an isolated exact-source 128×128 render layer. She has a synchronized cap-tip greeting, native four-frame drifting spores, a dedicated animated 3D spawn egg, Mushroom Fields ecology, and a centralized themed-explosion profile that blooms 248 spores plus 64 mycelium particles. Real Forge 47.4.23 dedicated-server and native-client gates cover base, greeting, charged, real fuse/explosion FX, family parity, and clear-state cleanup. Blossom remains compatibility-only and aliases Cherry for old saves.

> **1.4.21 Blossom parity + native family release:** Blossom Creeper is no longer only Cherry's alternate texture treatment. She now keeps the proven Cherry Remake source animation baseline while owning a separate generated sakura silhouette with seven crown/shoulder/hip petal accents and subtle secondary motion. Blossom also receives a full standalone content family matching Cherry's depth: **Blossom Powder, Blossom TNT + primed TNT, Blossom Creeper Head, Blossom Creebet painting, dedicated loot/skull behavior, recipe, tags, localization, and native QA commands**. The real Forge 47.4.23 client gate verifies all six mobs, normal and charged Cherry-vs-Blossom comparison, the real Blossom TNT block→primed-entity path, sidecar rendering, and the complete Cat animation reel. Cherry's protected source-authored geometry/textures/formulas remain hash-identical.

# Creeperella: Bloom & Boom
> **1.4.18 Cat grounded-rest + lively-tail pass:** every Cat rest family is now checked against one fixed standing-paw Minecraft ground plane. Standard **SIT** rear paws are grounded with calibrated two-link IK; **LOAF** keeps its compact tuck while all four paws settle to the same floor; the goofy full **SPRAWL** keeps straight forelegs without burying their lower segments by rotating only the terminal paws down while lowering the hind roots safely. **Sit 2** and the approved upright horse-style **SIDE_LIE** body/leg poses are regression-locked unchanged. Every rest pose now has subtle always-on cat-like tail life (small root drift, delayed larger tip follow-through) with pose-specific amplitudes, and LOAF tail curl mirrors by variant. Full 1.4.17 rollback source is bundled under `pose-history/1.4.17-before/`. QA is deterministic from the real project model/texture; no image generation is used.

> **1.4.17 Cat sploot + tail-visibility update:** the 1.4.15 `SPRAWL` is preserved exactly as a new owner-command **Sit 2** option. `SPRAWL` is now the goofy full sploot: both forelegs extend nearly straight forward and both hind legs extend nearly straight backward, almost parallel to the Minecraft ground plane. The approved upright `SIDE_LIE` body/tail transforms remain unchanged; QA now includes rear/side/turntable views so the tail cannot disappear behind the haunches in a single 3Q preview. Full 1.4.15 rollback source is bundled under `pose-history/1.4.15-before/`. No image generation is used for Creeperella QA.


> **1.4.15 Cat rest-pose polish:** after the 1.4.14 horse-rest correction, the other Cat rest families were audited too. SIT now uses compact grounded rest IK, LOAF is genuinely tucked/compact, and SPRAWL has four readable outward paw targets. The approved 1.4.14 upright horse-rest/SIDE_LIE and the CREEP/WALK/RUN locomotion solver are regression-locked unchanged. Full 1.4.14 rollback source + before renders are bundled in `pose-history/1.4.14-before/`. No image generation is used for Creeperella QA.

> **1.4.14 Cat upright alert-rest update:** horse-style `SIDE_LIE` keeps the grounded side-folded lower body, but the visible torso/chest now cancels nearly all side roll and forward bend. The upper torso and head remain essentially vertical with only a tiny natural lean, preserving a comfortable Creeper-like silhouette while she stays alert.


**Creeperella** is a standalone Forge 1.20.1 Creeper-family mod built from the supplied Pie's Female Creeper and Cherry Creeper designs. It does **not** replace or reskin `minecraft:creeper`.

## 1.4.9 — seated tail direction correction

Cat Creeper seated/rest tail posing now respects the actual Cat rig axes. The tail no longer uses large seated yaw/side offsets that made it spear out of the flank or appear thrown into the ground. In SIT the root remains in the sagittal plane, trails rearward/down from the rump, and the second segment eases toward a rear trail. Tail-wag motion is applied only as a small bounded lateral oscillation after that rearward solve.

`tools/test_cat_aaa_gait.py` now hard-fails seated tail regressions: full SIT samples must remain effectively zero-lateral at rest, extend rearward by more than 12 model units, retain more than 4 model units of floor clearance, and remain outside the torso core. `tools/make_cat_seated_tail_qa.py` renders front / three-quarter / side / back inspection plus GIFs from the actual project model and texture; no image generation is used.

## 1.4.8 — Cat behavior states + personality idles

Cat Creeper now layers a server-authoritative **IDLE → CREEP → WALK → RUN → SWELL / SIT / REFORM** controller over the clipping-safe 1.4.7 feline IK rig. Wild Cats stalk unnoticed players at configurable speed, switch to a distinct run when noticed/hurt/in ambush range, and use notice-memory hysteresis so the state cannot flicker. Tamed Cats walk normally, run to catch up beyond 10 blocks, and return to walk inside 8 blocks. Actual `limbSwingAmount` remains the physical gait gate, so a blocked Cat never treadmills in place.

Four interruptible personality clips are included: **Paw Lift** (58 ticks), **Tail Wag** (72), **Curious Look** (62), and tamed-only **Knead** (80). They require true stillness, use randomized cooldowns and repeat avoidance, blend in/out smoothly, and immediately yield to movement, targets, damage, fuse behavior, sit, or reform. Positive taming/healing/bond interactions can trigger the Paw Lift greeting. The server synchronizes only motion state, idle clip, and animation start tick—continuous curves remain client-local.

`tools/test_cat_behavior_contract.py` verifies state/hysteresis/network rules. `tools/test_cat_aaa_gait.py` now covers **17,328** creep/walk/run leg-phase samples plus SIT/SWELL and every idle in both handedness directions, rejecting distal torso penetration, side crossing, discontinuity and tail tunneling. See `CAT_ANIMATION_AI_ARCHITECTURE.md`. **No image generation is used for project QA.**

## 1.4.7 — AAA Cat Creeper locomotion

Cat Creeper locomotion is now a real articulated feline gait instead of a large vanilla-style leg swing. The supplied FemaleCreeper geometry, texture, blink timing and authored idle/secondary curves remain the visual source baseline, but **movement locomotion is intentionally upgraded** to a four-beat cat walk that blends toward a diagonal trot at high movement intensity.

Each leg now follows a ground-relative paw trajectory through a two-link IK solve using the **actual generated Cat rig joint lengths and pivots**. During stance the paw travels backward relative to the body to read as planted; during swing it lifts through a smooth arc and advances for the next step. Upper-leg, lower-leg/hock, and paw rotations have anatomical hard limits, and the paw counter-rotates toward level so knees/hocks do not fold through the torso. The torso shifts weight, spine and shoulders counter-flex, the head stabilizes, and the two-segment tail gains a small bounded balance yaw with delayed tip follow-through.

`tools/test_cat_aaa_gait.py` samples thousands of real rig poses across slow walk, normal walk, fast walk/trot blend and extreme movement input. It rejects lower-leg/paw penetration into torso cores, body-side swaps, joint inversion/out-of-range angles, discontinuous paw teleporting and tail-tip tunneling. Deterministic side / 3⁄4 / front GIFs are rendered directly from the checked-in model, texture and runtime-equivalent gait code; **no image generation is used**.

## 1.4.5 — vanilla-anchored Cherry TNT

Cherry TNT now uses **the same cube geometry contract as vanilla Minecraft TNT** instead of reproducing the source resource pack's Blockbench UV adapter literally. The source 64×64 Cherry TNT atlas is still preserved byte-for-byte, and `tools/generate_cherry_tnt_vanilla_faces.py` deterministically derives the exact authored 16×16 side/top/bottom pixels used by the vanilla `cube_bottom_top` runtime model. This keeps the author's art while fixing the malformed TNT presentation and making both placed and primed Cherry TNT follow vanilla geometry/render semantics.

The dedicated Cherry TNT identity and behavior from 1.4.4 are unchanged: redstone, flint-and-steel, fire charges, flaming projectiles, chain reactions, shortened chained fuse, swell/flash rendering and normal TNT explosion behavior remain namespaced to Cherry TNT. Vanilla `minecraft:tnt` remains untouched.

## 1.4.4 — full standalone source-pack sidecars

The project rule is now explicit: when a supplied pack contains art/content intended to accompany one of our mobs, Creeperella brings that content over as its **own standalone namespaced feature** rather than dropping it or hijacking the vanilla equivalent. Cherry Creeper Remake 3.0 therefore contributes:

- **Cherry Gunpowder** — exact source sprite; dropped by Cherry Creepers, tagged as Forge gunpowder, and used by Cherry TNT / Cherry recipes.
- **Cherry TNT** — exact source 64×64 atlas preserved; runtime uses vanilla TNT cube geometry with deterministic exact-source side/top/bottom face extraction; dedicated block/item/primed entity keeps normal redstone, fire, projectile, chain-reaction and explosion behavior. The primed renderer stays Cherry instead of becoming vanilla TNT.
- **Cherry Creeper Head** — generated directly from the supplied `head_creeper.jem`; dedicated standing block, wall block and custom-rendered inventory item; drops from a Cherry Creeper under vanilla charged-Creeper skull-drop rules.
- **Cherry Creebet Painting** — exact source 32×16 art, registered as its own 2×1 painting variant with a dedicated placement item.
- **Source identity strings** — authored English/Russian Cherry mob, spawn-egg and Creeper-head names remapped safely under `creeperella:` keys.

Vanilla `minecraft:tnt`, `minecraft:gunpowder`, the vanilla Creeper Head, vanilla paintings, and global vanilla language keys remain untouched. The source pack is still mirrored byte-for-byte for auditability.


## 1.4.3 source-completeness + motion QA pass

1.4.3 performs a full byte-level re-audit of all three supplied packs instead of checking only the already-selected textures/models. All **45/45 supplied files** are now mirrored under `reference-assets/source-packs/` and permanently hash-gated. The inventory confirms the supplied packs contain **no particle or sound asset files**, so there are no hidden source particles/sounds being omitted. Mob-relevant textures, base/charged geometry, render semantics, animation programs and source language values are either actively ported or explicitly accounted for in `SOURCE_PACK_PARITY.md`.

The Cat keeps the corrected Bedrock source loop and receives bounded walk-reactive secondary body/head/breast/tail/ear motion without inventing tail yaw/roll. Cherry/Blossom also gain source channels that earlier versions had missed: the original body-proxy Y=18 placement, complete chest/leaf/hair/hurt channels and the exact 2.5-tick face timing. Female/Bunny/Bee retain the full Pie CEM program restored in 1.4.2, including charged-CEM parity.

Deterministic QA now includes a per-mob GIF **and MP4 for every one of the six mobs**, an animated six-mob grid, a static six-mob/egg approval grid, four-angle all-mob inspection, a dedicated Cat improved-motion contact sheet and a 1.4.2-vs-1.4.3 Cat/Cherry/Blossom comparison. These are rendered from the actual Java model layers and exact textures—no image generation.

## 1.4.2 Pie-family animation fidelity pass

Female, Bunny, and Bee now use a native Forge adaptation of the **full animation program authored in the supplied Pie CEM files**, rather than the earlier blink-plus-small-accessory approximation. This brings their motion up to the same source-driven standard as Cherry/Blossom while keeping the corrected 1.4.1 Cat animation untouched.

- Restores the source CEM's coordinated idle breathing, torso sway, walk bob, body lean, and head counter-motion.
- Replaces vanilla Creeper leg animation with Pie's original CEM proxy-part gait: absolute source pivots, independent step lift, fore/aft stride, stance yaw/roll, head-turn influence, idle weight shift, and hurt recoil.
- Restores source hair inertia and aggression lift, chest secondary motion, and pupil tracking while preserving Pie's exact blink timing expression.
- Bunny regains source tail wag/perk and articulated ear response, including the floppy second right-ear segment.
- Bee regains source antenna/ear response and authored bilateral wing motion; the invented generic 1.4.1 high-frequency flap is removed.
- `tools/audit_pie_animation_fidelity.py` locks exact Pie hashes, source channel sets (Female 53 / Bunny 61 / Bee 64), CEM target hierarchy, exact blink/gaze semantics, and byte-identical Cat + Cherry/Blossom animation methods. `tools/test_pie_animation_formula_parity.py` additionally checks 712 sampled channel values against the supplied JEM expressions.

See [`PIE_CEM_ANIMATION_PORT.md`](PIE_CEM_ANIMATION_PORT.md) for the native-hierarchy adaptation and non-regression contract.

## 1.4.1 Cat Creeper Bedrock-parity correction

The Cat Creeper is now generated and audited directly against the supplied `FemaleCreeper.mcpack` instead of relying on a hand-converted approximation. The 1.4.0 port had a coordinate-sign regression that could rotate the authored tail through the torso and make a blocky piece visibly protrude from the model. 1.4.1 corrects that conversion and adds a permanent regression gate.

- The base and charged Cat geometry are regenerated from the exact supplied Bedrock `.geo.json` files.
- Bedrock bone pivots, parent hierarchy, UV offsets, cube deformation/inflate, zero-thickness face planes, and bone/cube mirror inheritance are preserved.
- Blockbench's Bedrock-import + Java-export transform semantics are followed: Java bind rotations retain the authored Bedrock X/Y/Z signs; Java model-space Y positions are inverted.
- Cat animation keyframes are read from the exact supplied `creeper.animation.json`, including Catmull-Rom body/head sway, breast motion, ear motion, two-stage tail motion, source leg override direction, and the authored blink timing.
- The source pack's powered/charged geometry and armor texture are preserved independently instead of approximating the charge layer from the base mesh.
- `tools/audit_cat_bedrock_port.py` independently checks the source hashes and the generated Java model/animation semantics so the tail-sign bug cannot quietly return.

See [`BEDROCK_TO_JAVA_CAT_PORT.md`](BEDROCK_TO_JAVA_CAT_PORT.md) for the conversion proof and QA contract.

## 1.3.1 3D egg-head rework

The optional 3D spawn eggs are now built as **rounded, convex 3D versions of the exact supplied 16x16 egg sprites** instead of separate little character statues. In other words: the pack-authored head/egg art is the actual surface texture, then that face is given egg-like depth and small mob-specific head details. The exact 2D files remain untouched and are still the immediate fallback when 3D mode is disabled.

The rework deliberately keeps the recognizable pixel art:

- **Female** — exact green Creeperella egg face on a rounded shell, with compact side ponytail/hair lobes instead of a torso.
- **Bunny** — exact green/black/white Bunny egg texture, with the source ears preserved as real 3D silhouette.
- **Bee** — exact gold/burgundy Bee egg face, with compact antennae and wing relief.
- **Cherry** — exact supplied pink Cherry-family egg surface, with a tight high-side ponytail and a small Remake 3.0 green leaf/stem accent.
- **Blossom** — the same exact supplied Cherry-family 2D base required by the source packs, differentiated in 3D by compact sakura puffs/crown treatment and a Blossom-texture green leaf accent.

The old 1.3.0 generic five-material 3D texture tiles are no longer used or shipped. The new egg-head geometry samples the real 2D PNG directly, and its curved depth is generated deterministically from the sprite silhouette. Animation remains client-only and now uses subtle whole-egg sway plus a soft bob/squish phase so the face and accessories stay together.

Client config: `config/creeperella-client.toml`

```toml
[spawnEggs]
use3DSpawnEggs = true
animate3DSpawnEggs = true
spawnEggAnimationSpeed = 1.0
```

Set `use3DSpawnEggs = false` to restore the **exact supplied 2D pack sprites**. Set `animate3DSpawnEggs = false` to keep the rounded 3D egg-heads completely still.

## 1.2.3 pack-accurate spawn eggs

Spawn eggs now use the **actual 16x16 item textures from the supplied packs**, not generic Forge egg tinting: Pie's supplied Female/Bunny/Bee sprites and Cherry Creeper 1.0.2's supplied pink Cherry sprite. Blossom shares the exact provided Cherry-family pink sprite because the supplied packs contain no separate Blossom egg PNG. Cherry/Blossom mobs themselves remain on the Remake 3.0 geometry.


## The family

| Mob | Origin | Personality / role |
|---|---|---|
| `creeperella:female_creeper` | Pie standard model | Regular Female Creeper and main makeover result. |
| `creeperella:bunny_creeper` | Pie `bunny` name-tag model | Standalone Bunny variant with ear/tail animation. |
| `creeperella:bee_creeper` | Pie `bee` name-tag model | Standalone Bee variant with animated wings and nectar particles. |
| `creeperella:cherry_creeper` | Cherry Creeper | Cherry Grove family member using the supplied cherry geometry. |
| `creeperella:boomshroom_creeper` | Cherry-style feminine rig + authorized Creeper Overhaul Mushroom cap | Active Mushroom Fields variant with an independent cream fungal body, cap-tip greeting, spores, and themed explosion FX. |
| `creeperella:blossom_creeper` | Legacy compatibility ID | Existing saves remain loadable; legacy Blossom resolves/render/loot as Cherry and is not an active natural variant. |
| `creeperella:cat_creeper` | Supplied `FemaleCreeper.mcpack` Bedrock cat model | Standalone Cat variant with ears, articulated tail, source animation, blink timing, and exact charged geometry. |

Wild Creeperellas keep the familiar hostile Creeper loop. Once bonded, they switch into the **Demolition Buddy** companion system and can no longer accidentally enter vanilla's one-life fuse path.

## Demolition Buddies — 1.2.0

Each variant has a matching craftable explosive treat. Taming is deterministic: by default **three correct treats** bond the Creeperella; there is no random failure roll.

| Variant | Taming / healing treat |
|---|---|
| Female | **Rosy Fuse Cake** |
| Bunny | **Bunny Boom Bite** |
| Bee | **Honey Pop** |
| Cherry | **Cherry Bomb Bonbon** |
| Boomshroom | **Brown Mushroom** |
| Cat | **Catnip Crunch** |

After bonding:

- Empty-hand right-click toggles **Follow / Stay**.
- Long-distance catch-up recalls her safely near the owner.
- Matching treats heal the owner's companion.
- Owner UUID, state, bond, cooldown, reform state, and active command target persist in NBT.
- Vanilla hostile targeting and vanilla Creeper ignition are suppressed while tamed.

### Fuse Whistle

The craftable **Fuse Whistle** is the command tool.

- Right-click a Creeperella with it to **bind that exact companion**.
- Right-click an enemy/mob with it to order a **Boom Run**.
- Aim at a visible mob and use the whistle in the air to command a long-range Boom Run; the ray respects blocks instead of targeting through walls.
- Use it in the air with no target to **recall** the bound/nearest owned companion.
- **Sneak + use** orders an immediate detonation.

Command targets reject the owner, allied players, creative players, sibling Creeperellas, and the owner's tameable pets.

### Reusable explosions and balance defaults

A commanded blast does **not** kill the companion. She phases out, becomes invulnerable, and reforms beside her owner after a short delay.

- Normal blast power: **2.75**
- Charged blast power: **4.25**
- Normal cooldown: **30 seconds**
- Charged cooldown: **45 seconds**
- Reformation delay: **3 seconds**
- Whistle command range: **48 blocks**
- Boom-run timeout: **30 seconds**
- Explosion block damage: **off by default**
- Owner / allied player / sibling / owner-pet blast protection: **on by default**

All of these are configurable in `config/creeperella-common.toml`.

## Makeovers and transformations

| From | Item | To |
|---|---|---|
| Vanilla Creeper | Pink Tulip | Female Creeper |
| Any Creeperella | Rabbit Foot | Bunny Creeper |
| Any Creeperella | Honey Bottle | Bee Creeper |
| Any Creeperella | Cherry Sapling | Cherry Creeper |
| Vanilla Creeper | Red Mushroom | Boomshroom |
| Any non-Boomshroom Creeperella | Red Mushroom | Boomshroom |
| Any non-Female Creeperella | Pink Tulip | Female Creeper |
| Vanilla Creeper | String | Cat Creeper |
| Any non-Cat Creeperella | String | Cat Creeper |

Transformation preserves Creeper NBT, including custom names, health, powered state, fuse length, explosion radius, motion, ignition/state data, and Creeperella companion state. Honey Bottle conversion returns the Glass Bottle. Pink Petals no longer create a second Blossom mob; on Cherry they trigger the in-place **Bloom & Boom!** celebration, while legacy Blossom IDs remain loadable as Cherry for old worlds.

A freshly transformed wild mob grants the transforming player configurable **Makeover Grace** (default 6 seconds). Pie compatibility is preserved: Name Tags named exactly `bunny` or `bee` convert to those standalone entities.

## Natural spawning

- Female: low weight across normal Overworld biomes, excluding Deep Dark and Mushroom Fields.
- Bunny: Plains, Sunflower Plains, Meadow, Flower Forest.
- Bee: Sunflower Plains, Meadow, Flower Forest, Cherry Grove.
- Cherry: Cherry Grove, weight **18**, group **1-2**.
- Boomshroom: Mushroom Fields, weight **10**, group **1-2**.
- Blossom: no active natural spawning; the registry ID remains only for save compatibility and aliases Cherry.
- Cat: cat-friendly Overworld biomes, with its own independent spawn toggle.

Each family can be disabled independently without removing registry IDs or spawn eggs.

## Integration and technical notes

- Forge **1.20.1 / 47.4.23** target; Java 17 production verification.
- No OptiFine, EMF, or ETF runtime dependency.
- Exact supplied CEM geometry converted to native vanilla `ModelPart` layers.
- Dedicated-server-safe client separation.
- Data-driven Forge biome modifiers and public entity/item tags.
- Six independent entities and spawn eggs; vanilla Creeper remains untouched.
- Distinct charged rendering, including Pie-family charged art.
- Native animation for hair, ears, tail, and wings.
- Transformation and companion advancements, including **Best Friends with Booms**.
- Public datapack tags include `#creeperella:creeper_family`, `#creeperella:female_family`, `#creeperella:cherry_family`, `#creeperella:transformation_items`, and `#creeperella:taming_treats`.

## Research and compatibility targets

See [`RESEARCH_CREEPER_MODS.md`](RESEARCH_CREEPER_MODS.md) for the current Creeper-expansion/companion survey and ideas worth learning from or testing against. Asset-pack research remains in [`RESEARCH_CREEPER_PACKS.md`](RESEARCH_CREEPER_PACKS.md).

Future guest/content additions must not dilute or regress the six polished core variants or their source-derived animation behavior.

## Assets and permissions

See `ASSET_LICENSES.md`. The project records the supplied Pie/Cherry provenance and the user's direct author-confirmed authorization for this use. Source-authored Cherry sidecars are ported as **standalone namespaced content** instead of globally replacing vanilla: Cherry Gunpowder, Cherry TNT, the Cherry Creeper Head, and the Creebet painting are all bundled as dedicated `creeperella:` content. Packaging-only/source-selection files remain reference inputs.

### Cat Creeper (1.4.1)

The Cat Creeper is a new standalone sixth variant based on the supplied `FemaleCreeper.mcpack`. It keeps the source pack's cat ears, tail, face, charged look, idle/walk motion, and visible blinking. It can spawn naturally in cat-friendly overworld biomes, can be created from a vanilla Creeper with **String** (a ball-of-yarn gag), and can be tamed with **Catnip Crunch**. Existing Female, Bunny, Bee, Cherry, and Blossom variants remain intact; their source-derived animation/blink behavior is preserved.


### 1.4.17 Sit 2 grounding
- Sit 2 rear-leg IK reach is extended from 7.00 to 8.72 model units so both hind paws actually meet the same ground plane as the forepaws while preserving the hip pivots and overall pose.
- The full 1.4.16 source ZIP is preserved under `pose-history/1.4.16-before/`.


## 1.4.22 Cherry Grove merge

Cherry Creeper is the single active cherry/pink biome variant and naturally spawns in `minecraft:cherry_grove` at weight 18 (group 1-2). The old Blossom entity/item IDs remain registered only so existing worlds load safely; legacy Blossom entities resolve and render as Cherry. Pink Petals now celebrate Cherry in place and award **Bloom & Boom!** instead of creating a second pink mob.
