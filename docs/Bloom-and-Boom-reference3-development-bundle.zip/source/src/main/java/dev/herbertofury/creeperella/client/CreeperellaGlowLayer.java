package dev.herbertofury.creeperella.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.herbertofury.creeperella.Creeperella;
import dev.herbertofury.creeperella.entity.CreeperellaEntity;
import dev.herbertofury.creeperella.entity.CreeperellaKind;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;

/** Full-bright overlay for remake 3.0's supplied emissive Cherry-family pixels. */
public final class CreeperellaGlowLayer extends RenderLayer<CreeperellaEntity, CreeperellaModel<CreeperellaEntity>> {
    private static final ResourceLocation CHERRY = texture("cherry_creeper_e.png");
    private static final ResourceLocation BLOSSOM = texture("blossom_creeper_e.png");
    private static final ResourceLocation BOOMSHROOM = texture("boomshroom_creeper_e.png");
    private static final ResourceLocation CINDERELLA = texture("cinderella_creeper_e.png");
    private static final ResourceLocation MARIGLOW = texture("mariglow_creeper_e.png");
    private static final ResourceLocation VERDALIA = texture("verdalia_creeper_e.png");
    private static final ResourceLocation NACRELLA = texture("nacrella_creeper_e.png");
    private final CreeperellaKind kind;

    public CreeperellaGlowLayer(RenderLayerParent<CreeperellaEntity, CreeperellaModel<CreeperellaEntity>> parent,
                                CreeperellaKind kind) {
        super(parent);
        this.kind = kind;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, CreeperellaEntity entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (this.kind != CreeperellaKind.CHERRY && this.kind != CreeperellaKind.BLOSSOM
                && this.kind != CreeperellaKind.BOOMSHROOM && this.kind != CreeperellaKind.CINDERELLA
                && this.kind != CreeperellaKind.MARIGLOW && this.kind != CreeperellaKind.VERDALIA
                && this.kind != CreeperellaKind.NACRELLA) {
            return;
        }
        ResourceLocation texture = switch (this.kind) {
            case BOOMSHROOM -> BOOMSHROOM;
            case CINDERELLA -> CINDERELLA;
            case MARIGLOW -> MARIGLOW;
            case VERDALIA -> VERDALIA;
            case NACRELLA -> NACRELLA;
            default -> CHERRY;
        };
        // Blossom is a legacy ID; all cherry-family glow now uses Cherry art.
        VertexConsumer consumer = buffer.getBuffer(RenderType.eyes(texture));
        this.getParentModel().renderToBuffer(
                poseStack,
                consumer,
                LightTexture.FULL_BRIGHT,
                LivingEntityRenderer.getOverlayCoords(entity, 0.0F),
                1.0F, 1.0F, 1.0F, 1.0F
        );
    }

    private static ResourceLocation texture(String name) {
        return new ResourceLocation(Creeperella.MOD_ID, "textures/entity/" + name);
    }
}
