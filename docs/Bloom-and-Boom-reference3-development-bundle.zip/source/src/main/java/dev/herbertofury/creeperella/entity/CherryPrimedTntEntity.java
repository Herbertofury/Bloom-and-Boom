package dev.herbertofury.creeperella.entity;

import dev.herbertofury.creeperella.registry.ModEntities;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/** Primed form of the standalone Cherry TNT. */
public class CherryPrimedTntEntity extends PrimedTnt {
    @Nullable
    private LivingEntity cherryOwner;

    public CherryPrimedTntEntity(EntityType<? extends PrimedTnt> type, Level level) {
        super(type, level);
    }

    public CherryPrimedTntEntity(Level level, double x, double y, double z, @Nullable LivingEntity owner) {
        this(ModEntities.CHERRY_PRIMED_TNT.get(), level);
        this.setPos(x, y, z);
        double angle = level.random.nextDouble() * (Math.PI * 2.0D);
        this.setDeltaMovement(-Mth.sin((float) angle) * 0.02D, 0.2D, -Mth.cos((float) angle) * 0.02D);
        this.setFuse(80);
        this.xo = x;
        this.yo = y;
        this.zo = z;
        this.cherryOwner = owner;
    }

    @Nullable
    @Override
    public LivingEntity getOwner() {
        return this.cherryOwner;
    }
}
