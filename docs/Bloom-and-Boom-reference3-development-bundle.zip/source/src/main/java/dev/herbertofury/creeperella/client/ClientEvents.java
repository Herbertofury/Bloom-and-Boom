package dev.herbertofury.creeperella.client;

import dev.herbertofury.creeperella.Creeperella;
import dev.herbertofury.creeperella.config.CreeperellaClientConfig;
import dev.herbertofury.creeperella.entity.CreeperellaKind;
import dev.herbertofury.creeperella.registry.ModBlockEntities;
import dev.herbertofury.creeperella.registry.ModEntities;
import dev.herbertofury.creeperella.registry.ModItems;
import net.minecraft.Util;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = Creeperella.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientEvents {
    public static final ModelLayerLocation FEMALE = layer("female_creeper");
    public static final ModelLayerLocation BUNNY = layer("bunny_creeper");
    public static final ModelLayerLocation BEE = layer("bee_creeper");
    public static final ModelLayerLocation CHERRY = layer("cherry_creeper");
    public static final ModelLayerLocation BLOSSOM = layer("blossom_creeper");
    public static final ModelLayerLocation BOOMSHROOM = layer("boomshroom_creeper");
    public static final ModelLayerLocation BOOMSHROOM_CAP = layer("boomshroom_cap");
    public static final ModelLayerLocation NACRELLA_ACCESSORIES = layer("nacrella_accessories");
    public static final ModelLayerLocation SHROOMBOOM = layer("shroomboom_creeper");
    public static final ModelLayerLocation SHROOMBOOM_DETAILS = layer("shroomboom_details");
    public static final ModelLayerLocation CAT = layer("cat_creeper");
    public static final ModelLayerLocation FEMALE_CHARGE = layer("female_creeper_charge");
    public static final ModelLayerLocation BUNNY_CHARGE = layer("bunny_creeper_charge");
    public static final ModelLayerLocation BEE_CHARGE = layer("bee_creeper_charge");
    public static final ModelLayerLocation CHERRY_CHARGE = layer("cherry_creeper_charge");
    public static final ModelLayerLocation BLOSSOM_CHARGE = layer("blossom_creeper_charge");
    public static final ModelLayerLocation BOOMSHROOM_CHARGE = layer("boomshroom_creeper_charge");
    public static final ModelLayerLocation SHROOMBOOM_CHARGE = layer("shroomboom_creeper_charge");
    public static final ModelLayerLocation CAT_CHARGE = layer("cat_creeper_charge");
    public static final ModelLayerLocation CHERRY_HEAD = layer("cherry_creeper_head");
    public static final ModelLayerLocation BLOSSOM_HEAD = layer("blossom_creeper_head");

    private static final ResourceLocation SPAWN_EGG_3D = new ResourceLocation(Creeperella.MOD_ID, "spawn_egg_3d");
    private static final ResourceLocation SPAWN_EGG_ANIM = new ResourceLocation(Creeperella.MOD_ID, "spawn_egg_anim");
    private static final long EGG_ANIMATION_CYCLE_MS = 3200L;

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            registerSpawnEggProperties(ModItems.FEMALE_CREEPER_SPAWN_EGG.get(), 0L);
            registerSpawnEggProperties(ModItems.BUNNY_CREEPER_SPAWN_EGG.get(), 430L);
            registerSpawnEggProperties(ModItems.BEE_CREEPER_SPAWN_EGG.get(), 860L);
            registerSpawnEggProperties(ModItems.CHERRY_CREEPER_SPAWN_EGG.get(), 1290L);
            registerSpawnEggProperties(ModItems.BLOSSOM_CREEPER_SPAWN_EGG.get(), 1720L);
            registerSpawnEggProperties(ModItems.BOOMSHROOM_CREEPER_SPAWN_EGG.get(), 2010L);
            registerSpawnEggProperties(ModItems.CINDERELLA_CREEPER_SPAWN_EGG.get(), 2180L);
            registerSpawnEggProperties(ModItems.MARIGLOW_CREEPER_SPAWN_EGG.get(), 2220L);
            registerSpawnEggProperties(ModItems.VERDALIA_CREEPER_SPAWN_EGG.get(), 2240L);
            registerSpawnEggProperties(ModItems.NACRELLA_CREEPER_SPAWN_EGG.get(), 2265L);
            registerSpawnEggProperties(ModItems.SHROOMBOOM_CREEPER_SPAWN_EGG.get(), 2305L);
            registerSpawnEggProperties(ModItems.CAT_CREEPER_SPAWN_EGG.get(), 2350L);
        });
    }

    private static void registerSpawnEggProperties(Item item, long phaseOffsetMs) {
        ItemProperties.register(item, SPAWN_EGG_3D, (stack, level, entity, seed) ->
                CreeperellaClientConfig.USE_3D_SPAWN_EGGS.get() ? 1.0F : 0.0F);

        ItemProperties.register(item, SPAWN_EGG_ANIM, (stack, level, entity, seed) -> {
            if (!CreeperellaClientConfig.USE_3D_SPAWN_EGGS.get()
                    || !CreeperellaClientConfig.ANIMATE_3D_SPAWN_EGGS.get()) {
                return 0.0F;
            }

            double speed = CreeperellaClientConfig.SPAWN_EGG_ANIMATION_SPEED.get();
            long scaledNow = (long) (Util.getMillis() * speed) + phaseOffsetMs;
            long t = Math.floorMod(scaledNow, EGG_ANIMATION_CYCLE_MS);

            // Two-frame whole-egg sway, followed later by a quick soft bob/squish phase. The phases are
            // deliberately offset per variant so a creative-tab row feels alive rather than synchronized.
            if (t >= 2460L && t < 2580L) {
                return 1.0F; // soft bob/squish phase (legacy model state name: blink)
            }
            if (t >= 820L && t < 1140L) {
                return 0.67F; // sway right
            }
            if (t >= 500L && t < 820L) {
                return 0.34F; // sway left
            }
            return 0.0F; // idle
        });
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(FEMALE, CreeperellaModelLayers::createFemaleLayer);
        event.registerLayerDefinition(BUNNY, CreeperellaModelLayers::createBunnyLayer);
        event.registerLayerDefinition(BEE, CreeperellaModelLayers::createBeeLayer);
        event.registerLayerDefinition(CHERRY, CherryRemakeModelLayers::createCherryLayer);
        event.registerLayerDefinition(BLOSSOM, BlossomRemakeModelLayers::createBlossomLayer);
        event.registerLayerDefinition(BOOMSHROOM, CherryRemakeModelLayers::createCherryLayer);
        event.registerLayerDefinition(BOOMSHROOM_CAP, BoomshroomCapLayer::createLayer);
        event.registerLayerDefinition(NACRELLA_ACCESSORIES, NacrellaAccessoryLayer::createLayer);
        event.registerLayerDefinition(SHROOMBOOM, CreeperellaModelLayers::createFemaleLayer);
        event.registerLayerDefinition(SHROOMBOOM_DETAILS, ShroomboomDetailModelLayers::createLayer);
        event.registerLayerDefinition(FEMALE_CHARGE, CreeperellaModelLayers::createFemaleChargeLayer);
        event.registerLayerDefinition(BUNNY_CHARGE, CreeperellaModelLayers::createBunnyChargeLayer);
        event.registerLayerDefinition(BEE_CHARGE, CreeperellaModelLayers::createBeeChargeLayer);
        event.registerLayerDefinition(CHERRY_CHARGE, CherryRemakeModelLayers::createCherryChargeLayer);
        event.registerLayerDefinition(BLOSSOM_CHARGE, BlossomRemakeModelLayers::createBlossomChargeLayer);
        event.registerLayerDefinition(BOOMSHROOM_CHARGE, CherryRemakeModelLayers::createCherryChargeLayer);
        event.registerLayerDefinition(SHROOMBOOM_CHARGE, CreeperellaModelLayers::createFemaleChargeLayer);
        event.registerLayerDefinition(CAT, CatCreeperModelLayers::createCatLayer);
        event.registerLayerDefinition(CAT_CHARGE, CatCreeperModelLayers::createCatChargeLayer);
        event.registerLayerDefinition(CHERRY_HEAD, CherryRemakeModelLayers::createCherryHeadLayer);
        event.registerLayerDefinition(BLOSSOM_HEAD, BlossomRemakeModelLayers::createBlossomHeadLayer);
    }

    @SubscribeEvent
    public static void registerParticleProviders(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(dev.herbertofury.creeperella.registry.ModParticles.BOOMSHROOM_SPORE.get(),
                BoomshroomSporeParticle.Provider::new);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.FEMALE_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.FEMALE));
        event.registerEntityRenderer(ModEntities.BUNNY_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.BUNNY));
        event.registerEntityRenderer(ModEntities.BEE_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.BEE));
        event.registerEntityRenderer(ModEntities.CHERRY_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.CHERRY));
        event.registerEntityRenderer(ModEntities.BLOSSOM_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.CHERRY));
        event.registerEntityRenderer(ModEntities.BOOMSHROOM_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.BOOMSHROOM));
        event.registerEntityRenderer(ModEntities.CINDERELLA_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.CINDERELLA));
        event.registerEntityRenderer(ModEntities.MARIGLOW_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.MARIGLOW));
        event.registerEntityRenderer(ModEntities.VERDALIA_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.VERDALIA));
        event.registerEntityRenderer(ModEntities.NACRELLA_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.NACRELLA));
        event.registerEntityRenderer(ModEntities.SHROOMBOOM_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.SHROOMBOOM));
        event.registerEntityRenderer(ModEntities.CAT_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.CAT));
        event.registerEntityRenderer(ModEntities.CHERRY_PRIMED_TNT.get(), CherryPrimedTntRenderer::new);
        event.registerEntityRenderer(ModEntities.BLOSSOM_PRIMED_TNT.get(), BlossomPrimedTntRenderer::new);
        event.registerBlockEntityRenderer(ModBlockEntities.CHERRY_CREEPER_HEAD.get(), CherryCreeperHeadRenderer::new);
        event.registerBlockEntityRenderer(ModBlockEntities.BLOSSOM_CREEPER_HEAD.get(), BlossomCreeperHeadRenderer::new);
    }

    public static ModelLayerLocation baseLayer(CreeperellaKind kind) {
        return switch (kind) {
            case FEMALE -> FEMALE;
            case BUNNY -> BUNNY;
            case BEE -> BEE;
            case CHERRY -> CHERRY;
            case BLOSSOM -> CHERRY;
            case BOOMSHROOM -> BOOMSHROOM;
            case CINDERELLA, MARIGLOW, VERDALIA, NACRELLA -> FEMALE;
            case SHROOMBOOM -> SHROOMBOOM;
            case CAT -> CAT;
        };
    }

    public static ModelLayerLocation chargeLayer(CreeperellaKind kind) {
        return switch (kind) {
            case FEMALE -> FEMALE_CHARGE;
            case BUNNY -> BUNNY_CHARGE;
            case BEE -> BEE_CHARGE;
            case CHERRY -> CHERRY_CHARGE;
            case BLOSSOM -> CHERRY_CHARGE;
            case BOOMSHROOM -> BOOMSHROOM_CHARGE;
            case CINDERELLA, MARIGLOW, VERDALIA, NACRELLA -> FEMALE_CHARGE;
            case SHROOMBOOM -> SHROOMBOOM_CHARGE;
            case CAT -> CAT_CHARGE;
        };
    }

    private static ModelLayerLocation layer(String path) {
        return new ModelLayerLocation(new ResourceLocation(Creeperella.MOD_ID, path), "main");
    }

    private ClientEvents() {}
}
