package dev.herbertofury.creeperella;

import dev.herbertofury.creeperella.config.CreeperellaClientConfig;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import dev.herbertofury.creeperella.config.CreeperellaConfig;
import dev.herbertofury.creeperella.registry.ModBlockEntities;
import dev.herbertofury.creeperella.registry.ModBlocks;
import dev.herbertofury.creeperella.registry.ModEntities;
import dev.herbertofury.creeperella.registry.ModItems;
import dev.herbertofury.creeperella.registry.ModPaintings;
import dev.herbertofury.creeperella.registry.ModParticles;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(Creeperella.MOD_ID)
public final class Creeperella {
    public static final String MOD_ID = "creeperella";
    public static final Logger LOGGER = LogUtils.getLogger();

    public Creeperella() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.register(modBus);
        ModEntities.register(modBus);
        ModBlockEntities.register(modBus);
        ModPaintings.register(modBus);
        ModParticles.register(modBus);
        ModItems.register(modBus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, CreeperellaConfig.SPEC, "creeperella-common.toml");
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, CreeperellaClientConfig.SPEC, "creeperella-client.toml");
        modBus.addListener(this::populateCreativeTabs);
        MinecraftForge.EVENT_BUS.addListener(this::registerCommands);
    }

    private void registerCommands(RegisterCommandsEvent event) {
        CreeperellaQaCommands.register(event.getDispatcher());
    }

    private void populateCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModItems.FEMALE_CREEPER_SPAWN_EGG.get());
            event.accept(ModItems.BUNNY_CREEPER_SPAWN_EGG.get());
            event.accept(ModItems.BEE_CREEPER_SPAWN_EGG.get());
            event.accept(ModItems.CHERRY_CREEPER_SPAWN_EGG.get());
            event.accept(ModItems.BOOMSHROOM_CREEPER_SPAWN_EGG.get());
            event.accept(ModItems.CINDERELLA_CREEPER_SPAWN_EGG.get());
            event.accept(ModItems.MARIGLOW_CREEPER_SPAWN_EGG.get());
            event.accept(ModItems.VERDALIA_CREEPER_SPAWN_EGG.get());
            event.accept(ModItems.NACRELLA_CREEPER_SPAWN_EGG.get());
            event.accept(ModItems.SHROOMBOOM_CREEPER_SPAWN_EGG.get());
            event.accept(ModItems.CAT_CREEPER_SPAWN_EGG.get());
        }
        if (event.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
            event.accept(ModItems.ROSY_FUSE_CAKE.get());
            event.accept(ModItems.BUNNY_BOOM_BITE.get());
            event.accept(ModItems.HONEY_POP.get());
            event.accept(ModItems.CHERRY_BOMB_BONBON.get());
            event.accept(ModItems.CATNIP_CRUNCH.get());
        }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(ModItems.CHERRY_GUNPOWDER.get());
        }
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(ModItems.CHERRY_TNT.get());
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ModItems.CHERRY_CREEPER_HEAD.get());
            event.accept(ModItems.CHERRY_CREEBET_PAINTING.get());
        }
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.FUSE_WHISTLE.get());
        }
    }
}
