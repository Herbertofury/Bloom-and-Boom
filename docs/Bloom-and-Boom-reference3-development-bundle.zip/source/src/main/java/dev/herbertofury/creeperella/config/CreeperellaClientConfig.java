package dev.herbertofury.creeperella.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** Client-only visual preferences. These never alter spawning or gameplay. */
public final class CreeperellaClientConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue USE_3D_SPAWN_EGGS;
    public static final ForgeConfigSpec.BooleanValue ANIMATE_3D_SPAWN_EGGS;
    public static final ForgeConfigSpec.DoubleValue SPAWN_EGG_ANIMATION_SPEED;
    public static final ForgeConfigSpec.BooleanValue VANILLA_FRIENDLY_BODY_STYLE;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.push("spawnEggs");
        USE_3D_SPAWN_EGGS = builder
                .comment(
                        "Render Creeperella spawn eggs as rounded 3D egg-head versions of the exact pack sprites.",
                        "Turn this off to use the exact original Pie/Cherry pack sprites from Creeperella 1.2.3."
                )
                .define("use3DSpawnEggs", true);
        ANIMATE_3D_SPAWN_EGGS = builder
                .comment("Animate the 3D egg-heads with subtle whole-item sway and a soft bob/squish phase.")
                .define("animate3DSpawnEggs", true);
        SPAWN_EGG_ANIMATION_SPEED = builder
                .comment("Visual-only animation speed multiplier for the 3D spawn eggs.")
                .defineInRange("spawnEggAnimationSpeed", 1.0D, 0.25D, 4.0D);
        builder.pop();

        builder.push("presentation");
        VANILLA_FRIENDLY_BODY_STYLE = builder
                .comment("Hide the feminine chest geometry for a more vanilla/SFW Creeper silhouette. Visual-only: hitbox, AI, networking, damage and companion behavior are unchanged. Default false preserves Creeperella presentation.")
                .define("vanillaFriendlyBodyStyle", false);
        builder.pop();

        SPEC = builder.build();
    }

    private CreeperellaClientConfig() {}
}
