package dev.herbertofury.creeperella.registry;

import dev.herbertofury.creeperella.Creeperella;
import dev.herbertofury.creeperella.entity.CherryPrimedTntEntity;
import dev.herbertofury.creeperella.entity.BlossomPrimedTntEntity;
import dev.herbertofury.creeperella.entity.CreeperellaEntity;
import dev.herbertofury.creeperella.entity.CreeperellaKind;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Creeperella.MOD_ID);

    public static final RegistryObject<EntityType<CreeperellaEntity>> FEMALE_CREEPER = register("female_creeper");
    public static final RegistryObject<EntityType<CreeperellaEntity>> BUNNY_CREEPER = register("bunny_creeper");
    public static final RegistryObject<EntityType<CreeperellaEntity>> BEE_CREEPER = register("bee_creeper");
    public static final RegistryObject<EntityType<CreeperellaEntity>> CHERRY_CREEPER = register("cherry_creeper");
    public static final RegistryObject<EntityType<CreeperellaEntity>> BLOSSOM_CREEPER = register("blossom_creeper");
    public static final RegistryObject<EntityType<CreeperellaEntity>> BOOMSHROOM_CREEPER = register("boomshroom_creeper");
    public static final RegistryObject<EntityType<CreeperellaEntity>> CINDERELLA_CREEPER = register("cinderella_creeper");
    public static final RegistryObject<EntityType<CreeperellaEntity>> MARIGLOW_CREEPER = register("mariglow_creeper");
    public static final RegistryObject<EntityType<CreeperellaEntity>> VERDALIA_CREEPER = register("verdalia_creeper");
    public static final RegistryObject<EntityType<CreeperellaEntity>> NACRELLA_CREEPER = register("nacrella_creeper");
    public static final RegistryObject<EntityType<CreeperellaEntity>> SHROOMBOOM_CREEPER = register("shroomboom_creeper");
    public static final RegistryObject<EntityType<CreeperellaEntity>> CAT_CREEPER = register("cat_creeper");

    public static final RegistryObject<EntityType<CherryPrimedTntEntity>> CHERRY_PRIMED_TNT = ENTITIES.register("cherry_primed_tnt",
            () -> EntityType.Builder.<CherryPrimedTntEntity>of(CherryPrimedTntEntity::new, MobCategory.MISC)
                    .sized(0.98F, 0.98F)
                    .clientTrackingRange(10)
                    .updateInterval(10)
                    .build(Creeperella.MOD_ID + ":cherry_primed_tnt"));

    public static final RegistryObject<EntityType<BlossomPrimedTntEntity>> BLOSSOM_PRIMED_TNT = ENTITIES.register("blossom_primed_tnt",
            () -> EntityType.Builder.<BlossomPrimedTntEntity>of(BlossomPrimedTntEntity::new, MobCategory.MISC)
                    .sized(0.98F, 0.98F)
                    .clientTrackingRange(10)
                    .updateInterval(10)
                    .build(Creeperella.MOD_ID + ":blossom_primed_tnt"));

    private static RegistryObject<EntityType<CreeperellaEntity>> register(String id) {
        return ENTITIES.register(id, () -> EntityType.Builder
                .of(CreeperellaEntity::new, MobCategory.MONSTER)
                .sized(0.6F, 1.7F)
                .clientTrackingRange(8)
                .build(Creeperella.MOD_ID + ":" + id));
    }

    public static CreeperellaKind kindOf(EntityType<?> type) {
        if (type == BUNNY_CREEPER.get()) return CreeperellaKind.BUNNY;
        if (type == BEE_CREEPER.get()) return CreeperellaKind.BEE;
        if (type == CHERRY_CREEPER.get()) return CreeperellaKind.CHERRY;
        if (type == BLOSSOM_CREEPER.get()) return CreeperellaKind.CHERRY; // legacy 1.4.21 ID -> merged Cherry behavior
        if (type == BOOMSHROOM_CREEPER.get()) return CreeperellaKind.BOOMSHROOM;
        if (type == CINDERELLA_CREEPER.get()) return CreeperellaKind.CINDERELLA;
        if (type == MARIGLOW_CREEPER.get()) return CreeperellaKind.MARIGLOW;
        if (type == VERDALIA_CREEPER.get()) return CreeperellaKind.VERDALIA;
        if (type == NACRELLA_CREEPER.get()) return CreeperellaKind.NACRELLA;
        if (type == SHROOMBOOM_CREEPER.get()) return CreeperellaKind.SHROOMBOOM;
        if (type == CAT_CREEPER.get()) return CreeperellaKind.CAT;
        return CreeperellaKind.FEMALE;
    }

    public static EntityType<CreeperellaEntity> typeFor(CreeperellaKind kind) {
        return switch (kind) {
            case BUNNY -> BUNNY_CREEPER.get();
            case BEE -> BEE_CREEPER.get();
            case CHERRY -> CHERRY_CREEPER.get();
            case BLOSSOM -> CHERRY_CREEPER.get(); // legacy enum path intentionally aliases to Cherry
            case BOOMSHROOM -> BOOMSHROOM_CREEPER.get();
            case CINDERELLA -> CINDERELLA_CREEPER.get();
            case MARIGLOW -> MARIGLOW_CREEPER.get();
            case VERDALIA -> VERDALIA_CREEPER.get();
            case NACRELLA -> NACRELLA_CREEPER.get();
            case SHROOMBOOM -> SHROOMBOOM_CREEPER.get();
            case CAT -> CAT_CREEPER.get();
            case FEMALE -> FEMALE_CREEPER.get();
        };
    }

    public static void register(IEventBus bus) {
        ENTITIES.register(bus);
    }

    private ModEntities() {}
}
