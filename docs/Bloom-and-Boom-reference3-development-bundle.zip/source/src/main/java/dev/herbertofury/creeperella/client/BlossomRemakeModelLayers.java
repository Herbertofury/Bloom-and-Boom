package dev.herbertofury.creeperella.client;

import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Blossom Creeper layer: Cherry Remake source geometry plus namespaced sakura silhouette accents.
 * Base Cherry geometry stays source-faithful and untouched; only Blossom receives these additions.
 */
public final class BlossomRemakeModelLayers {
    private BlossomRemakeModelLayers() {}

    public static LayerDefinition createBlossomLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition vanilla_head = root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 6.0F, 0.0F));
        PartDefinition vanilla_body = root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(0.0F, 6.0F, 0.0F));
        PartDefinition vanilla_right_hind_leg = root.addOrReplaceChild("right_hind_leg", CubeListBuilder.create(), PartPose.offset(-2.0F, 18.0F, 4.0F));
        PartDefinition vanilla_left_hind_leg = root.addOrReplaceChild("left_hind_leg", CubeListBuilder.create(), PartPose.offset(2.0F, 18.0F, 4.0F));
        PartDefinition vanilla_right_front_leg = root.addOrReplaceChild("right_front_leg", CubeListBuilder.create(), PartPose.offset(-2.0F, 18.0F, -4.0F));
        PartDefinition vanilla_left_front_leg = root.addOrReplaceChild("left_front_leg", CubeListBuilder.create(), PartPose.offset(2.0F, 18.0F, -4.0F));

        PartDefinition custom_head = vanilla_head.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition custom_body = vanilla_body.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition custom_body_body_cherry_rotation_0 = custom_body.addOrReplaceChild("body_cherry_rotation", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0Cubes = CubeListBuilder.create()
                .texOffs(16, 16).addBox(-4.0F, -12.0F, -2.0F, 8.0F, 12.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0 = custom_body_body_cherry_rotation_0.addOrReplaceChild("body_cherry", custom_body_body_cherry_rotation_0_body_cherry_0Cubes, PartPose.offsetAndRotation(0.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0Cubes = CubeListBuilder.create()
                .texOffs(39, 0).addBox(-3.5F, -1.62326F, -3.90883F, 7.0F, 3.0F, 5.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("boobs", custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0Cubes, PartPose.offsetAndRotation(0.0F, -9.37765F, -1.06585F, 0.872665F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0_bone3_0Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.50494F, -3.51398F, -2.80142F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0_bone3_0 = custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0.addOrReplaceChild("bone3", custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0_bone3_0Cubes, PartPose.offsetAndRotation(3.40016F, -1.7429F, -2.25083F, -0.663276F, -0.963134F, 0.552018F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_bone9_1Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.15497F, -3.70997F, -2.78623F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_bone9_1 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("bone9", custom_body_body_cherry_rotation_0_body_cherry_0_bone9_1Cubes, PartPose.offsetAndRotation(-3.73132F, -9.83162F, 2.15852F, -2.402003F, 1.349861F, -2.885305F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_bone15_2Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.01362F, -3.16173F, -1.76597F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_bone15_2 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("bone15", custom_body_body_cherry_rotation_0_body_cherry_0_bone15_2Cubes, PartPose.offsetAndRotation(-4.0F, -5.2F, 1.9F, 0.914943F, -1.523732F, 2.671598F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3Cubes = CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("head_cherry", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3Cubes, PartPose.offsetAndRotation(0.0F, -12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0Cubes = CubeListBuilder.create()
                .texOffs(44, 49).addBox(-6.0F, -7.6F, -2.0F, 6.0F, 11.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("bone11", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0Cubes, PartPose.offsetAndRotation(-2.0F, -4.0F, 3.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0_bone12_0Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.20169F, -3.41787F, -3.15447F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0_bone12_0 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0.addOrReplaceChild("bone12", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0_bone12_0Cubes, PartPose.offsetAndRotation(-5.7F, -7.2F, 1.1F, 3.008518F, 1.349861F, -2.885305F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1Cubes = CubeListBuilder.create()
                .texOffs(44, 49).addBox(0.0F, -6.6F, -2.0F, 6.0F, 11.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("bone13", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1Cubes, PartPose.offsetAndRotation(2.0F, -4.0F, 3.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1_bone14_0Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(-0.11421F, -3.19212F, -3.19168F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1_bone14_0 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1.addOrReplaceChild("bone14", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1_bone14_0Cubes, PartPose.offsetAndRotation(5.6F, -3.4F, 1.0F, 3.008518F, -1.349861F, 2.885305F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone10_2Cubes = CubeListBuilder.create()
                .texOffs(9, 39).addBox(-0.3F, -1.0F, -6.0F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone10_2 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("bone10", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone10_2Cubes, PartPose.offsetAndRotation(0.0F, -4.0F, -3.4F, 2.44105F, -1.264799F, 2.843435F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("head_cherry_face", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr1_0Cubes = CubeListBuilder.create()
                .texOffs(26, 37).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 0.01F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr1_0 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3.addOrReplaceChild("head_cherry_face_fr1", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr1_0Cubes, PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr2_1Cubes = CubeListBuilder.create()
                .texOffs(26, 45).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 0.01F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr2_1 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3.addOrReplaceChild("head_cherry_face_fr2", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr2_1Cubes, PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr3_2Cubes = CubeListBuilder.create()
                .texOffs(26, 53).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 0.01F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr3_2 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3.addOrReplaceChild("head_cherry_face_fr3", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr3_2Cubes, PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_center_4Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(-2.1F, -2.1F, 0.0F, 4.2F, 4.2F, 0.01F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_center_4 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("blossom_crown_center", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_center_4Cubes, PartPose.offsetAndRotation(0.0F, -8.2F, -0.35F, 0.0F, 0.0F, 0.785398F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_left_5Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.0F, -2.0F, -2.0F, 0.01F, 4.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_left_5 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("blossom_crown_left", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_left_5Cubes, PartPose.offsetAndRotation(-4.15F, -6.9F, 0.7F, -0.20944F, 0.593412F, 0.488692F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_right_6Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.0F, -2.0F, -2.0F, 0.01F, 4.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_right_6 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("blossom_crown_right", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_right_6Cubes, PartPose.offsetAndRotation(4.15F, -6.8F, 0.7F, -0.20944F, -0.593412F, -0.488692F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_back_bloom_7Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(-2.2F, -2.2F, 0.0F, 4.4F, 4.4F, 0.01F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_back_bloom_7 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("blossom_back_bloom", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_back_bloom_7Cubes, PartPose.offsetAndRotation(0.0F, -5.1F, 4.05F, 0.349066F, 0.0F, 0.349066F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_blossom_shoulder_left_4Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.0F, -2.05F, -2.05F, 0.01F, 4.1F, 4.1F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_blossom_shoulder_left_4 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("blossom_shoulder_left", custom_body_body_cherry_rotation_0_body_cherry_0_blossom_shoulder_left_4Cubes, PartPose.offsetAndRotation(-4.15F, -9.4F, -0.8F, -0.314159F, 0.733038F, 0.488692F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_blossom_shoulder_right_5Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.0F, -2.05F, -2.05F, 0.01F, 4.1F, 4.1F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_blossom_shoulder_right_5 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("blossom_shoulder_right", custom_body_body_cherry_rotation_0_body_cherry_0_blossom_shoulder_right_5Cubes, PartPose.offsetAndRotation(4.15F, -9.4F, -0.8F, -0.314159F, -0.733038F, -0.488692F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_blossom_hip_bloom_6Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(-2.15F, -2.15F, 0.0F, 4.3F, 4.3F, 0.01F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_blossom_hip_bloom_6 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("blossom_hip_bloom", custom_body_body_cherry_rotation_0_body_cherry_0_blossom_hip_bloom_6Cubes, PartPose.offsetAndRotation(0.0F, -2.35F, 2.15F, -0.139626F, 0.0F, 0.785398F));
        PartDefinition custom_body_body_cherry_rotation_0_cherrycreeper_legs_1 = custom_body_body_cherry_rotation_0.addOrReplaceChild("cherrycreeper_legs", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg1_0Cubes = CubeListBuilder.create()
                .texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg1_0 = custom_body_body_cherry_rotation_0_cherrycreeper_legs_1.addOrReplaceChild("cherrycreeper_leg1", custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg1_0Cubes, PartPose.offsetAndRotation(-2.0F, -6.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg2_1Cubes = CubeListBuilder.create()
                .texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg2_1 = custom_body_body_cherry_rotation_0_cherrycreeper_legs_1.addOrReplaceChild("cherrycreeper_leg2", custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg2_1Cubes, PartPose.offsetAndRotation(2.0F, -6.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg3_2Cubes = CubeListBuilder.create()
                .texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg3_2 = custom_body_body_cherry_rotation_0_cherrycreeper_legs_1.addOrReplaceChild("cherrycreeper_leg3", custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg3_2Cubes, PartPose.offsetAndRotation(-2.0F, -6.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg4_3Cubes = CubeListBuilder.create()
                .texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg4_3 = custom_body_body_cherry_rotation_0_cherrycreeper_legs_1.addOrReplaceChild("cherrycreeper_leg4", custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg4_3Cubes, PartPose.offsetAndRotation(2.0F, -6.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition custom_leg1 = vanilla_right_hind_leg.addOrReplaceChild("leg1", CubeListBuilder.create(), PartPose.offsetAndRotation(2.0F, 6.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition custom_leg2 = vanilla_left_hind_leg.addOrReplaceChild("leg2", CubeListBuilder.create(), PartPose.offsetAndRotation(-2.0F, 6.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition custom_leg3 = vanilla_right_front_leg.addOrReplaceChild("leg3", CubeListBuilder.create(), PartPose.offsetAndRotation(2.0F, 6.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition custom_leg4 = vanilla_left_front_leg.addOrReplaceChild("leg4", CubeListBuilder.create(), PartPose.offsetAndRotation(-2.0F, 6.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    public static LayerDefinition createBlossomChargeLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition vanilla_head = root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 6.0F, 0.0F));
        PartDefinition vanilla_body = root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(0.0F, 6.0F, 0.0F));
        PartDefinition vanilla_right_hind_leg = root.addOrReplaceChild("right_hind_leg", CubeListBuilder.create(), PartPose.offset(-2.0F, 18.0F, 4.0F));
        PartDefinition vanilla_left_hind_leg = root.addOrReplaceChild("left_hind_leg", CubeListBuilder.create(), PartPose.offset(2.0F, 18.0F, 4.0F));
        PartDefinition vanilla_right_front_leg = root.addOrReplaceChild("right_front_leg", CubeListBuilder.create(), PartPose.offset(-2.0F, 18.0F, -4.0F));
        PartDefinition vanilla_left_front_leg = root.addOrReplaceChild("left_front_leg", CubeListBuilder.create(), PartPose.offset(2.0F, 18.0F, -4.0F));

        PartDefinition custom_head = vanilla_head.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition custom_body = vanilla_body.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition custom_body_body_cherry_rotation_0 = custom_body.addOrReplaceChild("body_cherry_rotation", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0Cubes = CubeListBuilder.create()
                .texOffs(16, 16).addBox(-4.0F, -12.0F, -2.0F, 8.0F, 12.0F, 4.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0 = custom_body_body_cherry_rotation_0.addOrReplaceChild("body_cherry", custom_body_body_cherry_rotation_0_body_cherry_0Cubes, PartPose.offsetAndRotation(0.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0Cubes = CubeListBuilder.create()
                .texOffs(39, 0).addBox(-3.5F, -1.62326F, -3.90883F, 7.0F, 3.0F, 5.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("boobs", custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0Cubes, PartPose.offsetAndRotation(0.0F, -9.37765F, -1.06585F, 0.872665F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0_bone3_0Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.50494F, -3.51398F, -2.80142F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0_bone3_0 = custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0.addOrReplaceChild("bone3", custom_body_body_cherry_rotation_0_body_cherry_0_boobs_0_bone3_0Cubes, PartPose.offsetAndRotation(3.40016F, -1.7429F, -2.25083F, -0.663276F, -0.963134F, 0.552018F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_bone9_1Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.15497F, -3.70997F, -2.78623F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_bone9_1 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("bone9", custom_body_body_cherry_rotation_0_body_cherry_0_bone9_1Cubes, PartPose.offsetAndRotation(-3.73132F, -9.83162F, 2.15852F, -2.402003F, 1.349861F, -2.885305F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_bone15_2Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.01362F, -3.16173F, -1.76597F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_bone15_2 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("bone15", custom_body_body_cherry_rotation_0_body_cherry_0_bone15_2Cubes, PartPose.offsetAndRotation(-4.0F, -5.2F, 1.9F, 0.914943F, -1.523732F, 2.671598F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3Cubes = CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("head_cherry", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3Cubes, PartPose.offsetAndRotation(0.0F, -12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0Cubes = CubeListBuilder.create()
                .texOffs(44, 49).addBox(-6.0F, -7.6F, -2.0F, 6.0F, 11.0F, 4.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("bone11", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0Cubes, PartPose.offsetAndRotation(-2.0F, -4.0F, 3.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0_bone12_0Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.20169F, -3.41787F, -3.15447F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0_bone12_0 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0.addOrReplaceChild("bone12", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone11_0_bone12_0Cubes, PartPose.offsetAndRotation(-5.7F, -7.2F, 1.1F, 3.008518F, 1.349861F, -2.885305F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1Cubes = CubeListBuilder.create()
                .texOffs(44, 49).addBox(0.0F, -6.6F, -2.0F, 6.0F, 11.0F, 4.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("bone13", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1Cubes, PartPose.offsetAndRotation(2.0F, -4.0F, 3.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1_bone14_0Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(-0.11421F, -3.19212F, -3.19168F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1_bone14_0 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1.addOrReplaceChild("bone14", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone13_1_bone14_0Cubes, PartPose.offsetAndRotation(5.6F, -3.4F, 1.0F, 3.008518F, -1.349861F, 2.885305F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone10_2Cubes = CubeListBuilder.create()
                .texOffs(9, 39).addBox(-0.3F, -1.0F, -6.0F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone10_2 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("bone10", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_bone10_2Cubes, PartPose.offsetAndRotation(0.0F, -4.0F, -3.4F, 2.44105F, -1.264799F, 2.843435F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("head_cherry_face", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr1_0Cubes = CubeListBuilder.create()
                .texOffs(26, 37).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 0.01F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr1_0 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3.addOrReplaceChild("head_cherry_face_fr1", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr1_0Cubes, PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr2_1Cubes = CubeListBuilder.create()
                .texOffs(26, 45).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 0.01F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr2_1 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3.addOrReplaceChild("head_cherry_face_fr2", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr2_1Cubes, PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr3_2Cubes = CubeListBuilder.create()
                .texOffs(26, 53).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 0.01F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr3_2 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3.addOrReplaceChild("head_cherry_face_fr3", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_head_cherry_face_3_head_cherry_face_fr3_2Cubes, PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_center_4Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(-2.1F, -2.1F, 0.0F, 4.2F, 4.2F, 0.01F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_center_4 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("blossom_crown_center", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_center_4Cubes, PartPose.offsetAndRotation(0.0F, -8.2F, -0.35F, 0.0F, 0.0F, 0.785398F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_left_5Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.0F, -2.0F, -2.0F, 0.01F, 4.0F, 4.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_left_5 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("blossom_crown_left", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_left_5Cubes, PartPose.offsetAndRotation(-4.15F, -6.9F, 0.7F, -0.20944F, 0.593412F, 0.488692F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_right_6Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.0F, -2.0F, -2.0F, 0.01F, 4.0F, 4.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_right_6 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("blossom_crown_right", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_crown_right_6Cubes, PartPose.offsetAndRotation(4.15F, -6.8F, 0.7F, -0.20944F, -0.593412F, -0.488692F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_back_bloom_7Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(-2.2F, -2.2F, 0.0F, 4.4F, 4.4F, 0.01F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_back_bloom_7 = custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3.addOrReplaceChild("blossom_back_bloom", custom_body_body_cherry_rotation_0_body_cherry_0_head_cherry_3_blossom_back_bloom_7Cubes, PartPose.offsetAndRotation(0.0F, -5.1F, 4.05F, 0.349066F, 0.0F, 0.349066F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_blossom_shoulder_left_4Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.0F, -2.05F, -2.05F, 0.01F, 4.1F, 4.1F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_blossom_shoulder_left_4 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("blossom_shoulder_left", custom_body_body_cherry_rotation_0_body_cherry_0_blossom_shoulder_left_4Cubes, PartPose.offsetAndRotation(-4.15F, -9.4F, -0.8F, -0.314159F, 0.733038F, 0.488692F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_blossom_shoulder_right_5Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.0F, -2.05F, -2.05F, 0.01F, 4.1F, 4.1F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_blossom_shoulder_right_5 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("blossom_shoulder_right", custom_body_body_cherry_rotation_0_body_cherry_0_blossom_shoulder_right_5Cubes, PartPose.offsetAndRotation(4.15F, -9.4F, -0.8F, -0.314159F, -0.733038F, -0.488692F));
        CubeListBuilder custom_body_body_cherry_rotation_0_body_cherry_0_blossom_hip_bloom_6Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(-2.15F, -2.15F, 0.0F, 4.3F, 4.3F, 0.01F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_body_cherry_0_blossom_hip_bloom_6 = custom_body_body_cherry_rotation_0_body_cherry_0.addOrReplaceChild("blossom_hip_bloom", custom_body_body_cherry_rotation_0_body_cherry_0_blossom_hip_bloom_6Cubes, PartPose.offsetAndRotation(0.0F, -2.35F, 2.15F, -0.139626F, 0.0F, 0.785398F));
        PartDefinition custom_body_body_cherry_rotation_0_cherrycreeper_legs_1 = custom_body_body_cherry_rotation_0.addOrReplaceChild("cherrycreeper_legs", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg1_0Cubes = CubeListBuilder.create()
                .texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg1_0 = custom_body_body_cherry_rotation_0_cherrycreeper_legs_1.addOrReplaceChild("cherrycreeper_leg1", custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg1_0Cubes, PartPose.offsetAndRotation(-2.0F, -6.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg2_1Cubes = CubeListBuilder.create()
                .texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg2_1 = custom_body_body_cherry_rotation_0_cherrycreeper_legs_1.addOrReplaceChild("cherrycreeper_leg2", custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg2_1Cubes, PartPose.offsetAndRotation(2.0F, -6.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg3_2Cubes = CubeListBuilder.create()
                .texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg3_2 = custom_body_body_cherry_rotation_0_cherrycreeper_legs_1.addOrReplaceChild("cherrycreeper_leg3", custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg3_2Cubes, PartPose.offsetAndRotation(-2.0F, -6.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg4_3Cubes = CubeListBuilder.create()
                .texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new CubeDeformation(0.5F));
        PartDefinition custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg4_3 = custom_body_body_cherry_rotation_0_cherrycreeper_legs_1.addOrReplaceChild("cherrycreeper_leg4", custom_body_body_cherry_rotation_0_cherrycreeper_legs_1_cherrycreeper_leg4_3Cubes, PartPose.offsetAndRotation(2.0F, -6.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition custom_leg1 = vanilla_right_hind_leg.addOrReplaceChild("leg1", CubeListBuilder.create(), PartPose.offsetAndRotation(2.0F, 6.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition custom_leg2 = vanilla_left_hind_leg.addOrReplaceChild("leg2", CubeListBuilder.create(), PartPose.offsetAndRotation(-2.0F, 6.0F, -4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition custom_leg3 = vanilla_right_front_leg.addOrReplaceChild("leg3", CubeListBuilder.create(), PartPose.offsetAndRotation(2.0F, 6.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition custom_leg4 = vanilla_left_front_leg.addOrReplaceChild("leg4", CubeListBuilder.create(), PartPose.offsetAndRotation(-2.0F, 6.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    public static LayerDefinition createBlossomHeadLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        CubeListBuilder blossom_headCubes = CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.0F));
        PartDefinition blossom_head = root.addOrReplaceChild("head", blossom_headCubes, PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition blossom_head_head_cherry_face_0 = blossom_head.addOrReplaceChild("head_cherry_face", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder blossom_head_head_cherry_face_0_head_cherry_face_fr1_0Cubes = CubeListBuilder.create()
                .texOffs(26, 37).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 0.01F, new CubeDeformation(0.0F));
        PartDefinition blossom_head_head_cherry_face_0_head_cherry_face_fr1_0 = blossom_head_head_cherry_face_0.addOrReplaceChild("head_cherry_face_fr1", blossom_head_head_cherry_face_0_head_cherry_face_fr1_0Cubes, PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition blossom_head_head2_1 = blossom_head.addOrReplaceChild("head2", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder blossom_head_bone11_2Cubes = CubeListBuilder.create()
                .texOffs(44, 49).addBox(-8.0F, -11.6F, 1.0F, 6.0F, 11.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition blossom_head_bone11_2 = blossom_head.addOrReplaceChild("bone11", blossom_head_bone11_2Cubes, PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder blossom_head_bone11_2_bone12_0Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(-2.5F, -0.5F, -4.9F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.0F));
        PartDefinition blossom_head_bone11_2_bone12_0 = blossom_head_bone11_2.addOrReplaceChild("bone12", blossom_head_bone11_2_bone12_0Cubes, PartPose.offsetAndRotation(-5.6F, -13.4F, 1.0F, 3.008518F, 1.349861F, -2.885305F));
        CubeListBuilder blossom_head_bone13_3Cubes = CubeListBuilder.create()
                .texOffs(44, 49).addBox(2.0F, -10.6F, 1.0F, 6.0F, 11.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition blossom_head_bone13_3 = blossom_head.addOrReplaceChild("bone13", blossom_head_bone13_3Cubes, PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        CubeListBuilder blossom_head_bone13_3_bone14_0Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(2.55555F, 0.42597F, -4.52651F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.0F));
        PartDefinition blossom_head_bone13_3_bone14_0 = blossom_head_bone13_3.addOrReplaceChild("bone14", blossom_head_bone13_3_bone14_0Cubes, PartPose.offsetAndRotation(5.6F, -10.4F, 1.0F, 3.008518F, -1.349861F, 2.885305F));
        CubeListBuilder blossom_head_bone10_4Cubes = CubeListBuilder.create()
                .texOffs(9, 39).addBox(-0.3F, -1.0F, -6.0F, 0.01F, 6.0F, 5.0F, new CubeDeformation(0.0F));
        PartDefinition blossom_head_bone10_4 = blossom_head.addOrReplaceChild("bone10", blossom_head_bone10_4Cubes, PartPose.offsetAndRotation(0.0F, -4.0F, -3.4F, 2.44105F, -1.264799F, 2.843435F));
        CubeListBuilder blossom_head_blossom_crown_center_5Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(-2.1F, -2.1F, 0.0F, 4.2F, 4.2F, 0.01F, new CubeDeformation(0.0F));
        PartDefinition blossom_head_blossom_crown_center_5 = blossom_head.addOrReplaceChild("blossom_crown_center", blossom_head_blossom_crown_center_5Cubes, PartPose.offsetAndRotation(0.0F, -8.2F, -0.35F, 0.0F, 0.0F, 0.785398F));
        CubeListBuilder blossom_head_blossom_crown_left_6Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.0F, -2.0F, -2.0F, 0.01F, 4.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition blossom_head_blossom_crown_left_6 = blossom_head.addOrReplaceChild("blossom_crown_left", blossom_head_blossom_crown_left_6Cubes, PartPose.offsetAndRotation(-4.15F, -6.9F, 0.7F, -0.20944F, 0.593412F, 0.488692F));
        CubeListBuilder blossom_head_blossom_crown_right_7Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(0.0F, -2.0F, -2.0F, 0.01F, 4.0F, 4.0F, new CubeDeformation(0.0F));
        PartDefinition blossom_head_blossom_crown_right_7 = blossom_head.addOrReplaceChild("blossom_crown_right", blossom_head_blossom_crown_right_7Cubes, PartPose.offsetAndRotation(4.15F, -6.8F, 0.7F, -0.20944F, -0.593412F, -0.488692F));
        CubeListBuilder blossom_head_blossom_back_bloom_8Cubes = CubeListBuilder.create()
                .texOffs(46, 21).addBox(-2.2F, -2.2F, 0.0F, 4.4F, 4.4F, 0.01F, new CubeDeformation(0.0F));
        PartDefinition blossom_head_blossom_back_bloom_8 = blossom_head.addOrReplaceChild("blossom_back_bloom", blossom_head_blossom_back_bloom_8Cubes, PartPose.offsetAndRotation(0.0F, -5.1F, 4.05F, 0.349066F, 0.0F, 0.349066F));
        return LayerDefinition.create(mesh, 64, 64);
    }
}
