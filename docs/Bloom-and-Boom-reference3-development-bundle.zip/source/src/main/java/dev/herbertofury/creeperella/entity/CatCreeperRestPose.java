package dev.herbertofury.creeperella.entity;

/**
 * Owner-commanded rest families for the Cat Creeper. Motion/locomotion stays separate so the model
 * can keep a stable resting state (SIT/LOAF/SIDE_LIE/SPRAWL) while still layering short seated idle
 * clips such as tail wags or curious looks.
 */
public enum CatCreeperRestPose {
    NONE(0, 1, "None"),
    SIT(1, 4, "Sit"),
    LOAF(2, 2, "Loaf"),
    SIDE_LIE(3, 4, "Side-Lie"),
    SPRAWL(4, 2, "Sprawl"),
    SIT_2(5, 2, "Sit 2");

    private static final CatCreeperRestPose[] VALUES = values();
    private final int id;
    private final int variantCount;
    private final String displayName;

    CatCreeperRestPose(int id, int variantCount, String displayName) {
        this.id = id;
        this.variantCount = variantCount;
        this.displayName = displayName;
    }

    public int id() {
        return this.id;
    }

    public int variantCount() {
        return this.variantCount;
    }

    public String displayName() {
        return this.displayName;
    }

    public int clampVariant(int variant) {
        return Math.floorMod(variant, Math.max(1, this.variantCount));
    }

    public CatCreeperRestPose nextPose() {
        return switch (this) {
            case NONE, SPRAWL -> SIT;
            case SIT -> SIT_2;
            case SIT_2 -> LOAF;
            case LOAF -> SIDE_LIE;
            case SIDE_LIE -> SPRAWL;
        };
    }

    public static CatCreeperRestPose byId(int id) {
        return id >= 0 && id < VALUES.length ? VALUES[id] : NONE;
    }
}
