package dev.herbertofury.creeperella.entity;

/**
 * Short, interruptible Cat Creeper personality clips. The server only syncs the selected clip and
 * its start tick; the client evaluates deterministic curves locally.
 */
public enum CatCreeperIdleAnimation {
    NONE(0, 0),
    PAW_LIFT(1, 58),
    TAIL_WAG(2, 72),
    CURIOUS_LOOK(3, 62),
    KNEAD(4, 80);

    private static final CatCreeperIdleAnimation[] VALUES = values();
    private final int id;
    private final int durationTicks;

    CatCreeperIdleAnimation(int id, int durationTicks) {
        this.id = id;
        this.durationTicks = durationTicks;
    }

    public int id() {
        return this.id;
    }

    public int durationTicks() {
        return this.durationTicks;
    }

    public static CatCreeperIdleAnimation byId(int id) {
        return id >= 0 && id < VALUES.length ? VALUES[id] : NONE;
    }
}
