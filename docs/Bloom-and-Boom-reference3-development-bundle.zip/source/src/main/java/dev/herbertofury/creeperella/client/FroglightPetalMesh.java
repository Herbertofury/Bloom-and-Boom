package dev.herbertofury.creeperella.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelPart;
import java.util.ArrayList;
import java.util.List;

/** Cached curved petal surfaces. No changes to the family rig or animation clocks. */
final class FroglightPetalMesh {
    private FroglightPetalMesh() {}
    // Unit geometry is built once, not allocated per entity/frame.
    private static final float[][] VERTICES = bake();

    static void renderGroup(ModelPart group, PoseStack pose, VertexConsumer buffer, int light, int overlay) {
        if(!group.visible || !(group.hasChild("hero_c") || group.hasChild("bloom_top") || group.hasChild("torso_flower_l"))) return;
        pose.pushPose();
        group.translateAndRotate(pose);
        if (group.hasChild("hero_c")) {
            for (String name : new String[]{"hero_l2","hero_l1","hero_c","hero_r1","hero_r2",
                    "roof_l","roof_c","roof_r","roof_back","roof_back_l","roof_back_r","roof_front"}) renderFlower(group.getChild(name),pose,buffer,light,overlay);
            for (int i=0;i<7;i++) {
                ModelPart ring=group.getChild("ring_blossom_"+i);
                pose.pushPose(); ring.translateAndRotate(pose);
                renderFlower(ring.getChild("bloom"),pose,buffer,light,overlay);
                pose.popPose();
            }
        } else if (group.hasChild("bloom_top")) {
            for (String name : new String[]{"bloom_top","bloom_companion","bloom_outer"})
                renderFlower(group.getChild(name),pose,buffer,light,overlay);
        } else if (group.hasChild("torso_flower_l")) {
            renderFlower(group.getChild("torso_flower_l"),pose,buffer,light,overlay);
            renderFlower(group.getChild("torso_flower_r"),pose,buffer,light,overlay);
        }
        pose.popPose();
    }

    private static void renderFlower(ModelPart flower,PoseStack pose,VertexConsumer buffer,int light,int overlay) {
        if (!flower.visible || !flower.hasChild("organic_shape")) return;
        ModelPart shape=flower.getChild("organic_shape");
        pose.pushPose(); flower.translateAndRotate(pose);
        if (shape.y>0.5F) pose.mulPose(Axis.XP.rotationDegrees(-90));
        float scale=shape.x/16.0F; pose.scale(scale,scale,scale);
        PoseStack.Pose entry=pose.last();
        for (float[] v:VERTICES) {
            buffer.vertex(entry.pose(),v[0],v[1],v[2]).color(v[5],v[5],v[5],1.0F)
                    .uv(v[3],v[4]).overlayCoords(overlay).uv2(light)
                    .normal(entry.normal(),v[6],v[7],v[8]).endVertex();
        }
        pose.popPose();
    }

    private static float[][] bake() {
        List<float[]> out=new ArrayList<>();
        for(int layer=0;layer<2;layer++) {
            int count=layer==0?8:6;
            for(int petal=0;petal<count;petal++) {
                float angle=(float)(petal*Math.PI*2/count+(layer==0?0:Math.PI/6));
                for(int along=0;along<5;along++) for(int across=0;across<3;across++) {
                    float t0=along/5F,t1=(along+1)/5F,s0=-1+across*2/3F,s1=-1+(across+1)*2/3F;
                    out.add(vertex(t0,s0,angle,layer));out.add(vertex(t1,s0,angle,layer));
                    out.add(vertex(t1,s1,angle,layer));out.add(vertex(t0,s1,angle,layer));
                }
            }
        }
        return out.toArray(float[][]::new);
    }

    private static float[] vertex(float t,float side,float angle,int layer) {
        float length=layer==0?1.38F:0.95F, width=layer==0?0.37F:0.29F;
        float breadth=(float)Math.pow(Math.sin(Math.PI*t),0.65)*width;
        float x=side*breadth,y=-0.10F-length*t;
        float z=-0.11F-(float)Math.sin(Math.PI*t)*0.32F+side*side*0.13F-(layer==0?0:0.23F);
        float c=(float)Math.cos(angle),s=(float)Math.sin(angle);
        float shade=0.78F+0.16F*t+0.06F*(1-Math.abs(side));
        float u=((layer==0?4:20)+(side+1)*3)/64F,v=(4+t*6)/64F;
        float nt=Math.max(0.015F,Math.min(0.985F,t));
        double sn=Math.sin(Math.PI*nt),cs=Math.cos(Math.PI*nt);
        float nb=(float)Math.pow(sn,0.65)*width;
        float db=(float)(0.65*Math.PI*width*cs*Math.pow(sn,-0.35));
        float dz=(float)(-0.32*Math.PI*cs);
        float nx=length*0.26F*side,ny=side*db*0.26F*side-dz*nb,nz=-length*nb;
        float norm=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);
        return new float[]{x*c-y*s,x*s+y*c,z,u,v,shade,(nx*c-ny*s)/norm,(nx*s+ny*c)/norm,nz/norm};
    }
}
