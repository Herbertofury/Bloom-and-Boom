package dev.herbertofury.creeperella.entity;

import dev.herbertofury.creeperella.Creeperella;
import dev.herbertofury.creeperella.config.CreeperellaConfig;
import dev.herbertofury.creeperella.registry.ModEntities;
import dev.herbertofury.creeperella.registry.ModItems;
import dev.herbertofury.creeperella.registry.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;
import java.util.UUID;

public class CreeperellaEntity extends Creeper {
    private static final String TAG_MAKEOVER_GRACE = "CreeperellaMakeoverGrace";
    private static final String TAG_MAKEOVER_FRIEND = "CreeperellaMakeoverFriend";
    private static final String TAG_TAMED = "CreeperellaTamed";
    private static final String TAG_OWNER = "CreeperellaOwner";
    private static final String TAG_SITTING = "CreeperellaSitting";
    private static final String TAG_BOND = "CreeperellaBond";
    private static final String TAG_COOLDOWN = "CreeperellaDetonationCooldown";
    private static final String TAG_REFORM = "CreeperellaReformTicks";
    private static final String TAG_COMMAND_TARGET = "CreeperellaCommandTarget";
    private static final String TAG_COMMAND_TICKS = "CreeperellaCommandTicks";
    private static final String TAG_CAT_REST_POSE = "CreeperellaCatRestPose";
    private static final String TAG_CAT_REST_VARIANT = "CreeperellaCatRestVariant";
    private static final ResourceLocation CHERRY_LOOT = new ResourceLocation(Creeperella.MOD_ID, "entities/cherry_creeper");
    private static final EntityDataAccessor<Byte> DATA_CAT_MOTION = SynchedEntityData.defineId(CreeperellaEntity.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Byte> DATA_CAT_IDLE = SynchedEntityData.defineId(CreeperellaEntity.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Integer> DATA_CAT_ANIM_START_TICK = SynchedEntityData.defineId(CreeperellaEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Byte> DATA_CAT_REST_POSE = SynchedEntityData.defineId(CreeperellaEntity.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Byte> DATA_CAT_REST_VARIANT = SynchedEntityData.defineId(CreeperellaEntity.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Integer> DATA_BOOMSHROOM_EMOTE_START_TICK = SynchedEntityData.defineId(CreeperellaEntity.class, EntityDataSerializers.INT);

    // Read-only client ownership mirror. Decisions and legacy save fields remain server-authoritative.
    private static final EntityDataAccessor<Optional<UUID>> DATA_COMPANION_OWNER =
            SynchedEntityData.defineId(CreeperellaEntity.class, EntityDataSerializers.OPTIONAL_UUID);

    private int makeoverGraceTicks;
    private UUID makeoverFriend;

    private boolean companionTamed;
    private UUID ownerUuid;
    private boolean orderedToSit;
    private int bondProgress;
    private int detonationCooldownTicks;
    private int reformTicks;
    private UUID commandTargetUuid;
    private int commandChaseTicks;

    // Cat-only server state. Presentation is synced only when state changes; timers stay server-local.
    private int catNoticeMemoryTicks;
    private int catStillTicks;
    private int catIdleCooldownTicks = 80;
    private int catIdleTicksRemaining;
    private int catRestPoseCooldownTicks = 120;
    private boolean catFollowingRun;
    private CatCreeperIdleAnimation lastCatIdle = CatCreeperIdleAnimation.NONE;

    public CreeperellaEntity(EntityType<? extends CreeperellaEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_CAT_MOTION, (byte) CatCreeperMotionState.IDLE.id());
        this.entityData.define(DATA_CAT_IDLE, (byte) CatCreeperIdleAnimation.NONE.id());
        this.entityData.define(DATA_CAT_ANIM_START_TICK, 0);
        this.entityData.define(DATA_CAT_REST_POSE, (byte) CatCreeperRestPose.NONE.id());
        this.entityData.define(DATA_CAT_REST_VARIANT, (byte) 0);
        this.entityData.define(DATA_BOOMSHROOM_EMOTE_START_TICK, -200);
        this.entityData.define(DATA_COMPANION_OWNER, Optional.empty());
    }

    public CreeperellaKind kind() {
        return ModEntities.kindOf(this.getType());
    }

    public CatCreeperMotionState getCatMotionState() {
        return CatCreeperMotionState.byId(this.entityData.get(DATA_CAT_MOTION));
    }

    public CatCreeperIdleAnimation getCatIdleAnimation() {
        return CatCreeperIdleAnimation.byId(this.entityData.get(DATA_CAT_IDLE));
    }

    public CatCreeperRestPose getCatRestPose() {
        return CatCreeperRestPose.byId(this.entityData.get(DATA_CAT_REST_POSE));
    }

    public int getCatRestVariant() {
        return Byte.toUnsignedInt(this.entityData.get(DATA_CAT_REST_VARIANT));
    }

    public void triggerBoomshroomGreeting() {
        if (!this.level().isClientSide && this.kind() == CreeperellaKind.BOOMSHROOM) {
            this.entityData.set(DATA_BOOMSHROOM_EMOTE_START_TICK, this.tickCount);
        }
    }

    public float getBoomshroomGreetingProgress(float ageInTicks) {
        if (this.kind() != CreeperellaKind.BOOMSHROOM) return 0.0F;
        float elapsed = ageInTicks - this.entityData.get(DATA_BOOMSHROOM_EMOTE_START_TICK);
        return elapsed >= 0.0F && elapsed <= 30.0F ? elapsed / 30.0F : 0.0F;
    }

    public int getCatAnimationStartTick() {
        return this.entityData.get(DATA_CAT_ANIM_START_TICK);
    }

    public float getCatAnimationElapsedTicks(float ageInTicks) {
        return Math.max(0.0F, ageInTicks - this.getCatAnimationStartTick());
    }

    public boolean isCompanionTamed() {
        return companionTamed;
    }

    public UUID getOwnerUuid() {
        return ownerUuid;
    }

    public boolean isOwnedBy(Player player) {
        if (this.level().isClientSide) {
            return this.entityData.get(DATA_COMPANION_OWNER).filter(player.getUUID()::equals).isPresent();
        }
        return companionTamed && ownerUuid != null && ownerUuid.equals(player.getUUID());
    }

    public boolean isOrderedToSit() {
        return orderedToSit;
    }

    public int getBondProgress() {
        return bondProgress;
    }

    public int getDetonationCooldownTicks() {
        return Math.max(0, detonationCooldownTicks);
    }

    public int getReformTicks() {
        return Math.max(0, reformTicks);
    }

    public boolean isReforming() {
        return reformTicks > 0;
    }

    public boolean isReadyToDetonate() {
        return companionTamed && !isReforming() && detonationCooldownTicks <= 0;
    }

    public void tameTo(Player player) {
        this.companionTamed = true;
        this.ownerUuid = player.getUUID();
        syncCompanionOwner();
        this.orderedToSit = false;
        this.bondProgress = 0;
        setCatRestPose(CatCreeperRestPose.NONE, 0);
        this.commandTargetUuid = null;
        this.commandChaseTicks = 0;
        this.setTarget(null);
        this.setSwellDir(-1);
        this.setPersistenceRequired();
        this.heal(this.getMaxHealth());
    }

    private void syncCompanionOwner() {
        if (!this.level().isClientSide) {
            this.entityData.set(DATA_COMPANION_OWNER,
                    this.companionTamed ? Optional.ofNullable(this.ownerUuid) : Optional.empty());
        }
    }

    public int addBondProgress() {
        this.bondProgress = Math.min(CreeperellaConfig.TAME_TREATS_REQUIRED.get(), this.bondProgress + 1);
        return this.bondProgress;
    }

    public boolean toggleSitting(Player player) {
        if (!isOwnedBy(player) || isReforming()) {
            return false;
        }
        this.orderedToSit = !this.orderedToSit;
        if (this.kind() == CreeperellaKind.CAT) {
            if (this.orderedToSit) {
                CatCreeperRestPose pose = getCatRestPose() == CatCreeperRestPose.NONE ? CatCreeperRestPose.SIT : getCatRestPose();
                setCatRestPose(pose, nextVariantForPose(pose, -1));
                this.catRestPoseCooldownTicks = nextCatRestPoseCooldown();
            } else {
                setCatRestPose(CatCreeperRestPose.NONE, 0);
                this.catRestPoseCooldownTicks = 80;
            }
        }
        this.commandTargetUuid = null;
        this.commandChaseTicks = 0;
        this.setTarget(null);
        this.setSwellDir(-1);
        this.getNavigation().stop();
        return true;
    }

    public CatCreeperRestPose cycleCatRestPose() {
        if (this.kind() != CreeperellaKind.CAT) {
            return CatCreeperRestPose.NONE;
        }
        CatCreeperRestPose next = getCatRestPose();
        if (next == CatCreeperRestPose.NONE) next = CatCreeperRestPose.SIT;
        else next = next.nextPose();
        setCatRestPose(next, nextVariantForPose(next, getCatRestVariant()));
        this.catRestPoseCooldownTicks = nextCatRestPoseCooldown();
        this.catStillTicks = 24;
        this.catIdleCooldownTicks = Math.min(this.catIdleCooldownTicks, 24);
        return next;
    }

    public boolean cycleCatRestVariant() {
        CatCreeperRestPose pose = getCatRestPose();
        if (this.kind() != CreeperellaKind.CAT || pose == CatCreeperRestPose.NONE || pose.variantCount() <= 1) {
            return false;
        }
        setCatRestPose(pose, getCatRestVariant() + 1);
        this.catRestPoseCooldownTicks = nextCatRestPoseCooldown();
        return true;
    }

    public boolean commandTarget(Player player, LivingEntity target) {
        if (!CreeperellaConfig.ENABLE_COMPANIONS.get() || !isOwnedBy(player) || !isReadyToDetonate()) {
            return false;
        }
        if (!isValidCommandTarget(player, target)) {
            return false;
        }
        this.orderedToSit = false;
        this.commandTargetUuid = target.getUUID();
        this.commandChaseTicks = 0;
        this.setTarget(target);
        this.setSwellDir(-1);
        this.getNavigation().moveTo(target, catNavigationSpeed(CatCreeperMotionState.RUN, CreeperellaConfig.COMPANION_MOVE_SPEED.get()));
        return true;
    }

    public boolean commandDetonateNow(Player player) {
        if (!CreeperellaConfig.ENABLE_COMPANIONS.get() || !isOwnedBy(player) || !isReadyToDetonate()) {
            return false;
        }
        performCompanionExplosion();
        return true;
    }

    public boolean recallTo(Player player) {
        if (!CreeperellaConfig.ENABLE_COMPANIONS.get() || !isOwnedBy(player) || isReforming()) {
            return false;
        }
        this.orderedToSit = false;
        this.commandTargetUuid = null;
        this.commandChaseTicks = 0;
        this.setTarget(null);
        this.setSwellDir(-1);
        this.getNavigation().stop();
        return safeTeleportNear(player);
    }

    public boolean isOwnedAlly(LivingEntity entity) {
        if (!companionTamed || ownerUuid == null || entity == null) {
            return false;
        }
        if (ownerUuid.equals(entity.getUUID())) {
            return true;
        }
        if (entity instanceof Player player) {
            ServerPlayer owner = getOwnerPlayer();
            return owner != null && owner.isAlliedTo(player);
        }
        if (entity instanceof CreeperellaEntity other) {
            return other.isCompanionTamed() && ownerUuid.equals(other.getOwnerUuid());
        }
        if (entity instanceof TamableAnimal pet) {
            return ownerUuid.equals(pet.getOwnerUUID());
        }
        return false;
    }

    public boolean isValidCommandTarget(Player owner, LivingEntity target) {
        if (target == null || !target.isAlive() || target == this || target.isSpectator()) {
            return false;
        }
        if (target.getUUID().equals(owner.getUUID()) || owner.isAlliedTo(target) || isOwnedAlly(target)) {
            return false;
        }
        if (target instanceof Player targetPlayer && targetPlayer.isCreative()) {
            return false;
        }
        return true;
    }

    /**
     * Gives the player who performed a transformation a short non-hostile window.
     * A tamed Creeperella ignores normal hostile targeting permanently; this grace is for wild makeovers.
     */
    public void grantMakeoverGrace(Player player) {
        this.makeoverFriend = player.getUUID();
        this.makeoverGraceTicks = CreeperellaConfig.MAKEOVER_GRACE_TICKS.get();
        this.setTarget(null);
        this.setSwellDir(-1);
    }

    public boolean hasMakeoverGraceFor(LivingEntity entity) {
        return this.makeoverGraceTicks > 0
                && this.makeoverFriend != null
                && this.makeoverFriend.equals(entity.getUUID());
    }

    @Override
    protected ResourceLocation getDefaultLootTable() {
        return switch (this.kind()) {
            case CHERRY, BLOSSOM -> CHERRY_LOOT;
            default -> EntityType.CREEPER.getDefaultLootTable();
        };
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int lootingLevel, boolean recentlyHit) {
        // Preserve vanilla charged-creeper head semantics, but make Cherry Creepers drop their own
        // source-authored head instead of globally replacing minecraft:creeper_head.
        if ((this.kind() == CreeperellaKind.CHERRY || this.kind() == CreeperellaKind.BLOSSOM)
                && source.getEntity() instanceof Creeper chargedCreeper
                && chargedCreeper.canDropMobsSkull()) {
            chargedCreeper.increaseDroppedSkulls();
            this.spawnAtLocation(ModItems.CHERRY_CREEPER_HEAD.get());
            return;
        }
        super.dropCustomDeathLoot(source, lootingLevel, recentlyHit);
    }

    /**
     * Hard safety boundary for companions: no vanilla AI, modded goal, or stale ignition state may
     * ever push a tamed Creeperella into Creeper's destructive one-life fuse path. Companion
     * detonations are only performed through the reusable command/reformation system.
     */
    @Override
    public void setSwellDir(int direction) {
        if (this.companionTamed && direction > 0) {
            super.setSwellDir(-1);
            return;
        }
        super.setSwellDir(direction);
    }

    @Override
    public void ignite() {
        if (!this.companionTamed) {
            super.ignite();
        }
    }

    @Override
    public void aiStep() {
        // Tamed companions never use the vanilla self-destructive fuse. Their explosions are deliberate,
        // reusable commands handled below, so a stray target-selector tick can never destroy the pet.
        if (!this.level().isClientSide && this.companionTamed) {
            this.setSwellDir(-1);
        }

        super.aiStep();

        if (!this.level().isClientSide) {
            tickMakeoverGrace();
            tickCompanion();
            tickCatMotionSystem();
            return;
        }

        if (!CreeperellaConfig.AMBIENT_PARTICLES.get() || this.random.nextInt(34) != 0 || this.isInvisible()) {
            return;
        }

        ParticleOptions particle = switch (this.kind()) {
            case BUNNY -> this.random.nextBoolean() ? ParticleTypes.HEART : ParticleTypes.POOF;
            case BEE -> this.random.nextBoolean() ? ParticleTypes.FALLING_NECTAR : ParticleTypes.WAX_ON;
            case CHERRY, BLOSSOM -> this.random.nextBoolean() ? ParticleTypes.CHERRY_LEAVES : ParticleTypes.HEART;
            case BOOMSHROOM, SHROOMBOOM -> ModParticles.BOOMSHROOM_SPORE.get();
            case CINDERELLA -> this.random.nextBoolean() ? ParticleTypes.ASH : ParticleTypes.FLAME;
            case MARIGLOW -> this.random.nextBoolean() ? ParticleTypes.WAX_ON : ParticleTypes.END_ROD;
            case VERDALIA -> this.random.nextBoolean() ? ParticleTypes.HAPPY_VILLAGER : ParticleTypes.GLOW;
            case NACRELLA -> this.random.nextBoolean() ? ParticleTypes.ENCHANT : ParticleTypes.END_ROD;
            case FEMALE -> ParticleTypes.HEART;
            case CAT -> this.random.nextBoolean() ? ParticleTypes.HEART : ParticleTypes.POOF;
        };

        double x = this.getX() + (this.random.nextDouble() - 0.5D) * 0.7D;
        double y = this.getY() + 0.7D + this.random.nextDouble() * 0.9D;
        double z = this.getZ() + (this.random.nextDouble() - 0.5D) * 0.7D;
        this.level().addParticle(particle, x, y, z, 0.0D, 0.01D, 0.0D);
    }

    private void tickCompanion() {
        if (this.detonationCooldownTicks > 0) {
            --this.detonationCooldownTicks;
        }

        if (!this.companionTamed || !CreeperellaConfig.ENABLE_COMPANIONS.get()) {
            return;
        }

        this.setPersistenceRequired();
        this.setSwellDir(-1);

        if (this.reformTicks > 0) {
            tickReforming();
            return;
        }

        this.setInvisible(false);
        this.setInvulnerable(false);
        this.noPhysics = false;

        if (this.orderedToSit) {
            this.commandTargetUuid = null;
            this.commandChaseTicks = 0;
            this.setTarget(null);
            this.getNavigation().stop();
            this.setDeltaMovement(Vec3.ZERO);
            return;
        }

        LivingEntity commandTarget = resolveCommandTarget();
        if (commandTarget != null) {
            tickCommandAttack(commandTarget);
            return;
        }

        // Suppress all vanilla hostile targets while tamed. A companion attacks only a whistle-designated target.
        if (this.getTarget() != null) {
            this.setTarget(null);
        }
        tickFollowOwner();
    }

    private void tickCommandAttack(LivingEntity target) {
        ServerPlayer owner = getOwnerPlayer();
        if (owner == null || !isValidCommandTarget(owner, target)) {
            clearCommandTarget();
            return;
        }

        ++this.commandChaseTicks;
        int timeout = CreeperellaConfig.COMMAND_TIMEOUT_TICKS.get();
        double maxRange = CreeperellaConfig.COMMAND_RANGE.get();
        if (this.commandChaseTicks > timeout || this.distanceToSqr(target) > maxRange * maxRange) {
            clearCommandTarget();
            return;
        }

        this.setTarget(target);
        this.setSwellDir(-1);
        this.getLookControl().setLookAt(target, 20.0F, this.getMaxHeadXRot());
        if (this.tickCount % 5 == 0 || this.getNavigation().isDone()) {
            this.getNavigation().moveTo(target, catNavigationSpeed(CatCreeperMotionState.RUN, CreeperellaConfig.COMPANION_MOVE_SPEED.get()));
        }

        double trigger = CreeperellaConfig.DETONATION_TRIGGER_DISTANCE.get();
        if (this.distanceToSqr(target) <= trigger * trigger && this.hasLineOfSight(target)) {
            performCompanionExplosion();
        }
    }

    private void tickFollowOwner() {
        ServerPlayer owner = getOwnerPlayer();
        if (owner == null || owner.level() != this.level() || owner.isSpectator()) {
            this.getNavigation().stop();
            return;
        }

        double distanceSq = this.distanceToSqr(owner);
        double teleportDistance = CreeperellaConfig.FOLLOW_TELEPORT_DISTANCE.get();
        if (distanceSq > teleportDistance * teleportDistance) {
            safeTeleportNear(owner);
            return;
        }

        double start = CreeperellaConfig.FOLLOW_START_DISTANCE.get();
        double stop = CreeperellaConfig.FOLLOW_STOP_DISTANCE.get();
        if (distanceSq > start * start) {
            this.getLookControl().setLookAt(owner, 10.0F, this.getMaxHeadXRot());
            if (this.tickCount % 10 == 0 || this.getNavigation().isDone()) {
                CatCreeperMotionState motion = this.kind() == CreeperellaKind.CAT
                        ? chooseCatFollowMotion(distanceSq, true)
                        : CatCreeperMotionState.WALK;
                this.getNavigation().moveTo(owner, catNavigationSpeed(motion, CreeperellaConfig.COMPANION_MOVE_SPEED.get()));
            }
        } else if (distanceSq < stop * stop) {
            this.getNavigation().stop();
        }
    }

    /**
     * Server-authoritative Cat Creeper behavior/presentation state. The state is intentionally tiny
     * and synced only on transitions; limb motion stays client-side and deterministic. This avoids a
     * per-tick animation packet while still letting the model distinguish creep/walk/run/idle/swell.
     */
    private void tickCatMotionSystem() {
        if (this.kind() != CreeperellaKind.CAT) {
            return;
        }

        if (this.isReforming()) {
            setCatMotionState(CatCreeperMotionState.REFORM);
            cancelCatIdle(40);
            return;
        }

        if (this.orderedToSit) {
            setCatMotionState(CatCreeperMotionState.SIT);
            if (getCatRestPose() == CatCreeperRestPose.NONE) {
                setCatRestPose(CatCreeperRestPose.SIT, nextVariantForPose(CatCreeperRestPose.SIT, -1));
            }
            tickCatSeatedScheduler();
            return;
        }

        if (getCatRestPose() != CatCreeperRestPose.NONE) {
            setCatRestPose(CatCreeperRestPose.NONE, 0);
        }

        LivingEntity target = this.getTarget();
        if (!this.companionTamed && this.getSwellDir() > 0) {
            setCatMotionState(CatCreeperMotionState.SWELL);
            cancelCatIdle(60);
            return;
        }

        CatCreeperMotionState desired;
        if (this.companionTamed) {
            if (target != null || this.commandTargetUuid != null) {
                desired = CatCreeperMotionState.RUN;
            } else {
                ServerPlayer owner = getOwnerPlayer();
                if (owner != null && owner.level() == this.level()) {
                    double d2 = this.distanceToSqr(owner);
                    double stop = CreeperellaConfig.FOLLOW_STOP_DISTANCE.get();
                    if (!this.getNavigation().isDone() && d2 > stop * stop) {
                        desired = chooseCatFollowMotion(d2, true);
                    } else {
                        desired = chooseCatFollowMotion(d2, false);
                    }
                } else {
                    desired = this.getNavigation().isDone() ? CatCreeperMotionState.IDLE : CatCreeperMotionState.WALK;
                }
            }
        } else if (target != null) {
            desired = chooseWildCatPursuitState(target);
            if (desired == CatCreeperMotionState.CREEP || desired == CatCreeperMotionState.RUN) {
                double speed = catNavigationSpeed(desired, 1.0D);
                this.getNavigation().setSpeedModifier(speed);
                // Re-issue at a bounded cadence so vanilla Creeper goals keep ownership of target/pathing
                // while our stealth/run state controls speed without path recalculation spam.
                if (this.tickCount % 8 == 0 || this.getNavigation().isDone()) {
                    this.getNavigation().moveTo(target, speed);
                }
            }
        } else {
            desired = this.getNavigation().isDone() ? CatCreeperMotionState.IDLE : CatCreeperMotionState.WALK;
        }

        setCatMotionState(desired);
        if (desired == CatCreeperMotionState.IDLE) {
            tickCatIdleScheduler();
        } else {
            cancelCatIdle(35);
        }
    }


    private void tickCatSeatedScheduler() {
        boolean trulyStill = this.getTarget() == null
                && this.hurtTime <= 0
                && this.getSwellDir() <= 0
                && this.getNavigation().isDone()
                && this.getDeltaMovement().lengthSqr() < 1.0E-4D;
        if (!trulyStill) {
            this.catStillTicks = 0;
            cancelCatIdle(20);
            return;
        }

        this.catStillTicks = Math.min(200, this.catStillTicks + 1);

        if (this.catIdleTicksRemaining > 0) {
            --this.catIdleTicksRemaining;
            if (this.catIdleTicksRemaining <= 0) {
                this.entityData.set(DATA_CAT_IDLE, (byte) CatCreeperIdleAnimation.NONE.id());
                this.entityData.set(DATA_CAT_ANIM_START_TICK, this.tickCount);
                this.catIdleCooldownTicks = nextCatIdleCooldown();
            }
        } else {
            if (this.catIdleCooldownTicks > 0) {
                --this.catIdleCooldownTicks;
            }
            if (this.catStillTicks >= 18 && this.catIdleCooldownTicks <= 0) {
                startCatIdle(selectCatSeatedIdle());
            }
        }

        if (this.catRestPoseCooldownTicks > 0) {
            --this.catRestPoseCooldownTicks;
            return;
        }
        if (this.catIdleTicksRemaining > 0 || this.catStillTicks < 40) {
            return;
        }

        advanceAmbientCatRestPose();
    }

    private CatCreeperIdleAnimation selectCatSeatedIdle() {
        CatCreeperRestPose pose = getCatRestPose();
        int roll = this.random.nextInt(100);
        return switch (pose) {
            // Side-rest/sprawl keep all four support points stable. The old weighted table could fire
            // PAW_LIFT while fully resting and yank a limb out of the approved pose.
            case SIDE_LIE -> roll < 58 ? CatCreeperIdleAnimation.CURIOUS_LOOK
                    : CatCreeperIdleAnimation.TAIL_WAG;
            case LOAF -> roll < 28 ? CatCreeperIdleAnimation.KNEAD
                    : roll < 64 ? CatCreeperIdleAnimation.CURIOUS_LOOK
                    : CatCreeperIdleAnimation.TAIL_WAG;
            case SPRAWL, SIT_2 -> roll < 54 ? CatCreeperIdleAnimation.TAIL_WAG
                    : CatCreeperIdleAnimation.CURIOUS_LOOK;
            case SIT, NONE -> roll < 36 ? CatCreeperIdleAnimation.PAW_LIFT
                    : roll < 70 ? CatCreeperIdleAnimation.TAIL_WAG
                    : CatCreeperIdleAnimation.CURIOUS_LOOK;
        };
    }

    private void advanceAmbientCatRestPose() {
        CatCreeperRestPose current = getCatRestPose();
        CatCreeperRestPose next = current;
        int roll = this.random.nextInt(100);
        switch (current) {
            case NONE -> next = CatCreeperRestPose.SIT;
            case SIT -> next = roll < 34 ? CatCreeperRestPose.SIT : roll < 50 ? CatCreeperRestPose.SIT_2 : roll < 70 ? CatCreeperRestPose.LOAF : roll < 86 ? CatCreeperRestPose.SIDE_LIE : CatCreeperRestPose.SPRAWL;
            case SIT_2 -> next = roll < 38 ? CatCreeperRestPose.SIT_2 : roll < 65 ? CatCreeperRestPose.SIT : roll < 84 ? CatCreeperRestPose.LOAF : CatCreeperRestPose.SPRAWL;
            case LOAF -> next = roll < 30 ? CatCreeperRestPose.LOAF : roll < 55 ? CatCreeperRestPose.SIT : roll < 70 ? CatCreeperRestPose.SIT_2 : roll < 88 ? CatCreeperRestPose.SIDE_LIE : CatCreeperRestPose.SPRAWL;
            case SIDE_LIE -> next = roll < 45 ? CatCreeperRestPose.SIDE_LIE : roll < 66 ? CatCreeperRestPose.LOAF : roll < 84 ? CatCreeperRestPose.SIT : CatCreeperRestPose.SIT_2;
            case SPRAWL -> next = roll < 32 ? CatCreeperRestPose.SPRAWL : roll < 60 ? CatCreeperRestPose.SIT : roll < 80 ? CatCreeperRestPose.SIT_2 : CatCreeperRestPose.LOAF;
        }
        int variant = next == current ? getCatRestVariant() + 1 : nextVariantForPose(next, -1);
        setCatRestPose(next, variant);
        this.catRestPoseCooldownTicks = nextCatRestPoseCooldown();
    }

    private int nextVariantForPose(CatCreeperRestPose pose, int previous) {
        if (pose == CatCreeperRestPose.NONE) {
            return 0;
        }
        int count = Math.max(1, pose.variantCount());
        if (count == 1) {
            return 0;
        }
        int candidate = this.random.nextInt(count);
        int normalizedPrevious = Math.floorMod(previous, count);
        if (candidate == normalizedPrevious) {
            candidate = (candidate + 1 + this.random.nextInt(count - 1)) % count;
        }
        return candidate;
    }

    private int nextCatRestPoseCooldown() {
        return this.companionTamed ? 90 + this.random.nextInt(90) : 120 + this.random.nextInt(100);
    }

    private void setCatRestPose(CatCreeperRestPose pose, int variant) {
        this.entityData.set(DATA_CAT_REST_POSE, (byte) pose.id());
        this.entityData.set(DATA_CAT_REST_VARIANT, (byte) pose.clampVariant(variant));
    }

    /** Operator-only animation-QA hook; normal gameplay never calls this. */
    public void forceCatQaState(CatCreeperRestPose pose, int variant, CatCreeperIdleAnimation idle) {
        if (this.kind() != CreeperellaKind.CAT) {
            return;
        }
        this.orderedToSit = true;
        setCatRestPose(pose, variant);
        setCatMotionState(CatCreeperMotionState.SIT);
        this.catRestPoseCooldownTicks = Integer.MAX_VALUE;
        this.catIdleCooldownTicks = Integer.MAX_VALUE;
        if (idle == CatCreeperIdleAnimation.NONE) {
            cancelCatIdle(Integer.MAX_VALUE);
        } else {
            this.entityData.set(DATA_CAT_IDLE, (byte) idle.id());
            this.entityData.set(DATA_CAT_ANIM_START_TICK, this.tickCount);
            this.catIdleTicksRemaining = idle.durationTicks();
            this.lastCatIdle = idle;
        }
    }


    private CatCreeperMotionState chooseCatFollowMotion(double distanceSq, boolean navigationActive) {
        if (!navigationActive) {
            this.catFollowingRun = false;
            return CatCreeperMotionState.IDLE;
        }
        double runStart = CreeperellaConfig.CAT_FOLLOW_RUN_DISTANCE.get();
        double runExit = Math.min(runStart, CreeperellaConfig.CAT_FOLLOW_RUN_EXIT_DISTANCE.get());
        if (this.catFollowingRun) {
            if (distanceSq <= runExit * runExit) {
                this.catFollowingRun = false;
            }
        } else if (distanceSq > runStart * runStart) {
            this.catFollowingRun = true;
        }
        return this.catFollowingRun ? CatCreeperMotionState.RUN : CatCreeperMotionState.WALK;
    }

    private CatCreeperMotionState chooseWildCatPursuitState(LivingEntity target) {
        double distanceSq = this.distanceToSqr(target);
        double ambush = CreeperellaConfig.CAT_AMBUSH_DISTANCE.get();
        if (this.hurtTime > 0 || distanceSq <= ambush * ambush) {
            this.catNoticeMemoryTicks = CreeperellaConfig.CAT_NOTICE_MEMORY_TICKS.get();
            return CatCreeperMotionState.RUN;
        }

        if (target instanceof Player player && player.isAlive() && !player.isSpectator()) {
            if (playerNoticesCat(player)) {
                this.catNoticeMemoryTicks = CreeperellaConfig.CAT_NOTICE_MEMORY_TICKS.get();
            } else if (this.catNoticeMemoryTicks > 0) {
                --this.catNoticeMemoryTicks;
            }
            if (this.catNoticeMemoryTicks <= 0) {
                return CatCreeperMotionState.CREEP;
            }
        } else {
            this.catNoticeMemoryTicks = CreeperellaConfig.CAT_NOTICE_MEMORY_TICKS.get();
        }
        return CatCreeperMotionState.RUN;
    }

    private boolean playerNoticesCat(Player player) {
        Vec3 toCat = this.getEyePosition().subtract(player.getEyePosition());
        if (toCat.lengthSqr() < 1.0E-6D) {
            return true;
        }
        double dot = player.getViewVector(1.0F).normalize().dot(toCat.normalize());
        return dot >= CreeperellaConfig.CAT_NOTICE_VIEW_DOT.get() && player.hasLineOfSight(this);
    }

    private double catNavigationSpeed(CatCreeperMotionState state, double fallback) {
        if (this.kind() != CreeperellaKind.CAT) {
            return fallback;
        }
        return switch (state) {
            case CREEP -> CreeperellaConfig.CAT_CREEP_NAV_SPEED.get();
            case RUN -> CreeperellaConfig.CAT_RUN_NAV_SPEED.get();
            case WALK -> CreeperellaConfig.CAT_WALK_NAV_SPEED.get();
            default -> fallback;
        };
    }

    private void setCatMotionState(CatCreeperMotionState state) {
        CatCreeperMotionState current = getCatMotionState();
        if (current == state) {
            return;
        }
        this.entityData.set(DATA_CAT_MOTION, (byte) state.id());
        this.entityData.set(DATA_CAT_ANIM_START_TICK, this.tickCount);
        if (state != CatCreeperMotionState.IDLE) {
            this.entityData.set(DATA_CAT_IDLE, (byte) CatCreeperIdleAnimation.NONE.id());
            this.catIdleTicksRemaining = 0;
        }
    }

    private void tickCatIdleScheduler() {
        boolean trulyStill = this.getNavigation().isDone()
                && this.getDeltaMovement().horizontalDistanceSqr() < 9.0E-4D
                && this.getTarget() == null
                && this.hurtTime <= 0
                && this.getSwellDir() <= 0;
        if (!trulyStill) {
            this.catStillTicks = 0;
            cancelCatIdle(30);
            return;
        }

        this.catStillTicks = Math.min(200, this.catStillTicks + 1);
        if (this.catIdleTicksRemaining > 0) {
            --this.catIdleTicksRemaining;
            if (this.catIdleTicksRemaining <= 0) {
                this.entityData.set(DATA_CAT_IDLE, (byte) CatCreeperIdleAnimation.NONE.id());
                this.entityData.set(DATA_CAT_ANIM_START_TICK, this.tickCount);
                this.catIdleCooldownTicks = nextCatIdleCooldown();
            }
            return;
        }

        if (this.catIdleCooldownTicks > 0) {
            --this.catIdleCooldownTicks;
        }
        if (this.catStillTicks < 24 || this.catIdleCooldownTicks > 0) {
            return;
        }

        startCatIdle(selectCatIdle());
    }


    private CatCreeperIdleAnimation selectCatIdle() {
        CatCreeperIdleAnimation idle = rollCatIdle();
        // Avoid robotic back-to-back repeats when another valid personality clip exists.
        if (idle == this.lastCatIdle) {
            CatCreeperIdleAnimation retry = rollCatIdle();
            if (retry != idle) {
                idle = retry;
            }
        }
        return idle;
    }

    private CatCreeperIdleAnimation rollCatIdle() {
        int roll = this.random.nextInt(100);
        if (roll < 38) {
            return CatCreeperIdleAnimation.PAW_LIFT;
        }
        if (roll < 68) {
            return CatCreeperIdleAnimation.TAIL_WAG;
        }
        if (roll < 90 || !this.companionTamed) {
            return CatCreeperIdleAnimation.CURIOUS_LOOK;
        }
        return CatCreeperIdleAnimation.KNEAD;
    }

    private int nextCatIdleCooldown() {
        int min = CreeperellaConfig.CAT_IDLE_MIN_COOLDOWN_TICKS.get();
        int max = Math.max(min, CreeperellaConfig.CAT_IDLE_MAX_COOLDOWN_TICKS.get());
        int cooldown = min + this.random.nextInt(max - min + 1);
        // Bonded cats show personality slightly more often without becoming a constant animation loop.
        return this.companionTamed ? Math.max(30, (int) (cooldown * 0.78F)) : cooldown;
    }

    private void startCatIdle(CatCreeperIdleAnimation idle) {
        if (this.kind() != CreeperellaKind.CAT || idle == CatCreeperIdleAnimation.NONE) {
            return;
        }
        setCatMotionState(this.orderedToSit ? CatCreeperMotionState.SIT : CatCreeperMotionState.IDLE);
        this.entityData.set(DATA_CAT_IDLE, (byte) idle.id());
        this.entityData.set(DATA_CAT_ANIM_START_TICK, this.tickCount);
        this.catIdleTicksRemaining = idle.durationTicks();
        this.catIdleCooldownTicks = 0;
        this.lastCatIdle = idle;
    }

    private void cancelCatIdle(int minimumCooldown) {
        if (this.entityData.get(DATA_CAT_IDLE) != (byte) CatCreeperIdleAnimation.NONE.id()) {
            this.entityData.set(DATA_CAT_IDLE, (byte) CatCreeperIdleAnimation.NONE.id());
            this.entityData.set(DATA_CAT_ANIM_START_TICK, this.tickCount);
        }
        this.catIdleTicksRemaining = 0;
        this.catIdleCooldownTicks = Math.max(this.catIdleCooldownTicks, minimumCooldown);
    }

    /** Triggered by positive owner interactions so Cat Creeper responds immediately instead of waiting for RNG. */
    public void triggerCatAffectionIdle() {
        if (this.level().isClientSide || this.kind() != CreeperellaKind.CAT || this.isReforming()
                || this.getTarget() != null || this.getSwellDir() > 0) {
            return;
        }
        this.getNavigation().stop();
        this.setDeltaMovement(Vec3.ZERO);
        this.catStillTicks = 24;
        startCatIdle(CatCreeperIdleAnimation.PAW_LIFT);
    }

    private void performCompanionExplosion() {
        if (!(this.level() instanceof ServerLevel serverLevel) || !this.isReadyToDetonate()) {
            return;
        }

        ServerPlayer owner = getOwnerPlayer();
        this.clearCommandTarget();
        this.getNavigation().stop();
        this.setSwellDir(-1);
        this.setInvulnerable(true);
        this.setInvisible(true);
        this.noPhysics = true;
        this.setDeltaMovement(Vec3.ZERO);

        float power = this.isPowered()
                ? CreeperellaConfig.CHARGED_FOLLOWER_EXPLOSION_POWER.get().floatValue()
                : CreeperellaConfig.FOLLOWER_EXPLOSION_POWER.get().floatValue();
        Level.ExplosionInteraction interaction = CreeperellaConfig.FOLLOWER_EXPLOSIONS_BREAK_BLOCKS.get()
                ? Level.ExplosionInteraction.MOB
                : Level.ExplosionInteraction.NONE;

        double blastX = this.getX();
        double blastY = this.getY();
        double blastZ = this.getZ();
        serverLevel.explode(this, blastX, blastY, blastZ, power, false, interaction);
        serverLevel.sendParticles(ParticleTypes.POOF, blastX, blastY + 0.8D, blastZ,
                24, 0.55D, 0.7D, 0.55D, 0.08D);

        this.detonationCooldownTicks = this.isPowered()
                ? CreeperellaConfig.CHARGED_DETONATION_COOLDOWN_TICKS.get()
                : CreeperellaConfig.DETONATION_COOLDOWN_TICKS.get();
        this.reformTicks = Math.max(1, CreeperellaConfig.REFORM_TICKS.get());

        // Move the hidden, invulnerable entity beside its owner immediately so its chunk stays loaded.
        // The visible "respawn" happens only after the configurable reform timer expires.
        if (owner != null && owner.level() == this.level()) {
            safeTeleportNear(owner);
        }
    }

    private void tickReforming() {
        this.setTarget(null);
        this.setSwellDir(-1);
        this.getNavigation().stop();
        this.setInvulnerable(true);
        this.setInvisible(true);
        this.noPhysics = true;
        this.setDeltaMovement(Vec3.ZERO);

        ServerPlayer owner = getOwnerPlayer();
        if (owner != null && owner.level() == this.level() && this.tickCount % 20 == 0) {
            safeTeleportNear(owner);
        }

        --this.reformTicks;
        if (this.reformTicks > 0) {
            return;
        }

        if (owner == null || owner.level() != this.level()) {
            // Keep the companion safely phased out until its owner is available in the same dimension.
            this.reformTicks = 20;
            return;
        }

        safeTeleportNear(owner);
        this.noPhysics = false;
        this.setInvisible(false);
        this.setInvulnerable(false);
        this.heal(this.getMaxHealth());
        this.level().playSound(null, this.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                this.getSoundSource(), 0.9F, 1.35F);
        if (this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 1.0D, this.getZ(),
                    8, 0.35D, 0.45D, 0.35D, 0.03D);
            serverLevel.sendParticles(ParticleTypes.POOF, this.getX(), this.getY() + 0.7D, this.getZ(),
                    18, 0.4D, 0.5D, 0.4D, 0.05D);
        }
    }

    private LivingEntity resolveCommandTarget() {
        if (this.commandTargetUuid == null || !(this.level() instanceof ServerLevel serverLevel)) {
            return null;
        }
        Entity entity = serverLevel.getEntity(this.commandTargetUuid);
        if (entity instanceof LivingEntity living && living.isAlive()) {
            return living;
        }
        clearCommandTarget();
        return null;
    }

    private void clearCommandTarget() {
        this.commandTargetUuid = null;
        this.commandChaseTicks = 0;
        this.setTarget(null);
        this.setSwellDir(-1);
    }

    private ServerPlayer getOwnerPlayer() {
        if (this.ownerUuid == null || !(this.level() instanceof ServerLevel serverLevel)) {
            return null;
        }
        return serverLevel.getServer().getPlayerList().getPlayer(this.ownerUuid);
    }

    private boolean safeTeleportNear(Player player) {
        if (!(this.level() instanceof ServerLevel serverLevel) || player.level() != this.level()) {
            return false;
        }

        BlockPos origin = player.blockPosition();
        int[][] offsets = {
                {2, 0}, {-2, 0}, {0, 2}, {0, -2},
                {2, 2}, {-2, 2}, {2, -2}, {-2, -2},
                {1, 0}, {-1, 0}, {0, 1}, {0, -1}
        };
        for (int[] offset : offsets) {
            for (int dy = 1; dy >= -1; --dy) {
                BlockPos pos = origin.offset(offset[0], dy, offset[1]);
                if (!serverLevel.isEmptyBlock(pos) || !serverLevel.isEmptyBlock(pos.above())) {
                    continue;
                }
                BlockPos below = pos.below();
                if (!serverLevel.getBlockState(below).isFaceSturdy(serverLevel, below, Direction.UP)) {
                    continue;
                }
                this.teleportTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
                this.setDeltaMovement(Vec3.ZERO);
                return true;
            }
        }

        this.teleportTo(player.getX(), player.getY(), player.getZ());
        this.setDeltaMovement(Vec3.ZERO);
        return true;
    }

    private void tickMakeoverGrace() {
        if (this.makeoverGraceTicks <= 0) {
            return;
        }

        --this.makeoverGraceTicks;
        LivingEntity target = this.getTarget();
        if (target != null && hasMakeoverGraceFor(target)) {
            this.setTarget(null);
            this.setSwellDir(-1);
        }

        if (this.makeoverGraceTicks == 0) {
            this.makeoverFriend = null;
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (this.makeoverGraceTicks > 0) {
            tag.putInt(TAG_MAKEOVER_GRACE, this.makeoverGraceTicks);
            if (this.makeoverFriend != null) {
                tag.putUUID(TAG_MAKEOVER_FRIEND, this.makeoverFriend);
            }
        }

        tag.putBoolean(TAG_TAMED, this.companionTamed);
        tag.putBoolean(TAG_SITTING, this.orderedToSit);
        tag.putInt(TAG_BOND, this.bondProgress);
        tag.putInt(TAG_COOLDOWN, this.detonationCooldownTicks);
        tag.putInt(TAG_REFORM, this.reformTicks);
        tag.putInt(TAG_COMMAND_TICKS, this.commandChaseTicks);
        tag.putByte(TAG_CAT_REST_POSE, (byte) getCatRestPose().id());
        tag.putByte(TAG_CAT_REST_VARIANT, (byte) getCatRestVariant());
        if (this.ownerUuid != null) {
            tag.putUUID(TAG_OWNER, this.ownerUuid);
        }
        if (this.commandTargetUuid != null) {
            tag.putUUID(TAG_COMMAND_TARGET, this.commandTargetUuid);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.makeoverGraceTicks = Math.max(0, tag.getInt(TAG_MAKEOVER_GRACE));
        this.makeoverFriend = tag.hasUUID(TAG_MAKEOVER_FRIEND) ? tag.getUUID(TAG_MAKEOVER_FRIEND) : null;

        this.companionTamed = tag.getBoolean(TAG_TAMED);
        this.ownerUuid = tag.hasUUID(TAG_OWNER) ? tag.getUUID(TAG_OWNER) : null;
        syncCompanionOwner();
        this.orderedToSit = tag.getBoolean(TAG_SITTING);
        this.bondProgress = Math.max(0, tag.getInt(TAG_BOND));
        this.detonationCooldownTicks = Math.max(0, tag.getInt(TAG_COOLDOWN));
        this.reformTicks = Math.max(0, tag.getInt(TAG_REFORM));
        this.commandTargetUuid = tag.hasUUID(TAG_COMMAND_TARGET) ? tag.getUUID(TAG_COMMAND_TARGET) : null;
        this.commandChaseTicks = Math.max(0, tag.getInt(TAG_COMMAND_TICKS));
        setCatRestPose(CatCreeperRestPose.byId(tag.getByte(TAG_CAT_REST_POSE)), tag.getByte(TAG_CAT_REST_VARIANT));
        if (this.companionTamed) {
            this.setPersistenceRequired();
            this.setSwellDir(-1);
        }
    }
}
