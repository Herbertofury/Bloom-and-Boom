package dev.herbertofury.creeperella.blockentity;

import dev.herbertofury.creeperella.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.SkullBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class CherryCreeperHeadBlockEntity extends SkullBlockEntity {
    public CherryCreeperHeadBlockEntity(BlockPos pos, BlockState state) {
        super(pos, state);
    }

    @Override
    public BlockEntityType<?> getType() {
        return ModBlockEntities.CHERRY_CREEPER_HEAD.get();
    }
}
