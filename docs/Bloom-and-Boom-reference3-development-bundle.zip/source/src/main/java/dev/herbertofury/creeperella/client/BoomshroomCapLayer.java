package dev.herbertofury.creeperella.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.herbertofury.creeperella.Creeperella;
import dev.herbertofury.creeperella.entity.CreeperellaEntity;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Exact Creeper Overhaul Mushroom Creeper cap geometry/UV silhouette, rendered as a separate layer
 * over Bloom & Boom's Cherry-quality feminine body rig. Keeping the cap isolated preserves both
 * source atlases and gives future Sporella/Moobella/Shroomella accessories a stable attachment point.
 */
public final class BoomshroomCapLayer extends RenderLayer<CreeperellaEntity, CreeperellaModel<CreeperellaEntity>> {
    private static final ResourceLocation CAP = texture("boomshroom_cap.png");
    private static final ResourceLocation GLOW = texture("boomshroom_cap_glow.png");
    private final ModelPart cap;

    public BoomshroomCapLayer(RenderLayerParent<CreeperellaEntity, CreeperellaModel<CreeperellaEntity>> parent,
                              EntityModelSet modelSet) {
        super(parent);
        this.cap = modelSet.bakeLayer(ClientEvents.BOOMSHROOM_CAP).getChild("cap");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        CubeListBuilder cubes = CubeListBuilder.create()
                .texOffs(0, 0).addBox(-7.0F, -6.0F, -7.0F, 14.0F, 6.0F, 14.0F, new CubeDeformation(0.0F))
                .texOffs(0, 108).addBox(-7.0F, -6.0F, -7.0F, 14.0F, 6.0F, 14.0F, new CubeDeformation(2.0F));
        root.addOrReplaceChild("cap", cubes, PartPose.offset(0.0F, -8.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, CreeperellaEntity entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        this.cap.resetPose();

        // Creeper Overhaul's gentle mushroom idle: tiny opposing sway + soft vertical breathing.
        float idle = Mth.sin(ageInTicks / 9.0F);
        this.cap.zRot += idle * 1.15F * Mth.DEG_TO_RAD;
        this.cap.y -= (Mth.cos(ageInTicks / 7.5F) + 1.0F) * 0.045F;

        // Bloom & Boom personality pass: a synchronized hat-tip greeting with anticipation,
        // lift, overshoot, and settle. The body model adds a small matching head bow.
        float greet = entity.getBoomshroomGreetingProgress(ageInTicks);
        if (greet > 0.0F) {
            float arc = Mth.sin(greet * Mth.PI);
            float overshoot = Mth.sin(greet * Mth.PI * 2.0F) * (1.0F - greet);
            this.cap.x += arc * 0.72F;
            this.cap.y -= arc * 0.95F;
            this.cap.xRot += arc * 8.5F * Mth.DEG_TO_RAD;
            this.cap.zRot -= (arc * 29.0F + overshoot * 5.0F) * Mth.DEG_TO_RAD;
        }

        poseStack.pushPose();
        this.getParentModel().applyBoomshroomCapAnchor(poseStack);

        int overlay = LivingEntityRenderer.getOverlayCoords(entity, 0.0F);
        VertexConsumer base = buffer.getBuffer(RenderType.entityCutoutNoCull(CAP));
        this.cap.render(poseStack, base, packedLight, overlay, 1.0F, 1.0F, 1.0F, 1.0F);

        VertexConsumer glow = buffer.getBuffer(RenderType.eyes(GLOW));
        this.cap.render(poseStack, glow, LightTexture.FULL_BRIGHT, overlay, 1.0F, 1.0F, 1.0F, 1.0F);
        poseStack.popPose();
    }

    private static ResourceLocation texture(String name) {
        return new ResourceLocation(Creeperella.MOD_ID, "textures/entity/" + name);
    }
}
