package dev.herbertofury.creeperella.registry;

import dev.herbertofury.creeperella.Creeperella;
import dev.herbertofury.creeperella.block.CherryCreeperHeadBlock;
import dev.herbertofury.creeperella.block.CherryCreeperWallHeadBlock;
import dev.herbertofury.creeperella.block.CherryTntBlock;
import dev.herbertofury.creeperella.block.BlossomTntBlock;
import dev.herbertofury.creeperella.block.BlossomCreeperHeadBlock;
import dev.herbertofury.creeperella.block.BlossomCreeperWallHeadBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, Creeperella.MOD_ID);

    public static final RegistryObject<CherryTntBlock> CHERRY_TNT = BLOCKS.register("cherry_tnt",
            () -> new CherryTntBlock(BlockBehaviour.Properties.copy(Blocks.TNT)));

    public static final RegistryObject<CherryCreeperHeadBlock> CHERRY_CREEPER_HEAD = BLOCKS.register("cherry_creeper_head",
            () -> new CherryCreeperHeadBlock(CherryCreeperHeadBlock.Types.CHERRY,
                    BlockBehaviour.Properties.copy(Blocks.CREEPER_HEAD)));

    public static final RegistryObject<CherryCreeperWallHeadBlock> CHERRY_CREEPER_WALL_HEAD = BLOCKS.register("cherry_creeper_wall_head",
            () -> new CherryCreeperWallHeadBlock(CherryCreeperHeadBlock.Types.CHERRY,
                    BlockBehaviour.Properties.copy(Blocks.CREEPER_WALL_HEAD).dropsLike(CHERRY_CREEPER_HEAD.get())));

    public static final RegistryObject<BlossomTntBlock> BLOSSOM_TNT = BLOCKS.register("blossom_tnt",
            () -> new BlossomTntBlock(BlockBehaviour.Properties.copy(Blocks.TNT)));

    public static final RegistryObject<BlossomCreeperHeadBlock> BLOSSOM_CREEPER_HEAD = BLOCKS.register("blossom_creeper_head",
            () -> new BlossomCreeperHeadBlock(BlossomCreeperHeadBlock.Types.BLOSSOM,
                    BlockBehaviour.Properties.copy(Blocks.CREEPER_HEAD)));

    public static final RegistryObject<BlossomCreeperWallHeadBlock> BLOSSOM_CREEPER_WALL_HEAD = BLOCKS.register("blossom_creeper_wall_head",
            () -> new BlossomCreeperWallHeadBlock(BlossomCreeperHeadBlock.Types.BLOSSOM,
                    BlockBehaviour.Properties.copy(Blocks.CREEPER_WALL_HEAD).dropsLike(BLOSSOM_CREEPER_HEAD.get())));

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
    }

    private ModBlocks() {}
}
