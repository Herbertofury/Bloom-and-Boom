package dev.herbertofury.creeperella.effect;

import com.mojang.logging.LogUtils;
import dev.herbertofury.creeperella.entity.CreeperellaEntity;
import dev.herbertofury.creeperella.registry.ModParticles;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import org.slf4j.Logger;

/**
 * Central family explosion-VFX router.
 *
 * Each Creeperella keeps vanilla explosion gameplay semantics while this layer supplies its
 * biome/theme identity. New variants only need a profile here; render/model code does not have to
 * know how an explosion is decorated.
 */
public final class ThemedExplosionEffects {
    private static final Logger LOGGER = LogUtils.getLogger();

    private static final int BOOMSHROOM_BURST_SPORES = 144;
    private static final int BOOMSHROOM_CROWN_SPORES = 72;
    private static final int BOOMSHROOM_RING_SPORES = 32;
    private static final int BOOMSHROOM_MYCELIUM = 64;
    private static final int BOOMSHROOM_TOTAL_SPORES =
            BOOMSHROOM_BURST_SPORES + BOOMSHROOM_CROWN_SPORES + BOOMSHROOM_RING_SPORES;

    private ThemedExplosionEffects() {}

    public static void emit(ServerLevel level, CreeperellaEntity entity) {
        double x = entity.getX();
        double y = entity.getY() + 0.8D;
        double z = entity.getZ();

        switch (entity.kind()) {
            case CHERRY, BLOSSOM -> emitCherryBloom(level, x, y, z);
            case BOOMSHROOM, SHROOMBOOM -> emitBoomshroomBloom(level, x, y, z);
            case CINDERELLA -> emitCinderellaBurst(level, x, y, z);
            case MARIGLOW -> emitMariglowBloom(level, x, y, z);
            case VERDALIA -> emitVerdaliaBloom(level, x, y, z);
            case NACRELLA -> emitNacrellaBloom(level, x, y, z);
            default -> { }
        }
    }

    private static void emitCherryBloom(ServerLevel level, double x, double y, double z) {
        // Two-depth petal burst: a broad blast silhouette plus a slower lingering petal cloud.
        level.sendParticles(ParticleTypes.CHERRY_LEAVES, x, y, z,
                96, 1.15D, 0.95D, 1.15D, 0.13D);
        level.sendParticles(ParticleTypes.CHERRY_LEAVES, x, y + 0.2D, z,
                48, 0.82D, 0.72D, 0.82D, 0.065D);
    }

    private static void emitMariglowBloom(ServerLevel level, double x, double y, double z) {
        level.sendParticles(ParticleTypes.WAX_ON, x, y + 0.15D, z, 72, 0.95D, 0.82D, 0.95D, 0.07D);
        level.sendParticles(ParticleTypes.END_ROD, x, y + 0.10D, z, 24, 0.58D, 0.72D, 0.58D, 0.028D);
        level.sendParticles(ParticleTypes.FALLING_NECTAR, x, y + 0.2D, z, 48, 0.82D, 0.82D, 0.82D, 0.04D);
        LOGGER.info("MMV_QA_MARIGLOW_EXPLOSION_FX amber={} end_rods={} nectar={}", 72, 24, 48);
    }

    private static void emitVerdaliaBloom(ServerLevel level, double x, double y, double z) {
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, x, y + 0.15D, z, 72, 0.95D, 0.82D, 0.95D, 0.07D);
        level.sendParticles(ParticleTypes.GLOW, x, y + 0.10D, z, 48, 0.82D, 0.82D, 0.82D, 0.05D);
        level.sendParticles(ParticleTypes.END_ROD, x, y + 0.15D, z, 20, 0.52D, 0.70D, 0.52D, 0.025D);
        LOGGER.info("MMV_QA_VERDALIA_EXPLOSION_FX petals={} glow={} end_rods={}", 72, 48, 20);
    }

    private static void emitNacrellaBloom(ServerLevel level, double x, double y, double z) {
        level.sendParticles(ParticleTypes.END_ROD, x, y + 0.15D, z, 24, 0.55D, 0.75D, 0.55D, 0.035D);
        level.sendParticles(ParticleTypes.CHERRY_LEAVES, x, y, z, 112, 1.15D, 0.95D, 1.15D, 0.105D);
        level.sendParticles(ParticleTypes.GLOW, x, y + 0.15D, z, 56, 0.82D, 0.82D, 0.82D, 0.055D);
        for (int i = 0; i < 32; ++i) {
            double angle = Math.PI * 2.0D * i / 32.0D;
            level.sendParticles(ParticleTypes.END_ROD, x, y + 0.05D, z, 0,
                    Math.cos(angle) * 0.13D, 0.045D + (i % 3) * 0.01D, Math.sin(angle) * 0.13D, 1.0D);
        }
        LOGGER.info("MMV_QA_NACRELLA_EXPLOSION_FX petals={} glow={} end_rods={} ring={}", 112, 56, 24, 32);
    }

    private static void emitCinderellaBurst(ServerLevel level, double x, double y, double z) {
        level.sendParticles(ParticleTypes.FLAME, x, y, z, 72, 0.85D, 0.72D, 0.85D, 0.08D);
        level.sendParticles(ParticleTypes.LAVA, x, y - 0.1D, z, 28, 0.72D, 0.35D, 0.72D, 0.03D);
        level.sendParticles(ParticleTypes.ASH, x, y + 0.2D, z, 64, 1.0D, 0.75D, 1.0D, 0.05D);
        LOGGER.info("MMV_QA_CINDERELLA_EXPLOSION_FX flame={} lava={} ash={}", 72, 28, 64);
    }

    private static void emitBoomshroomBloom(ServerLevel level, double x, double y, double z) {
        // Dense warm spore blast that reads through vanilla explosion smoke.
        level.sendParticles(ModParticles.BOOMSHROOM_SPORE.get(), x, y, z,
                BOOMSHROOM_BURST_SPORES, 1.25D, 1.0D, 1.25D, 0.18D);

        // Slower rising crown keeps the fungal identity visible after the white explosion flash clears.
        level.sendParticles(ModParticles.BOOMSHROOM_SPORE.get(), x, y + 0.2D, z,
                BOOMSHROOM_CROWN_SPORES, 0.78D, 0.95D, 0.78D, 0.075D);

        // Authored radial spore halo. count=0 is Minecraft's exact directional-particle mode,
        // so every packet receives this velocity rather than random Gaussian spread.
        for (int i = 0; i < BOOMSHROOM_RING_SPORES; ++i) {
            double angle = Math.PI * 2.0D * i / BOOMSHROOM_RING_SPORES;
            double speed = 0.155D + (i % 4) * 0.018D;
            double dx = Math.cos(angle) * speed;
            double dz = Math.sin(angle) * speed;
            double dy = 0.055D + (i % 3) * 0.012D;
            level.sendParticles(ModParticles.BOOMSHROOM_SPORE.get(), x, y + 0.05D, z,
                    0, dx, dy, dz, 1.0D);
        }

        // Low fungal dust anchors the bloom to the Mushroom Fields / mycelium theme.
        level.sendParticles(ParticleTypes.MYCELIUM, x, y - 0.28D, z,
                BOOMSHROOM_MYCELIUM, 1.05D, 0.42D, 1.05D, 0.10D);

        LOGGER.info("MMV_QA_BOOMSHROOM_EXPLOSION_FX spores={} mycelium={} ring={}",
                BOOMSHROOM_TOTAL_SPORES, BOOMSHROOM_MYCELIUM, BOOMSHROOM_RING_SPORES);
    }
}
