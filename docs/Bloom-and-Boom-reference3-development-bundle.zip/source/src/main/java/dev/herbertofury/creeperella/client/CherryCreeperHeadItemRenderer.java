package dev.herbertofury.creeperella.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.SkullModel;
import net.minecraft.client.model.SkullModelBase;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class CherryCreeperHeadItemRenderer extends BlockEntityWithoutLevelRenderer {
    private final SkullModelBase model;

    public CherryCreeperHeadItemRenderer() {
        super(Minecraft.getInstance().getBlockEntityRenderDispatcher(), Minecraft.getInstance().getEntityModels());
        this.model = new SkullModel(Minecraft.getInstance().getEntityModels().bakeLayer(ClientEvents.CHERRY_HEAD));
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext displayContext, PoseStack poseStack,
                             MultiBufferSource buffers, int packedLight, int packedOverlay) {
        CherryCreeperHeadRenderer.renderSkull(null, 180.0F, poseStack, buffers, packedLight, this.model);
    }
}
