package dev.herbertofury.creeperella.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

/** Soft fungal mote with authored rise/drift/fade motion; sprite frames are hand-pixelled project assets. */
public final class BoomshroomSporeParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private final float driftPhase;
    private final float baseSize;

    private BoomshroomSporeParticle(ClientLevel level, double x, double y, double z,
                                    double xd, double yd, double zd, SpriteSet sprites) {
        super(level, x, y, z, xd, yd, zd);
        this.sprites = sprites;
        this.lifetime = 52 + this.random.nextInt(27);
        this.baseSize = 0.115F + this.random.nextFloat() * 0.105F;
        this.quadSize = this.baseSize;
        this.friction = 0.94F;
        this.gravity = -0.018F;
        this.xd = xd * 0.32D + (this.random.nextDouble() - 0.5D) * 0.018D;
        this.yd = yd * 0.28D + 0.018D + this.random.nextDouble() * 0.025D;
        this.zd = zd * 0.32D + (this.random.nextDouble() - 0.5D) * 0.018D;
        this.alpha = 0.94F;
        this.driftPhase = this.random.nextFloat() * Mth.TWO_PI;
        this.roll = this.random.nextFloat() * Mth.TWO_PI;
        this.oRoll = this.roll;
        this.setSpriteFromAge(sprites);
    }

    @Override
    public void tick() {
        this.oRoll = this.roll;
        super.tick();
        if (this.removed) return;
        float life = this.age / (float) this.lifetime;
        float sway = Mth.sin(this.age * 0.23F + this.driftPhase) * 0.0028F;
        this.xd += sway;
        this.zd += Mth.cos(this.age * 0.19F + this.driftPhase) * 0.0022F;
        this.roll += 0.018F * (1.0F - life);
        // Stay legible through the vanilla explosion flash, then dissolve softly instead of
        // fading from frame one. A tiny bloom envelope makes the mote feel organic.
        this.alpha = life < 0.62F
                ? 0.94F
                : Mth.clamp((1.0F - life) / 0.38F, 0.0F, 1.0F) * 0.94F;
        this.quadSize = this.baseSize * (0.88F + Mth.sin(life * Mth.PI) * 0.28F);
        this.setSpriteFromAge(this.sprites);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static final class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                       double x, double y, double z, double xd, double yd, double zd) {
            return new BoomshroomSporeParticle(level, x, y, z, xd, yd, zd, this.sprites);
        }
    }
}
