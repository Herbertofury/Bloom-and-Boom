package dev.herbertofury.creeperella.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.herbertofury.creeperella.Creeperella;
import dev.herbertofury.creeperella.entity.CreeperellaEntity;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Reference-driven Shroomboom detail rig layered over the proven Pie/Female Creeperella model.
 *
 * Pie remains the locomotion/chest authority. This layer follows Pie's live head/body/breast/leg
 * anchors and adds the oversized stepped cap, deep gills, dimensional eyes/lashes, six articulated
 * moss-hair chains, shelf fungi, mini mushrooms, bark and rooted growth. Every animated custom part
 * is reset before additive motion so the render pose cannot accumulate between frames.
 */
public final class ShroomboomDetailLayer extends RenderLayer<CreeperellaEntity, CreeperellaModel<CreeperellaEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(Creeperella.MOD_ID, "textures/entity/shroomboom_details.png");

    private final ModelPart root;
    private final ModelPart capRoot;
    private final ModelPart faceDetails;
    private final ModelPart bodyDetails;
    private final ModelPart chestDetails;
    private final ModelPart[] legDetails = new ModelPart[4];

    private final HairChain leftHair;
    private final HairChain rightHair;
    private final HairChain leftFrontHair;
    private final HairChain rightFrontHair;
    private final HairChain leftBackHair;
    private final HairChain rightBackHair;
    private final Map<CreeperellaEntity, HairPhysicsState> hairStates = new WeakHashMap<>();

    public ShroomboomDetailLayer(RenderLayerParent<CreeperellaEntity, CreeperellaModel<CreeperellaEntity>> parent,
                                 EntityModelSet modelSet) {
        super(parent);
        this.root = modelSet.bakeLayer(ClientEvents.SHROOMBOOM_DETAILS);
        this.capRoot = this.root.getChild("cap_root");
        this.faceDetails = this.root.getChild("face_details");
        this.bodyDetails = this.root.getChild("body_details");
        this.chestDetails = this.root.getChild("chest_details");
        for (int i = 0; i < 4; i++) {
            this.legDetails[i] = this.root.getChild("leg" + (i + 1) + "_details");
        }

        this.leftHair = chain(this.root, "hair_left");
        this.rightHair = chain(this.root, "hair_right");
        this.leftFrontHair = chain(this.root, "hair_front_left");
        this.rightFrontHair = chain(this.root, "hair_front_right");
        this.leftBackHair = chain(this.root, "hair_back_left");
        this.rightBackHair = chain(this.root, "hair_back_right");
    }

    private static HairChain chain(ModelPart parent, String stem) {
        ModelPart root = parent.getChild(stem + "_root");
        ModelPart mid = root.getChild(stem + "_mid");
        ModelPart tip = mid.getChild(stem + "_tip");
        return new HairChain(root, mid, tip);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffers, int light, CreeperellaEntity entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        int overlay = LivingEntityRenderer.getOverlayCoords(entity, 0.0F);

        animateHair(entity, ageInTicks, netHeadYaw, headPitch, limbSwing, limbSwingAmount);
        animateFace(ageInTicks);
        this.capRoot.resetPose();
        this.capRoot.zRot = Mth.sin(ageInTicks * 0.055F) * 0.012F;
        this.capRoot.xRot = Mth.sin(ageInTicks * 0.041F + 0.7F) * 0.006F;

        poseStack.pushPose();
        this.getParentModel().applyPieHeadAnchor(poseStack);
        this.capRoot.render(poseStack, vc, light, overlay, 1, 1, 1, 1);
        this.faceDetails.render(poseStack, vc, light, overlay, 1, 1, 1, 1);
        renderHair(this.leftHair, poseStack, vc, light, overlay);
        renderHair(this.rightHair, poseStack, vc, light, overlay);
        renderHair(this.leftFrontHair, poseStack, vc, light, overlay);
        renderHair(this.rightFrontHair, poseStack, vc, light, overlay);
        renderHair(this.leftBackHair, poseStack, vc, light, overlay);
        renderHair(this.rightBackHair, poseStack, vc, light, overlay);
        poseStack.popPose();

        this.bodyDetails.resetPose();
        poseStack.pushPose();
        this.getParentModel().applyPieBodyAnchor(poseStack);
        this.bodyDetails.render(poseStack, vc, light, overlay, 1, 1, 1, 1);
        poseStack.popPose();

        this.chestDetails.resetPose();
        this.chestDetails.zRot = Mth.sin(ageInTicks * 0.09F) * 0.018F;
        poseStack.pushPose();
        this.getParentModel().applyPieBreastAnchor(poseStack);
        this.chestDetails.render(poseStack, vc, light, overlay, 1, 1, 1, 1);
        poseStack.popPose();

        for (int i = 0; i < 4; i++) {
            ModelPart detail = this.legDetails[i];
            detail.resetPose();
            poseStack.pushPose();
            this.getParentModel().applyPieLegAnchor(poseStack, i + 1);
            detail.render(poseStack, vc, light, overlay, 1, 1, 1, 1);
            poseStack.popPose();
        }
    }

    private static void renderHair(HairChain chain, PoseStack poseStack, VertexConsumer vc, int light, int overlay) {
        chain.root.render(poseStack, vc, light, overlay, 1, 1, 1, 1);
    }

    private void animateFace(float ageInTicks) {
        this.faceDetails.resetPose();
        ModelPart leftLashes = this.faceDetails.getChild("lashes_left");
        ModelPart rightLashes = this.faceDetails.getChild("lashes_right");
        ModelPart leftLid = this.faceDetails.getChild("eyelid_left");
        ModelPart rightLid = this.faceDetails.getChild("eyelid_right");
        leftLashes.resetPose();
        rightLashes.resetPose();
        leftLid.resetPose();
        rightLid.resetPose();

        // Deterministic irregular-feeling 3D blink. The eyelids are actual geometry laid over the
        // dimensional eyes, so the lashes remain a silhouette instead of disappearing into a texture.
        int frame = Mth.floor(ageInTicks) % 97;
        boolean blink = frame >= 91 && frame <= 94;
        leftLid.visible = blink;
        rightLid.visible = blink;
        float lashBreath = Mth.sin(ageInTicks * 0.065F) * 0.012F;
        leftLashes.zRot -= lashBreath;
        rightLashes.zRot += lashBreath;
    }

    private void animateHair(CreeperellaEntity entity, float ageInTicks, float headYaw, float headPitch,
                             float limbSwing, float limbAmount) {
        HairPhysicsState state = this.hairStates.computeIfAbsent(entity, ignored -> new HairPhysicsState(ageInTicks));
        float elapsed = ageInTicks - state.lastAge;
        if (elapsed < 0.0F || elapsed > 8.0F) {
            state.reset(ageInTicks);
            elapsed = 1.0F;
        }
        float dt = Mth.clamp(elapsed, 0.0F, 1.25F);
        state.lastAge = ageInTicks;

        Vec3 velocity = entity.getDeltaMovement();
        float bodyYaw = entity.yBodyRot * Mth.DEG_TO_RAD;
        float sin = Mth.sin(bodyYaw);
        float cos = Mth.cos(bodyYaw);
        float localSide = (float) (velocity.x * cos + velocity.z * sin);
        float localForward = (float) (-velocity.x * sin + velocity.z * cos);
        float turnImpulse = Mth.wrapDegrees(entity.yBodyRot - entity.yBodyRotO) * Mth.DEG_TO_RAD * 0.38F;
        float sway = Mth.sin(ageInTicks * 0.075F) * 0.045F;
        float crossSway = Mth.sin(ageInTicks * 0.061F + 1.7F) * 0.028F;
        float gait = Mth.sin(limbSwing * 0.5F) * Mth.clamp(limbAmount, 0.0F, 1.0F) * 0.055F;

        float targetZ = Mth.clamp(-headYaw * Mth.DEG_TO_RAD * 0.16F - localSide * 1.8F - turnImpulse + sway,
                -0.42F, 0.42F);
        float targetX = Mth.clamp(headPitch * Mth.DEG_TO_RAD * 0.08F + localForward * 1.1F + gait,
                -0.30F, 0.32F);

        // Side curtains are the heaviest and lag body turns the most.
        state.left.step(targetX, targetZ, dt, 1.0F, 1.00F, 0.00F);
        state.right.step(targetX, -targetZ, dt, -1.0F, 1.00F, 0.00F);

        // Face-framing locks are lighter: more head response, slightly quicker recovery.
        float frontX = Mth.clamp(targetX * 1.12F + headPitch * Mth.DEG_TO_RAD * 0.025F, -0.34F, 0.36F);
        float frontZ = Mth.clamp(targetZ * 0.78F + crossSway, -0.38F, 0.38F);
        state.frontLeft.step(frontX, frontZ, dt, 1.0F, 1.12F, -0.035F);
        state.frontRight.step(frontX, -frontZ, dt, -1.0F, 1.12F, -0.035F);

        // Rear locks are heavier and preserve more inertia when she starts/stops or changes direction.
        float backX = Mth.clamp(targetX * 0.84F + localForward * 0.18F, -0.28F, 0.30F);
        float backZ = Mth.clamp(targetZ * 0.92F - crossSway * 0.6F, -0.44F, 0.44F);
        state.backLeft.step(backX, backZ, dt, 1.0F, 0.86F, 0.045F);
        state.backRight.step(backX, -backZ, dt, -1.0F, 0.86F, 0.045F);

        applyChain(this.leftHair, state.left);
        applyChain(this.rightHair, state.right);
        applyChain(this.leftFrontHair, state.frontLeft);
        applyChain(this.rightFrontHair, state.frontRight);
        applyChain(this.leftBackHair, state.backLeft);
        applyChain(this.rightBackHair, state.backRight);
    }

    private static void applyChain(HairChain chain, SpringChain physics) {
        ModelPart[] parts = {chain.root, chain.mid, chain.tip};
        for (int i = 0; i < parts.length; i++) {
            parts[i].resetPose();
            parts[i].xRot += physics.x[i];
            parts[i].zRot += physics.z[i];
        }
    }

    private record HairChain(ModelPart root, ModelPart mid, ModelPart tip) {}

    private static final class HairPhysicsState {
        private float lastAge;
        private final SpringChain left = new SpringChain();
        private final SpringChain right = new SpringChain();
        private final SpringChain frontLeft = new SpringChain();
        private final SpringChain frontRight = new SpringChain();
        private final SpringChain backLeft = new SpringChain();
        private final SpringChain backRight = new SpringChain();

        private HairPhysicsState(float age) {
            this.lastAge = age;
        }

        private void reset(float age) {
            this.lastAge = age;
            this.left.reset();
            this.right.reset();
            this.frontLeft.reset();
            this.frontRight.reset();
            this.backLeft.reset();
            this.backRight.reset();
        }
    }

    private static final class SpringChain {
        private final float[] x = new float[3];
        private final float[] z = new float[3];
        private final float[] vx = new float[3];
        private final float[] vz = new float[3];

        private void reset() {
            for (int i = 0; i < 3; i++) {
                x[i] = z[i] = vx[i] = vz[i] = 0.0F;
            }
        }

        private void step(float targetX, float targetZ, float dt, float side, float stiffnessScale, float dampingShift) {
            for (int i = 0; i < 3; i++) {
                float follow = (i + 1) / 3.0F;
                float stiffness = (0.34F - i * 0.065F) * stiffnessScale;
                float damping = Mth.clamp(0.62F + i * 0.055F + dampingShift, 0.50F, 0.86F);
                float tx = targetX * (0.48F + follow * 0.62F);
                float tz = targetZ * (0.44F + follow * 0.78F) + side * i * 0.006F;
                vx[i] += (tx - x[i]) * stiffness * dt;
                vz[i] += (tz - z[i]) * stiffness * dt;
                float decay = (float) Math.pow(damping, dt);
                vx[i] *= decay;
                vz[i] *= decay;
                x[i] = Mth.clamp(x[i] + vx[i] * dt, -0.40F, 0.44F);
                z[i] = Mth.clamp(z[i] + vz[i] * dt, -0.54F, 0.54F);
            }
        }
    }
}
