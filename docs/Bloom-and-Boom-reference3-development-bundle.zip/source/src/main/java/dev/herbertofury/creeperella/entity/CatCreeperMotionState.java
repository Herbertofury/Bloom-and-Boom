package dev.herbertofury.creeperella.entity;

/**
 * Server-authoritative Cat Creeper presentation/locomotion state.
 *
 * The ID is synced through SynchedEntityData and intentionally stable so the client model can
 * blend animation modes without network spam or guessing from render-only limbSwingAmount.
 */
public enum CatCreeperMotionState {
    IDLE(0),
    CREEP(1),
    WALK(2),
    RUN(3),
    SWELL(4),
    SIT(5),
    REFORM(6);

    private static final CatCreeperMotionState[] VALUES = values();
    private final int id;

    CatCreeperMotionState(int id) {
        this.id = id;
    }

    public int id() {
        return this.id;
    }

    public static CatCreeperMotionState byId(int id) {
        return id >= 0 && id < VALUES.length ? VALUES[id] : IDLE;
    }
}
