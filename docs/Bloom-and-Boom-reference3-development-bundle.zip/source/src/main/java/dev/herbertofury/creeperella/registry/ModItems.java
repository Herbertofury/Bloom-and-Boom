package dev.herbertofury.creeperella.registry;

import dev.herbertofury.creeperella.Creeperella;
import dev.herbertofury.creeperella.item.CherryCreeperHeadItem;
import dev.herbertofury.creeperella.item.CherryPaintingItem;
import dev.herbertofury.creeperella.item.BlossomCreeperHeadItem;
import dev.herbertofury.creeperella.item.BlossomPaintingItem;
import dev.herbertofury.creeperella.item.FuseWhistleItem;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, Creeperella.MOD_ID);

    public static final RegistryObject<Item> FEMALE_CREEPER_SPAWN_EGG = ITEMS.register("female_creeper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.FEMALE_CREEPER, 0x5A9E51, 0xEAA9CC, new Item.Properties()));
    public static final RegistryObject<Item> BUNNY_CREEPER_SPAWN_EGG = ITEMS.register("bunny_creeper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BUNNY_CREEPER, 0x7CAA63, 0xF5D9E5, new Item.Properties()));
    public static final RegistryObject<Item> BEE_CREEPER_SPAWN_EGG = ITEMS.register("bee_creeper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BEE_CREEPER, 0x5F9B58, 0xF6C645, new Item.Properties()));
    public static final RegistryObject<Item> CHERRY_CREEPER_SPAWN_EGG = ITEMS.register("cherry_creeper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.CHERRY_CREEPER, 0xE7A0AF, 0x6C7D4C, new Item.Properties()));
    public static final RegistryObject<Item> BLOSSOM_CREEPER_SPAWN_EGG = ITEMS.register("blossom_creeper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BLOSSOM_CREEPER, 0xF7CAD7, 0xA55372, new Item.Properties()));
    public static final RegistryObject<Item> BOOMSHROOM_CREEPER_SPAWN_EGG = ITEMS.register("boomshroom_creeper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BOOMSHROOM_CREEPER, 0xEFE4D2, 0xA52B32, new Item.Properties()));
    public static final RegistryObject<Item> CINDERELLA_CREEPER_SPAWN_EGG = ITEMS.register("cinderella_creeper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.CINDERELLA_CREEPER, 0x342A27, 0xFF7A18, new Item.Properties()));
    public static final RegistryObject<Item> MARIGLOW_CREEPER_SPAWN_EGG = ITEMS.register("mariglow_creeper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.MARIGLOW_CREEPER, 0xFCFACD, 0xD7A658, new Item.Properties()));
    public static final RegistryObject<Item> VERDALIA_CREEPER_SPAWN_EGG = ITEMS.register("verdalia_creeper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.VERDALIA_CREEPER, 0xEBF9EC, 0x78A65C, new Item.Properties()));
    public static final RegistryObject<Item> NACRELLA_CREEPER_SPAWN_EGG = ITEMS.register("nacrella_creeper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.NACRELLA_CREEPER, 0xEEE5F6, 0xB88DDD, new Item.Properties()));
    public static final RegistryObject<Item> SHROOMBOOM_CREEPER_SPAWN_EGG = ITEMS.register("shroomboom_creeper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.SHROOMBOOM_CREEPER, 0xEEE2CB, 0xD9483F, new Item.Properties()));
    public static final RegistryObject<Item> CAT_CREEPER_SPAWN_EGG = ITEMS.register("cat_creeper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.CAT_CREEPER, 0x547A3C, 0x26351E, new Item.Properties()));


    // Cherry Creeper remake 3.0 sidecar assets, namespaced instead of replacing vanilla content.
    public static final RegistryObject<Item> CHERRY_GUNPOWDER = ITEMS.register("cherry_gunpowder",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> CHERRY_TNT = ITEMS.register("cherry_tnt",
            () -> new BlockItem(ModBlocks.CHERRY_TNT.get(), new Item.Properties()));
    public static final RegistryObject<Item> CHERRY_CREEPER_HEAD = ITEMS.register("cherry_creeper_head",
            () -> new CherryCreeperHeadItem(ModBlocks.CHERRY_CREEPER_HEAD.get(), ModBlocks.CHERRY_CREEPER_WALL_HEAD.get(),
                    new Item.Properties()));
    public static final RegistryObject<Item> CHERRY_CREEBET_PAINTING = ITEMS.register("cherry_creebet_painting",
            () -> new CherryPaintingItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> BLOSSOM_POWDER = ITEMS.register("blossom_powder",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> BLOSSOM_TNT = ITEMS.register("blossom_tnt",
            () -> new BlockItem(ModBlocks.BLOSSOM_TNT.get(), new Item.Properties()));
    public static final RegistryObject<Item> BLOSSOM_CREEPER_HEAD = ITEMS.register("blossom_creeper_head",
            () -> new BlossomCreeperHeadItem(ModBlocks.BLOSSOM_CREEPER_HEAD.get(), ModBlocks.BLOSSOM_CREEPER_WALL_HEAD.get(), new Item.Properties()));
    public static final RegistryObject<Item> BLOSSOM_CREEBET_PAINTING = ITEMS.register("blossom_creebet_painting",
            () -> new BlossomPaintingItem(new Item.Properties().stacksTo(16)));

    private static final FoodProperties ROSY_FUSE_CAKE_FOOD = new FoodProperties.Builder()
            .nutrition(6).saturationMod(0.6F).build();
    private static final FoodProperties BUNNY_BOOM_BITE_FOOD = new FoodProperties.Builder()
            .nutrition(4).saturationMod(0.5F).build();
    private static final FoodProperties HONEY_POP_FOOD = new FoodProperties.Builder()
            .nutrition(3).saturationMod(0.6F).build();
    private static final FoodProperties CHERRY_BOMB_BONBON_FOOD = new FoodProperties.Builder()
            .nutrition(4).saturationMod(0.5F).build();
    private static final FoodProperties BLOSSOM_BURST_COOKIE_FOOD = new FoodProperties.Builder()
            .nutrition(3).saturationMod(0.4F).build();
    private static final FoodProperties CATNIP_CRUNCH_FOOD = new FoodProperties.Builder()
            .nutrition(3).saturationMod(0.4F).build();

    public static final RegistryObject<Item> ROSY_FUSE_CAKE = ITEMS.register("rosy_fuse_cake",
            () -> new Item(new Item.Properties().food(ROSY_FUSE_CAKE_FOOD)));
    public static final RegistryObject<Item> BUNNY_BOOM_BITE = ITEMS.register("bunny_boom_bite",
            () -> new Item(new Item.Properties().food(BUNNY_BOOM_BITE_FOOD)));
    public static final RegistryObject<Item> HONEY_POP = ITEMS.register("honey_pop",
            () -> new Item(new Item.Properties().food(HONEY_POP_FOOD)));
    public static final RegistryObject<Item> CHERRY_BOMB_BONBON = ITEMS.register("cherry_bomb_bonbon",
            () -> new Item(new Item.Properties().food(CHERRY_BOMB_BONBON_FOOD)));
    public static final RegistryObject<Item> BLOSSOM_BURST_COOKIE = ITEMS.register("blossom_burst_cookie",
            () -> new Item(new Item.Properties().food(BLOSSOM_BURST_COOKIE_FOOD)));
    public static final RegistryObject<Item> CATNIP_CRUNCH = ITEMS.register("catnip_crunch",
            () -> new Item(new Item.Properties().food(CATNIP_CRUNCH_FOOD)));

    public static final RegistryObject<Item> FUSE_WHISTLE = ITEMS.register("fuse_whistle",
            () -> new FuseWhistleItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));

    public static void register(IEventBus bus) {
        ITEMS.register(bus);
    }

    private ModItems() {}
}
