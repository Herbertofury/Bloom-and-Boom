package dev.herbertofury.creeperella.event;

import dev.herbertofury.creeperella.Creeperella;
import dev.herbertofury.creeperella.config.CreeperellaConfig;
import dev.herbertofury.creeperella.entity.CreeperellaEntity;
import dev.herbertofury.creeperella.effect.ThemedExplosionEffects;
import dev.herbertofury.creeperella.entity.CatCreeperRestPose;
import dev.herbertofury.creeperella.entity.CreeperellaKind;
import dev.herbertofury.creeperella.registry.ModEntities;
import dev.herbertofury.creeperella.registry.ModItems;
import dev.herbertofury.creeperella.registry.ModParticles;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.frog.Frog;
import net.minecraft.world.entity.animal.FrogVariant;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Locale;

@Mod.EventBusSubscriber(modid = Creeperella.MOD_ID)
public final class CommonEvents {
    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof Creeper creeper)) {
            return;
        }

        Player player = event.getEntity();
        ItemStack held = player.getItemInHand(event.getHand());

        if (creeper instanceof CreeperellaEntity companion && CreeperellaConfig.ENABLE_COMPANIONS.get()) {
            if (handleCompanionInteraction(event, player, held, companion)) {
                return;
            }
        }

        if (CreeperellaConfig.ENABLE_LEGACY_NAME_TAGS.get() && held.is(Items.NAME_TAG) && held.hasCustomHoverName()) {
            String tag = held.getHoverName().getString().trim().toLowerCase(Locale.ROOT);
            CreeperellaKind legacyKind = switch (tag) {
                case "bunny" -> CreeperellaKind.BUNNY;
                case "bee" -> CreeperellaKind.BEE;
                default -> null;
            };
            if (legacyKind != null && !(creeper instanceof CreeperellaEntity current && current.kind() == legacyKind)) {
                if (!event.getLevel().isClientSide && event.getLevel() instanceof ServerLevel serverLevel) {
                    CreeperellaEntity transformed = replace(serverLevel, creeper, legacyKind);
                    if (transformed != null) {
                        transformed.setCustomName(held.getHoverName());
                        transformed.setCustomNameVisible(creeper.isCustomNameVisible());
                        transformed.grantMakeoverGrace(player);
                        consumeOne(player, held, false);
                        celebrate(serverLevel, transformed, legacyKind);
                        awardTransformationAdvancement(serverLevel, player, legacyKind);
                    }
                }
                finishInteraction(event);
                return;
            }
        }

        if (!CreeperellaConfig.ENABLE_TRANSFORMATIONS.get()) {
            return;
        }

        // Blossom is no longer a second mob. Pink Petals now celebrate the approved Cherry Creeper
        // in-place, preserving the old Bloom & Boom interaction/advancement without swapping entity IDs.
        if (creeper instanceof CreeperellaEntity cherry
                && cherry.kind() == CreeperellaKind.CHERRY
                && held.is(Items.PINK_PETALS)) {
            if (!event.getLevel().isClientSide && event.getLevel() instanceof ServerLevel serverLevel) {
                consumeOne(player, held, false);
                cherry.grantMakeoverGrace(player);
                celebrate(serverLevel, cherry, CreeperellaKind.CHERRY);
                award(serverLevel, player instanceof ServerPlayer sp ? sp : null, "bloom_and_boom");
                player.displayClientMessage(Component.literal("Your Cherry Creeper is in full bloom!")
                        .withStyle(ChatFormatting.LIGHT_PURPLE), true);
            }
            finishInteraction(event);
            return;
        }

        CreeperellaKind destination = destinationFor(creeper, held);
        if (destination == null) {
            return;
        }

        if (!event.getLevel().isClientSide && event.getLevel() instanceof ServerLevel serverLevel) {
            CreeperellaEntity transformed = replace(serverLevel, creeper, destination);
            if (transformed != null) {
                transformed.grantMakeoverGrace(player);
                transformed.triggerBoomshroomGreeting();
                boolean honey = held.is(Items.HONEY_BOTTLE);
                consumeOne(player, held, honey);
                celebrate(serverLevel, transformed, destination);
                awardTransformationAdvancement(serverLevel, player, destination);
            }
        }

        finishInteraction(event);
    }

    @SubscribeEvent
    public static void onExplosionDetonate(ExplosionEvent.Detonate event) {
        Entity sourceEntity = event.getExplosion().getExploder();
        if (sourceEntity instanceof CreeperellaEntity themed && event.getLevel() instanceof ServerLevel serverLevel) {
            ThemedExplosionEffects.emit(serverLevel, themed);
        }

        if (!CreeperellaConfig.ENABLE_COMPANIONS.get()
                || !CreeperellaConfig.PROTECT_OWNER_AND_PETS_FROM_FOLLOWER_EXPLOSIONS.get()) {
            return;
        }

        if (!(sourceEntity instanceof CreeperellaEntity companion) || !companion.isCompanionTamed()) {
            return;
        }

        // Remove protected allies before vanilla computes explosion damage/knockback. The LivingAttackEvent
        // guard below remains as defense in depth for modded explosion implementations.
        event.getAffectedEntities().removeIf(entity ->
                entity instanceof LivingEntity living && companion.isOwnedAlly(living));
    }

    @SubscribeEvent
    public static void onLivingAttack(LivingAttackEvent event) {
        // Tamed Cinderella is never frog food. Cancel before the generic follower-protection guard so
        // this ecology safety rule does not depend on the explosion-protection config.
        if (event.getEntity() instanceof CreeperellaEntity cinderella
                && cinderella.kind() == CreeperellaKind.CINDERELLA
                && cinderella.isCompanionTamed()
                && event.getSource().getEntity() instanceof Frog) {
            event.setCanceled(true);
            return;
        }
        if (!CreeperellaConfig.ENABLE_COMPANIONS.get()
                || !CreeperellaConfig.PROTECT_OWNER_AND_PETS_FROM_FOLLOWER_EXPLOSIONS.get()) {
            return;
        }

        Entity sourceEntity = event.getSource().getEntity();
        if (!(sourceEntity instanceof CreeperellaEntity companion) || !companion.isCompanionTamed()) {
            return;
        }

        LivingEntity victim = event.getEntity();
        if (companion.isOwnedAlly(victim)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof CreeperellaEntity source)
                || source.kind() != CreeperellaKind.CINDERELLA
                || !(event.getSource().getEntity() instanceof Frog frog)
                || !(source.level() instanceof ServerLevel level)) {
            return;
        }
        // Companion safety is absolute even if another mod bypassed LivingAttackEvent.
        if (source.isCompanionTamed()) {
            event.setCanceled(true);
            source.heal(source.getMaxHealth());
            return;
        }
        CreeperellaKind resultKind;
        var resultType = ModEntities.NACRELLA_CREEPER.get();
        String frogName;
        if (frog.getVariant() == FrogVariant.TEMPERATE) {
            resultKind = CreeperellaKind.MARIGLOW;
            resultType = ModEntities.MARIGLOW_CREEPER.get();
            frogName = "temperate";
        } else if (frog.getVariant() == FrogVariant.COLD) {
            resultKind = CreeperellaKind.VERDALIA;
            resultType = ModEntities.VERDALIA_CREEPER.get();
            frogName = "cold";
        } else {
            resultKind = CreeperellaKind.NACRELLA;
            frogName = "warm";
        }
        CreeperellaEntity result = resultType.create(level);
        if (result == null) {
            event.setCanceled(true);
            source.heal(source.getMaxHealth());
            return;
        }
        result.moveTo(source.getX(), source.getY(), source.getZ(), source.getYRot(), source.getXRot());
        result.setDeltaMovement(source.getDeltaMovement());
        result.setCustomName(source.getCustomName());
        result.setCustomNameVisible(source.isCustomNameVisible());
        result.setNoAi(source.isNoAi());
        if (source.isPersistenceRequired()) result.setPersistenceRequired();
        for (String tag : source.getTags()) result.addTag(tag);
        level.addFreshEntity(result);
        if (resultKind == CreeperellaKind.MARIGLOW) {
            level.sendParticles(ParticleTypes.WAX_ON, source.getX(), source.getY() + 0.9D, source.getZ(),
                    36, 0.5D, 0.6D, 0.5D, 0.035D);
            level.sendParticles(ParticleTypes.END_ROD, source.getX(), source.getY() + 0.9D, source.getZ(),
                    18, 0.4D, 0.55D, 0.4D, 0.025D);
        } else if (resultKind == CreeperellaKind.VERDALIA) {
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, source.getX(), source.getY() + 0.9D, source.getZ(),
                    36, 0.5D, 0.6D, 0.5D, 0.035D);
            level.sendParticles(ParticleTypes.GLOW, source.getX(), source.getY() + 0.9D, source.getZ(),
                    24, 0.4D, 0.55D, 0.4D, 0.03D);
        } else {
            level.sendParticles(ParticleTypes.END_ROD, source.getX(), source.getY() + 0.9D, source.getZ(),
                    28, 0.4D, 0.55D, 0.4D, 0.04D);
            level.sendParticles(ParticleTypes.GLOW, source.getX(), source.getY() + 0.9D, source.getZ(),
                    36, 0.5D, 0.6D, 0.5D, 0.035D);
        }
        level.playSound(null, source.blockPosition(), SoundEvents.FROG_TONGUE, source.getSoundSource(), 0.9F, 1.3F);
        Creeperella.LOGGER.info("MMV_QA_FROG_CONVERSION frog={} source=cinderella result={} tags={}",
                frogName, resultKind.name().toLowerCase(java.util.Locale.ROOT), result.getTags().size());
    }

    private static boolean handleCompanionInteraction(PlayerInteractEvent.EntityInteract event,
                                                       Player player,
                                                       ItemStack held,
                                                       CreeperellaEntity companion) {
        if (companion.isReforming()) {
            return false;
        }

        if (isTamingTreatFor(companion.kind(), held)) {
            if (!event.getLevel().isClientSide && event.getLevel() instanceof ServerLevel serverLevel) {
                feedCompanionTreat(serverLevel, player, held, companion);
            }
            finishInteraction(event);
            return true;
        }

        // Ownership is server-authoritative; a client can try both empty hands before
        // receiving a result. Let only the main hand toggle commands/rest poses so one
        // click cannot immediately undo itself. Item-based off-hand interactions remain intact.
        if (event.getHand() == InteractionHand.MAIN_HAND && held.isEmpty() && companion.isOwnedBy(player)) {
            if (!event.getLevel().isClientSide) {
                companion.triggerBoomshroomGreeting();
                if (player.isShiftKeyDown() && companion.kind() == CreeperellaKind.CAT && companion.isOrderedToSit()) {
                    if (player.isSprinting()) {
                        boolean changed = companion.cycleCatRestVariant();
                        if (changed) {
                            player.displayClientMessage(Component.literal(companion.getDisplayName().getString()
                                            + ": " + companion.getCatRestPose().displayName()
                                            + " v" + (companion.getCatRestVariant() + 1))
                                    .withStyle(ChatFormatting.AQUA), true);
                        }
                    } else {
                        CatCreeperRestPose pose = companion.cycleCatRestPose();
                        player.displayClientMessage(Component.literal(companion.getDisplayName().getString()
                                        + ": " + pose.displayName())
                                .withStyle(ChatFormatting.YELLOW), true);
                    }
                } else {
                    boolean changed = companion.toggleSitting(player);
                    if (changed) {
                        String state = companion.isOrderedToSit() ? "Stay" : "Follow";
                        player.displayClientMessage(Component.literal(companion.getDisplayName().getString() + ": " + state)
                                .withStyle(companion.isOrderedToSit() ? ChatFormatting.YELLOW : ChatFormatting.GREEN), true);
                    }
                }
            }
            finishInteraction(event);
            return true;
        }

        return false;
    }

    private static void feedCompanionTreat(ServerLevel level,
                                           Player player,
                                           ItemStack held,
                                           CreeperellaEntity companion) {
        if (companion.isCompanionTamed()) {
            if (!companion.isOwnedBy(player)) {
                player.displayClientMessage(Component.literal("This Creeperella is already bonded to someone else.")
                        .withStyle(ChatFormatting.YELLOW), true);
                return;
            }
            if (companion.getHealth() >= companion.getMaxHealth()) {
                player.displayClientMessage(Component.literal("She's already at full health.")
                        .withStyle(ChatFormatting.GREEN), true);
                return;
            }

            consumeTamingTreat(player, held);
            companion.heal(CreeperellaConfig.TREAT_HEAL_AMOUNT.get().floatValue());
            level.playSound(null, companion.blockPosition(), SoundEvents.GENERIC_EAT,
                    companion.getSoundSource(), 0.8F, 1.15F);
            level.sendParticles(ParticleTypes.HEART, companion.getX(), companion.getY() + 1.0D, companion.getZ(),
                    5, 0.3D, 0.4D, 0.3D, 0.02D);
            companion.triggerCatAffectionIdle();
            companion.triggerBoomshroomGreeting();
            return;
        }

        consumeTamingTreat(player, held);
        int progress = companion.addBondProgress();
        int required = CreeperellaConfig.TAME_TREATS_REQUIRED.get();
        if (progress >= required) {
            companion.tameTo(player);
            level.playSound(null, companion.blockPosition(), SoundEvents.PLAYER_LEVELUP,
                    companion.getSoundSource(), 0.8F, 1.45F);
            level.sendParticles(ParticleTypes.HEART, companion.getX(), companion.getY() + 1.0D, companion.getZ(),
                    12, 0.4D, 0.55D, 0.4D, 0.03D);
            companion.triggerCatAffectionIdle();
            companion.triggerBoomshroomGreeting();
            player.displayClientMessage(Component.literal(companion.getDisplayName().getString() + " is now your demolition buddy!")
                    .withStyle(ChatFormatting.LIGHT_PURPLE), true);
            award(level, player instanceof ServerPlayer sp ? sp : null, "best_friends_with_booms");
        } else {
            level.playSound(null, companion.blockPosition(), SoundEvents.GENERIC_EAT,
                    companion.getSoundSource(), 0.8F, 0.95F + progress * 0.08F);
            level.sendParticles(ParticleTypes.HEART, companion.getX(), companion.getY() + 1.0D, companion.getZ(),
                    3, 0.25D, 0.35D, 0.25D, 0.01D);
            companion.triggerCatAffectionIdle();
            companion.triggerBoomshroomGreeting();
            player.displayClientMessage(Component.literal("Bonding: " + progress + "/" + required)
                    .withStyle(ChatFormatting.AQUA), true);
        }
    }

    private static boolean isTamingTreatFor(CreeperellaKind kind, ItemStack held) {
        return switch (kind) {
            case FEMALE -> held.is(ModItems.ROSY_FUSE_CAKE.get());
            case BUNNY -> held.is(ModItems.BUNNY_BOOM_BITE.get());
            case BEE -> held.is(ModItems.HONEY_POP.get());
            case CHERRY, BLOSSOM -> held.is(ModItems.CHERRY_BOMB_BONBON.get())
                    || held.is(ModItems.BLOSSOM_BURST_COOKIE.get());
            case BOOMSHROOM, SHROOMBOOM -> held.is(Items.BROWN_MUSHROOM);
            case CINDERELLA -> held.is(Items.MAGMA_CREAM);
            case MARIGLOW -> held.is(Items.OCHRE_FROGLIGHT);
            case VERDALIA -> held.is(Items.VERDANT_FROGLIGHT);
            case NACRELLA -> held.is(Items.PEARLESCENT_FROGLIGHT);
            case CAT -> held.is(ModItems.CATNIP_CRUNCH.get());
        };
    }

    private static CreeperellaKind destinationFor(Creeper creeper, ItemStack held) {
        if (creeper.getType() == EntityType.CREEPER) {
            if (held.is(Items.PINK_TULIP)) {
                return CreeperellaKind.FEMALE;
            }
            // String doubles as a playful ball-of-yarn transformation for the Cat Creeper.
            if (held.is(Items.STRING)) {
                return CreeperellaKind.CAT;
            }
            // Red Mushroom is the direct vanilla-Creeper invitation into the Mushroom Fields family.
            if (held.is(Items.RED_MUSHROOM)) {
                return CreeperellaKind.BOOMSHROOM;
            }
            if (held.is(Items.MAGMA_CREAM)) {
                return CreeperellaKind.CINDERELLA;
            }
        }
        if (!(creeper instanceof CreeperellaEntity current)) {
            return null;
        }
        if (held.is(Items.PINK_TULIP) && current.kind() != CreeperellaKind.FEMALE) {
            return CreeperellaKind.FEMALE;
        }
        if (held.is(Items.RABBIT_FOOT) && current.kind() != CreeperellaKind.BUNNY) {
            return CreeperellaKind.BUNNY;
        }
        if (held.is(Items.HONEY_BOTTLE) && current.kind() != CreeperellaKind.BEE) {
            return CreeperellaKind.BEE;
        }
        if (held.is(Items.CHERRY_SAPLING) && current.kind() != CreeperellaKind.CHERRY) {
            return CreeperellaKind.CHERRY;
        }
        if (held.is(Items.RED_MUSHROOM) && current.kind() != CreeperellaKind.BOOMSHROOM
                && current.kind() != CreeperellaKind.SHROOMBOOM) {
            return CreeperellaKind.BOOMSHROOM;
        }
        if (held.is(Items.MAGMA_CREAM) && current.kind() != CreeperellaKind.CINDERELLA) {
            return CreeperellaKind.CINDERELLA;
        }
        if (held.is(Items.OCHRE_FROGLIGHT) && current.kind() != CreeperellaKind.MARIGLOW) {
            return CreeperellaKind.MARIGLOW;
        }
        if (held.is(Items.VERDANT_FROGLIGHT) && current.kind() != CreeperellaKind.VERDALIA) {
            return CreeperellaKind.VERDALIA;
        }
        if (held.is(Items.PEARLESCENT_FROGLIGHT) && current.kind() != CreeperellaKind.NACRELLA) {
            return CreeperellaKind.NACRELLA;
        }
        if (held.is(Items.STRING) && current.kind() != CreeperellaKind.CAT) {
            return CreeperellaKind.CAT;
        }
        return null;
    }

    private static CreeperellaEntity replace(ServerLevel level, Creeper source, CreeperellaKind destination) {
        CreeperellaEntity target = ModEntities.typeFor(destination).create(level);
        if (target == null) {
            return null;
        }

        CompoundTag data = new CompoundTag();
        source.saveWithoutId(data);
        data.remove("UUID");
        target.load(data);
        target.moveTo(source.getX(), source.getY(), source.getZ(), source.getYRot(), source.getXRot());
        target.setDeltaMovement(source.getDeltaMovement());
        target.setSwellDir(source.getSwellDir());

        if (source.isVehicle()) {
            source.ejectPassengers();
        }
        source.discard();
        level.addFreshEntity(target);
        return target;
    }

    private static void consumeOne(Player player, ItemStack held, boolean returnBottle) {
        if (!CreeperellaConfig.CONSUME_TRANSFORMATION_ITEMS.get() || player.getAbilities().instabuild) {
            return;
        }
        held.shrink(1);
        if (returnBottle) {
            ItemStack bottle = new ItemStack(Items.GLASS_BOTTLE);
            if (!player.getInventory().add(bottle) && player instanceof ServerPlayer serverPlayer) {
                serverPlayer.drop(bottle, false);
            }
        }
    }

    private static void consumeTamingTreat(Player player, ItemStack held) {
        if (!CreeperellaConfig.CONSUME_TAMING_TREATS.get() || player.getAbilities().instabuild) {
            return;
        }
        held.shrink(1);
    }

    private static void celebrate(ServerLevel level, CreeperellaEntity entity, CreeperellaKind kind) {
        level.playSound(null, entity.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                entity.getSoundSource(), 0.9F, 1.15F + level.random.nextFloat() * 0.2F);
        level.sendParticles(ParticleTypes.HEART, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                7, 0.35D, 0.45D, 0.35D, 0.02D);
        if (kind == CreeperellaKind.CHERRY || kind == CreeperellaKind.BLOSSOM) {
            level.sendParticles(ParticleTypes.CHERRY_LEAVES, entity.getX(), entity.getY() + 1.1D, entity.getZ(),
                    24, 0.45D, 0.6D, 0.45D, 0.02D);
        } else if (kind == CreeperellaKind.BOOMSHROOM || kind == CreeperellaKind.SHROOMBOOM) {
            level.sendParticles(ModParticles.BOOMSHROOM_SPORE.get(), entity.getX(), entity.getY() + 1.15D, entity.getZ(),
                    28, 0.5D, 0.65D, 0.5D, 0.035D);
            entity.triggerBoomshroomGreeting();
        } else if (kind == CreeperellaKind.CINDERELLA) {
            level.sendParticles(ParticleTypes.FLAME, entity.getX(), entity.getY() + 0.9D, entity.getZ(),
                    20, 0.35D, 0.45D, 0.35D, 0.025D);
        } else if (kind == CreeperellaKind.MARIGLOW) {
            level.sendParticles(ParticleTypes.WAX_ON, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                    18, 0.35D, 0.45D, 0.35D, 0.02D);
        } else if (kind == CreeperellaKind.VERDALIA) {
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                    18, 0.35D, 0.45D, 0.35D, 0.02D);
        } else if (kind == CreeperellaKind.NACRELLA) {
            level.sendParticles(ParticleTypes.END_ROD, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                    18, 0.35D, 0.45D, 0.35D, 0.02D);
        }
    }

    private static void awardTransformationAdvancement(ServerLevel level, Player player, CreeperellaKind kind) {
        if (!(player instanceof ServerPlayer serverPlayer)) {
            return;
        }
        award(level, serverPlayer, "root");
        String advancement = switch (kind) {
            case FEMALE -> "makeover";
            case BUNNY -> "bunny_business";
            case BEE -> "bee_yourself";
            case CHERRY -> "cherry_on_top";
            case BLOSSOM -> "bloom_and_boom";
            case BOOMSHROOM, SHROOMBOOM -> "mushroom_makeover";
            case CINDERELLA, MARIGLOW, VERDALIA, NACRELLA -> "root";
            case CAT -> "cat_got_your_fuse";
        };
        award(level, serverPlayer, advancement);
    }

    private static void award(ServerLevel level, ServerPlayer player, String path) {
        if (player == null) {
            return;
        }
        var advancement = level.getServer().getAdvancements()
                .getAdvancement(new ResourceLocation(Creeperella.MOD_ID, path));
        if (advancement != null) {
            player.getAdvancements().award(advancement, "trigger");
        }
    }

    private static void finishInteraction(PlayerInteractEvent.EntityInteract event) {
        event.setCancellationResult(InteractionResult.sidedSuccess(event.getLevel().isClientSide));
        event.setCanceled(true);
    }

    private CommonEvents() {}
}
