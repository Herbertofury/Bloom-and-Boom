package dev.herbertofury.creeperella.registry;

import dev.herbertofury.creeperella.Creeperella;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.decoration.PaintingVariant;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModPaintings {
    public static final ResourceLocation CHERRY_CREEBET_ID = new ResourceLocation(Creeperella.MOD_ID, "cherry_creebet");
    public static final ResourceKey<PaintingVariant> CHERRY_CREEBET_KEY = ResourceKey.create(Registries.PAINTING_VARIANT, CHERRY_CREEBET_ID);
    public static final ResourceLocation BLOSSOM_CREEBET_ID = new ResourceLocation(Creeperella.MOD_ID, "blossom_creebet");
    public static final ResourceKey<PaintingVariant> BLOSSOM_CREEBET_KEY = ResourceKey.create(Registries.PAINTING_VARIANT, BLOSSOM_CREEBET_ID);

    public static final DeferredRegister<PaintingVariant> PAINTINGS =
            DeferredRegister.create(ForgeRegistries.PAINTING_VARIANTS, Creeperella.MOD_ID);

    // Source artwork is exactly 32x16, matching a 2x1 vanilla painting footprint.
    public static final RegistryObject<PaintingVariant> CHERRY_CREEBET = PAINTINGS.register("cherry_creebet",
            () -> new PaintingVariant(32, 16));
    public static final RegistryObject<PaintingVariant> BLOSSOM_CREEBET = PAINTINGS.register("blossom_creebet",
            () -> new PaintingVariant(32, 16));

    public static void register(IEventBus bus) {
        PAINTINGS.register(bus);
    }

    private ModPaintings() {}
}
