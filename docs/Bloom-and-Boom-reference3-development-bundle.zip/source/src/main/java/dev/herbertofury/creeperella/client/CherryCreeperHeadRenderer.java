package dev.herbertofury.creeperella.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.herbertofury.creeperella.Creeperella;
import dev.herbertofury.creeperella.block.CherryCreeperWallHeadBlock;
import dev.herbertofury.creeperella.blockentity.CherryCreeperHeadBlockEntity;
import net.minecraft.client.model.SkullModel;
import net.minecraft.client.model.SkullModelBase;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.SkullBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RotationSegment;

import javax.annotation.Nullable;

public class CherryCreeperHeadRenderer implements BlockEntityRenderer<CherryCreeperHeadBlockEntity> {
    public static final ResourceLocation TEXTURE = new ResourceLocation(Creeperella.MOD_ID, "textures/entity/cherry_creeper.png");
    private final SkullModelBase model;

    public CherryCreeperHeadRenderer(BlockEntityRendererProvider.Context context) {
        this.model = new SkullModel(context.bakeLayer(ClientEvents.CHERRY_HEAD));
    }

    @Override
    public void render(CherryCreeperHeadBlockEntity blockEntity, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffers, int packedLight, int packedOverlay) {
        BlockState state = blockEntity.getBlockState();
        boolean wall = state.getBlock() instanceof CherryCreeperWallHeadBlock;
        Direction direction = wall ? state.getValue(CherryCreeperWallHeadBlock.FACING) : null;
        int segment = wall
                ? RotationSegment.convertToSegment(direction.getOpposite())
                : state.getValue(SkullBlock.ROTATION);
        float degrees = RotationSegment.convertToDegrees(segment);
        renderSkull(direction, degrees, poseStack, buffers, packedLight, this.model);
    }

    public static void renderSkull(@Nullable Direction wallDirection, float rotationDegrees, PoseStack poseStack,
                                   MultiBufferSource buffers, int packedLight, SkullModelBase model) {
        poseStack.pushPose();
        if (wallDirection == null) {
            poseStack.translate(0.5F, 0.0F, 0.5F);
        } else {
            poseStack.translate(0.5F - wallDirection.getStepX() * 0.25F,
                    0.25F,
                    0.5F - wallDirection.getStepZ() * 0.25F);
        }
        poseStack.scale(-1.0F, -1.0F, 1.0F);
        VertexConsumer vertexConsumer = buffers.getBuffer(RenderType.entityCutoutNoCullZOffset(TEXTURE));
        model.setupAnim(0.0F, rotationDegrees, 0.0F);
        model.renderToBuffer(poseStack, vertexConsumer, packedLight, OverlayTexture.NO_OVERLAY,
                1.0F, 1.0F, 1.0F, 1.0F);
        poseStack.popPose();
    }
}
