package dev.herbertofury.creeperella.entity;

public enum CreeperellaKind {
    FEMALE("female_creeper"),
    BUNNY("bunny_creeper"),
    BEE("bee_creeper"),
    CHERRY("cherry_creeper"),
    BLOSSOM("blossom_creeper"),
    BOOMSHROOM("boomshroom_creeper"),
    CINDERELLA("cinderella_creeper"),
    MARIGLOW("mariglow_creeper"),
    VERDALIA("verdalia_creeper"),
    NACRELLA("nacrella_creeper"),
    SHROOMBOOM("shroomboom_creeper"),
    CAT("cat_creeper");

    private final String id;

    CreeperellaKind(String id) {
        this.id = id;
    }

    public String id() {
        return this.id;
    }
}
