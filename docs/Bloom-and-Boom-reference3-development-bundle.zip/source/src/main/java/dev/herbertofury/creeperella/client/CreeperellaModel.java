package dev.herbertofury.creeperella.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.herbertofury.creeperella.entity.CatCreeperIdleAnimation;
import dev.herbertofury.creeperella.entity.CatCreeperMotionState;
import dev.herbertofury.creeperella.entity.CatCreeperRestPose;
import dev.herbertofury.creeperella.entity.CreeperellaEntity;
import dev.herbertofury.creeperella.entity.CreeperellaKind;
import dev.herbertofury.creeperella.config.CreeperellaClientConfig;
import net.minecraft.client.model.CreeperModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

import java.util.Map;
import java.util.WeakHashMap;

public class CreeperellaModel<T extends CreeperellaEntity> extends CreeperModel<T> {
    private final CreeperellaKind kind;
    private final float tintR;
    private final float tintG;
    private final float tintB;
    private final Map<CreeperellaEntity, PieAggroState> pieAggroStates = new WeakHashMap<>();
    private final Map<CreeperellaEntity, CherryHurtState> cherryHurtStates = new WeakHashMap<>();
    private final Map<CreeperellaEntity, CatVisualState> catVisualStates = new WeakHashMap<>();

    public CreeperellaModel(ModelPart root, CreeperellaKind kind, float tintR, float tintG, float tintB) {
        super(root);
        this.kind = kind;
        this.tintR = tintR;
        this.tintG = tintG;
        this.tintB = tintB;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);

        if (this.kind == CreeperellaKind.FEMALE || this.kind == CreeperellaKind.BUNNY || this.kind == CreeperellaKind.BEE
                || this.kind == CreeperellaKind.CINDERELLA || this.kind == CreeperellaKind.MARIGLOW
                || this.kind == CreeperellaKind.VERDALIA || this.kind == CreeperellaKind.NACRELLA
                || this.kind == CreeperellaKind.SHROOMBOOM) {
            animatePieSource(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            applyPresentationStyle();
            return;
        }
        if (this.kind == CreeperellaKind.CAT) {
            animateCatSource(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            applyPresentationStyle();
            return;
        }
        if (this.kind == CreeperellaKind.CHERRY || this.kind == CreeperellaKind.BLOSSOM || this.kind == CreeperellaKind.BOOMSHROOM) {
            animateCherryRemake(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            applyPresentationStyle();
        }
    }

    /**
     * Native Forge adaptation of the full animation program embedded in Pie's supplied CEM files.
     *
     * CEM top-level animation targets such as body/leg1/leg2/leg3/leg4 resolve to the original
     * vanilla model parts. Pie's visible custom meshes are children of those targets. The native
     * layer generator intentionally mirrors that structure, so these channels are assigned to the
     * vanilla proxy parents exactly as CEM/EMF would do; nested custom IDs (head2, breasts, hair,
     * eyes, ears, tail and wings) remain child-part channels. This distinction is what keeps the
     * authored walk cycle, head sway and secondary motion source-faithful instead of double-moving
     * converted geometry.
     */
    private void animatePieSource(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch) {
        ModelPart vanillaHead = child(this.root(), "head");
        ModelPart head2 = child(vanillaHead, "head2");
        ModelPart vanillaBody = child(this.root(), "body");
        ModelPart body = child(vanillaBody, "body");
        if (vanillaHead == null || head2 == null || vanillaBody == null || body == null) return;

        final float pi = (float) Math.PI;
        final float deg = pi / 180.0F;
        final float speed = Mth.clamp(limbSwingAmount, 0.0F, 1.0F);
        final float idle = 1.0F - Mth.clamp(speed * 3.0F, 0.0F, 1.0F);
        final float random = stablePieRandom(entity);
        final float sourceSeed = 1.0F + random * 2.0F;
        final float b = sourceSeed + ageInTicks / (10.0F + 5.0F * random);
        final float ls = sourceSeed + limbSwing;
        final float yaw = Mth.clamp(netHeadYaw, -70.0F, 70.0F) * deg;
        final float invYaw = Mth.clamp(-netHeadYaw, -70.0F, 70.0F) * deg;
        final float pitch = headPitch * deg;
        final float clampedPitch = Mth.clamp(headPitch, -70.0F, 30.0F) * deg;
        final float hurt = Mth.sin(entity.hurtTime / 2.0F) * entity.hurtTime / 10.0F;
        final float aggro = updatePieAggro(entity, ageInTicks);
        final float aggroSine = easeInOutSine(aggro);
        final float aggroBack = easeOutBack(aggro);

        // Pie source body.* targets the ORIGINAL vanilla body part, not custom id=body.
        final float bodyX = -Mth.sin(b) * pi / 5.0F * idle;
        final float bodyY = 5.0F - Mth.sin(b * 2.0F) / 5.0F * idle
                + Mth.sin(ls * 2.0F) / 2.0F * speed;
        final float bodyZ = -pitch * pi / 2.0F - 22.5F * deg * pi * pi * speed - hurt * pi;
        final float bodyXRot = pitch / (pi * 2.0F) + 22.5F * deg * speed + hurt / pi;
        final float bodyYRot = yaw / 2.0F - Mth.cos(ls) / pi * (speed + 0.25F);
        final float bodyZRot = -Mth.sin(b) / (pi * 5.0F) * idle;

        vanillaBody.resetPose();
        vanillaBody.x = bodyX;
        vanillaBody.y = bodyY;
        vanillaBody.z = bodyZ;
        vanillaBody.xRot = bodyXRot;
        vanillaBody.yRot = bodyYRot;
        vanillaBody.zRot = bodyZRot;

        // The custom body keeps the static translation authored in the JEM (converted at layer-build time).
        body.resetPose();
        final boolean froglightBody = this.kind == CreeperellaKind.MARIGLOW
                || this.kind == CreeperellaKind.VERDALIA
                || this.kind == CreeperellaKind.NACRELLA;
        // Visual refresh: use the family's authored proportions and connected joints.
        // Froglight identity comes from material and botanical accessories, not a stretched shell.

        ModelPart breasts = child(body, "breasts");
        if (breasts != null) {
            breasts.resetPose();
            breasts.y += Mth.cos(b * 2.0F) / 3.0F * idle + Mth.sin(ls * 2.0F) / 2.0F * speed;
            breasts.xRot += Mth.sin(b * 2.0F) / (pi * 3.0F) * idle
                    - Mth.cos(ls * 2.0F) / pi * speed - hurt / pi * 2.0F;
            breasts.yRot += Mth.sin(ls) / pi * speed;
        }

        // The native layer generator detached source body/head2 so vanilla look routing could coexist.
        // Reconstruct the original animated parent by copying body.* onto the vanilla head proxy. The
        // combined static body(+20) + head2(-20) translation was already baked to head2 bind y=0, so
        // head2 receives only its dynamic local channel values here.
        vanillaHead.resetPose();
        vanillaHead.x = vanillaBody.x;
        vanillaHead.y = vanillaBody.y;
        vanillaHead.z = vanillaBody.z;
        vanillaHead.xRot = vanillaBody.xRot;
        vanillaHead.yRot = vanillaBody.yRot;
        vanillaHead.zRot = vanillaBody.zRot;

        head2.resetPose();
        head2.y += Mth.cos(b * 2.0F) / 5.0F * idle - Mth.cos(ls * 2.0F) / 2.0F * speed;
        head2.xRot += clampedPitch - pitch / (pi * 2.0F) - 22.5F * deg * speed - hurt / pi * 2.0F;
        head2.yRot += yaw + invYaw / 2.0F + Mth.cos(ls) / pi * (speed + 0.25F);
        head2.zRot += Mth.cos(b) / (pi * 5.0F) * idle + Mth.sin(ls) / (pi * 2.0F) * speed;

        animatePieHair(child(head2, "hair_left"), b, ls, speed, idle, aggroSine, hurt);
        animatePieHair(child(head2, "hair_right"), b, ls, speed, idle, aggroSine, hurt);
        animatePieBlink(ageInTicks, netHeadYaw, headPitch);

        // Pie source leg1..leg4 channels also target the ORIGINAL vanilla leg parts. Their visible
        // converted child meshes keep their static bind transforms while the proxy parents receive
        // the complete authored translation/rotation program, including lift, stride and turn lean.
        animatePieProxyLeg(child(this.root(), "right_hind_leg"), 1, b, ls, speed, idle, yaw, invYaw, hurt);
        animatePieProxyLeg(child(this.root(), "left_hind_leg"), 2, b, ls, speed, idle, yaw, invYaw, hurt);
        animatePieProxyLeg(child(this.root(), "right_front_leg"), 3, b, ls, speed, idle, yaw, invYaw, hurt);
        animatePieProxyLeg(child(this.root(), "left_front_leg"), 4, b, ls, speed, idle, yaw, invYaw, hurt);

        // The four feet retain the same authored anchors as the rest of the family.

        if (this.kind == CreeperellaKind.BUNNY || this.kind == CreeperellaKind.BEE) {
            animatePieTailAndEars(body, head2, b, ls, speed, idle, pitch, headPitch,
                    hurt, aggroSine, aggroBack);
        }
        if (this.kind == CreeperellaKind.BEE) {
            animatePieBeeWings(body, b, ls, speed, idle);
        }
    }

    private void animatePieBlink(float ageInTicks, float netHeadYaw, float headPitch) {
        ModelPart head2 = child(this.root(), "head", "head2");
        if (head2 == null) return;

        // Faithful port of Pie's CEM var.blink expression:
        // pow(clamp(abs(sin(age/20)*8 + cos(age/30)*2 + cos(age/20)*6), 0, 1), 2)
        float signal = Math.abs(Mth.sin(ageInTicks / 20.0F) * 8.0F
                + Mth.cos(ageInTicks / 30.0F) * 2.0F
                + Mth.cos(ageInTicks / 20.0F) * 6.0F);
        float blink = Mth.clamp(signal, 0.0F, 1.0F);
        blink *= blink;

        animatePieEye(child(head2, "left_eye"), "l_eye_white", "l_pupil", "l_eyebrow",
                blink, netHeadYaw, headPitch, true);
        animatePieEye(child(head2, "right_eye"), "r_eye_white", "r_pupil", "r_eyebrow",
                blink, netHeadYaw, headPitch, false);
    }

    private static void animatePieEye(ModelPart eye, String whiteName, String pupilName, String browName,
                                      float blink, float netHeadYaw, float headPitch, boolean left) {
        if (eye == null) return;
        ModelPart white = child(eye, whiteName);
        ModelPart pupil = child(eye, pupilName);
        ModelPart brow = child(eye, browName);
        if (white != null) {
            white.resetPose();
            white.yScale = blink;
        }
        if (pupil != null) {
            pupil.resetPose();
            pupil.x += left
                    ? Mth.clamp(-netHeadYaw, 0.0F, 90.0F) / 180.0F
                    : Mth.clamp(-netHeadYaw, -90.0F, 0.0F) / 180.0F;
            pupil.yScale = blink + Mth.clamp(-headPitch, -90.0F, 0.0F) / 180.0F;
            pupil.visible = pupil.yScale >= 0.0F;
        }
        if (brow != null) {
            brow.resetPose();
            brow.y += 1.0F - blink;
        }
    }

    private static void animatePieHair(ModelPart hair, float b, float ls, float speed, float idle,
                                       float aggroSine, float hurt) {
        if (hair == null) return;
        float pi = (float) Math.PI;
        hair.resetPose();
        hair.y += aggroSine + Mth.cos(b * 2.0F) / 5.0F * idle + Mth.cos(ls * 2.0F) * speed;
        hair.xRot += -hurt / pi;
        hair.zRot += Mth.sin(b) / (pi * 5.0F) * idle - Mth.cos(ls) / (pi * 2.0F) * speed;
    }

    private static void animatePieProxyLeg(ModelPart leg, int index, float b, float ls, float speed, float idle,
                                           float yaw, float invYaw, float hurt) {
        if (leg == null) return;
        final float pi = (float) Math.PI;
        final float deg = pi / 180.0F;
        final float quarter = pi / 2.0F;
        final float third = pi / 3.0F;
        final float idlePitch = Mth.sin(b * 2.0F) / (pi * 8.0F) * idle;
        final float strideScale = speed + 0.25F;

        float x;
        float y;
        float z;
        float xRot;
        float yRot;
        float zRot;

        switch (index) {
            case 1 -> {
                x = -2.5F + yaw / 2.0F;
                y = 18.0F + Mth.clamp(Mth.cos(0.25F + ls + Mth.cos(quarter + ls) / 2.0F), -3.0F, 0.0F)
                        * 3.0F * speed + hurt;
                z = 4.0F + yaw - Mth.sin(b * 2.0F) * pi / 16.0F * idle
                        + Mth.sin(ls - Mth.sin(third + ls) / 3.0F) * 2.0F * strideScale;
                xRot = invYaw / pi + idlePitch
                        + (20.0F * deg + Mth.sin(0.5F + ls + Mth.cos(quarter + ls) / 2.0F) * 2.0F / pi)
                        * strideScale - hurt / pi;
                yRot = 10.0F * deg;
                zRot = -2.0F * deg + yaw / (pi * 2.0F);
            }
            case 2 -> {
                x = 2.5F + yaw / 2.0F;
                y = 18.0F + Mth.clamp(-Mth.cos(0.25F + ls - Mth.cos(quarter + ls) / 2.0F), -3.0F, 0.0F)
                        * 3.0F * speed + hurt;
                z = 4.0F + invYaw - Mth.sin(b * 2.0F) * pi / 16.0F * idle
                        - Mth.sin(ls - Mth.sin(-third + ls) / 3.0F) * 2.0F * strideScale;
                xRot = yaw / pi + idlePitch
                        + (20.0F * deg - Mth.sin(0.5F + ls + Mth.cos(-quarter + ls) / 2.0F) * 2.0F / pi)
                        * strideScale - hurt / pi;
                yRot = -10.0F * deg;
                zRot = 2.0F * deg + yaw / (pi * 2.0F);
            }
            case 3 -> {
                x = 2.5F + invYaw / 2.0F;
                y = 18.0F + Mth.clamp(Mth.cos(0.25F + ls - Mth.cos(-quarter + ls) / 2.0F), -3.0F, 0.0F)
                        * 3.0F * speed + hurt;
                z = -4.0F + invYaw + Mth.sin(b * 2.0F) * pi / 16.0F * idle
                        + Mth.sin(ls + Mth.sin(-third + ls) / 3.0F) * 2.0F * strideScale;
                xRot = yaw / pi - idlePitch
                        + (20.0F * deg + Mth.sin(0.5F + ls - Mth.cos(-quarter + ls) / 2.0F) * 2.0F / pi)
                        * strideScale + hurt / pi;
                yRot = -10.0F * deg;
                zRot = 2.0F * deg + invYaw / (pi * 2.0F);
            }
            default -> {
                x = -2.5F + invYaw / 2.0F;
                y = 18.0F + Mth.clamp(-Mth.cos(0.25F + ls - Mth.cos(quarter + ls) / 2.0F), -3.0F, 0.0F)
                        * 3.0F * speed + hurt;
                z = -4.0F + yaw + Mth.sin(b * 2.0F) * pi / 16.0F * idle
                        - Mth.sin(ls + Mth.sin(third + ls) / 3.0F) * 2.0F * strideScale;
                xRot = invYaw / pi - idlePitch
                        + (20.0F * deg - Mth.sin(0.5F + ls - Mth.cos(quarter + ls) / 2.0F) * 2.0F / pi)
                        * strideScale + hurt / pi;
                yRot = 10.0F * deg;
                zRot = -2.0F * deg + invYaw / (pi * 2.0F);
            }
        }

        leg.resetPose();
        leg.x = x;
        leg.y = y;
        leg.z = z;
        leg.xRot = xRot;
        leg.yRot = yRot;
        leg.zRot = zRot;
    }

    private void animatePieTailAndEars(ModelPart body, ModelPart head2, float b, float ls, float speed, float idle,
                                       float pitch, float headPitchDegrees, float hurt,
                                       float aggroSine, float aggroBack) {
        final float pi = (float) Math.PI;
        final float deg = pi / 180.0F;

        ModelPart tail = child(body, "tail");
        if (tail != null) {
            tail.resetPose();
            tail.xRot += 20.0F * deg * aggroSine;
            tail.yRot += Mth.sin(b) * 2.0F / pi * idle - Mth.sin(ls) * 2.0F / pi * speed;
        }

        ModelPart leftEar = child(head2, "left_ear");
        ModelPart rightEar = child(head2, "right_ear");
        float sourceEarBase = this.kind == CreeperellaKind.BEE ? 10.0F * deg : 0.0F;
        if (leftEar != null) {
            leftEar.resetPose();
            leftEar.xRot += pitch / 3.0F + hurt / pi * 3.0F;
            leftEar.zRot += sourceEarBase + 20.0F * deg * aggroBack
                    + Mth.cos(b) / (pi * 2.0F) * idle - Mth.cos(ls) * 2.0F / pi * speed;
        }
        if (rightEar != null) {
            rightEar.resetPose();
            rightEar.xRot += pitch / 3.0F + hurt / pi * 3.0F;
            rightEar.zRot += -sourceEarBase - 20.0F * deg * aggroBack
                    + Mth.cos(b) / (pi * 2.0F) * idle - Mth.cos(ls) * 2.0F / pi * speed;

            ModelPart rightEar2 = child(rightEar, "right_ear2");
            if (rightEar2 != null) {
                float pitchFactor = Mth.clamp(headPitchDegrees / 90.0F * 2.0F + 1.0F, -1.0F, 1.25F);
                rightEar2.resetPose();
                rightEar2.xRot += pitch / 3.0F
                        + Mth.cos(b * 2.0F) / pi * (idle * pitchFactor)
                        - Mth.sin(ls) * 2.0F / pi * (speed * pitchFactor)
                        + hurt / pi * 3.0F;
                rightEar2.zRot += Mth.cos(b) / pi * idle - Mth.sin(ls) * 2.0F / pi * speed;
            }
        }
    }

    private static void animatePieBeeWings(ModelPart body, float b, float ls, float speed, float idle) {
        final float pi = (float) Math.PI;
        ModelPart left = child(body, "left_wings");
        ModelPart right = child(body, "right_wings");
        if (left != null) {
            left.resetPose();
            left.yRot += Mth.sin(b * 2.0F) / pi * idle
                    + Mth.sin(ls * 2.0F) * 2.0F / pi * speed
                    + Mth.cos(ls) / pi * speed;
        }
        if (right != null) {
            right.resetPose();
            right.yRot += -Mth.sin(b * 2.0F) / pi * idle
                    - Mth.sin(ls * 2.0F) * 2.0F / pi * speed
                    + Mth.cos(ls) / pi * speed;
        }
    }

    private float updatePieAggro(T entity, float ageInTicks) {
        PieAggroState state = this.pieAggroStates.computeIfAbsent(entity, ignored -> new PieAggroState(ageInTicks));
        float dt = Mth.clamp(ageInTicks - state.lastAge, 0.0F, 1.5F);
        state.lastAge = ageInTicks;
        float target = entity.getSwelling(0.0F) > 0.01F ? 1.0F : 0.0F;
        float step = 0.2F * dt;
        if (state.value < target) state.value = Math.min(target, state.value + step);
        else if (state.value > target) state.value = Math.max(target, state.value - step);
        return Mth.clamp(state.value, 0.0F, 1.0F);
    }

    private static float stablePieRandom(CreeperellaEntity entity) {
        long x = entity.getUUID().getMostSignificantBits() ^ entity.getUUID().getLeastSignificantBits();
        x ^= x >>> 33;
        x *= 0xff51afd7ed558ccdL;
        x ^= x >>> 33;
        x *= 0xc4ceb9fe1a85ec53L;
        x ^= x >>> 33;
        return (float) ((x >>> 40) & 0xFFFFFFL) / 16777215.0F;
    }

    private static float easeInOutSine(float value) {
        return -(Mth.cos((float) Math.PI * Mth.clamp(value, 0.0F, 1.0F)) - 1.0F) / 2.0F;
    }

    private static float easeOutBack(float value) {
        float x = Mth.clamp(value, 0.0F, 1.0F) - 1.0F;
        final float c1 = 1.70158F;
        final float c3 = c1 + 1.0F;
        return 1.0F + c3 * x * x * x + c1 * x * x;
    }

    private static final class CherryHurtState {
        float value;
        float lastAge;

        CherryHurtState(float value, float lastAge) {
            this.value = value;
            this.lastAge = lastAge;
        }
    }

    private static final class PieAggroState {
        float value;
        float lastAge;

        PieAggroState(float lastAge) {
            this.lastAge = lastAge;
        }
    }

    private static final class CatVisualState {
        float creep;
        float walk;
        float run;
        float swell;
        float sit;
        float restSit;
        float sit2;
        float loaf;
        float sideLie;
        float sprawl;
        float phase;
        float lastLimbSwing;
        float lastAge = Float.NaN;
    }

    private CatVisualState updateCatVisualState(T entity, float limbSwing, float ageInTicks) {
        CatVisualState state = this.catVisualStates.computeIfAbsent(entity, ignored -> new CatVisualState());
        CatCreeperMotionState motion = entity.getCatMotionState();
        float tc = motion == CatCreeperMotionState.CREEP ? 1.0F : 0.0F;
        float tw = motion == CatCreeperMotionState.WALK ? 1.0F : 0.0F;
        float tr = motion == CatCreeperMotionState.RUN ? 1.0F : 0.0F;
        float ts = motion == CatCreeperMotionState.SWELL ? 1.0F : 0.0F;
        float tsi = motion == CatCreeperMotionState.SIT ? 1.0F : 0.0F;
        CatCreeperRestPose restPose = entity.getCatRestPose();
        float trs = motion == CatCreeperMotionState.SIT && restPose == CatCreeperRestPose.SIT ? 1.0F : 0.0F;
        float ts2 = motion == CatCreeperMotionState.SIT && restPose == CatCreeperRestPose.SIT_2 ? 1.0F : 0.0F;
        float tl = motion == CatCreeperMotionState.SIT && restPose == CatCreeperRestPose.LOAF ? 1.0F : 0.0F;
        float tsl = motion == CatCreeperMotionState.SIT && restPose == CatCreeperRestPose.SIDE_LIE ? 1.0F : 0.0F;
        float tsp = motion == CatCreeperMotionState.SIT && restPose == CatCreeperRestPose.SPRAWL ? 1.0F : 0.0F;

        if (Float.isNaN(state.lastAge)) {
            state.creep = tc;
            state.walk = tw;
            state.run = tr;
            state.swell = ts;
            state.sit = tsi;
            state.restSit = trs;
            state.sit2 = ts2;
            state.loaf = tl;
            state.sideLie = tsl;
            state.sprawl = tsp;
            float cadence = tc * 0.56F + tw + tr * 1.58F;
            if (cadence <= 0.001F) cadence = 1.0F;
            state.phase = limbSwing * 0.6662F * cadence;
            state.lastLimbSwing = limbSwing;
            state.lastAge = ageInTicks;
            return state;
        }

        float dt = Mth.clamp(ageInTicks - state.lastAge, 0.0F, 4.0F);
        // Critically damped-feeling client blend: fast enough to react to gameplay, slow enough to
        // prevent creep/walk/run state packets from producing a visible one-frame pose snap.
        float alpha = 1.0F - (float)Math.exp(-dt * 0.42F);
        state.creep = Mth.lerp(alpha, state.creep, tc);
        state.walk = Mth.lerp(alpha, state.walk, tw);
        state.run = Mth.lerp(alpha, state.run, tr);
        state.swell = Mth.lerp(alpha, state.swell, ts);
        state.sit = Mth.lerp(alpha, state.sit, tsi);
        state.restSit = Mth.lerp(alpha, state.restSit, trs);
        state.sit2 = Mth.lerp(alpha, state.sit2, ts2);
        state.loaf = Mth.lerp(alpha, state.loaf, tl);
        state.sideLie = Mth.lerp(alpha, state.sideLie, tsl);
        state.sprawl = Mth.lerp(alpha, state.sprawl, tsp);

        float deltaSwing = limbSwing - state.lastLimbSwing;
        if (Math.abs(deltaSwing) > 4.0F) deltaSwing = 0.0F;
        float totalMove = state.creep + state.walk + state.run;
        float cadence = totalMove > 0.001F
                ? (state.creep * 0.56F + state.walk + state.run * 1.58F) / totalMove
                : 1.0F;
        state.phase += deltaSwing * 0.6662F * cadence;
        state.lastLimbSwing = limbSwing;
        state.lastAge = ageInTicks;
        return state;
    }

    private void animateCatSource(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch) {
        ModelPart waist = child(this.root(), "body", "waist");
        ModelPart body = child(waist, "Body");
        ModelPart upper = child(body, "Upperbody");
        ModelPart catHead = child(upper, "head");
        if (waist == null || body == null || upper == null || catHead == null) return;

        final float deg = (float)Math.PI / 180.0F;
        final float seconds = ageInTicks / 20.0F;
        final float movement = Mth.clamp(limbSwingAmount, 0.0F, 1.0F);
        CatVisualState visual = updateCatVisualState(entity, limbSwing, ageInTicks);
        final int restVariant = entity.getCatRestVariant();

        float moveSum = Math.max(0.0001F, visual.creep + visual.walk + visual.run);
        float creepN = visual.creep / moveSum;
        float walkN = visual.walk / moveSum;
        float runN = visual.run / moveSum;
        float movementGate = smoothStep(0.015F, 0.20F, movement);
        float gait = Mth.clamp((visual.creep + visual.walk + visual.run) * movementGate, 0.0F, 1.0F);
        float phase = visual.phase;
        float stride = Mth.sin(phase);
        float doubleStride = Mth.sin(phase * 2.0F);

        // State-specific cadence is integrated in CatVisualState so changing states cannot phase-jump.
        // Creep = long planted stance/low clearance. Walk = four-beat feline gait. Run = longer,
        // higher bound with hind drive followed by fore catch-up.
        float strideEnergy = creepN * 0.58F + walkN + runN * 1.36F;
        float liftEnergy = creepN * 0.52F + walkN + runN * 1.22F;
        float stanceFraction = creepN * 0.76F + walkN * 0.68F + runN * 0.50F;

        final float spineFlex = doubleStride * (0.012F * creepN + 0.030F * walkN + 0.046F * runN) * gait;
        final float pelvisRoll = stride * (0.010F * creepN + 0.018F * walkN + 0.030F * runN) * gait;
        final float shoulderRoll = -stride * (0.014F * creepN + 0.026F * walkN + 0.036F * runN) * gait;
        final float weightShift = Mth.sin(phase + 0.65F)
                * (0.050F * creepN + 0.085F * walkN + 0.115F * runN) * gait;
        final float stepBob = (0.5F - 0.5F * Mth.cos(phase * 2.0F))
                * (0.040F * creepN + 0.100F * walkN + 0.155F * runN) * gait;
        final float creepCrouch = visual.creep * movementGate;
        final float runStretch = visual.run * movementGate;

        // This parent is outside CreeperModel's vanilla animation set, so super.setupAnim() never
        // resets it. Rest poses intentionally translate/roll the waist; without an explicit reset
        // those offsets accumulate every rendered frame and rapidly move the entire Cat rig out of
        // view. Always restore the authored bind pose before applying the current frame.
        waist.resetPose();
        body.resetPose();
        body.y += CatCreeperSourceAnimation.bodyYOffset(seconds);
        body.x += weightShift;
        body.y += stepBob + creepCrouch * 0.24F - runStretch * 0.05F + visual.swell * 0.18F + visual.sit * 0.85F;
        body.xRot -= (0.010F * creepN + 0.018F * walkN + 0.026F * runN) * gait + spineFlex * 0.55F;
        body.xRot += visual.swell * 0.035F + visual.sit * 0.080F;
        body.zRot += pelvisRoll;

        upper.resetPose();
        upper.x += CatCreeperSourceAnimation.upperXOffset(seconds);
        upper.y += CatCreeperSourceAnimation.upperYOffset(seconds);
        upper.x -= weightShift * 0.72F;
        upper.y += creepCrouch * 0.18F + visual.sit * 0.35F;
        upper.xRot += spineFlex + visual.swell * 0.065F - visual.sit * 0.035F;
        upper.zRot += CatCreeperSourceAnimation.upperZRot(seconds);
        upper.zRot += shoulderRoll;

        catHead.resetPose();
        catHead.yRot += netHeadYaw * deg;
        catHead.xRot += headPitch * deg;
        catHead.xRot -= spineFlex * 0.82F + visual.swell * 0.045F;
        catHead.y += stepBob * 0.22F + creepCrouch * 0.08F + visual.sit * 0.25F;
        
        catHead.zRot += CatCreeperSourceAnimation.headZRot(seconds);
        catHead.zRot -= shoulderRoll * 0.62F;

        ModelPart breast = child(upper, "Breast");
        if (breast != null) {
            breast.resetPose();
            breast.xRot += CatCreeperSourceAnimation.breastXRot(seconds);
            breast.xRot += doubleStride * (0.008F * creepN + 0.018F * walkN + 0.026F * runN) * gait;
        }

        ModelPart tail = child(body, "tail");
        ModelPart tail2 = tail == null ? null : child(tail, "tail2");
        if (tail != null) {
            tail.resetPose();
            tail.xRot += CatCreeperSourceAnimation.tailXRot(seconds);
            tail.xRot += Mth.sin(phase - 0.45F) * (0.028F * creepN + 0.050F * walkN + 0.070F * runN) * gait;
            tail.xRot += visual.swell * 0.10F - visual.sit * 0.12F;
            tail.yRot += Mth.sin(phase - 0.70F) * (0.035F * creepN + 0.055F * walkN + 0.080F * runN) * gait;
            if (tail2 != null) {
                tail2.resetPose();
                tail2.xRot += CatCreeperSourceAnimation.tail2XRot(seconds);
                tail2.xRot += Mth.sin(phase - 1.08F) * (0.070F * creepN + 0.115F * walkN + 0.155F * runN) * gait;
                tail2.xRot += visual.swell * 0.06F - visual.sit * 0.18F;
                tail2.yRot += Mth.sin(phase - 1.30F) * (0.060F * creepN + 0.095F * walkN + 0.130F * runN) * gait;
            }
        }

        ModelPart ears = child(catHead, "Ears");
        ModelPart earL = ears == null ? null : child(ears, "earL");
        ModelPart earR = ears == null ? null : child(ears, "earL2");
        if (earL != null) {
            earL.resetPose();
            earL.zRot += CatCreeperSourceAnimation.earLZRot(seconds);
            earL.zRot += doubleStride * 0.012F * gait + visual.swell * 0.11F;
        }
        if (earR != null) {
            earR.resetPose();
            earR.zRot += CatCreeperSourceAnimation.earRZRot(seconds);
            earR.zRot -= doubleStride * 0.012F * gait + visual.swell * 0.11F;
        }

        // Four-beat walk offsets blend into a feline bound at run speed. The slight left/right
        // separation in the run offsets prevents both legs on one end from occupying the same volume.
        float lhPhase = phase + lerpAngle(0.0F, 0.00F, runN);
        float lfPhase = phase + lerpAngle((float)Math.PI * 0.5F, (float)Math.PI * 0.96F, runN);
        float rhPhase = phase + lerpAngle((float)Math.PI, (float)Math.PI * 0.28F, runN);
        float rfPhase = phase + lerpAngle((float)Math.PI * 1.5F, (float)Math.PI * 1.24F, runN);

        animateCatLegIk(child(waist, "leftLeg"), "leftlegsub2", "leftfoot3", lfPhase,
                movement, gait, stanceFraction, strideEnergy, liftEnergy, false);
        animateCatLegIk(child(waist, "rightLeg"), "rightlegsub2", "rightfoot3", rfPhase,
                movement, gait, stanceFraction, strideEnergy, liftEnergy, false);
        animateCatLegIk(child(waist, "leftLegback"), "leftlegsub", "leftfoot2", lhPhase,
                movement, gait, stanceFraction, strideEnergy, liftEnergy, true);
        animateCatLegIk(child(waist, "rightLegback"), "rightlegsub", "rightfoot2", rhPhase,
                movement, gait, stanceFraction, strideEnergy, liftEnergy, true);

        if (visual.sit > 0.001F) {
            if (visual.restSit > 0.001F) {
                applyCatSitPose(waist, body, upper, catHead, visual.restSit, restVariant);
            }
            if (visual.sit2 > 0.001F) {
                applyCatSit2Pose(waist, body, upper, catHead, visual.sit2, restVariant);
            }
            if (visual.loaf > 0.001F) {
                applyCatLoafPose(waist, body, upper, catHead, visual.loaf, restVariant);
            }
            if (visual.sideLie > 0.001F) {
                applyCatSideLiePose(waist, body, upper, catHead, visual.sideLie, restVariant);
            }
            if (visual.sprawl > 0.001F) {
                applyCatSprawlPose(waist, body, upper, catHead, visual.sprawl, restVariant);
            }
            applyCatRestTailPose(entity, tail, tail2, visual, restVariant);
            animateCatRestTailLife(entity, tail, tail2, ageInTicks, visual, restVariant);
        }

        float idleGate = entity.getCatMotionState() == CatCreeperMotionState.SIT
                ? Mth.clamp(visual.sit, 0.0F, 1.0F)
                : Mth.clamp(1.0F - visual.creep - visual.walk - visual.run - visual.swell - visual.sit, 0.0F, 1.0F);
        if (idleGate > 0.001F) {
            animateCatPersonalityIdle(entity, waist, body, catHead, tail, tail2, earL, earR, ageInTicks, idleGate);
        }

        float blinkAmount = CatCreeperSourceAnimation.blinkPulse(seconds);
        setEyeBlink(child(catHead, "eye1"), blinkAmount);
        setEyeBlink(child(catHead, "eye2"), blinkAmount);
    }

    private static void animateCatLegIk(ModelPart leg, String lowerName, String footName,
                                        float legPhase, float movement, float gait,
                                        float stanceFraction, float strideEnergy, float liftEnergy,
                                        boolean hind) {
        if (leg == null) return;
        ModelPart lower = child(leg, lowerName);
        ModelPart foot = child(lower, footName);
        if (lower == null || foot == null) return;

        leg.resetPose();
        lower.resetPose();
        foot.resetPose();
        if (gait <= 0.0001F) return;

        final float tau = (float)(Math.PI * 2.0);
        float wrapped = legPhase % tau;
        if (wrapped < 0.0F) wrapped += tau;
        float u = wrapped / tau;

        final float strideLength = (hind ? 2.45F : 2.15F) * movement * strideEnergy;
        final float groundReach = hind ? 9.68F : 7.72F;
        final float liftHeight = (hind ? 1.52F : 1.30F) * (0.45F + 0.55F * movement) * liftEnergy;
        float targetZ;
        float targetY;

        if (u < stanceFraction) {
            float p = smooth01(u / stanceFraction);
            targetZ = Mth.lerp(p, -strideLength * 0.5F, strideLength * 0.5F);
            targetY = groundReach + Mth.sin(p * (float)Math.PI) * 0.040F * gait;
        } else {
            float p = smooth01((u - stanceFraction) / (1.0F - stanceFraction));
            float arc = Mth.sin(p * (float)Math.PI);
            targetZ = Mth.lerp(p, strideLength * 0.5F, -strideLength * 0.5F);
            targetY = groundReach - liftHeight * (float)Math.pow(Math.max(0.0F, arc), 1.15F);
        }

        final float upperDy = 5.25F;
        final float upperDz = 1.75F;
        final float lowerDy = hind ? 5.05F : 3.00F;
        final float lowerDz = hind ? -0.25F : 0.00F;
        final float l1 = Mth.sqrt(upperDy * upperDy + upperDz * upperDz);
        final float l2 = Mth.sqrt(lowerDy * lowerDy + lowerDz * lowerDz);
        final float a1 = (float)Math.atan2(upperDz, upperDy);
        final float a2 = (float)Math.atan2(lowerDz, lowerDy);

        float distance = Mth.sqrt(targetY * targetY + targetZ * targetZ);
        distance = Mth.clamp(distance, Math.abs(l1 - l2) + 0.08F, l1 + l2 - 0.08F);
        float cosKnee = Mth.clamp((distance * distance - l1 * l1 - l2 * l2) / (2.0F * l1 * l2), -1.0F, 1.0F);
        float knee = (float)Math.acos(cosKnee);
        float targetAngle = (float)Math.atan2(targetZ, targetY);
        float upperAngle = targetAngle - (float)Math.atan2(l2 * Mth.sin(knee), l1 + l2 * Mth.cos(knee)) - a1;
        float lowerAngle = knee + a1 - a2;

        // Expanded just enough for the run bound, still far inside the screenshot-style fold that
        // motivated the 1.4.7 hard gate. Collision QA samples the actual distal geometry as backup.
        upperAngle = Mth.clamp(upperAngle, hind ? -1.02F : -0.96F, hind ? 0.24F : 0.26F);
        lowerAngle = Mth.clamp(lowerAngle, hind ? 0.38F : 0.36F, hind ? 1.42F : 1.36F);
        float pawAngle = Mth.clamp(-(upperAngle + lowerAngle), -0.92F, 0.46F);

        leg.xRot = upperAngle;
        lower.xRot = lowerAngle;
        foot.xRot = pawAngle;
    }

    private static void applyCatSitPose(ModelPart waist, ModelPart body, ModelPart upper, ModelPart head,
                                        float amount, int variant) {
        int style = Math.floorMod(variant, 4);
        if (waist != null) {
            // Ground-calibrated from the standing paw plane: this lowers the tucked legs without
            // sinking the torso into the block below.
            waist.y += 0.61F * amount;
        }
        if (body != null) {
            body.y += 0.82F * amount;
            body.xRot += 0.09F * amount;
        }
        if (upper != null) {
            upper.y += 0.16F * amount;
            upper.xRot -= 0.07F * amount;
        }
        if (head != null) {
            head.xRot -= 0.01F * amount;
            if (style == 1) head.xRot += 0.06F * amount;
            else if (style == 2) head.zRot += 0.055F * amount;
            else if (style == 3) head.yRot += 0.085F * amount;
        }

        // 1.4.15: static two-link IK instead of hand-picked angles. Front paws stay underneath the
        // chest while the longer rear legs fold into the haunches rather than shooting forward.
        poseCatRestLegIk(child(waist, "leftLeg"), "leftlegsub2", "leftfoot3", amount,
                7.50F, -0.05F, false, 0.12F, 0.25F, 0.0F, 0.0F, 0.03F);
        poseCatRestLegIk(child(waist, "rightLeg"), "rightlegsub2", "rightfoot3", amount,
                7.50F, -0.05F, false, -0.12F, 0.25F, 0.0F, 0.0F, -0.03F);
        poseCatRestLegIk(child(waist, "leftLegback"), "leftlegsub", "leftfoot2", amount,
                8.83F, 1.05F, true, 0.62F, 0.55F, -0.55F, 0.0F, 0.22F);
        poseCatRestLegIk(child(waist, "rightLegback"), "rightlegsub", "rightfoot2", amount,
                8.83F, 1.05F, true, -0.62F, 0.55F, -0.55F, 0.0F, -0.22F);
    }

    private static void applyCatLoafPose(ModelPart waist, ModelPart body, ModelPart upper, ModelPart head,
                                         float amount, int variant) {
        int style = Math.floorMod(variant, 2);
        if (waist != null) {
            waist.y += 0.70F * amount;
            waist.xRot += 0.25F * amount;
        }
        if (body != null) {
            body.y += 1.75F * amount;
            body.xRot += 0.45F * amount;
        }
        if (upper != null) {
            upper.y += 0.65F * amount;
            // Counter most of the body fold so the neck/head remain pleasantly alert while the
            // torso settles into the compact loaf silhouette.
            upper.xRot -= 0.47F * amount;
        }
        if (head != null) {
            head.y += 0.15F * amount;
            head.xRot -= 0.23F * amount;
            head.zRot += (style == 0 ? 0.025F : -0.025F) * amount;
        }

        // Paws are tucked under the chest/hips with deeper, anatomically continuous bends.
        poseCatRestLegIk(child(waist, "leftLeg"), "leftlegsub2", "leftfoot3", amount,
                5.45F, 1.55F, false, 0.22F, 0.65F, 0.60F, 0.0F, 0.08F);
        poseCatRestLegIk(child(waist, "rightLeg"), "rightlegsub2", "rightfoot3", amount,
                5.45F, 1.55F, false, -0.22F, 0.65F, 0.60F, 0.0F, -0.08F);
        poseCatRestLegIk(child(waist, "leftLegback"), "leftlegsub", "leftfoot2", amount,
                8.15F, -0.45F, true, 0.40F, 0.80F, -0.40F, 0.0F, 0.10F);
        poseCatRestLegIk(child(waist, "rightLegback"), "rightlegsub", "rightfoot2", amount,
                8.15F, -0.45F, true, -0.40F, 0.80F, -0.40F, 0.0F, -0.10F);
    }

    private static void applyCatSideLiePose(ModelPart waist, ModelPart body, ModelPart upper, ModelPart head,
                                            float amount, int variant) {
        int style = Math.floorMod(variant, 4);
        float roll = switch (style) {
            case 1 -> 0.86F;
            case 2 -> 0.80F;
            case 3 -> 0.84F;
            default -> 0.82F;
        };
        // Measured against the standing paw-bottom ground plane. The side-rested hips/legs stay
        // grounded while the chest/head are independently straightened into a comfortable Creeper-like
        // alert posture.
        float groundOffset = switch (style) {
            case 1 -> -3.8517F;
            case 2 -> -2.5893F;
            case 3 -> -3.0833F;
            default -> -2.8239F;
        };

        // 1.4.14 upright alert-rest refinement. The waist keeps the horse-rest roll for the lower
        // body and side-folded legs, but the torso cancels nearly all of that roll. Only a tiny
        // natural lean remains so she looks comfortable and recognizably Creeper-like rather than
        // tipped over.
        float bodyLean = switch (style) {
            case 1 -> 0.040F;
            case 2 -> 0.060F;
            case 3 -> 0.025F;
            default -> 0.050F;
        };
        float upperLean = switch (style) {
            case 1 -> 0.020F;
            case 2 -> 0.030F;
            case 3 -> 0.010F;
            default -> 0.025F;
        };
        float headLean = switch (style) {
            case 1 -> 0.006F;
            case 2 -> 0.010F;
            case 3 -> 0.002F;
            default -> 0.008F;
        };
        float bodyPitch = switch (style) {
            case 1 -> 0.10F;
            case 2 -> 0.14F;
            case 3 -> 0.08F;
            default -> 0.12F;
        };
        float upperPitch = switch (style) {
            case 1 -> -0.08F;
            case 2 -> -0.10F;
            case 3 -> -0.07F;
            default -> -0.09F;
        };
        float headPitch = switch (style) {
            case 1 -> 0.000F;
            case 2 -> 0.015F;
            case 3 -> -0.005F;
            default -> 0.010F;
        };
        float upperDrop = switch (style) {
            case 1 -> 0.27F;
            case 2 -> 0.31F;
            case 3 -> 0.23F;
            default -> 0.29F;
        };

        if (waist != null) {
            waist.y += groundOffset * amount;
            waist.zRot += roll * amount;
        }
        if (body != null) {
            body.y += 1.15F * amount;
            body.xRot += bodyPitch * amount;
            body.zRot += (-roll + bodyLean) * amount;
        }
        if (upper != null) {
            upper.y += upperDrop * amount;
            upper.xRot += upperPitch * amount;
            upper.zRot += (upperLean - bodyLean) * amount;
        }
        if (head != null) {
            float headDrop = switch (style) {
                case 1 -> -0.02F;
                case 2 -> 0.08F;
                case 3 -> -0.28F;
                default -> -0.08F;
            };
            float headYaw = switch (style) {
                case 1 -> 0.16F;
                case 2 -> 0.12F;
                case 3 -> 0.22F;
                default -> 0.14F;
            };
            head.y += headDrop * amount;
            head.xRot += headPitch * amount;
            head.yRot += headYaw * amount;
            head.zRot += (headLean - upperLean) * amount;
        }

        switch (style) {
            case 1 -> {
                // Extended foreleg: closest to the reference horse with one foreleg reaching out.
                poseCatRestLeg(child(waist, "leftLeg"), "leftlegsub2", "leftfoot3", amount,
                        2.80F, 1.30F, -2.20F, 0.05F, -0.24F, 0.86F, 0.38F, -0.05F);
                poseCatRestLeg(child(waist, "rightLeg"), "rightlegsub2", "rightfoot3", amount,
                        4.40F, 1.80F, -0.20F, -0.65F, -0.10F, 0.52F, 1.42F, -0.38F);
                poseCatRestLeg(child(waist, "leftLegback"), "leftlegsub", "leftfoot2", amount,
                        3.00F, 1.60F, 1.60F, 0.62F, 0.12F, 0.96F, 1.46F, -0.48F);
                poseCatRestLeg(child(waist, "rightLegback"), "rightlegsub", "rightfoot2", amount,
                        4.70F, 1.90F, 0.50F, 0.30F, 0.06F, 0.62F, 1.28F, -0.30F);
            }
            case 2 -> {
                // Sleepy rest: same grounded layout with a softer head and more folded limbs.
                poseCatRestLeg(child(waist, "leftLeg"), "leftlegsub2", "leftfoot3", amount,
                        1.80F, 1.40F, -1.20F, -0.22F, -0.16F, 0.70F, 0.78F, -0.18F);
                poseCatRestLeg(child(waist, "rightLeg"), "rightlegsub2", "rightfoot3", amount,
                        3.80F, 1.80F, -0.20F, -0.62F, -0.08F, 0.50F, 1.38F, -0.35F);
                poseCatRestLeg(child(waist, "leftLegback"), "leftlegsub", "leftfoot2", amount,
                        2.80F, 1.70F, 1.80F, 0.70F, 0.12F, 1.02F, 1.50F, -0.52F);
                poseCatRestLeg(child(waist, "rightLegback"), "rightlegsub", "rightfoot2", amount,
                        4.60F, 2.00F, 0.70F, 0.34F, 0.05F, 0.62F, 1.30F, -0.32F);
            }
            case 3 -> {
                // Alert rest: head highest, legs still unmistakably resting to the side.
                poseCatRestLeg(child(waist, "leftLeg"), "leftlegsub2", "leftfoot3", amount,
                        2.40F, 1.20F, -1.80F, -0.02F, -0.22F, 0.78F, 0.46F, -0.08F);
                poseCatRestLeg(child(waist, "rightLeg"), "rightlegsub2", "rightfoot3", amount,
                        4.20F, 1.60F, -0.50F, -0.52F, -0.12F, 0.58F, 1.25F, -0.30F);
                poseCatRestLeg(child(waist, "leftLegback"), "leftlegsub", "leftfoot2", amount,
                        2.50F, 1.50F, 1.30F, 0.50F, 0.14F, 0.88F, 1.36F, -0.40F);
                poseCatRestLeg(child(waist, "rightLegback"), "rightlegsub", "rightfoot2", amount,
                        4.40F, 1.80F, 0.40F, 0.25F, 0.06F, 0.60F, 1.20F, -0.28F);
            }
            default -> {
                // Calm head-up horse rest.
                poseCatRestLeg(child(waist, "leftLeg"), "leftlegsub2", "leftfoot3", amount,
                        2.00F, 1.40F, -1.60F, -0.10F, -0.20F, 0.72F, 0.50F, -0.10F);
                poseCatRestLeg(child(waist, "rightLeg"), "rightlegsub2", "rightfoot3", amount,
                        4.00F, 1.70F, -0.40F, -0.58F, -0.10F, 0.54F, 1.35F, -0.35F);
                poseCatRestLeg(child(waist, "leftLegback"), "leftlegsub", "leftfoot2", amount,
                        2.40F, 1.60F, 1.20F, 0.55F, 0.12F, 0.82F, 1.40F, -0.45F);
                poseCatRestLeg(child(waist, "rightLegback"), "rightlegsub", "rightfoot2", amount,
                        4.30F, 1.80F, 0.40F, 0.28F, 0.06F, 0.60F, 1.25F, -0.30F);
            }
        }
    }

    private static void applyCatSit2Pose(ModelPart waist, ModelPart body, ModelPart upper, ModelPart head,
                                         float amount, int variant) {
        // 1.4.15 SPRAWL is preserved verbatim as the alternate owner-command sitting option.
        float side = Math.floorMod(variant, 2) == 0 ? 1.0F : -1.0F;
        if (waist != null) {
            waist.y += 0.89F * amount;
        }
        if (body != null) {
            body.y += 1.40F * amount;
            body.xRot += 0.16F * amount;
        }
        if (upper != null) {
            upper.y += 0.28F * amount;
            upper.xRot -= 0.08F * amount;
        }
        if (head != null) {
            head.xRot += 0.01F * amount;
            head.zRot += side * 0.035F * amount;
        }
        poseCatRestLegIk(child(waist, "leftLeg"), "leftlegsub2", "leftfoot3", amount,
                6.90F, -1.60F, false, 1.50F, 0.35F, 0.0F, 0.18F, 0.42F);
        poseCatRestLegIk(child(waist, "rightLeg"), "rightlegsub2", "rightfoot3", amount,
                6.90F, -1.60F, false, -1.50F, 0.35F, 0.0F, -0.18F, -0.42F);
        // Ground the rear paws without moving the hip pivots: extend the hind-leg IK reach just
        // enough for both rear feet to settle onto the same Minecraft floor plane as the forepaws.
        poseCatRestLegIk(child(waist, "leftLegback"), "leftlegsub", "leftfoot2", amount,
                8.72F, 1.60F, true, 2.00F, 0.50F, 0.0F, 0.08F, 0.42F);
        poseCatRestLegIk(child(waist, "rightLegback"), "rightlegsub", "rightfoot2", amount,
                8.72F, 1.60F, true, -2.00F, 0.50F, 0.0F, -0.08F, -0.42F);
    }

    private static void applyCatSprawlPose(ModelPart waist, ModelPart body, ModelPart upper, ModelPart head,
                                           float amount, int variant) {
        // Full goofy sploot: forelegs reach straight forward, hind legs reach straight backward,
        // and all four chains stay almost parallel to the ground instead of hanging down.
        float side = Math.floorMod(variant, 2) == 0 ? 1.0F : -1.0F;
        if (waist != null) {
            waist.y += 6.28F * amount;
        }
        if (body != null) {
            body.y += 0.30F * amount;
            body.xRot += 1.48F * amount;
        }
        if (upper != null) {
            upper.y += 0.05F * amount;
            upper.xRot -= 1.18F * amount;
        }
        if (head != null) {
            head.xRot -= 0.28F * amount;
            head.zRot += side * 0.020F * amount;
        }

        ModelPart leftFront = child(waist, "leftLeg");
        ModelPart rightFront = child(waist, "rightLeg");
        ModelPart leftHind = child(waist, "leftLegback");
        ModelPart rightHind = child(waist, "rightLegback");
        if (leftHind != null) leftHind.y += 1.35F * amount;
        if (rightHind != null) rightHind.y += 1.35F * amount;
        // Keep the straight foreleg chains on the floor without burying the lower segment: rotate
        // only the terminal paw down to the contact plane instead of translating the whole leg root.
        poseCatLegAdvanced(leftFront, "leftlegsub2", "leftfoot3", amount,
                -1.46F, 0.02F, 0.30F, 0.0F, 0.03F);
        poseCatLegAdvanced(rightFront, "rightlegsub2", "rightfoot3", amount,
                -1.46F, 0.02F, 0.30F, 0.0F, -0.03F);
        poseCatLegAdvanced(leftHind, "leftlegsub", "leftfoot2", amount,
                1.34F, 0.02F, -0.02F, 0.0F, 0.015F);
        poseCatLegAdvanced(rightHind, "rightlegsub", "rightfoot2", amount,
                1.34F, 0.02F, -0.02F, 0.0F, -0.015F);
    }

    private static void poseCatLeg(ModelPart leg, String lowerName, String footName, float amount,
                                   float upperTarget, float lowerTarget, float pawTarget) {
        poseCatLegAdvanced(leg, lowerName, footName, amount, upperTarget, lowerTarget, pawTarget, 0.0F, 0.0F);
    }

    private static void poseCatLegAdvanced(ModelPart leg, String lowerName, String footName, float amount,
                                           float upperTarget, float lowerTarget, float pawTarget,
                                           float yawTarget, float rollTarget) {
        if (leg == null) return;
        ModelPart lower = child(leg, lowerName);
        ModelPart foot = child(lower, footName);
        if (lower == null || foot == null) return;
        leg.xRot = Mth.lerp(amount, leg.xRot, upperTarget);
        leg.yRot = Mth.lerp(amount, leg.yRot, yawTarget);
        leg.zRot = Mth.lerp(amount, leg.zRot, rollTarget);
        lower.xRot = Mth.lerp(amount, lower.xRot, lowerTarget);
        foot.xRot = Mth.lerp(amount, foot.xRot, pawTarget);
    }

    private static void poseCatRestLegIk(ModelPart leg, String lowerName, String footName, float amount,
                                         float targetY, float targetZ, boolean hind,
                                         float xOffset, float yOffset, float zOffset,
                                         float yawTarget, float rollTarget) {
        if (leg == null) return;
        ModelPart lower = child(leg, lowerName);
        ModelPart foot = child(lower, footName);
        if (lower == null || foot == null) return;

        final float upperDy = 5.25F;
        final float upperDz = 1.75F;
        final float lowerDy = hind ? 5.05F : 3.00F;
        final float lowerDz = hind ? -0.25F : 0.00F;
        final float l1 = Mth.sqrt(upperDy * upperDy + upperDz * upperDz);
        final float l2 = Mth.sqrt(lowerDy * lowerDy + lowerDz * lowerDz);
        final float a1 = (float)Math.atan2(upperDz, upperDy);
        final float a2 = (float)Math.atan2(lowerDz, lowerDy);

        float distance = Mth.sqrt(targetY * targetY + targetZ * targetZ);
        distance = Mth.clamp(distance, Math.abs(l1 - l2) + 0.08F, l1 + l2 - 0.08F);
        float cosKnee = Mth.clamp((distance * distance - l1 * l1 - l2 * l2) / (2.0F * l1 * l2), -1.0F, 1.0F);
        float knee = (float)Math.acos(cosKnee);
        float targetAngle = (float)Math.atan2(targetZ, targetY);
        float upperAngle = targetAngle - (float)Math.atan2(l2 * Mth.sin(knee), l1 + l2 * Mth.cos(knee)) - a1;
        float lowerAngle = knee + a1 - a2;
        float pawAngle = -(upperAngle + lowerAngle);

        leg.x += xOffset * amount;
        leg.y += yOffset * amount;
        leg.z += zOffset * amount;
        leg.xRot = Mth.lerp(amount, leg.xRot, upperAngle);
        leg.yRot = Mth.lerp(amount, leg.yRot, yawTarget);
        leg.zRot = Mth.lerp(amount, leg.zRot, rollTarget);
        lower.xRot = Mth.lerp(amount, lower.xRot, lowerAngle);
        foot.xRot = Mth.lerp(amount, foot.xRot, pawAngle);
    }


    private static void poseCatRestLeg(ModelPart leg, String lowerName, String footName, float amount,
                                       float xOffset, float yOffset, float zOffset,
                                       float upperTarget, float yawTarget, float rollTarget,
                                       float lowerTarget, float pawTarget) {
        if (leg == null) return;
        ModelPart lower = child(leg, lowerName);
        ModelPart foot = child(lower, footName);
        if (lower == null || foot == null) return;
        leg.x += xOffset * amount;
        leg.y += yOffset * amount;
        leg.z += zOffset * amount;
        leg.xRot = Mth.lerp(amount, leg.xRot, upperTarget);
        leg.yRot = Mth.lerp(amount, leg.yRot, yawTarget);
        leg.zRot = Mth.lerp(amount, leg.zRot, rollTarget);
        lower.xRot = Mth.lerp(amount, lower.xRot, lowerTarget);
        foot.xRot = Mth.lerp(amount, foot.xRot, pawTarget);
    }


    private static void applyCatRestTailPose(CreeperellaEntity entity, ModelPart tail, ModelPart tail2,
                                             CatVisualState visual, int variant) {
        if (tail == null) return;

        if (visual.restSit > 0.001F) {
            float amount = visual.restSit;
            float side = ((entity.getId() & 1) == 0) ? 1.0F : -1.0F;
            tail.z = Mth.lerp(amount, tail.z, tail.z + 0.08F);
            tail.xRot = Mth.lerp(amount, tail.xRot, 0.40F);
            tail.yRot = Mth.lerp(amount, tail.yRot, 0.0F);
            if (tail2 != null) {
                tail2.xRot = Mth.lerp(amount, tail2.xRot, 0.82F);
                tail2.yRot = Mth.lerp(amount, tail2.yRot, side * 0.20F);
            }
        }

        if (visual.loaf > 0.001F) {
            float amount = visual.loaf;
            float side = Math.floorMod(variant, 2) == 0 ? 1.0F : -1.0F;
            tail.z = Mth.lerp(amount, tail.z, tail.z + 0.02F);
            tail.xRot = Mth.lerp(amount, tail.xRot, 0.52F);
            tail.yRot = Mth.lerp(amount, tail.yRot, side * 0.12F);
            if (tail2 != null) {
                tail2.xRot = Mth.lerp(amount, tail2.xRot, 1.02F);
                tail2.yRot = Mth.lerp(amount, tail2.yRot, side * 0.28F);
            }
        }

        if (visual.sideLie > 0.001F) {
            float amount = visual.sideLie;
            // Keep the already-approved 1.4.14 horse-rest tail unchanged.
            tail.xRot = Mth.lerp(amount, tail.xRot, 0.28F);
            tail.yRot = Mth.lerp(amount, tail.yRot, -0.08F);
            if (tail2 != null) {
                tail2.xRot = Mth.lerp(amount, tail2.xRot, 0.58F);
                tail2.yRot = Mth.lerp(amount, tail2.yRot, -0.04F);
            }
        }


        if (visual.sit2 > 0.001F) {
            float amount = visual.sit2;
            float side = Math.floorMod(variant, 2) == 0 ? 1.0F : -1.0F;
            // Exact 1.4.15 SPRAWL tail, preserved with the renamed Sit 2 pose.
            tail.z = Mth.lerp(amount, tail.z, tail.z + 0.16F);
            tail.xRot = Mth.lerp(amount, tail.xRot, 0.24F);
            tail.yRot = Mth.lerp(amount, tail.yRot, 0.0F);
            if (tail2 != null) {
                tail2.xRot = Mth.lerp(amount, tail2.xRot, 0.50F);
                tail2.yRot = Mth.lerp(amount, tail2.yRot, side * 0.10F);
            }
        }

        if (visual.sprawl > 0.001F) {
            float amount = visual.sprawl;
            // The sploot tail trails straight back between the extended hind legs with a very soft bend.
            tail.z = Mth.lerp(amount, tail.z, tail.z + 0.10F);
            tail.xRot = Mth.lerp(amount, tail.xRot, -0.50F);
            tail.yRot = Mth.lerp(amount, tail.yRot, 0.0F);
            if (tail2 != null) {
                tail2.xRot = Mth.lerp(amount, tail2.xRot, -0.15F);
                tail2.yRot = Mth.lerp(amount, tail2.yRot, 0.0F);
            }
        }
    }

    private static void animateCatRestTailLife(CreeperellaEntity entity, ModelPart tail, ModelPart tail2,
                                               float ageInTicks, CatVisualState visual, int variant) {
        if (tail == null) return;

        // Always-on, low-amplitude cat-like tail life layered over each correct static rest pose.
        // The root moves less than the tip; two incommensurate phases avoid a mechanical dog-wag loop.
        float seed = (entity.getId() & 31) * 0.37F + variant * 0.61F;
        float slow = Mth.sin(ageInTicks * 0.085F + seed);
        float drift = Mth.sin(ageInTicks * 0.137F + seed * 1.63F + 0.80F);
        float tipWave = slow * 0.72F + drift * 0.28F;
        float tipPitch = Mth.sin(ageInTicks * 0.103F + seed + 1.15F);

        float rootYawAmp = visual.restSit * 0.040F
                + visual.loaf * 0.016F
                + visual.sideLie * 0.012F
                + visual.sit2 * 0.032F
                + visual.sprawl * 0.012F;
        float tipYawAmp = visual.restSit * 0.105F
                + visual.loaf * 0.050F
                + visual.sideLie * 0.040F
                + visual.sit2 * 0.085F
                + visual.sprawl * 0.045F;
        float tipPitchAmp = visual.restSit * 0.010F
                + visual.loaf * 0.005F
                + visual.sideLie * 0.004F
                + visual.sit2 * 0.008F
                + visual.sprawl * 0.005F;

        tail.yRot += tipWave * rootYawAmp;
        if (tail2 != null) {
            tail2.yRot += tipWave * tipYawAmp;
            tail2.xRot += tipPitch * tipPitchAmp;
        }
    }

    private void animateCatPersonalityIdle(T entity, ModelPart waist, ModelPart body, ModelPart head,
                                           ModelPart tail, ModelPart tail2, ModelPart earL, ModelPart earR,
                                           float ageInTicks, float idleGate) {
        CatCreeperIdleAnimation idle = entity.getCatIdleAnimation();
        if (idle == CatCreeperIdleAnimation.NONE || idle.durationTicks() <= 0) return;

        float elapsed = entity.getCatAnimationElapsedTicks(ageInTicks);
        float u = Mth.clamp(elapsed / idle.durationTicks(), 0.0F, 1.0F);
        float enter = smoothStep(0.0F, 0.16F, u);
        float exit = 1.0F - smoothStep(0.82F, 1.0F, u);
        float envelope = enter * exit * idleGate;
        if (envelope <= 0.0001F) return;

        // Stable per-entity handedness means a repeated paw-lift doesn't always use the same global side,
        // but every client renders the same choice for this entity.
        boolean left = (entity.getId() & 1) == 0;
        float side = left ? 1.0F : -1.0F;
        CatCreeperRestPose restPose = entity.getCatRestPose();

        switch (idle) {
            case PAW_LIFT -> {
                // Paw-lift is safe for standing/SIT only. Pulling a support leg out of LOAF,
                // SIDE_LIE, or SPRAWL was a hidden pose-regression path in 1.4.14.
                if (restPose != CatCreeperRestPose.NONE && restPose != CatCreeperRestPose.SIT) break;
                float lift = (float)Math.pow(Mth.sin(u * (float)Math.PI), 1.20F) * envelope;
                ModelPart leg = child(waist, left ? "leftLeg" : "rightLeg");
                String lower = left ? "leftlegsub2" : "rightlegsub2";
                String foot = left ? "leftfoot3" : "rightfoot3";
                poseCatLeg(leg, lower, foot, lift, -0.58F, 0.96F, -0.34F);
                if (leg != null) leg.yRot += side * 0.055F * lift;
                body.x -= side * 0.10F * lift;
                head.zRot += side * 0.15F * lift;
                head.yRot += side * 0.07F * lift;
                if (tail != null) tail.yRot += Mth.sin(u * (float)Math.PI * 6.0F) * 0.10F * envelope;
                if (tail2 != null) tail2.yRot += Mth.sin(u * (float)Math.PI * 6.0F - 0.65F) * 0.18F * envelope;
            }
            case TAIL_WAG -> {
                // Feline tail swish: slower root, delayed/larger tip, and a tiny asymmetric flick.
                // The previous four-cycle sine read like a metronome and aliased badly in QA reels.
                float phase = u * (float)Math.PI * 4.15F;
                float rootWave = (Mth.sin(phase) * 0.82F
                        + Mth.sin(phase * 0.47F + 0.85F) * 0.18F) * envelope;
                float tipWave = (Mth.sin(phase - 0.72F) * 0.76F
                        + Mth.sin(phase * 0.51F + 0.15F) * 0.24F) * envelope;
                float flickSource = Math.max(0.0F, Mth.sin(phase * 0.53F + 1.20F));
                float flick = flickSource * flickSource * flickSource * envelope;
                if (tail != null) {
                    tail.yRot += rootWave * 0.135F;
                    tail.xRot += Mth.sin(phase * 0.50F + 0.35F) * 0.010F * envelope;
                }
                if (tail2 != null) {
                    tail2.yRot += tipWave * 0.305F + side * flick * 0.055F;
                    tail2.xRot += Mth.sin(phase - 1.05F) * 0.025F * envelope;
                }
                body.zRot += rootWave * 0.008F;
                float earTwitch = Mth.sin(phase * 0.50F + 1.55F) * 0.012F * envelope;
                if (earL != null) earL.zRot += earTwitch;
                if (earR != null) earR.zRot -= earTwitch;
            }
            case CURIOUS_LOOK -> {
                float look = Mth.sin(u * (float)Math.PI) * envelope;
                head.yRot += side * 0.30F * look;
                head.zRot += side * 0.17F * look;
                head.xRot -= 0.055F * look;
                float twitch = Mth.sin(u * (float)Math.PI * 7.0F) * envelope;
                if (earL != null) earL.zRot += (left ? 0.06F : 0.025F) * twitch;
                if (earR != null) earR.zRot -= (left ? 0.025F : 0.06F) * twitch;
                if (tail2 != null) tail2.yRot += Mth.sin(u * (float)Math.PI * 3.0F - 0.4F) * 0.11F * envelope;
            }
            case KNEAD -> {
                // Alternating paw compression rather than lifting/reopening the loaf. Each paw flexes
                // through its existing tucked pose, with tiny shoulder/body weight transfer.
                float wave = u * (float)Math.PI * 6.0F;
                float kneadPulse = Mth.sin(wave);
                float leftPress = smooth01(Math.max(0.0F, kneadPulse)) * envelope;
                float rightPress = smooth01(Math.max(0.0F, -kneadPulse)) * envelope;
                float alternating = leftPress - rightPress;
                float settle = (leftPress + rightPress) * 0.5F;

                if (restPose == CatCreeperRestPose.LOAF) {
                    ModelPart leftLeg = child(waist, "leftLeg");
                    ModelPart rightLeg = child(waist, "rightLeg");
                    ModelPart leftLower = leftLeg == null ? null : child(leftLeg, "leftlegsub2");
                    ModelPart rightLower = rightLeg == null ? null : child(rightLeg, "rightlegsub2");
                    ModelPart leftFoot = leftLower == null ? null : child(leftLower, "leftfoot3");
                    ModelPart rightFoot = rightLower == null ? null : child(rightLower, "rightfoot3");
                    if (leftLeg != null) leftLeg.xRot += leftPress * 0.035F;
                    if (rightLeg != null) rightLeg.xRot += rightPress * 0.035F;
                    if (leftLower != null) leftLower.xRot += leftPress * 0.070F;
                    if (rightLower != null) rightLower.xRot += rightPress * 0.070F;
                    if (leftFoot != null) {
                        leftFoot.xRot -= leftPress * 0.095F;
                        leftFoot.y += leftPress * 0.055F;
                    }
                    if (rightFoot != null) {
                        rightFoot.xRot -= rightPress * 0.095F;
                        rightFoot.y += rightPress * 0.055F;
                    }
                    body.x += alternating * 0.030F;
                    body.y += settle * 0.016F;
                    head.zRot -= alternating * 0.012F;
                    head.xRot += settle * 0.008F;
                } else if (restPose == CatCreeperRestPose.NONE || restPose == CatCreeperRestPose.SIT) {
                    float leftLift = leftPress * 0.72F;
                    float rightLift = rightPress * 0.72F;
                    poseCatLeg(child(waist, "leftLeg"), "leftlegsub2", "leftfoot3", leftLift,
                            -0.30F, 0.74F, -0.30F);
                    poseCatLeg(child(waist, "rightLeg"), "rightlegsub2", "rightfoot3", rightLift,
                            -0.30F, 0.74F, -0.30F);
                    body.x += alternating * 0.045F;
                    body.y += settle * 0.028F;
                    head.zRot -= alternating * 0.016F;
                    head.xRot += settle * 0.014F;
                }
                if (tail != null) tail.yRot += Mth.sin(wave * 0.34F + 0.35F) * 0.050F * envelope;
                if (tail2 != null) {
                    tail2.yRot += Mth.sin(wave * 0.34F - 0.45F) * 0.105F * envelope;
                    tail2.xRot += Mth.sin(wave * 0.17F + 0.80F) * 0.012F * envelope;
                }
            }
            default -> { }
        }
    }

    private static float smooth01(float value) {
        float x = Mth.clamp(value, 0.0F, 1.0F);
        return x * x * (3.0F - 2.0F * x);
    }

    private static float smoothStep(float edge0, float edge1, float value) {
        if (edge1 <= edge0) return value >= edge1 ? 1.0F : 0.0F;
        return smooth01((value - edge0) / (edge1 - edge0));
    }

    private static float lerpAngle(float from, float to, float alpha) {
        float tau = (float)(Math.PI * 2.0);
        float delta = (to - from) % tau;
        if (delta > Math.PI) delta -= tau;
        if (delta < -Math.PI) delta += tau;
        return from + delta * Mth.clamp(alpha, 0.0F, 1.0F);
    }

    private static void setEyeBlink(ModelPart eye, float amount) {
        if (eye == null) return;
        eye.resetPose();
        eye.yScale = Math.max(0.06F, 1.0F - amount * 0.94F);
    }

    private void animateCherryRemake(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                                     float netHeadYaw, float headPitch) {
        ModelPart vanillaBody = child(this.root(), "body");
        ModelPart cemBody = child(vanillaBody, "body");
        ModelPart rotation = child(cemBody, "body_cherry_rotation");
        ModelPart cherryBody = child(rotation, "body_cherry");
        ModelPart legs = child(rotation, "cherrycreeper_legs");
        if (vanillaBody == null || rotation == null || cherryBody == null || legs == null) return;

        final float deg = (float) Math.PI / 180.0F;
        final float idleSin = Mth.sin(ageInTicks / 7.0F);
        final float idleCos = Mth.cos(ageInTicks / 7.0F);
        final float limbSpeed = Mth.clamp(limbSwingAmount, 0.0F, 1.0F) * 10.0F;
        final float hurtTime = entity.hurtTime;
        final float hurtBlend = updateCherryHurtBlend(entity, ageInTicks);
        final float walkRx = (-Mth.sin(limbSwing) / 6.0F) * limbSpeed / 2.0F * hurtBlend;
        final float walk = Math.min(0.0F, (-Mth.sin(limbSwing + (float)Math.PI / 2.0F) + 0.3F)
                * limbSpeed / 1.5F) * hurtBlend;
        final float minusWalk = Math.min(0.0F, (Mth.sin(limbSwing + (float)Math.PI / 2.0F) + 0.3F)
                * limbSpeed / 1.5F) * hurtBlend;

        // CEM `body.ty = lerp(var.hurt, 18, 18)` targets the ORIGINAL Creeper body proxy.
        // This is easy to miss because the visible custom id=body is a child with the same name.
        // Without this source channel the whole Cherry-family rig sits 12 model units too high.
        vanillaBody.resetPose();
        vanillaBody.y = 18.0F;

        rotation.resetPose();
        rotation.zRot = -idleCos * 2.0F * deg;

        legs.resetPose();
        legs.yRot = (netHeadYaw / 6.0F) * deg;

        animateCherryLeg(child(legs, "cherrycreeper_leg1"),
                walkRx - hurtTime * 4.0F * deg,
                8.0F * deg - idleCos * 2.0F * deg + hurtTime * 3.5F * deg,
                8.0F * deg + idleSin * deg, walk);
        animateCherryLeg(child(legs, "cherrycreeper_leg2"),
                -walkRx - hurtTime * 4.0F * deg,
                -8.0F * deg + idleCos * 2.0F * deg - hurtTime * 3.5F * deg,
                -8.0F * deg - idleSin * deg, minusWalk);
        animateCherryLeg(child(legs, "cherrycreeper_leg3"),
                -walkRx - hurtTime * 4.0F * deg,
                -8.0F * deg + idleSin * 2.0F * deg + hurtTime * 3.5F * deg,
                8.0F * deg - idleCos * deg, minusWalk);
        animateCherryLeg(child(legs, "cherrycreeper_leg4"),
                walkRx - hurtTime * 4.0F * deg,
                -8.0F * deg - idleSin * 2.0F * deg - hurtTime * 3.5F * deg,
                -8.0F * deg + idleCos * deg, walk);

        cherryBody.resetPose();
        cherryBody.x = idleSin * 0.3F;
        cherryBody.y = Mth.lerp(hurtBlend, -5.95F,
                -5.95F - (Mth.sin(limbSwing) * limbSpeed / 7.0F) + limbSpeed * 0.18F);
        cherryBody.xRot = idleCos * 3.5F * deg + (headPitch / 4.0F) * deg;
        cherryBody.yRot = (netHeadYaw / 4.0F) * deg - idleCos * 2.0F * deg
                + Mth.sin(limbSwing) * hurtTime * 3.0F * deg;
        cherryBody.zRot = idleSin * 2.0F * deg + Mth.sin(limbSwing) * hurtTime * 2.0F * deg;

        ModelPart chest = child(cherryBody, "boobs");
        if (chest != null) {
            chest.resetPose();
            chest.xRot = -5.5F - idleSin * 3.0F * deg
                    + Mth.sin(limbSwing + (float)Math.PI / 4.0F) * limbSpeed / 58.0F;
            chest.yRot = Mth.cos(limbSwing) * hurtTime * 4.0F * deg;
            chest.zRot = idleCos * 6.0F * deg + Mth.sin(limbSwing) * hurtTime * 4.0F * deg;

            ModelPart bone3 = child(chest, "bone3");
            if (bone3 != null) {
                bone3.resetPose();
                bone3.xRot = -35.0F * deg + Mth.cos(limbSwing / 0.5F) * hurtTime * 6.0F * deg
                        - idleCos * 16.0F * deg;
            }
        }

        ModelPart bone9 = child(cherryBody, "bone9");
        if (bone9 != null) {
            bone9.resetPose();
            bone9.xRot = -140.0F * deg - Mth.sin(limbSwing / 0.5F) * hurtTime * 6.0F * deg
                    + idleCos * 16.0F * deg;
        }
        ModelPart bone15 = child(cherryBody, "bone15");
        if (bone15 != null) {
            bone15.resetPose();
            bone15.yRot = -120.0F * deg - Mth.sin(limbSwing / 0.5F) * hurtTime * 6.0F * deg
                    - idleCos * 6.0F * deg;
            bone15.zRot = -220.0F * deg - Mth.sin(limbSwing / 0.5F) * hurtTime * 6.0F * deg
                    - idleSin * 16.0F * deg;
        }

        ModelPart cherryHead = child(cherryBody, "head_cherry");
        if (cherryHead != null) {
            cherryHead.resetPose();
            cherryHead.x = idleSin * 16.0F * deg;
            cherryHead.y = -12.0F;
            cherryHead.xRot = idleSin * 4.0F * deg - (headPitch / 4.0F) * deg;
            cherryHead.yRot = (netHeadYaw / 2.5F) * deg + Mth.cos(limbSwing) * hurtTime * 2.5F * deg;
            cherryHead.zRot = -idleCos * 10.0F * deg + (netHeadYaw / 4.0F) * deg;
            if (this.kind == CreeperellaKind.BOOMSHROOM) {
                float greet = entity.getBoomshroomGreetingProgress(ageInTicks);
                float arc = Mth.sin(greet * (float)Math.PI);
                cherryHead.xRot += arc * 8.0F * deg;
                cherryHead.zRot -= arc * 3.5F * deg;
            }

            ModelPart hairLeft = child(cherryHead, "bone11");
            if (hairLeft != null) {
                hairLeft.resetPose();
                hairLeft.xRot = -idleCos * 6.0F * deg - Mth.sin(limbSwing) * hurtTime * 2.0F * deg;
                hairLeft.zRot = -idleSin * 6.0F * deg - Mth.cos(limbSwing) * hurtTime * 3.0F * deg;
                ModelPart bone12 = child(hairLeft, "bone12");
                if (bone12 != null) {
                    bone12.resetPose();
                    bone12.xRot = 177.0F * deg - Mth.cos(limbSwing / 0.5F) * hurtTime * 6.0F * deg;
                    bone12.zRot = 190.0F * deg + Mth.sin(limbSwing / 0.5F) * hurtTime * 8.0F * deg
                            - idleSin * 16.0F * deg;
                }
            }

            ModelPart hairRight = child(cherryHead, "bone13");
            if (hairRight != null) {
                hairRight.resetPose();
                hairRight.xRot = -idleCos * 6.0F * deg - Mth.sin(limbSwing) * hurtTime * 3.0F * deg;
                hairRight.zRot = -idleSin * 6.0F * deg - Mth.cos(limbSwing) * hurtTime * 4.0F * deg;
                ModelPart bone14 = child(hairRight, "bone14");
                if (bone14 != null) {
                    bone14.resetPose();
                    bone14.yRot = 290.0F * deg + Mth.cos(limbSwing / 0.5F) * hurtTime * 8.0F * deg;
                    bone14.zRot = -190.0F * deg + Mth.sin(limbSwing / 0.5F) * hurtTime * 6.0F * deg
                            - idleSin * 16.0F * deg;
                }
            }

            ModelPart face = child(cherryHead, "head_cherry_face");
            if (face != null) {
                // Source uses floor(time / 2.5) % 21: 18 normal frames, one transition, two blink frames.
                int frame = Mth.floor(ageInTicks / 2.5F) % 21;
                setVisible(child(face, "head_cherry_face_fr1"), frame >= 0 && frame <= 17);
                setVisible(child(face, "head_cherry_face_fr2"), frame == 18);
                setVisible(child(face, "head_cherry_face_fr3"), frame >= 19 && frame <= 20);
            }
        }

        if (this.kind == CreeperellaKind.BLOSSOM) {
            animateBlossomAccents(cherryBody, cherryHead, ageInTicks, limbSwing, limbSpeed, hurtTime);
        }
    }

    private static void animateBlossomAccents(ModelPart body, ModelPart head, float ageInTicks,
                                               float limbSwing, float limbSpeed, float hurtTime) {
        final float deg = (float) Math.PI / 180.0F;
        final float breeze = Mth.sin(ageInTicks / 9.0F);
        final float follow = Mth.sin(ageInTicks / 6.5F + 0.8F);
        final float step = Mth.sin(limbSwing) * Mth.clamp(limbSpeed / 10.0F, 0.0F, 1.0F);
        final float hurt = hurtTime * 0.35F;

        animateBlossomPetal(child(head, "blossom_crown_center"), (breeze * 2.5F - step * 1.5F) * deg, 0.0F, (follow * 3.0F + hurt) * deg);
        animateBlossomPetal(child(head, "blossom_crown_left"), (follow * 4.0F - step * 2.0F) * deg, (breeze * 2.0F) * deg, (breeze * 5.0F + hurt) * deg);
        animateBlossomPetal(child(head, "blossom_crown_right"), (follow * 4.0F + step * 2.0F) * deg, (-breeze * 2.0F) * deg, (-breeze * 5.0F - hurt) * deg);
        animateBlossomPetal(child(head, "blossom_back_bloom"), (-breeze * 4.0F + step * 2.0F) * deg, (follow * 2.5F) * deg, (follow * 3.5F) * deg);
        animateBlossomPetal(child(body, "blossom_shoulder_left"), (breeze * 4.0F + step * 3.0F) * deg, (follow * 2.0F) * deg, (follow * 5.0F) * deg);
        animateBlossomPetal(child(body, "blossom_shoulder_right"), (breeze * 4.0F - step * 3.0F) * deg, (-follow * 2.0F) * deg, (-follow * 5.0F) * deg);
        animateBlossomPetal(child(body, "blossom_hip_bloom"), (-follow * 3.0F + step * 2.0F) * deg, (breeze * 2.0F) * deg, (breeze * 4.0F) * deg);
    }

    private static void animateBlossomPetal(ModelPart part, float xRot, float yRot, float zRot) {
        if (part == null) return;
        part.resetPose();
        part.xRot += xRot;
        part.yRot += yRot;
        part.zRot += zRot;
    }

    private float updateCherryHurtBlend(T entity, float ageInTicks) {
        float target = entity.hurtTime > 0 ? 0.0F : 1.0F;
        CherryHurtState state = this.cherryHurtStates.computeIfAbsent(entity,
                ignored -> new CherryHurtState(0.0F, ageInTicks));
        float dt = Mth.clamp(ageInTicks - state.lastAge, 0.0F, 1.5F);
        state.lastAge = ageInTicks;
        float step = 0.2F * dt;
        if (state.value < target) state.value = Math.min(target, state.value + step);
        else if (state.value > target) state.value = Math.max(target, state.value - step);
        // Exact CEM expression: todeg(sin(torad(clamp(var.hurt, 0, 1)))).
        return (float)Math.toDegrees(Math.sin(Math.toRadians(Mth.clamp(state.value, 0.0F, 1.0F))));
    }

    private static void animateCherryLeg(ModelPart leg, float xRot, float yRot, float zRot, float yOffset) {
        if (leg == null) return;
        leg.resetPose();
        leg.xRot = xRot;
        leg.yRot = yRot;
        leg.zRot = zRot;
        leg.y = -6.0F + yOffset;
    }

    private static void animateLeaf(ModelPart part, float xRot, float yRot, float zRot) {
        if (part == null) return;
        part.resetPose();
        part.xRot += xRot;
        part.yRot += yRot;
        part.zRot += zRot;
    }

    public void applyBoomshroomCapAnchor(PoseStack poseStack) {
        ModelPart vanillaBody = child(this.root(), "body");
        ModelPart cemBody = child(vanillaBody, "body");
        ModelPart rotation = child(cemBody, "body_cherry_rotation");
        ModelPart cherryBody = child(rotation, "body_cherry");
        ModelPart cherryHead = child(cherryBody, "head_cherry");
        if (vanillaBody != null) vanillaBody.translateAndRotate(poseStack);
        if (cemBody != null) cemBody.translateAndRotate(poseStack);
        if (rotation != null) rotation.translateAndRotate(poseStack);
        if (cherryBody != null) cherryBody.translateAndRotate(poseStack);
        if (cherryHead != null) cherryHead.translateAndRotate(poseStack);
    }

    private void applyPresentationStyle() {
        boolean feminine = !CreeperellaClientConfig.VANILLA_FRIENDLY_BODY_STYLE.get();
        boolean froglight = this.kind == CreeperellaKind.MARIGLOW
                || this.kind == CreeperellaKind.VERDALIA
                || this.kind == CreeperellaKind.NACRELLA;

        ModelPart vanillaBody = child(this.root(), "body");
        ModelPart pieBody = child(vanillaBody, "body");
        setVisible(child(pieBody, "breasts"), feminine);

        ModelPart rotation = child(pieBody, "body_cherry_rotation");
        ModelPart cherryBody = child(rotation, "body_cherry");
        setVisible(child(cherryBody, "boobs"), feminine);

        ModelPart waist = child(this.root(), "Waist");
        ModelPart catBody = child(waist, "Body");
        ModelPart upper = child(catBody, "UpperBody");
        setVisible(child(upper, "Breast"), feminine);

        // Shared family mesh stays visible. Froglight crowns replace only the hair,
        // while native facial planes keep the same expression/animation language.
        ModelPart head2 = child(this.root(), "head", "head2");
        setVisible(head2, true);
        setVisible(pieBody, true);
        setVisible(child(this.root(), "right_hind_leg", "leg1"), true);
        setVisible(child(this.root(), "left_hind_leg", "leg2"), true);
        setVisible(child(this.root(), "right_front_leg", "leg3"), true);
        setVisible(child(this.root(), "left_front_leg", "leg4"), true);
        setVisible(child(head2, "hair_left"), !froglight);
        setVisible(child(head2, "hair_right"), !froglight);
        setVisible(child(head2, "left_eye"), !froglight);
        setVisible(child(head2, "right_eye"), !froglight);
    }

    /** Source-faithful Pie head/head2 anchor for layered Shroomboom geometry. */
    public void applyPieHeadAnchor(PoseStack poseStack) {
        ModelPart head = child(this.root(), "head");
        if (head != null) head.translateAndRotate(poseStack);
        ModelPart head2 = child(head, "head2");
        if (head2 != null) head2.translateAndRotate(poseStack);
    }

    /** Source-faithful Pie body anchor, following the animated custom body child. */
    public void applyPieBodyAnchor(PoseStack poseStack) {
        ModelPart vanillaBody = child(this.root(), "body");
        if (vanillaBody != null) vanillaBody.translateAndRotate(poseStack);
        ModelPart pieBody = child(vanillaBody, "body");
        if (pieBody != null) pieBody.translateAndRotate(poseStack);
    }

    /** Pie breast/chest anchor so attached fungi inherit the original chest animation. */
    public void applyPieBreastAnchor(PoseStack poseStack) {
        ModelPart vanillaBody = child(this.root(), "body");
        if (vanillaBody != null) vanillaBody.translateAndRotate(poseStack);
        ModelPart pieBody = child(vanillaBody, "body");
        if (pieBody != null) pieBody.translateAndRotate(poseStack);
        ModelPart breasts = child(pieBody, "breasts");
        if (breasts != null) breasts.translateAndRotate(poseStack);
    }

    /** One-based Pie leg anchor: 1 RH, 2 LH, 3 RF, 4 LF. */
    public void applyPieLegAnchor(PoseStack poseStack, int legIndex) {
        String vanillaName = switch (legIndex) {
            case 1 -> "right_hind_leg";
            case 2 -> "left_hind_leg";
            case 3 -> "right_front_leg";
            case 4 -> "left_front_leg";
            default -> null;
        };
        if (vanillaName == null) return;
        ModelPart vanillaLeg = child(this.root(), vanillaName);
        if (vanillaLeg != null) vanillaLeg.translateAndRotate(poseStack);
        ModelPart pieLeg = child(vanillaLeg, "leg" + legIndex);
        if (pieLeg != null) pieLeg.translateAndRotate(poseStack);
    }

    /** Reuse Pie's already-evaluated blink/gaze channels for reference-sized eye geometry. */
    public float referenceEyeOpenness(boolean left) {
        ModelPart eye = child(this.root(), "head", "head2", left ? "left_eye" : "right_eye");
        ModelPart white = child(eye, left ? "l_eye_white" : "r_eye_white");
        return white == null ? 1.0F : Mth.clamp(white.yScale, 0.0F, 1.0F);
    }

    public float referenceEyeGaze(boolean left) {
        ModelPart eye = child(this.root(), "head", "head2", left ? "left_eye" : "right_eye");
        ModelPart pupil = child(eye, left ? "l_pupil" : "r_pupil");
        return pupil == null ? 0.0F : pupil.x - pupil.getInitialPose().x;
    }

    public void applyNacrellaHeadAnchor(PoseStack poseStack) {
        ModelPart head = child(this.root(), "head");
        if (head != null) head.translateAndRotate(poseStack);
        ModelPart head2 = child(head, "head2");
        if (head2 != null) head2.translateAndRotate(poseStack);
    }

    public void applyNacrellaLegAnchor(PoseStack poseStack, int legIndex) {
        ModelPart leg = child(this.root(), "leg" + legIndex);
        if (leg != null) leg.translateAndRotate(poseStack);
    }

    private static void setVisible(ModelPart part, boolean visible) {
        if (part != null) part.visible = visible;
    }

    private static void animateZ(ModelPart part, float offset) {
        if (part == null) return;
        part.resetPose();
        part.zRot += offset;
    }

    private static ModelPart child(ModelPart parent, String... path) {
        ModelPart current = parent;
        try {
            for (String name : path) {
                current = current.getChild(name);
            }
            return current;
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        super.renderToBuffer(poseStack, vertexConsumer, packedLight, packedOverlay,
                red * this.tintR, green * this.tintG, blue * this.tintB, alpha);
    }
}
