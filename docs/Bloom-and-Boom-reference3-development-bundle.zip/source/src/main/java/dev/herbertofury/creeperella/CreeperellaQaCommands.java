package dev.herbertofury.creeperella;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.logging.LogUtils;
import dev.herbertofury.creeperella.entity.CatCreeperIdleAnimation;
import dev.herbertofury.creeperella.entity.CatCreeperRestPose;
import dev.herbertofury.creeperella.entity.CreeperellaEntity;
import dev.herbertofury.creeperella.entity.CreeperellaKind;
import dev.herbertofury.creeperella.registry.ModEntities;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;

/**
 * Deterministic in-game animation QA harness. These commands are operator-only and intentionally
 * separate from normal gameplay: they create labelled, non-AI Cat Creepers in a fixed grid so
 * runtime renderer captures can be compared frame-for-frame with the offline QA renderer.
 */
public final class CreeperellaQaCommands {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final String QA_TAG = "creeperella_animation_qa";

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("creeperella_qa_mariglow")
                .requires(source -> source.hasPermission(2))
                .executes(context -> spawnVariant(context.getSource(), CreeperellaKind.MARIGLOW, "MMV_QA_MARIGLOW")));
        dispatcher.register(Commands.literal("creeperella_qa_verdalia")
                .requires(source -> source.hasPermission(2))
                .executes(context -> spawnVariant(context.getSource(), CreeperellaKind.VERDALIA, "MMV_QA_VERDALIA")));
        dispatcher.register(Commands.literal("creeperella_qa_nacrella")
                .requires(source -> source.hasPermission(2))
                .executes(context -> spawnVariant(context.getSource(), CreeperellaKind.NACRELLA, "MMV_QA_NACRELLA")));
        dispatcher.register(Commands.literal("creeperella_qa_cinderella")
                .requires(source -> source.hasPermission(2))
                .executes(context -> spawnVariant(context.getSource(), CreeperellaKind.CINDERELLA, "MMV_QA_CINDERELLA")));
        dispatcher.register(Commands.literal("creeperella")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("qa")
                        .then(Commands.literal("cats")
                                .executes(context -> spawnCatGrid(context.getSource(), CatCreeperIdleAnimation.NONE))
                                .then(Commands.literal("tail_wag")
                                        .executes(context -> spawnCatGrid(context.getSource(), CatCreeperIdleAnimation.TAIL_WAG)))
                                .then(Commands.literal("knead")
                                        .executes(context -> spawnCatGrid(context.getSource(), CatCreeperIdleAnimation.KNEAD)))
                                .then(Commands.literal("curious_look")
                                        .executes(context -> spawnCatGrid(context.getSource(), CatCreeperIdleAnimation.CURIOUS_LOOK)))
                                .then(Commands.literal("paw_lift")
                                        .executes(context -> spawnCatGrid(context.getSource(), CatCreeperIdleAnimation.PAW_LIFT))))
                        .then(Commands.literal("family")
                                .executes(context -> spawnFamilyGrid(context.getSource(), false)))
                        .then(Commands.literal("cherry_family")
                                .executes(context -> spawnFamilyGrid(context.getSource(), true)))
                        .then(Commands.literal("charged_family")
                                .executes(context -> spawnChargedCherryFamily(context.getSource())))
                        .then(Commands.literal("cherry_ecology")
                                .executes(context -> verifyCherryEcology(context.getSource())))
                        .then(Commands.literal("boomshroom")
                                .executes(context -> spawnBoomshroom(context.getSource(), false)))
                        .then(Commands.literal("boomshroom_greeting")
                                .executes(context -> spawnBoomshroom(context.getSource(), true)))
                        .then(Commands.literal("charged_boomshroom")
                                .executes(context -> spawnChargedBoomshroom(context.getSource())))
                        .then(Commands.literal("boomshroom_explosion")
                                .executes(context -> primeBoomshroomExplosion(context.getSource())))
                        .then(Commands.literal("boomshroom_ecology")
                                .executes(context -> verifyBoomshroomEcology(context.getSource())))
                        .then(Commands.literal("shroomboom")
                                .executes(context -> spawnShroomboom(context.getSource(), false)))
                        .then(Commands.literal("shroomboom_motion")
                                .executes(context -> spawnShroomboom(context.getSource(), true)))
                        .then(Commands.literal("charged_shroomboom")
                                .executes(context -> spawnChargedShroomboom(context.getSource())))
                        .then(Commands.literal("legacy_blossom_alias")
                                .executes(context -> verifyLegacyBlossomAlias(context.getSource())))
                        .then(Commands.literal("clear")
                                .executes(context -> clearQaEntities(context.getSource(), true)))));
    }

    private static int spawnCatGrid(CommandSourceStack source, CatCreeperIdleAnimation idle) {
        ServerLevel level = source.getLevel();
        clearQaEntities(source, false);

        // Noon + clear weather removes two major sources of capture variance.
        level.setDayTime(6000L);
        level.setWeatherParameters(0, 0, false, false);

        double originX = Math.floor(source.getPosition().x) + 0.5D;
        double originY = Math.floor(source.getPosition().y);
        double originZ = Math.floor(source.getPosition().z) + 3.5D;
        int spawned = 0;
        int row = 0;

        for (CatCreeperRestPose pose : CatCreeperRestPose.values()) {
            if (pose == CatCreeperRestPose.NONE) {
                continue;
            }
            for (int variant = 0; variant < pose.variantCount(); variant++) {
                CreeperellaEntity cat = ModEntities.CAT_CREEPER.get().create(level);
                if (cat == null) {
                    continue;
                }
                double x = originX + variant * 3.0D;
                double z = originZ + row * 3.0D;
                cat.moveTo(x, originY, z, 180.0F, 0.0F);
                cat.setNoAi(true);
                cat.setInvulnerable(true);
                cat.setPersistenceRequired();
                cat.addTag(QA_TAG);
                cat.setCustomName(Component.literal(pose.displayName() + " " + (variant + 1)
                        + (idle == CatCreeperIdleAnimation.NONE ? "" : " / " + idle.name())));
                cat.setCustomNameVisible(true);
                cat.forceCatQaState(pose, variant, idle);
                if (level.addFreshEntity(cat)) {
                    spawned++;
                }
            }
            row++;
        }

        final int count = spawned;
        LOGGER.info("MMV_QA_CATS idle={} spawned={}", idle.name(), count);
        source.sendSuccess(() -> Component.literal("Creeperella QA: spawned " + count
                + " deterministic Cat pose samples (idle=" + idle.name() + ")."), true);
        return count;
    }

    private static int spawnFamilyGrid(CommandSourceStack source, boolean cherryFamilyOnly) {
        ServerLevel level = source.getLevel();
        clearQaEntities(source, false);
        level.setDayTime(6000L);
        level.setWeatherParameters(0, 0, false, false);

        CreeperellaKind[] kinds = cherryFamilyOnly
                ? new CreeperellaKind[]{CreeperellaKind.CHERRY}
                : new CreeperellaKind[]{CreeperellaKind.FEMALE, CreeperellaKind.BUNNY, CreeperellaKind.BEE,
                        CreeperellaKind.CHERRY, CreeperellaKind.BOOMSHROOM, CreeperellaKind.CINDERELLA,
                        CreeperellaKind.MARIGLOW, CreeperellaKind.VERDALIA, CreeperellaKind.NACRELLA, CreeperellaKind.CAT};
        double originX = Math.floor(source.getPosition().x) + 0.5D;
        double originY = Math.floor(source.getPosition().y);
        double originZ = Math.floor(source.getPosition().z) + 4.5D;
        int spawned = 0;

        for (int i = 0; i < kinds.length; i++) {
            CreeperellaKind kind = kinds[i];
            CreeperellaEntity mob = ModEntities.typeFor(kind).create(level);
            if (mob == null) continue;
            int column = i % 3;
            int row = i / 3;
            mob.moveTo(originX + (column - 1) * 4.0D, originY, originZ + row * 4.0D, 180.0F, 0.0F);
            mob.setNoAi(true);
            mob.setInvulnerable(true);
            mob.setPersistenceRequired();
            mob.addTag(QA_TAG);
            mob.setCustomName(Component.literal(kind.name()));
            mob.setCustomNameVisible(true);
            if (level.addFreshEntity(mob)) spawned++;
        }

        final int count = spawned;
        if (cherryFamilyOnly) LOGGER.info("MMV_QA_CHERRY_FAMILY cherry=1 blossom=0 spawned={}", count);
        else LOGGER.info("MMV_QA_FAMILY expected={} spawned={}", kinds.length, count);
        source.sendSuccess(() -> Component.literal("Creeperella QA: spawned " + count
                + (cherryFamilyOnly ? " Cherry Creeper." : " active family comparison mobs.")), true);
        return count;
    }

    private static int spawnChargedCherryFamily(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        clearQaEntities(source, false);
        level.setDayTime(6000L);
        level.setWeatherParameters(0, 0, false, false);

        CreeperellaEntity mob = ModEntities.CHERRY_CREEPER.get().create(level);
        if (mob == null) return 0;
        CompoundTag charge = new CompoundTag();
        charge.putBoolean("powered", true);
        mob.readAdditionalSaveData(charge);
        double x = Math.floor(source.getPosition().x) + 0.5D;
        double y = Math.floor(source.getPosition().y);
        double z = Math.floor(source.getPosition().z) + 4.5D;
        mob.moveTo(x, y, z, 180.0F, 0.0F);
        mob.setNoAi(true);
        mob.setInvulnerable(true);
        mob.setPersistenceRequired();
        mob.addTag(QA_TAG);
        mob.setCustomName(Component.literal("CHARGED CHERRY"));
        mob.setCustomNameVisible(true);
        int powered = mob.isPowered() ? 1 : 0;
        int spawned = level.addFreshEntity(mob) ? 1 : 0;
        LOGGER.info("MMV_QA_CHARGED_FAMILY cherry=1 blossom=0 powered={} spawned={}", powered, spawned);
        source.sendSuccess(() -> Component.literal("Creeperella QA: spawned charged Cherry Creeper (powered=" + powered + ")."), true);
        return spawned;
    }

    private static int verifyCherryEcology(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        BlockPos pos = new BlockPos((int) Math.floor(source.getPosition().x),
                (int) Math.floor(source.getPosition().y), (int) Math.floor(source.getPosition().z));
        var biome = level.getBiome(pos);
        var spawns = biome.value().getMobSettings().getMobs(MobCategory.MONSTER).unwrap();
        int cherryWeight = 0;
        int cherryMin = 0;
        int cherryMax = 0;
        int blossomWeight = 0;
        for (MobSpawnSettings.SpawnerData spawn : spawns) {
            if (spawn.type == ModEntities.CHERRY_CREEPER.get()) {
                cherryWeight += spawn.getWeight().asInt();
                cherryMin = spawn.minCount;
                cherryMax = spawn.maxCount;
            } else if (spawn.type == ModEntities.BLOSSOM_CREEPER.get()) {
                blossomWeight += spawn.getWeight().asInt();
            }
        }
        int cherryGrove = biome.is(Biomes.CHERRY_GROVE) ? 1 : 0;
        LOGGER.info("MMV_QA_CHERRY_ECOLOGY cherry_grove={} cherry_weight={} blossom_weight={} cherry_min={} cherry_max={}",
                cherryGrove, cherryWeight, blossomWeight, cherryMin, cherryMax);
        final int cw = cherryWeight, bw = blossomWeight, cg = cherryGrove, cmin = cherryMin, cmax = cherryMax;
        source.sendSuccess(() -> Component.literal("Creeperella QA ecology: cherry_grove=" + cg
                + " cherry_weight=" + cw + " blossom_weight=" + bw + " group=" + cmin + "-" + cmax), true);
        return cherryGrove == 1 && cherryWeight == 18 && blossomWeight == 0 && cherryMin == 1 && cherryMax == 2 ? 1 : 0;
    }


    private static int spawnBoomshroom(CommandSourceStack source, boolean greeting) {
        ServerLevel level = source.getLevel();
        clearQaEntities(source, false);
        level.setDayTime(6000L);
        level.setWeatherParameters(0, 0, false, false);

        CreeperellaEntity mob = ModEntities.BOOMSHROOM_CREEPER.get().create(level);
        if (mob == null) return 0;
        double x = Math.floor(source.getPosition().x) + 0.5D;
        double y = Math.floor(source.getPosition().y);
        double z = Math.floor(source.getPosition().z) + 4.5D;
        mob.moveTo(x, y, z, 180.0F, 0.0F);
        mob.setNoAi(true);
        mob.setInvulnerable(true);
        mob.setPersistenceRequired();
        mob.addTag(QA_TAG);
        mob.setCustomName(Component.literal(greeting ? "BOOMSHROOM / CAP TIP" : "BOOMSHROOM"));
        mob.setCustomNameVisible(true);
        int spawned = level.addFreshEntity(mob) ? 1 : 0;
        if (spawned == 1 && greeting) mob.triggerBoomshroomGreeting();
        LOGGER.info("MMV_QA_BOOMSHROOM greeting={} spawned={}", greeting ? 1 : 0, spawned);
        source.sendSuccess(() -> Component.literal("Creeperella QA: spawned Boomshroom (greeting=" + greeting + ")."), true);
        return spawned;
    }

    private static int spawnChargedBoomshroom(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        clearQaEntities(source, false);
        level.setDayTime(6000L);
        level.setWeatherParameters(0, 0, false, false);

        CreeperellaEntity mob = ModEntities.BOOMSHROOM_CREEPER.get().create(level);
        if (mob == null) return 0;
        CompoundTag charge = new CompoundTag();
        charge.putBoolean("powered", true);
        mob.readAdditionalSaveData(charge);
        double x = Math.floor(source.getPosition().x) + 0.5D;
        double y = Math.floor(source.getPosition().y);
        double z = Math.floor(source.getPosition().z) + 4.5D;
        mob.moveTo(x, y, z, 180.0F, 0.0F);
        mob.setNoAi(true);
        mob.setInvulnerable(true);
        mob.setPersistenceRequired();
        mob.addTag(QA_TAG);
        mob.setCustomName(Component.literal("CHARGED BOOMSHROOM"));
        mob.setCustomNameVisible(true);
        int powered = mob.isPowered() ? 1 : 0;
        int spawned = level.addFreshEntity(mob) ? 1 : 0;
        LOGGER.info("MMV_QA_CHARGED_BOOMSHROOM powered={} spawned={}", powered, spawned);
        source.sendSuccess(() -> Component.literal("Creeperella QA: spawned charged Boomshroom (powered=" + powered + ")."), true);
        return spawned;
    }

    private static int primeBoomshroomExplosion(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        clearQaEntities(source, false);
        level.setDayTime(6000L);
        level.setWeatherParameters(0, 0, false, false);
        level.getGameRules().getRule(net.minecraft.world.level.GameRules.RULE_MOBGRIEFING).set(false, level.getServer());

        CreeperellaEntity mob = ModEntities.BOOMSHROOM_CREEPER.get().create(level);
        if (mob == null) return 0;
        double x = Math.floor(source.getPosition().x) + 0.5D;
        double y = Math.floor(source.getPosition().y);
        double z = Math.floor(source.getPosition().z) + 4.5D;
        mob.moveTo(x, y, z, 180.0F, 0.0F);
        mob.setNoAi(true);
        mob.setPersistenceRequired();
        mob.addTag(QA_TAG);
        mob.setCustomName(Component.literal("BOOMSHROOM / SPORE BURST"));
        mob.setCustomNameVisible(true);
        int spawned = level.addFreshEntity(mob) ? 1 : 0;
        if (spawned == 1) mob.ignite();
        LOGGER.info("MMV_QA_BOOMSHROOM_EXPLOSION primed={} spawned={}", spawned, spawned);
        source.sendSuccess(() -> Component.literal("Creeperella QA: primed real Boomshroom fuse with mobGriefing=false."), true);
        return spawned;
    }

    private static int verifyBoomshroomEcology(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        BlockPos pos = new BlockPos((int)Math.floor(source.getPosition().x),
                (int)Math.floor(source.getPosition().y), (int)Math.floor(source.getPosition().z));
        var biome = level.getBiome(pos);
        var spawns = biome.value().getMobSettings().getMobs(MobCategory.MONSTER).unwrap();
        int weight = 0, min = 0, max = 0;
        for (MobSpawnSettings.SpawnerData spawn : spawns) {
            if (spawn.type == ModEntities.BOOMSHROOM_CREEPER.get()) {
                weight += spawn.getWeight().asInt();
                min = spawn.minCount;
                max = spawn.maxCount;
            }
        }
        int mushroomFields = biome.is(Biomes.MUSHROOM_FIELDS) ? 1 : 0;
        LOGGER.info("MMV_QA_BOOMSHROOM_ECOLOGY mushroom_fields={} weight={} min={} max={}",
                mushroomFields, weight, min, max);
        final int fw=weight, fmin=min, fmax=max, mf=mushroomFields;
        source.sendSuccess(() -> Component.literal("Creeperella QA Boomshroom ecology: mushroom_fields=" + mf
                + " weight=" + fw + " group=" + fmin + "-" + fmax), true);
        return mushroomFields == 1 && weight == 10 && min == 1 && max == 2 ? 1 : 0;
    }

    private static int spawnShroomboom(CommandSourceStack source, boolean moving) {
        ServerLevel level = source.getLevel();
        clearQaEntities(source, false);
        level.setDayTime(6000L);
        level.setWeatherParameters(0, 0, false, false);
        CreeperellaEntity mob = ModEntities.SHROOMBOOM_CREEPER.get().create(level);
        if (mob == null) return 0;
        double x = Math.floor(source.getPosition().x) + 0.5D;
        double y = Math.floor(source.getPosition().y);
        double z = Math.floor(source.getPosition().z) + 4.5D;
        mob.moveTo(x, y, z, 180.0F, 0.0F);
        mob.setNoAi(!moving);
        mob.setInvulnerable(true);
        mob.setPersistenceRequired();
        mob.addTag(QA_TAG);
        mob.setCustomName(Component.literal(moving ? "SHROOMBOOM MOTION" : "SHROOMBOOM"));
        mob.setCustomNameVisible(true);
        if (moving) mob.setDeltaMovement(0.045D, 0.0D, 0.018D);
        int spawned = level.addFreshEntity(mob) ? 1 : 0;
        if (moving && spawned == 1) {
            // Deterministic short walk for native chest/gait + hair-inertia capture.
            mob.getNavigation().moveTo(x + 3.0D, y, z + 1.5D, 0.85D);
        }
        LOGGER.info("MMV_QA_SHROOMBOOM moving={} spawned={}", moving ? 1 : 0, spawned);
        source.sendSuccess(() -> Component.literal("Creeperella QA: Shroomboom " + (moving ? "motion" : "static") + " spawned=" + spawned), true);
        return spawned;
    }

    private static int spawnChargedShroomboom(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        clearQaEntities(source, false);
        level.setDayTime(6000L);
        level.setWeatherParameters(0, 0, false, false);
        CreeperellaEntity mob = ModEntities.SHROOMBOOM_CREEPER.get().create(level);
        if (mob == null) return 0;
        CompoundTag charge = new CompoundTag();
        charge.putBoolean("powered", true);
        mob.readAdditionalSaveData(charge);
        double x = Math.floor(source.getPosition().x) + 0.5D;
        double y = Math.floor(source.getPosition().y);
        double z = Math.floor(source.getPosition().z) + 4.5D;
        mob.moveTo(x, y, z, 180.0F, 0.0F);
        mob.setNoAi(true);
        mob.setInvulnerable(true);
        mob.setPersistenceRequired();
        mob.addTag(QA_TAG);
        mob.setCustomName(Component.literal("CHARGED SHROOMBOOM"));
        mob.setCustomNameVisible(true);
        int spawned = level.addFreshEntity(mob) ? 1 : 0;
        int powered = mob.isPowered() ? 1 : 0;
        LOGGER.info("MMV_QA_CHARGED_SHROOMBOOM powered={} spawned={}", powered, spawned);
        source.sendSuccess(() -> Component.literal("Creeperella QA: charged Shroomboom powered=" + powered + " spawned=" + spawned), true);
        return spawned;
    }

    private static int verifyLegacyBlossomAlias(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        clearQaEntities(source, false);
        level.setDayTime(6000L);
        level.setWeatherParameters(0, 0, false, false);

        CreeperellaEntity cherry = ModEntities.CHERRY_CREEPER.get().create(level);
        CreeperellaEntity legacy = ModEntities.BLOSSOM_CREEPER.get().create(level);
        if (cherry == null || legacy == null) return 0;
        boolean aliasesCherry = legacy.kind() == CreeperellaKind.CHERRY;
        double x = Math.floor(source.getPosition().x) + 0.5D;
        double y = Math.floor(source.getPosition().y);
        double z = Math.floor(source.getPosition().z) + 4.5D;

        cherry.moveTo(x - 2.5D, y, z, 180.0F, 0.0F);
        cherry.setNoAi(true);
        cherry.setInvulnerable(true);
        cherry.setPersistenceRequired();
        cherry.addTag(QA_TAG);
        cherry.setCustomName(Component.literal("ACTIVE CHERRY"));
        cherry.setCustomNameVisible(true);

        legacy.moveTo(x + 2.5D, y, z, 180.0F, 0.0F);
        legacy.setNoAi(true);
        legacy.setInvulnerable(true);
        legacy.setPersistenceRequired();
        legacy.addTag(QA_TAG);
        legacy.setCustomName(Component.literal("LEGACY BLOSSOM ID -> CHERRY"));
        legacy.setCustomNameVisible(true);

        int cherryAdded = level.addFreshEntity(cherry) ? 1 : 0;
        int legacyAdded = level.addFreshEntity(legacy) ? 1 : 0;
        int spawned = cherryAdded + legacyAdded;
        LOGGER.info("MMV_QA_LEGACY_BLOSSOM_ALIAS aliases_cherry={} cherry={} legacy={} spawned={}",
                aliasesCherry ? 1 : 0, cherryAdded, legacyAdded, spawned);
        source.sendSuccess(() -> Component.literal("Creeperella QA: active Cherry + legacy Blossom ID comparison spawned=" + spawned), true);
        return aliasesCherry && spawned == 2 ? 1 : 0;
    }

    private static int clearQaEntities(CommandSourceStack source, boolean logPhase) {
        ServerLevel level = source.getLevel();
        AABB box = new AABB(source.getPosition(), source.getPosition()).inflate(128.0D);
        int removed = 0;
        for (Entity entity : level.getEntities((Entity) null, box, entity -> entity.getTags().contains(QA_TAG))) {
            entity.discard();
            removed++;
        }
        final int count = removed;
        if (count > 0) {
            source.sendSuccess(() -> Component.literal("Creeperella QA: cleared " + count + " QA entities."), false);
        }
        if (logPhase) {
            LOGGER.info("MMV_QA_CLEAR removed={}", count);
        }
        return removed;
    }

    private static int spawnVariant(CommandSourceStack source, CreeperellaKind kind, String marker) {
        ServerLevel level = source.getLevel();
        CreeperellaEntity entity = ModEntities.typeFor(kind).create(level);
        if (entity == null) return 0;
        Vec3 pos = source.getPosition();
        entity.moveTo(pos.x + 0.5D, pos.y, pos.z + 4.5D, 180.0F, 0.0F);
        entity.setNoAi(true);
        entity.setPersistenceRequired();
        entity.addTag("mmv_qa");
        level.addFreshEntity(entity);
        Creeperella.LOGGER.info("{} spawned=1", marker);
        return 1;
    }

    private CreeperellaQaCommands() {}
}
