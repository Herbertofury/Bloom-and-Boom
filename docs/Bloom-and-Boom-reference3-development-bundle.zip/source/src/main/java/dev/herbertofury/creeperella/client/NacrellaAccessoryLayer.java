package dev.herbertofury.creeperella.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.herbertofury.creeperella.Creeperella;
import dev.herbertofury.creeperella.entity.CreeperellaEntity;
import dev.herbertofury.creeperella.entity.CreeperellaKind;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Reference-fidelity Froglight floral architecture shared by Mariglow, Verdalia and Nacrella.
 *
 * The approved clean references use the same silhouette language across the trio: a dense layered
 * flower crown, leafy fringe, several hanging luminous vine strands and floral/glow clusters on the
 * feet.  This remains an additive layer over Pie's proven rig so the body/chest/leg animation
 * authority is untouched.  Every soft chain is reset each frame before secondary motion is applied.
 */
public final class NacrellaAccessoryLayer extends RenderLayer<CreeperellaEntity, CreeperellaModel<CreeperellaEntity>> {
    private static final int TASSEL_COUNT = 12;
    private static final int LASH_COUNT = 8;
    private final ModelPart root;
    private final ResourceLocation texture;
    private final ResourceLocation glow;
    private final ResourceLocation faceSkin;
    private final ResourceLocation faceIris;
    private final ResourceLocation lanternGlass;
    private static final ResourceLocation FACE_DARK = new ResourceLocation(Creeperella.MOD_ID, "textures/entity/froglight_face_dark.png");
    private static final ResourceLocation FACE_GLINT = new ResourceLocation(Creeperella.MOD_ID, "textures/entity/froglight_face_glint.png");

    public NacrellaAccessoryLayer(RenderLayerParent<CreeperellaEntity, CreeperellaModel<CreeperellaEntity>> parent,
                                  EntityModelSet set, CreeperellaKind kind) {
        super(parent);
        this.root = set.bakeLayer(ClientEvents.NACRELLA_ACCESSORIES);
        String prefix = switch (kind) {
            case MARIGLOW -> "mariglow";
            case VERDALIA -> "verdalia";
            default -> "nacrella";
        };
        this.texture = new ResourceLocation(Creeperella.MOD_ID, "textures/entity/" + prefix + "_accessories.png");
        this.glow = new ResourceLocation(Creeperella.MOD_ID, "textures/entity/" + prefix + "_accessories_e.png");
        this.faceSkin = new ResourceLocation(Creeperella.MOD_ID, "textures/entity/" + prefix + "_face_skin.png");
        this.faceIris = new ResourceLocation(Creeperella.MOD_ID, "textures/entity/" + prefix + "_face_iris.png");
        this.lanternGlass = new ResourceLocation(Creeperella.MOD_ID, "textures/entity/" + prefix + "_lantern_glass.png");
        for(int i=0;i<TASSEL_COUNT;i++) {
            this.root.getChild("crown").getChild("tassel_"+i).getChild("a").getChild("b").getChild("c")
                    .getChild("lantern_outer").visible=false;
        }
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition crown = root.addOrReplaceChild("crown", CubeListBuilder.create(), PartPose.ZERO);

        // POLISH37: one continuous crown at the actual head roof. Five large front blossoms sit at the
        // roof/front edge; four smaller roof blossoms provide depth behind them. No second forehead bracelet.
        addHeroFlower(crown, "hero_l2", -3.70F,-7.75F,-4.66F,-0.25F,0.88F);
        addHeroFlower(crown, "hero_l1", -2.20F,-8.25F,-4.78F,-0.12F,1.22F);
        addHeroFlower(crown, "hero_c",   0.08F,-8.65F,-4.86F, 0.02F,1.34F);
        addHeroFlower(crown, "hero_r1",  2.20F,-8.20F,-4.76F, 0.13F,1.20F);
        addHeroFlower(crown, "hero_r2",  3.72F,-7.75F,-4.62F, 0.27F,0.84F);

        addFlower(crown, "roof_l",   -2.30F,-8.48F,-1.00F,16,-0.18F,1.06F);
        addFlower(crown, "roof_c",    0.10F,-8.82F,-1.70F, 0, 0.06F,1.12F);
        addFlower(crown, "roof_r",    2.40F,-8.48F,-0.70F,16, 0.20F,1.04F);
        addFlower(crown, "roof_back", 0.05F,-8.58F, 1.65F, 0,-0.07F,1.12F);

        // Fill the rear/central roof gaps observed in the native three-quarter inspection.
        addFlower(crown, "roof_back_l", -2.35F,-8.56F,2.15F,16,-0.12F,1.16F);
        addFlower(crown, "roof_back_r",  2.35F,-8.58F,2.15F, 0, 0.14F,1.16F);
        addFlower(crown, "roof_front",   0.00F,-8.66F,-3.15F,16,0.03F,1.12F);

        // Reference crown wraps the entire head, not just a front-facing strip.
        for (int i=0; i<7; i++) {
            float angle=(i-3)*(float)Math.PI/4.0F;
            float x=Mth.sin(angle)*4.15F, z=Mth.cos(angle)*4.15F;
            PartDefinition anchor=crown.addOrReplaceChild("ring_blossom_"+i,
                    CubeListBuilder.create(), PartPose.offsetAndRotation(x,-8.05F,z,
                            -0.12F,angle+(float)Math.PI,(i%2==0?0.12F:-0.12F)));
            addHeroFlower(anchor,"bloom",0.0F,0.0F,0.0F,0.0F,0.92F+(i%3)*0.11F);
        }
        for (int i=0; i<20; i++) {
            float angle=i*(float)Math.PI/10.0F;
            PartDefinition leafAnchor=crown.addOrReplaceChild("crown_leaf_anchor_"+i,
                    CubeListBuilder.create(), PartPose.offsetAndRotation(Mth.sin(angle)*3.8F,
                            -7.9F,Mth.cos(angle)*3.8F,0.0F,angle,0.0F));
            addFacingLeaf(leafAnchor,"leaf",0.0F,0.0F,0.0F,(i%2==0?0.2F:-0.2F),0.58F);
        }

        // Sparse leafy underfringe breaks the crown edge without forming another horizontal stripe.
        addFacingLeaf(crown,"leaf_l2",-3.78F,-7.86F,-4.29F,-0.45F,0.16F);
        addFacingLeaf(crown,"leaf_l1",-2.42F,-7.91F,-4.34F,-0.28F,0.15F);
        addFacingLeaf(crown,"leaf_c", -0.22F,-7.83F,-4.38F,-0.05F,0.13F);
        addFacingLeaf(crown,"leaf_r1", 2.30F,-7.88F,-4.34F, 0.27F,0.15F);
        addFacingLeaf(crown,"leaf_r2", 3.82F,-7.78F,-4.27F, 0.45F,0.16F);

        // Three staggered delicate chains per side, rooted at the crown rather than the cheek plane.
        addTassel(crown,"tassel_0",-4.25F,-7.72F,-4.46F,-0.18F,5.65F);
        addTassel(crown,"tassel_1",-4.78F,-7.48F,-4.20F,-0.08F,7.30F);
        addTassel(crown,"tassel_2",-5.12F,-7.24F,-3.86F, 0.02F,8.80F);
        addTassel(crown,"tassel_3", 4.25F,-7.69F,-4.46F, 0.18F,5.90F);
        addTassel(crown,"tassel_4", 4.78F,-7.43F,-4.20F, 0.08F,7.15F);
        addTassel(crown,"tassel_5", 5.12F,-7.18F,-3.86F,-0.02F,8.65F);

        addTassel(crown,"tassel_6",-4.35F,-7.70F,2.70F,-0.08F,6.4F);
        addTassel(crown,"tassel_7", 4.35F,-7.70F,2.70F, 0.08F,6.8F);
        addTassel(crown,"tassel_8",-2.15F,-7.85F,4.25F,-0.06F,6.0F);
        addTassel(crown,"tassel_9", 2.15F,-7.85F,4.25F, 0.06F,5.7F);

        addTassel(crown,"tassel_10",-4.55F,-7.75F,0.1F,-0.07F,7.6F);
        addTassel(crown,"tassel_11", 4.55F,-7.75F,0.1F, 0.07F,7.3F);

        // Approved-reference face reconstruction. Two skin plates cover only the old eye-band region;
        // the Creeper mouth below remains intact.  Dark sockets, luminous irises, pupils and glints are
        // separate geometry/material passes so the eyes read as large jewel-like volumes instead of paint.
        PartDefinition faceSkin = root.addOrReplaceChild("face_skin", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition faceDark = root.addOrReplaceChild("face_dark", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition faceIris = root.addOrReplaceChild("face_iris", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition faceGlint = root.addOrReplaceChild("face_glint", CubeListBuilder.create(), PartPose.ZERO);
        faceSkin.addOrReplaceChild("inherited_eye_band_mask", CubeListBuilder.create().texOffs(0,0)
                        .addBox(-3.98F,-3.98F,-0.10F,7.96F,7.96F,0.20F,new CubeDeformation(0.018F)),
                PartPose.offset(0.0F,-4.0F,-4.205F));
        addReferenceEye(faceSkin, faceDark, faceIris, faceGlint, "left", -1.92F, -1.0F);
        addReferenceEye(faceSkin, faceDark, faceIris, faceGlint, "right", 1.92F, 1.0F);
        // POLISH17 lower-face rebuild. Mask the full inherited Pie mouth zone first so no source
        // texture can survive as a horizontal moustache, then draw a compact classic Creeper mouth:
        // small nose bridge, central vertical opening and two short lower side jaws.
        faceDark.addOrReplaceChild("mouth_nose",CubeListBuilder.create().texOffs(0,0)
                        .addBox(-0.52F,-0.50F,-0.08F,1.04F,1.00F,0.18F,new CubeDeformation(0.010F)),
                PartPose.offset(0.0F,-2.90F,-4.49F));
        // Leave a visible pale gap under the nose, then place the classic lower Creeper mouth.
        faceDark.addOrReplaceChild("mouth_center",CubeListBuilder.create().texOffs(0,0)
                        .addBox(-0.94F,-0.43F,-0.08F,1.88F,0.86F,0.18F,new CubeDeformation(0.009F)),
                PartPose.offset(0.0F,-1.98F,-4.50F));
        faceDark.addOrReplaceChild("mouth_left",CubeListBuilder.create().texOffs(0,0)
                        .addBox(-0.26F,-0.48F,-0.08F,0.52F,0.96F,0.18F,new CubeDeformation(0.008F)),
                PartPose.offset(-0.78F,-1.58F,-4.49F));
        faceDark.addOrReplaceChild("mouth_right",CubeListBuilder.create().texOffs(0,0)
                        .addBox(-0.26F,-0.48F,-0.08F,0.52F,0.96F,0.18F,new CubeDeformation(0.008F)),
                PartPose.offset(0.78F,-1.58F,-4.49F));


        // POLISH37 torso: the Minecraft-derived Froglight body is the hero material. Accessories only
        // punctuate the lower side edges; no bright chest decal and no fake pearl strip.
        PartDefinition torso = root.addOrReplaceChild("torso", CubeListBuilder.create(), PartPose.ZERO);
        addFacingFlower(torso, "torso_flower_l", -2.28F,-10.65F,-2.70F,-0.20F,0.22F);
        addFacingFlower(torso, "torso_flower_r",  2.28F,-8.15F,-2.70F, 0.18F,0.19F);
        addFacingLeaf(torso,"torso_leaf_l",-2.40F,-12.20F,-2.56F,-0.34F,0.18F);
        addFacingLeaf(torso,"torso_leaf_r", 2.40F,-9.65F,-2.56F, 0.32F,0.17F);

        // POLISH36: no breast/chest overlay. The actual Froglight torso owns the visible material.

        // POLISH37 feet: decorations live on outer/top corners so the actual four Froglight legs remain readable.
        for (int i = 1; i <= 4; i++) {
            PartDefinition foot = root.addOrReplaceChild("foot" + i, CubeListBuilder.create(), PartPose.ZERO);
            float baseX = (i == 1 || i == 3) ? -2.0F : 2.0F;
            float faceZ = i <= 2 ? 1.82F : -6.20F;
            float topZ = i <= 2 ? 4.0F : -4.0F;
            float outward = (i == 1 || i == 3) ? -1.0F : 1.0F;
            addFlower(foot, "bloom_top", baseX + outward*0.55F, -8.02F, topZ, (i % 2) * 16, outward * 0.11F, 0.94F);
            addFlower(foot,"bloom_companion",baseX-outward*0.70F,-8.10F,
                    topZ+0.75F,16,-outward*0.16F,0.48F);
            addFacingFlower(foot, "bloom_outer", baseX + outward*0.78F, -3.65F, faceZ, outward * 0.12F, 0.60F);
            addFacingLeaf(foot,"leaf_hi",baseX+outward*1.00F,-6.20F,faceZ,outward*0.42F,0.21F);
            addFacingLeaf(foot,"leaf_low",baseX+outward*0.88F,-1.20F,faceZ,outward*0.26F,0.18F);
            foot.addOrReplaceChild("pearl_core", CubeListBuilder.create().texOffs(48,16)
                    .addBox(-0.10F,-0.16F,-0.18F,0.20F,0.32F,0.34F,new CubeDeformation(0.022F)),
                    PartPose.offset(baseX + outward * 0.56F,-2.05F,faceZ-0.06F));
        }
        return LayerDefinition.create(mesh, 64, 64);
    }

    private static void addFlower(PartDefinition parent,String name,float x,float y,float z,int u,float roll) {
        addFlower(parent,name,x,y,z,u,roll,1.0F);
    }

    private static void addFlower(PartDefinition parent,String name,float x,float y,float z,int u,float roll,float scale) {
        addOrganicFlower(parent,name,x,y,z,roll,scale,true);
    }

    private static void addHeroFlower(PartDefinition parent,String name,float x,float y,float z,float roll,float scale) {
        addOrganicFlower(parent,name,x,y,z,roll,scale,false);
    }

    private static void addFacingFlower(PartDefinition parent,String name,float x,float y,float z,float roll,float scale) {
        addOrganicFlower(parent,name,x,y,z,roll,scale,false);
    }

    private static void addOrganicFlower(PartDefinition parent,String name,float x,float y,float z,float roll,float scale,boolean upward) {
        PartDefinition f=parent.addOrReplaceChild(name,CubeListBuilder.create(),PartPose.offsetAndRotation(x,y,z,0,0,roll));
        // Empty marker stores local scale/orientation for the cached curved-petal renderer.
        f.addOrReplaceChild("organic_shape",CubeListBuilder.create(),PartPose.offset(scale,upward?1.0F:0.0F,0));
        f.addOrReplaceChild("center",CubeListBuilder.create().texOffs(20,4)
                .addBox(-0.23F*scale,-0.23F*scale,-0.23F*scale,0.46F*scale,0.46F*scale,0.46F*scale),
                PartPose.offset(0,upward?-0.32F*scale:0,upward?0:-0.32F*scale));
        f.addOrReplaceChild("center_glow",CubeListBuilder.create().texOffs(52,4)
                .addBox(-0.10F*scale,-0.10F*scale,-0.10F*scale,0.20F*scale,0.20F*scale,0.20F*scale),
                PartPose.offset(0,upward?-0.57F*scale:0,upward?0:-0.57F*scale));
    }

    private static void addReferenceEye(PartDefinition skin, PartDefinition dark, PartDefinition iris,
                                        PartDefinition glint, String name, float x, float lashSide) {
        final float eyeY=-4.35F;
        // POLISH37: reference eyes are square violet jewels with a thin dark frame, not a black visor.
        skin.addOrReplaceChild(name+"_mask",CubeListBuilder.create().texOffs(0,0)
                        .addBox(-1.30F,-1.18F,-0.10F,2.60F,2.36F,0.20F,new CubeDeformation(0.014F)),
                PartPose.offset(x,eyeY-0.10F,-4.22F));
        dark.addOrReplaceChild(name+"_socket",CubeListBuilder.create().texOffs(0,0)
                        .addBox(-0.88F,-0.98F,-0.08F,1.76F,1.96F,0.18F,new CubeDeformation(0.010F)),
                PartPose.offset(x,eyeY-0.04F,-4.39F));
        iris.addOrReplaceChild(name+"_iris",CubeListBuilder.create().texOffs(3,3)
                        .addBox(-0.72F,-0.83F,-0.07F,1.44F,1.66F,0.18F,new CubeDeformation(0.016F)),
                PartPose.offset(x,eyeY-0.03F,-4.53F));
        dark.addOrReplaceChild(name+"_pupil",CubeListBuilder.create().texOffs(0,0)
                        .addBox(-0.16F,-0.46F,-0.06F,0.32F,0.92F,0.16F,new CubeDeformation(0.008F)),
                PartPose.offset(x,eyeY,-4.65F));
        glint.addOrReplaceChild(name+"_glint_big",CubeListBuilder.create().texOffs(0,0)
                        .addBox(-0.10F,-0.10F,-0.04F,0.20F,0.20F,0.10F,new CubeDeformation(0.008F)),
                PartPose.offset(x-0.27F,eyeY-0.40F,-4.76F));
        glint.addOrReplaceChild(name+"_glint_small",CubeListBuilder.create().texOffs(0,0)
                        .addBox(-0.055F,-0.055F,-0.04F,0.11F,0.11F,0.09F,new CubeDeformation(0.004F)),
                PartPose.offset(x+0.25F,eyeY+0.22F,-4.76F));

        dark.addOrReplaceChild(name+"_lid_mid",CubeListBuilder.create().texOffs(0,0)
                        .addBox(-0.72F,-0.055F,-0.06F,1.44F,0.11F,0.14F,new CubeDeformation(0.008F)),
                PartPose.offsetAndRotation(x,eyeY-1.05F,-4.59F,0,0,lashSide*0.035F));
        // Thin swept outer wings frame each eye without joining them into a visor.
        for(int i=0;i<2;i++) {
            float lx=x+lashSide*(0.79F+i*0.05F);
            float width=i==0?0.66F:0.43F;
            dark.addOrReplaceChild(name+"_lash_"+i,CubeListBuilder.create().texOffs(0,0)
                            .addBox(lashSide<0?-width:0,-0.075F,-0.04F,width,0.15F,0.10F,new CubeDeformation(0.003F)),
                    PartPose.offsetAndRotation(lx,eyeY-0.93F+i*0.30F,-4.64F,0,0,-lashSide*(0.25F+i*0.12F)));
        }
        // Compatibility dummies for blink reset loop; zero-sized and invisible by geometry.
        dark.addOrReplaceChild(name+"_lid_in",CubeListBuilder.create(),PartPose.ZERO);
        dark.addOrReplaceChild(name+"_lid_out",CubeListBuilder.create(),PartPose.ZERO);
        dark.addOrReplaceChild(name+"_lash_2",CubeListBuilder.create(),PartPose.ZERO);
    }

    private static void addLeaf(PartDefinition parent, String name, float x, float y, float z, float roll) {
        parent.addOrReplaceChild(name, CubeListBuilder.create().texOffs(32,0)
                        .addBox(-0.72F,-0.15F,-0.42F,1.44F,0.30F,2.35F,new CubeDeformation(0.02F)),
                PartPose.offsetAndRotation(x,y,z,-0.20F,0.0F,roll));
    }

    private static void addFacingLeaf(PartDefinition parent,String name,float x,float y,float z,float roll,float scale) {
        PartDefinition leaf=parent.addOrReplaceChild(name,CubeListBuilder.create(),PartPose.offsetAndRotation(x,y,z,0,0,roll));
        leaf.addOrReplaceChild("blade",CubeListBuilder.create().texOffs(32,0)
                        .addBox(-0.34F*scale,-1.20F*scale,-0.15F,0.68F*scale,2.20F*scale,0.30F,new CubeDeformation(0.018F)),
                PartPose.rotation(0.0F,0.0F,0.16F));
        leaf.addOrReplaceChild("tip",CubeListBuilder.create().texOffs(32,0)
                        .addBox(-0.24F*scale,-0.90F*scale,-0.13F,0.48F*scale,1.05F*scale,0.26F,new CubeDeformation(0.016F)),
                PartPose.offsetAndRotation(0.18F*scale,0.72F*scale,-0.04F,0.0F,0.0F,-0.42F));
    }

    private static void addTassel(PartDefinition crown,String name,float x,float y,float z,float roll,float length) {
        PartDefinition root=crown.addOrReplaceChild(name,CubeListBuilder.create(),PartPose.offsetAndRotation(x,y,z,0,0,roll));
        float seg=length/3.0F;
        PartDefinition a=root.addOrReplaceChild("a",vineCube(seg),PartPose.ZERO);
        addVineLeaf(a,"leaf_a",-0.42F,seg*0.48F,0.28F);
        PartDefinition b=a.addOrReplaceChild("b",vineCube(seg),PartPose.offset(0.0F,seg,0.0F));
        addVineLeaf(b,"leaf_b",0.42F,seg*0.52F,-0.34F);
        PartDefinition c=b.addOrReplaceChild("c",vineCube(seg),PartPose.offset(0.0F,seg,0.0F));
        addVineLeaf(c,"leaf_c",-0.38F,seg*0.46F,0.24F);
        for(int j=0;j<4;j++) {
            float side=j%2==0?-1.0F:1.0F;
            addVineLeaf(a,"fringe_a_"+j,side*0.22F,seg*(j+0.35F)/4.0F,side*0.42F);
            addVineLeaf(b,"fringe_b_"+j,-side*0.25F,seg*(j+0.45F)/4.0F,-side*0.38F);
            addVineLeaf(c,"fringe_c_"+j,side*0.23F,seg*(j+0.40F)/4.0F,side*0.46F);
        }
        c.addOrReplaceChild("lantern_outer",CubeListBuilder.create().texOffs(48,16)
                        .addBox(-0.43F,-0.43F,-0.43F,0.86F,0.86F,0.86F,new CubeDeformation(0.030F)),
                PartPose.offset(0.0F,seg+0.50F,0.0F));
        c.addOrReplaceChild("lantern_core",CubeListBuilder.create().texOffs(48,16)
                        .addBox(-0.24F,-0.24F,-0.24F,0.48F,0.48F,0.48F,new CubeDeformation(0.024F)),
                PartPose.offset(0.0F,seg+0.50F,-0.08F));
    }

    private static void addVineLeaf(PartDefinition parent,String name,float x,float y,float roll) {
        parent.addOrReplaceChild(name,CubeListBuilder.create().texOffs(32,0)
                        .addBox(-0.11F,-0.36F,-0.05F,0.22F,0.72F,0.10F,new CubeDeformation(0.008F)),
                PartPose.offsetAndRotation(x,y,-0.05F,0,0,roll));
    }

    private static CubeListBuilder vineCube(float seg) {
        return CubeListBuilder.create().texOffs(32,0)
                .addBox(-0.080F,0.0F,-0.080F,0.16F,seg+0.05F,0.16F,new CubeDeformation(0.003F));
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffer, int light, CreeperellaEntity entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float age, float yaw, float pitch) {
        ModelPart crown = root.getChild("crown");
        crown.resetPose();
        float movement = Mth.clamp(limbSwingAmount,0.0F,1.0F);
        crown.zRot = Mth.sin(age*0.09F)*0.030F + Mth.sin(limbSwing*0.52F)*movement*0.025F;
        crown.xRot = Mth.sin(age*0.07F+0.8F)*0.020F;

        for (int i=0; i<TASSEL_COUNT; i++) {
            animateTassel(crown.getChild("tassel_"+i), age, limbSwing, movement, i*0.83F, (i<3 || i==6 || i==8 || i==10) ? -1.0F : 1.0F);
        }

        // Tiny independent flower/leaf breathing avoids a rigid helmet read while remaining Minecraft-like.
        animateChildren(crown, age);

        // The base renderer now draws the connected family mesh with its proper UV atlas.
        // Do not render a second shell over it.
        ps.pushPose();
        this.getParentModel().applyNacrellaHeadAnchor(ps);
        renderPart(crown,ps,buffer.getBuffer(RenderType.entityCutoutNoCull(this.texture)),light,entity);
        renderPart(crown,ps,buffer.getBuffer(RenderType.eyes(this.glow)),LightTexture.FULL_BRIGHT,entity,false);
        renderLanternGlass(crown,ps,buffer,entity);
        ps.popPose();

        ModelPart faceSkin=root.getChild("face_skin");
        ModelPart faceDark=root.getChild("face_dark");
        ModelPart faceIris=root.getChild("face_iris");
        ModelPart faceGlint=root.getChild("face_glint");
        faceSkin.resetPose(); faceDark.resetPose(); faceIris.resetPose(); faceGlint.resetPose();
        animateReferenceBlink(faceDark, faceIris, faceGlint);
        ps.pushPose();
        this.getParentModel().applyNacrellaHeadAnchor(ps);
        renderPart(faceSkin,ps,buffer.getBuffer(RenderType.entityCutoutNoCull(this.faceSkin)),light,entity);
        renderPart(faceDark,ps,buffer.getBuffer(RenderType.entityCutoutNoCull(FACE_DARK)),light,entity);
        renderPart(faceIris,ps,buffer.getBuffer(RenderType.entityCutoutNoCull(this.faceIris)),LightTexture.FULL_BRIGHT,entity);
        renderPart(faceGlint,ps,buffer.getBuffer(RenderType.eyes(FACE_GLINT)),LightTexture.FULL_BRIGHT,entity);
        ps.popPose();

        // Torso decorations inherit Pie body motion independently from the head and legs.
        ModelPart torso=root.getChild("torso");
        torso.resetPose();
        torso.zRot=Mth.sin(age*0.047F+0.6F)*0.014F;
        ps.pushPose();
        this.getParentModel().applyPieBodyAnchor(ps);
        renderPart(torso,ps,buffer.getBuffer(RenderType.entityCutoutNoCull(this.texture)),light,entity);
        renderPart(torso,ps,buffer.getBuffer(RenderType.eyes(this.glow)),LightTexture.FULL_BRIGHT,entity,false);
        ps.popPose();

        for(int i=1;i<=4;i++) {
            ModelPart foot=root.getChild("foot"+i);
            foot.resetPose();
            foot.zRot=Mth.sin(age*0.10F+i)*0.028F + Mth.sin(limbSwing + i*1.4F)*movement*0.020F;
            ps.pushPose();
            this.getParentModel().applyPieLegAnchor(ps,i);
            renderPart(foot,ps,buffer.getBuffer(RenderType.entityCutoutNoCull(this.texture)),light,entity);
            renderPart(foot,ps,buffer.getBuffer(RenderType.eyes(this.glow)),LightTexture.FULL_BRIGHT,entity,false);
            ps.popPose();
        }
    }

    private void animateReferenceBlink(ModelPart dark, ModelPart iris, ModelPart glint) {
        for (String side : new String[]{"left", "right"}) {
            boolean left = side.equals("left");
            float openness = this.getParentModel().referenceEyeOpenness(left);
            float gaze = this.getParentModel().referenceEyeGaze(left);
            ModelPart socket = dark.getChild(side + "_socket");
            ModelPart pupil = dark.getChild(side + "_pupil");
            ModelPart eyeIris = iris.getChild(side + "_iris");
            socket.resetPose(); pupil.resetPose(); eyeIris.resetPose();
            socket.yScale = 0.24F + openness * 0.76F;
            pupil.yScale = openness;
            pupil.x += gaze;
            eyeIris.yScale = openness;
            float lidDrop = (1.0F - openness) * 0.72F;
            for (String part : new String[]{"_lid_mid", "_lid_in", "_lid_out", "_lash_0", "_lash_1", "_lash_2"}) {
                ModelPart lid = dark.getChild(side + part);
                lid.resetPose();
                lid.y += lidDrop;
            }
            ModelPart big = glint.getChild(side + "_glint_big");
            ModelPart small = glint.getChild(side + "_glint_small");
            big.resetPose(); small.resetPose();
            big.visible = openness > 0.42F;
            small.visible = openness > 0.58F;
        }
    }

    private static void animateTassel(ModelPart tassel,float age,float limbSwing,float movement,float phase,float side) {
        tassel.resetPose();
        float gait = Mth.sin(limbSwing*0.65F+phase)*movement;
        tassel.zRot += Mth.sin(age*0.060F+phase)*0.045F + gait*0.040F*side;
        tassel.xRot += Mth.cos(age*0.052F+phase)*0.026F + gait*0.018F;
        ModelPart a=tassel.getChild("a"); a.resetPose();
        ModelPart b=a.getChild("b"); b.resetPose();
        ModelPart c=b.getChild("c"); c.resetPose();
        a.zRot += Mth.sin(age*0.060F+phase+0.35F)*0.040F + gait*0.026F*side;
        b.zRot += Mth.sin(age*0.060F+phase+0.72F)*0.060F + gait*0.040F*side;
        c.zRot += Mth.sin(age*0.060F+phase+1.10F)*0.080F + gait*0.055F*side;
        a.xRot += Mth.cos(age*0.049F+phase)*0.016F;
        b.xRot += Mth.cos(age*0.049F+phase+0.5F)*0.024F;
        c.xRot += Mth.cos(age*0.049F+phase+1.0F)*0.032F;
    }

    private static void animateChildren(ModelPart crown,float age) {
        // Known flower names only: reset and add sub-degree-scale phase offsets; tassels are handled above.
        String[] names={"roof_l","roof_c","roof_r","roof_back","roof_back_l","roof_back_r","roof_front",
                "hero_l2","hero_l1","hero_c","hero_r1","hero_r2"};
        for(int i=0;i<names.length;i++){
            ModelPart f=crown.getChild(names[i]);
            f.resetPose();
            // resetPose restores authored roll; additive motion remains restrained.
            f.xRot += Mth.sin(age*0.043F+i*0.71F)*0.018F;
            f.zRot += Mth.sin(age*0.051F+i*0.53F)*0.012F;
        }
    }

    private void renderLanternGlass(ModelPart crown,PoseStack ps,MultiBufferSource buffer,CreeperellaEntity entity) {
        VertexConsumer glass=buffer.getBuffer(RenderType.entityTranslucent(this.lanternGlass));
        ps.pushPose(); crown.translateAndRotate(ps);
        for(int i=0;i<TASSEL_COUNT;i++) {
            ps.pushPose();
            ModelPart tassel=crown.getChild("tassel_"+i); tassel.translateAndRotate(ps);
            ModelPart a=tassel.getChild("a"); a.translateAndRotate(ps);
            ModelPart b=a.getChild("b"); b.translateAndRotate(ps);
            ModelPart c=b.getChild("c"); c.translateAndRotate(ps);
            ModelPart shell=c.getChild("lantern_outer");
            shell.visible=true;
            try { shell.render(ps,glass,LightTexture.FULL_BRIGHT,LivingEntityRenderer.getOverlayCoords(entity,0),1,1,1,1); }
            finally { shell.visible=false; ps.popPose(); }
        }
        ps.popPose();
    }

    private static void renderPart(ModelPart p, PoseStack ps, VertexConsumer vc, int light, CreeperellaEntity e){
        renderPart(p,ps,vc,light,e,true);
    }

    private static void renderPart(ModelPart p, PoseStack ps, VertexConsumer vc, int light, CreeperellaEntity e, boolean petals){
        p.render(ps,vc,light,LivingEntityRenderer.getOverlayCoords(e,0.0F),1,1,1,1);
        if(petals) FroglightPetalMesh.renderGroup(p,ps,vc,light,LivingEntityRenderer.getOverlayCoords(e,0.0F));
    }
}
