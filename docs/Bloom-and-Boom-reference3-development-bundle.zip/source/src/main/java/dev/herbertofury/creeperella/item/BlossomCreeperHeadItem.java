package dev.herbertofury.creeperella.item;

import dev.herbertofury.creeperella.client.BlossomCreeperHeadItemRenderer;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.core.Direction;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.StandingAndWallBlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.function.Consumer;

public class BlossomCreeperHeadItem extends StandingAndWallBlockItem {
    public BlossomCreeperHeadItem(Block standing, Block wall, Item.Properties properties) {
        super(standing, wall, properties, Direction.DOWN);
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            private BlockEntityWithoutLevelRenderer renderer;

            @Override
            public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                if (this.renderer == null) {
                    this.renderer = new BlossomCreeperHeadItemRenderer();
                }
                return this.renderer;
            }
        });
    }
}
