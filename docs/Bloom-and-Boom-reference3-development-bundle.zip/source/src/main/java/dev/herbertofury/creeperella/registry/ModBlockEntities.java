package dev.herbertofury.creeperella.registry;

import dev.herbertofury.creeperella.Creeperella;
import dev.herbertofury.creeperella.blockentity.CherryCreeperHeadBlockEntity;
import dev.herbertofury.creeperella.blockentity.BlossomCreeperHeadBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, Creeperella.MOD_ID);

    public static final RegistryObject<BlockEntityType<CherryCreeperHeadBlockEntity>> CHERRY_CREEPER_HEAD =
            BLOCK_ENTITIES.register("cherry_creeper_head", () -> BlockEntityType.Builder.of(
                    CherryCreeperHeadBlockEntity::new,
                    ModBlocks.CHERRY_CREEPER_HEAD.get(),
                    ModBlocks.CHERRY_CREEPER_WALL_HEAD.get()).build(null));

    public static final RegistryObject<BlockEntityType<BlossomCreeperHeadBlockEntity>> BLOSSOM_CREEPER_HEAD =
            BLOCK_ENTITIES.register("blossom_creeper_head", () -> BlockEntityType.Builder.of(
                    BlossomCreeperHeadBlockEntity::new,
                    ModBlocks.BLOSSOM_CREEPER_HEAD.get(),
                    ModBlocks.BLOSSOM_CREEPER_WALL_HEAD.get()).build(null));

    public static void register(IEventBus bus) {
        BLOCK_ENTITIES.register(bus);
    }

    private ModBlockEntities() {}
}
