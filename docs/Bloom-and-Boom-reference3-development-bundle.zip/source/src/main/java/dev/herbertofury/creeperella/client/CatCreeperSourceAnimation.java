package dev.herbertofury.creeperella.client;

import net.minecraft.util.Mth;

/**
 * Generated directly from reference-assets/cat/creeper.animation.json in FemaleCreeper.mcpack.
 * Bedrock-to-Java axis conversion is applied only at the public accessor boundary.
 * Do not hand-edit; run tools/generate_cat_bedrock_animation.py.
 */
public final class CatCreeperSourceAnimation {
    private CatCreeperSourceAnimation() {}
    public static final float LENGTH_SECONDS = 8.0417F;
    private static final float DEG = (float)Math.PI / 180.0F;

    private static final float[] BODY_Y_T = new float[]{0.0F, 0.5F, 1.0F, 1.5F, 2.0F, 2.5F, 3.0F, 3.5F, 4.0F, 4.5F, 5.0F, 5.5F, 6.0F, 6.5F, 7.0F, 7.5F, 8.0F};
    private static final float[] BODY_Y_V = new float[]{0.4F, 0.0F, 0.4F, 0.0F, 0.4F, 0.0F, 0.4F, 0.0F, 0.4F, 0.0F, 0.4F, 0.0F, 0.4F, 0.0F, 0.4F, 0.0F, 0.4F};
    private static final float[] UPPER_Z_T = new float[]{0.0F, 0.7917F, 1.5833F, 2.4167F, 3.2083F, 4.0F, 4.7917F, 5.625F, 6.4167F, 7.25F, 8.0417F};
    private static final float[] UPPER_Z_V = new float[]{1.75F, -1.75F, 1.75F, -1.75F, 1.75F, -1.75F, 1.75F, -1.75F, 1.75F, -1.75F, 1.75F};
    private static final float[] UPPER_X_T = new float[]{0.0F, 0.4167F, 0.7917F, 1.2083F, 1.5833F, 2.0F, 2.4167F, 2.7917F, 3.2083F, 3.5833F, 4.0F, 4.4167F, 4.7917F, 5.2083F, 5.625F, 6.0417F, 6.4167F, 6.8333F, 7.25F, 7.6667F, 8.0417F};
    private static final float[] UPPER_X_V = new float[]{-0.175F, 0.0F, 0.175F, 0.0F, -0.175F, 0.0F, 0.175F, 0.0F, -0.175F, 0.0F, 0.175F, 0.0F, -0.175F, 0.0F, 0.175F, 0.0F, -0.175F, 0.0F, 0.175F, 0.0F, -0.175F};
    private static final float[] UPPER_Y_T = new float[]{0.0F, 0.4167F, 0.7917F, 1.2083F, 1.5833F, 2.0F, 2.4167F, 2.7917F, 3.2083F, 3.5833F, 4.0F, 4.4167F, 4.7917F, 5.2083F, 5.625F, 6.0417F, 6.4167F, 6.8333F, 7.25F, 7.6667F, 8.0417F};
    private static final float[] UPPER_Y_V = new float[]{-0.75F, -0.35F, -0.75F, -0.35F, -0.75F, -0.35F, -0.75F, -0.35F, -0.75F, -0.35F, -0.75F, -0.35F, -0.75F, -0.35F, -0.75F, -0.35F, -0.75F, -0.35F, -0.75F, -0.35F, -0.75F};
    private static final float[] BREAST_X_T = new float[]{0.0F, 0.5F, 1.0F, 1.5F, 2.0F, 2.5F, 3.0F, 3.5F, 4.0F, 4.5F, 5.0F, 5.5F, 6.0F, 6.5F, 7.0F, 7.5F, 8.0F};
    private static final float[] BREAST_X_V = new float[]{-10.5F, 0.0F, -10.5F, 0.0F, -10.5F, 0.0F, -10.5F, 0.0F, -10.5F, 0.0F, -10.5F, 0.0F, -10.5F, 0.0F, -10.5F, 0.0F, -10.5F};
    private static final float[] HEAD_Z_T = new float[]{0.0F, 0.7917F, 1.5833F, 2.4167F, 3.2083F, 4.0F, 4.7917F, 5.5833F, 6.375F, 7.1667F, 7.9583F};
    private static final float[] HEAD_Z_V = new float[]{-1.75F, 1.75F, -1.75F, 1.75F, -1.75F, 1.75F, -1.75F, 1.75F, -1.75F, 1.75F, -1.75F};
    private static final float[] EAR_L_Z_T = new float[]{0.0F, 0.5F, 1.0F, 1.5F, 2.0F, 2.5F, 3.0F, 3.5F, 4.0F, 4.5F, 5.0F, 5.5F, 6.0F, 6.5F, 7.0F, 7.5F, 8.0F};
    private static final float[] EAR_L_Z_V = new float[]{5.0F, 0.0F, 5.0F, 0.0F, 5.0F, 0.0F, 5.0F, 0.0F, 5.0F, 0.0F, 5.0F, 0.0F, 5.0F, 0.0F, 5.0F, 0.0F, 5.0F};
    private static final float[] EAR_R_Z_T = new float[]{0.0F, 0.5F, 1.0F, 1.5F, 2.0F, 2.5F, 3.0F, 3.5F, 4.0F, 4.5F, 5.0F, 5.5F, 6.0F, 6.5F, 7.0F, 7.5F, 8.0F};
    private static final float[] EAR_R_Z_V = new float[]{-5.0F, 0.0F, -5.0F, 0.0F, -5.0F, 0.0F, -5.0F, 0.0F, -5.0F, 0.0F, -5.0F, 0.0F, -5.0F, 0.0F, -5.0F, 0.0F, -5.0F};
    private static final float[] TAIL_X_T = new float[]{0.0F, 0.5F, 1.0F, 1.5F, 2.0F, 2.5F, 3.0F, 3.5F, 4.0F, 4.5F, 5.0F, 5.5F, 6.0F, 6.5F, 7.0F, 7.5F, 8.0F};
    private static final float[] TAIL_X_V = new float[]{-10.5F, 0.0F, -10.5F, 0.0F, -10.5F, 0.0F, -10.5F, 0.0F, -10.5F, 0.0F, -10.5F, 0.0F, -10.5F, 0.0F, -10.5F, 0.0F, -10.5F};
    private static final float[] TAIL2_X_T = new float[]{0.0F, 0.5F, 1.0F, 1.5F, 2.0F, 2.5F, 3.0F, 3.5F, 4.0F, 4.5F, 5.0F, 5.5F, 6.0F, 6.5F, 7.0F, 7.5F, 8.0F};
    private static final float[] TAIL2_X_V = new float[]{10.0F, 25.0F, 10.0F, 25.0F, 10.0F, 25.0F, 10.0F, 25.0F, 10.0F, 25.0F, 10.0F, 25.0F, 10.0F, 25.0F, 10.0F, 25.0F, 10.0F};
    private static final float[] BLINK_PULSE_T = new float[]{0.0F, 1.4583F, 1.5F, 1.6667F, 1.7083F, 2.0F, 4.4583F, 4.5F, 4.6667F, 4.7083F, 5.0F, 7.4583F, 7.5F, 7.6667F, 7.7083F, 8.0F};
    private static final float[] BLINK_PULSE_V = new float[]{0.0F, 0.0F, 1.0F, 0.83F, 0.0F, 0.0F, 0.0F, 1.0F, 0.83F, 0.0F, 0.0F, 0.0F, 1.0F, 0.83F, 0.0F, 0.0F};

    public static float loop(float seconds) {
        float t = seconds % LENGTH_SECONDS;
        return t < 0.0F ? t + LENGTH_SECONDS : t;
    }

    // Java ModelPart Y is down. This is the same Y conversion performed by
    // KeyframeAnimations.posVec when Blockbench exports a modded-entity animation.
    public static float bodyYOffset(float seconds) { return -linear(loop(seconds), BODY_Y_T, BODY_Y_V); }
    public static float upperXOffset(float seconds) { return catmull(loop(seconds), UPPER_X_T, UPPER_X_V); }
    public static float upperYOffset(float seconds) { return -catmull(loop(seconds), UPPER_Y_T, UPPER_Y_V); }
    // Blockbench Bedrock import negates X/Y rotations and the Java animation exporter
    // negates X/Y again. Net Bedrock -> Java authored rotation values keep their signs.
    public static float upperZRot(float seconds) { return catmull(loop(seconds), UPPER_Z_T, UPPER_Z_V) * DEG; }
    public static float breastXRot(float seconds) { return linear(loop(seconds), BREAST_X_T, BREAST_X_V) * DEG; }
    public static float headZRot(float seconds) { return catmull(loop(seconds), HEAD_Z_T, HEAD_Z_V) * DEG; }
    public static float earLZRot(float seconds) { return linear(loop(seconds), EAR_L_Z_T, EAR_L_Z_V) * DEG; }
    public static float earRZRot(float seconds) { return linear(loop(seconds), EAR_R_Z_T, EAR_R_Z_V) * DEG; }
    public static float tailXRot(float seconds) { return linear(loop(seconds), TAIL_X_T, TAIL_X_V) * DEG; }
    public static float tail2XRot(float seconds) { return linear(loop(seconds), TAIL2_X_T, TAIL2_X_V) * DEG; }
    public static float blinkPulse(float seconds) { return Mth.clamp(linear(loop(seconds), BLINK_PULSE_T, BLINK_PULSE_V), 0.0F, 1.0F); }

    private static float linear(float t, float[] times, float[] values) {
        int i = segment(t, times);
        if (i >= times.length - 1) return values[values.length - 1];
        float span = times[i + 1] - times[i];
        if (span <= 0.000001F) return values[i];
        return Mth.lerp(Mth.clamp((t - times[i]) / span, 0.0F, 1.0F), values[i], values[i + 1]);
    }

    private static float catmull(float t, float[] times, float[] values) {
        int i = segment(t, times);
        if (i >= times.length - 1) return values[values.length - 1];
        float span = times[i + 1] - times[i];
        float u = span <= 0.000001F ? 0.0F : Mth.clamp((t - times[i]) / span, 0.0F, 1.0F);
        int lastUnique = values.length - 2; // final key duplicates loop start at animation length
        int p0i = (i == 0) ? lastUnique : i - 1;
        int p1i = i;
        int p2i = i + 1;
        int p3i = (i + 2 < values.length) ? i + 2 : 1;
        return catmullValue(u, values[p0i], values[p1i], values[p2i], values[p3i]);
    }

    private static float catmullValue(float t, float p0, float p1, float p2, float p3) {
        float t2 = t * t;
        float t3 = t2 * t;
        return 0.5F * ((2.0F * p1) + (-p0 + p2) * t
                + (2.0F * p0 - 5.0F * p1 + 4.0F * p2 - p3) * t2
                + (-p0 + 3.0F * p1 - 3.0F * p2 + p3) * t3);
    }

    private static int segment(float t, float[] times) {
        for (int i = 0; i < times.length - 1; i++) {
            if (t < times[i + 1]) return i;
        }
        return times.length - 1;
    }
}
