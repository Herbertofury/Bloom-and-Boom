package dev.herbertofury.creeperella.item;

import dev.herbertofury.creeperella.registry.ModPaintings;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.decoration.Painting;
import net.minecraft.world.entity.decoration.PaintingVariant;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;

public class CherryPaintingItem extends Item {
    public CherryPaintingItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Direction face = context.getClickedFace();
        if (!face.getAxis().isHorizontal()) {
            return InteractionResult.FAIL;
        }

        Level level = context.getLevel();
        if (context.getPlayer() != null
                && !context.getPlayer().mayUseItemAt(context.getClickedPos().relative(face), face, context.getItemInHand())) {
            return InteractionResult.FAIL;
        }
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        Holder<PaintingVariant> variant = serverLevel.registryAccess()
                .registryOrThrow(Registries.PAINTING_VARIANT)
                .getHolderOrThrow(ModPaintings.CHERRY_CREEBET_KEY);

        Painting painting = new Painting(level, context.getClickedPos().relative(face), face, variant);
        if (!painting.survives()) {
            return InteractionResult.CONSUME;
        }

        painting.playPlacementSound();
        level.gameEvent(context.getPlayer(), GameEvent.ENTITY_PLACE, painting.position());
        level.addFreshEntity(painting);
        if (context.getPlayer() == null || !context.getPlayer().getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }
}
