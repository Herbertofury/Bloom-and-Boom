package dev.herbertofury.creeperella.registry;

import dev.herbertofury.creeperella.Creeperella;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Native Forge particle registry for Bloom & Boom's reusable variant-effect pipeline. */
public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, Creeperella.MOD_ID);

    public static final RegistryObject<SimpleParticleType> BOOMSHROOM_SPORE =
            PARTICLES.register("boomshroom_spore", () -> new SimpleParticleType(false));

    public static void register(IEventBus bus) {
        PARTICLES.register(bus);
    }

    private ModParticles() {}
}
