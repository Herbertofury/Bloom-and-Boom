# Creeperella: Bloom & Boom — Shroomboom 1.6.0-dev5 Final Development Verification

**Target:** Minecraft 1.20.1 / Forge 47.4.23 / Java 17  
**Status:** development visual candidate, **not** a stable Boomshroom replacement  
**Natural spawn:** disabled  
**Image generation used:** no

## Acceptance contract

1. Preserve the existing stable Boomshroom and approved Cherry/Nacrella/Cinderella art.
2. Build Shroomboom as a separate variant on the Pie/female animation base, retaining chest/breast and four-leg motion.
3. Match the supplied voxel reference with an oversized red mushroom cap, white patches, creamy gills, warm dimensional eyes, 3D eyelashes, moss hair, small mushrooms, fungal shelf/bark/moss detail and rooted dark feet.
4. Hair must have real secondary motion rather than rigid decorative geometry.
5. If the asset tooling cannot safely author/audit this density, improve the tool first.
6. Prove the exact candidate with deterministic QA, Forge build, dedicated server, and real native client static/motion/charged gates.

## Reference lock

- attached/Drive reference SHA-256: `0322d3eb031093d586eab3a6e6cd87569d1f9ed5caf7cf65a430eed1cb7d0e4e`
- working copy `reference-assets/shroomboom/Shroomboom.png` is the same visual reference.

## Protected stable art

- stable Boomshroom entity texture: `37b72d8e1a11569bc79b743c5c77f90dc539ba9dd251f898de62a580bd5b9dd0`
- Cherry entity texture: `f616daad6e1aa1f9b9b81041cd8823aa17faa4eeb8d4e00801a1547328cf1bdb`
- Nacrella entity texture: `f3c8a72ba144d4fb0ed91f5990944cb0d6473f8450f4c6eb1fe52bc03811c7ae`
- Cinderella entity texture: `e95697d29896eb70346cbb6b435ee2f32ed27161fc6c2e1503e86226bfa5fab8`

The blocking Shroomboom audit verifies these protected assets and verifies natural spawning remains hard-disabled.

## dev5 model/art architecture

- deterministic detail recipe: **73 parts / 343 cubes / 14 roots**;
- hierarchy max depth: 2;
- recipe bounds: `21.7175 × 28.1 × 19.8` model units;
- texture atlas: 256×128;
- box-UV out-of-bounds issues: **0**;
- cap: stepped oversized red silhouette, 18 raised top spots, 10 eye-level side spots, nine physical cap mushrooms;
- underside: dark gill plate/hub with 24 lowered cream radial ribs;
- face: warm brown dimensional eye geometry, physical 3D lashes, blink lids, blush and Creeper facial read;
- hair: six independent spring chains (`left`, `right`, `front-left`, `front-right`, `back-left`, `back-right`), each root→mid→tip, each segment built from four irregular strand cuboids;
- fungal body: torso/chest/leg moss, bark/soil, shelves and miniature red mushrooms;
- feet: dark root/toe pads on all four legs;
- Pie anchors: head/cap/face/hair, body, breast/chest, and all four leg bones remain animation authorities.

## Tool upgrade — Minecraft Texture Intelligence 0.2.0-dev2

The Shroomboom density exposed a real safety gap: the previous recipe compiler could generate cubes but did not enforce a structural/UV audit before export. dev2 adds:

- recipe schema validation;
- root/part/cube counting;
- hierarchy depth and descendant-chain reporting;
- conservative model extents/bounds;
- texture-size-aware box-UV overflow detection;
- CLI `--audit-out` report generation.

Verification:

- Python tests: **11 passed**;
- Blockbench helper tests: **PASS**;
- Blockbench registration/runtime mock: **PASS**;
- Shroomboom dev5 recipe audit: **PASS / 0 UV issues**.

## Static/deterministic QA

`tools/audit_shroomboom_quality.py`: **PASS**

> stable Boomshroom/Cherry/Nacrella/Cinderella assets protected; Shroomboom reference exact; details parts=73 cubes=343; 3D lashes+blink lids+six 3-segment four-strand spring hair chains+exposed radial gills+dark rooted feet+Pie chest/leg anchors present; recipe UV-safe; natural spawn hard-disabled

## Production build

Toolchain:

- Eclipse Temurin Java 17.0.20.1+1
- Gradle 8.8
- Forge 1.20.1-47.4.23
- verified offline Forge/Omniporter cache

`clean build`: **PASS in 20 s**. `reobfJar`: PASS. 21 deprecation/removal warnings only; no compiler errors.

- JAR: `creeperella-1.20.1-forge-1.6.0-dev5.jar`
- size: 388,961 bytes
- SHA-256: `97cb39340fcbe9b18e4a9068da2e368f003ad3c22383c093957ff94361d111f3`

## Dedicated Forge server

Exact dev5 source/runtime candidate: **PASS**

`Done (6.254s)! For help, type "help"`

The isolated worker cannot reach Mojang authentication endpoints; those auth/network warnings are environment-only and the server readiness marker is authoritative.

## Real Forge client — native static / motion / charged QA

Environment: Xvfb 1280×720, Mesa llvmpipe GL 4.5, LWJGL Linux natives 7/7, Java 17, real Forge integrated server.

Authoritative markers:

- `MMV_QA_SHROOMBOOM moving=0 spawned=1`
- `MMV_QA_SHROOMBOOM moving=1 spawned=1`
- `MMV_QA_CHARGED_SHROOMBOOM powered=1 spawned=1`

Native evidence retained:

- front static still;
- 3/4 still;
- elevated/close under-cap still revealing dark plate + light radial gills;
- seven-second motion MP4 plus three sampled motion frames;
- charged still.

Motion-frame inspection shows different strand-chain lean/curvature across time while the QA actor walks, proving the visual hair layer is not a rigid pose. Charged Shroomboom also renders successfully through the powered overlay path.

Focused client-log scan found **0 Creeperella-specific error/exception/missing/model/texture failures**. Save-and-Quit stopped the integrated server and reported all three dimensions saved before the client exited. The full Mojang external asset-object cache remains absent, so known vanilla asset-index/icon/auth/sound-object warnings are classified as environment-only, consistent with the prior Creeperella native QA doctor.

## Development decision

**PASS as the current Shroomboom visual-development checkpoint.**

This does **not** promote Shroomboom over stable Boomshroom and does **not** enable natural spawning. dev5 is now the exact native-tested candidate to review visually. Any next art pass should be targeted from the retained native frames rather than restarting the model or discarding the Pie animation/physics foundation.
