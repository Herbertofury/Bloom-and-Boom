#!/usr/bin/env python3
"""Deterministically author Shroomboom textures, cuboid recipe, bbmodel and Forge layer source.

The user-supplied reference image is preserved as provenance only. Runtime art is authored as native
Minecraft pixel textures/geometry and never produced by image generation.
"""
from __future__ import annotations
import hashlib, json, math, os, shutil, subprocess, sys
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "src/main/resources/assets/creeperella"
JAVA = ROOT / "src/main/java/dev/herbertofury/creeperella/client"
REF = ROOT / "reference-assets/shroomboom"
TOOLS = ROOT / "tools"
TI = Path(os.environ.get("MCTEXINTEL_HOME", "/mnt/data/mctexintel-dev2"))
USER_REF = Path("/mnt/data/Shroomboom.png")

IVORY = [(248,239,218,255),(239,226,201,255),(229,211,181,255),(218,198,167,255)]
MOSS = [(83,112,35,255),(106,137,42,255),(128,155,52,255),(66,92,30,255)]
SOIL = [(112,79,54,255),(132,95,64,255),(91,65,48,255),(155,116,78,255)]
RED = [(205,50,48,255),(229,62,55,255),(244,75,65,255),(180,41,43,255)]
GILL = [(248,230,198,255),(226,204,171,255),(207,181,147,255),(255,242,219,255)]
GILL_SHADOW = [(191,164,132,255),(205,178,145,255),(218,193,160,255),(180,151,121,255)]
SHELF = [(207,143,76,255),(232,170,93,255),(246,197,128,255),(184,119,64,255)]
BLACK = [(18,17,16,255),(31,28,25,255),(45,40,35,255)]
EYE = [(89,47,28,255),(137,76,39,255),(191,118,59,255),(236,172,101,255)]
BLUSH = [(244,156,134,220),(235,126,118,210),(255,184,155,190)]
WHITE = [(255,252,240,255),(248,244,230,255),(235,229,210,255)]


def hnoise(x:int,y:int,seed:int=0)->int:
    return ((x*73856093) ^ (y*19349663) ^ (seed*83492791)) & 0xffffffff


def material(img, rect, palette, seed=0, stripe=None):
    x0,y0,x1,y1=rect; px=img.load()
    for y in range(y0,y1):
        for x in range(x0,x1):
            n=hnoise(x,y,seed)
            idx=(n >> 7) % len(palette)
            if stripe and ((x+y+seed)//stripe)%5==0: idx=min(len(palette)-1,idx+1)
            px[x,y]=palette[idx]


def author_body():
    src=Image.open(RES/'textures/entity/female_creeper.png').convert('RGBA')
    out=Image.new('RGBA',src.size,(0,0,0,0)); sp=src.load(); op=out.load()
    for y in range(src.height):
        for x in range(src.width):
            r,g,b,a=sp[x,y]
            if a < 10: continue
            lum=(r*3+g*6+b)//10
            idx=max(0,min(3,(lum*4)//256))
            base=list(IVORY[idx])
            n=hnoise(x,y,13)
            delta=((n>>10)%13)-6
            base[:3]=[max(0,min(255,c+delta)) for c in base[:3]]
            op[x,y]=tuple(base)
    # Organic moss/soil islands. These decorate existing opaque Pie texels only and retain its UV silhouette.
    for y in range(src.height):
        for x in range(src.width):
            if op[x,y][3] < 10: continue
            n=hnoise(x//2,y//2,31)
            # Lower atlas is leg-heavy: increase grounded soil/moss, plus sparse torso streaks.
            grounded = y >= 34
            lower = y >= 27
            # Reference-style growth is clustered and climbs upward in irregular fingers rather than salt-and-pepper noise.
            climb = lower and (((x // 3) + (y // 5) + ((n >> 9) & 3)) % 17 in (0, 1))
            moss_hit = ((n % (7 if grounded else 23)) == 0) or (grounded and (x + y * 3) % 17 in (0, 1, 2)) or climb
            soil_hit = grounded and (((n >> 5) % 9) in (0, 1, 2)) and not (((x + y) % 5) == 0)
            if soil_hit:
                op[x,y]=SOIL[(n>>12)%len(SOIL)]
            elif moss_hit:
                op[x,y]=MOSS[(n>>11)%len(MOSS)]
    return out


def author_details():
    img=Image.new('RGBA',(256,128),(0,0,0,0))
    # Material swatches used by box UV. Large enough for repeated cuboids.
    material(img,(0,0,80,40),RED,2,5)          # cap red
    material(img,(80,0,144,48),GILL,3,4)       # gills / stalks
    material(img,(144,0,160,32),WHITE,4,3)     # spots
    material(img,(160,0,176,64),MOSS,5,3)      # hair/moss
    material(img,(176,0,192,64),SHELF,6,3)     # shelf fungi
    material(img,(192,0,208,64),SOIL,7,4)      # bark/soil
    material(img,(208,0,224,48),BLACK,8,3)     # face/lashes
    material(img,(224,0,240,48),EYE,9,3)       # iris
    material(img,(240,0,256,32),BLUSH,10,4)    # blush
    # Secondary repeated material banks lower half to keep box-UV reads in bounds.
    material(img,(0,64,64,128),MOSS,15,4)
    material(img,(64,64,128,128),SHELF,16,4)
    material(img,(128,64,192,128),GILL_SHADOW,17,5)  # dark undercap plane; light ribs sit below it
    material(img,(192,64,224,128),SOIL,18,4)
    material(img,(224,64,256,128),BLACK,19,4)      # dark root/toe material
    # Hand-authored cap speckles inside the red bank so broad layers have native pixel breakup.
    d=ImageDraw.Draw(img)
    for x,y,w,h in [(10,7,5,3),(27,5,7,4),(48,11,4,5),(63,4,8,3),(18,24,6,4),(39,29,9,4),(67,25,5,5)]:
        d.rectangle([x,y,x+w-1,y+h-1], fill=WHITE[(x+y)%len(WHITE)])
    # Eye-bank catchlights and warm iris ring.
    d.rectangle([225,5,237,21], fill=EYE[1]); d.rectangle([228,8,235,19], fill=EYE[2]); d.rectangle([232,8,235,11], fill=WHITE[0])
    # Moss weave and shelf-fungus striations keep large 3D locks/tiers from reading as flat bars.
    for x,y,w,h in [(162,5,3,8),(168,13,2,11),(171,29,3,9),(164,43,2,12),(6,74,3,13),(19,89,2,17),(38,70,3,11),(51,101,2,16)]:
        d.rectangle([x,y,x+w-1,y+h-1], fill=MOSS[2])
    for x,y,w in [(177,7,10),(180,18,8),(176,31,12),(70,73,22),(78,87,18),(66,102,27)]:
        d.rectangle([x,y,x+w-1,y+1], fill=SHELF[2])
    return img


def cube(uv, box, *, inflate=0.0, mirror=False):
    d={"uv":list(uv),"box":[float(v) for v in box]}
    if inflate: d['inflate']=inflate
    if mirror: d['mirror']=True
    return d


def part(name, cubes=None, parent=None, pose=None):
    d={"name":name,"pose":list(pose or [0,0,0,0,0,0]),"cubes":list(cubes or [])}
    if parent: d['parent']=parent
    return d


def recipe():
    P=[]

    def mini_mushroom(scale=1.0):
        # Scale is intentionally applied to every axis; dev2 carried a scale parameter but did not
        # use it, which made all crown mushrooms identical. The reference clearly mixes sizes.
        def sb(box):
            x,y,z,dx,dy,dz=box
            return (x*scale,y*scale,z*scale,dx*scale,dy*scale,dz*scale)
        return [
            cube((80,24),sb((-.48,-2.35,-.48,.96,2.35,.96))),
            cube((128,72),sb((-1.20,-2.20,-1.20,2.40,.20,2.40))),
            cube((0,22),sb((-1.35,-2.72,-1.35,2.7,.62,2.7))),
            cube((144,8),sb((-.82,-2.91,-.45,1.22,.20,.9))),
        ]

    # Oversized asymmetrical storybook cap. Broad brim + seven-step dome + corner lobes give the
    # attached reference's soft mushroom silhouette without replacing Pie's animation hierarchy.
    P.append(part('cap_root',[
        cube((0,0),(-10.15,-8.25,-7.95,20.30,1.20,15.90)),
        cube((0,0),(-9.45,-9.35,-8.90,18.90,1.60,17.80)),
        cube((0,0),(-8.25,-10.78,-8.20,16.50,1.82,16.40)),
        cube((0,0),(-6.85,-12.28,-7.05,13.70,1.85,14.10)),
        cube((0,0),(-5.35,-13.62,-5.50,10.70,1.62,11.00)),
        cube((0,0),(-3.70,-14.76,-3.90,7.40,1.40,7.80)),
        cube((0,0),(-2.20,-15.55,-2.40,4.40,1.00,4.80)),
        # irregular brim lobes/corners: the reference is not a perfect rectangle from 3/4 view
        cube((0,0),(-10.75,-7.90,-5.10,3.35,.92,10.20)),
        cube((0,0),(7.40,-8.00,-5.55,3.35,.94,11.10)),
        cube((0,0),(-6.25,-7.78,-9.85,12.50,.88,2.55)),
        cube((0,0),(-6.60,-7.85,7.30,13.20,.90,2.65)),
        cube((0,0),(-9.60,-8.02,-8.85,3.40,.76,2.55)),
        cube((0,0),(6.45,-8.08,6.85,3.35,.78,2.45)),
    ]))

    # Cream underside with a thick lip. The plate is deliberately inset so the red brim remains
    # visible while the gill fan hangs below it at ordinary Minecraft camera height.
    P.append(part('gill_plate',[cube((128,64),(-9.00,-7.08,-8.50,18.0,.82,17.0))],parent='cap_root'))
    P.append(part('gill_skirt',[
        cube((128,64),(-8.95,-6.42,-8.72,17.9,.60,1.12)),
        cube((128,64),(-8.95,-6.42,7.60,17.9,.60,1.12)),
        cube((128,64),(-8.82,-6.42,-7.58,1.12,.60,15.16)),
        cube((128,64),(7.70,-6.42,-7.58,1.12,.60,15.16)),
        cube((128,72),(-7.7,-6.34,-8.84,3.25,.42,.62)),
        cube((128,72),(4.55,-6.34,8.22,3.25,.42,.62)),
    ],parent='cap_root'))
    P.append(part('gill_hub',[cube((112,0),(-1.20,-6.02,-1.20,2.40,.82,2.40))],parent='cap_root'))

    # Twenty-four ribs are deliberately lowered beneath the lip after the first native-client pass
    # showed that the old thick skirt hid the fan at ordinary camera height.
    for i in range(24):
        a=i*math.tau/24.0
        length=8.15 if i % 2 == 0 else 7.65
        y=-5.70 + (0.08 if i % 3 == 0 else 0.0)
        P.append(part(f'gill_rib_{i}',[
            cube((96 if i % 2 == 0 else 112,0),(-.225,y,-length,.45,.42,max(1.0,length-.72)))
        ],parent='cap_root',pose=(0,0,0,0,a,0)))

    # Raised white cap patches: real cuboid relief, mixed sizes, and a deliberately non-mirrored layout.
    spots=[
        (-6.6,-14.05,-3.0,4.0,.50,2.7),(-2.15,-15.40,-2.2,3.2,.50,2.8),(1.9,-14.78,-5.2,3.35,.48,2.65),
        (4.2,-13.15,-1.6,3.55,.46,3.25),(-7.5,-11.55,3.8,3.15,.44,2.45),(1.0,-12.35,5.35,3.75,.44,2.35),
        (6.35,-10.22,3.15,2.45,.42,2.55),(-1.05,-11.15,-7.75,2.65,.40,2.20),(-8.75,-9.42,-1.05,2.25,.37,2.35),
        (7.05,-9.62,-5.30,2.30,.38,2.00),(-4.2,-12.92,-5.8,2.0,.38,1.9),(3.35,-11.55,2.3,1.95,.36,1.8),
        (-5.9,-10.25,-7.4,1.75,.34,1.65),(5.75,-11.0,6.15,1.95,.36,1.7),(-.35,-13.15,6.2,2.2,.38,1.65),
        (8.0,-8.9,.3,1.65,.32,1.75),(-9.1,-8.95,5.2,1.55,.32,1.55),(.25,-15.05,1.45,1.55,.34,1.45),
    ]
    P.append(part('cap_spots',[cube((144,0),s) for s in spots],parent='cap_root'))
    # Edge-facing white patches stay visible from normal eye level instead of existing only on the dome top.
    P.append(part('cap_side_spots',[
        cube((144,0),(-7.65,-10.05,-9.08,3.15,1.42,.34)), cube((144,0),(-1.55,-9.55,-9.18,2.65,1.10,.34)),
        cube((144,0),(4.35,-9.18,-9.02,2.85,1.35,.34)), cube((144,0),(-8.96,-9.52,7.62,2.55,1.20,.34)),
        cube((144,0),(2.10,-9.62,8.10,3.25,1.18,.34)), cube((144,0),(-10.22,-9.15,-4.20,.34,1.42,2.85)),
        cube((144,0),(-10.12,-8.72,2.10,.34,1.18,2.35)), cube((144,0),(9.88,-9.08,-5.30,.34,1.36,2.65)),
        cube((144,0),(9.70,-8.72,2.85,.34,1.14,2.30)), cube((144,0),(6.70,-10.42,5.80,1.85,.90,.36)),
    ],parent='cap_root'))

    # Seven miniature red-white mushrooms around the cap, with the scale bug fixed so the cluster
    # actually contains small/medium/hero sprouts like the reference image.
    for name,x,y,z,scale,rx,rz in [
        ('mini_cap_r',7.25,-11.85,4.95,1.24,0.0,.10),
        ('mini_cap_l',-7.55,-10.35,-3.75,.92,0.0,-.12),
        ('mini_cap_back',4.35,-10.72,7.35,.72,.06,.08),
        ('mini_cap_front',-4.35,-11.35,-7.30,.66,-.04,-.10),
        ('mini_cap_top',2.70,-15.20,1.80,.60,0.0,.05),
        ('mini_cap_right_front',8.20,-9.50,-2.00,.58,.03,.14),
        ('mini_cap_left_back',-6.20,-9.72,7.15,.52,-.03,-.14),
        ('mini_cap_front_hero',-1.20,-12.05,-7.45,.88,-.04,.02),
        ('mini_cap_edge_hero',9.55,-9.62,3.25,1.05,.02,-.34),
    ]:
        P.append(part(name,mini_mushroom(scale),parent='cap_root',pose=(x,y,z,rx,0,rz)))

    # Moss roots under the brim bridge the cap into the moving hair. Four clusters prevent the hair
    # from reading as two isolated green strips when viewed from behind.
    P.append(part('cap_moss_left',[
        cube((160,0),(-1.30,-1.0,-.78,2.6,4.5,1.56)),cube((160,8),(-1.0,2.05,-.68,2.0,3.2,1.36)),
        cube((0,64),(-.58,.25,-1.38,1.16,4.6,1.0))
    ],parent='cap_root',pose=(-6.7,-7.05,-.1,0,0,.12)))
    P.append(part('cap_moss_right',[
        cube((160,0),(-1.30,-1.0,-.78,2.6,4.7,1.56)),cube((160,8),(-1.0,2.15,-.68,2.0,3.3,1.36)),
        cube((0,64),(-.58,.32,.38,1.16,4.7,1.0))
    ],parent='cap_root',pose=(6.7,-7.05,-.1,0,0,-.12)))
    P.append(part('cap_moss_front',[
        cube((160,0),(-.95,-.8,-.55,1.9,3.8,1.1)),cube((0,64),(-.45,1.2,-.82,.90,3.6,.72)),cube((160,16),(.25,.4,.18,.78,3.9,.72))
    ],parent='cap_root',pose=(-2.2,-7.0,-6.6,0,0,.07)))
    P.append(part('cap_moss_back',[
        cube((0,64),(-1.0,-.8,-.58,2.0,4.1,1.16)),cube((160,16),(-.42,1.0,.45,.84,3.9,.74)),cube((0,72),(.42,.3,-.1,.72,4.2,.72))
    ],parent='cap_root',pose=(2.6,-7.05,6.4,0,0,-.07)))

    # Dimensional face. Eyes are warm brown with raised irises/catchlights; the nose/mouth remains a
    # readable creeper motif and blush is a thin 3D overlay rather than baked-only pixels.
    P.append(part('face_details',[
        cube((208,0),(-3.78,-4.82,-4.48,3.20,3.25,.30)), cube((208,0),(.58,-4.82,-4.48,3.20,3.25,.30)),
        cube((224,0),(-3.35,-4.36,-4.80,2.28,2.40,.32)), cube((224,0),(1.08,-4.36,-4.80,2.28,2.40,.32)),
        cube((224,24),(-2.72,-3.92,-5.15,.62,.62,.22)), cube((224,24),(1.68,-3.92,-5.15,.62,.62,.22)),
        cube((208,20),(-.82,-2.18,-4.72,1.64,1.38,.44)), cube((208,24),(-1.78,-.86,-4.74,3.56,1.42,.45)),
        cube((208,28),(-1.28,.42,-4.70,.72,.70,.34)), cube((208,28),(.56,.42,-4.70,.72,.70,.34)),
        cube((240,0),(-4.15,-1.55,-4.60,1.55,.68,.20)), cube((240,0),(2.60,-1.55,-4.60,1.55,.68,.20)),
    ]))

    # Real 3D eyelashes. A top bar plus eight progressively offset feathers per side gives the strong
    # outer sweep visible in the reference while staying blocky/Minecraft-native.
    P.append(part('lashes_left',[
        cube((208,0),(-4.10,-5.32,-5.12,3.85,.36,.30)),
        cube((208,0),(-4.75,-5.27,-5.10,1.25,.32,.29)),cube((208,0),(-5.12,-5.00,-5.09,1.13,.30,.28)),
        cube((208,0),(-5.36,-4.68,-5.08,1.05,.28,.28)),cube((208,0),(-5.48,-4.34,-5.07,.96,.26,.27)),
        cube((208,0),(-5.45,-4.00,-5.06,.86,.24,.26)),cube((208,0),(-4.90,-3.78,-5.05,.72,.22,.25)),
        cube((208,0),(-3.90,-5.56,-5.06,1.40,.22,.24)),cube((208,0),(-2.90,-5.62,-5.05,1.05,.20,.23)),
    ],parent='face_details',pose=(0,0,0,0,0,-.115)))
    P.append(part('lashes_right',[
        cube((208,0),(.25,-5.32,-5.12,3.85,.36,.30)),
        cube((208,0),(3.50,-5.27,-5.10,1.25,.32,.29)),cube((208,0),(3.98,-5.00,-5.09,1.13,.30,.28)),
        cube((208,0),(4.31,-4.68,-5.08,1.05,.28,.28)),cube((208,0),(4.52,-4.34,-5.07,.96,.26,.27)),
        cube((208,0),(4.59,-4.00,-5.06,.86,.24,.26)),cube((208,0),(4.18,-3.78,-5.05,.72,.22,.25)),
        cube((208,0),(2.50,-5.56,-5.06,1.40,.22,.24)),cube((208,0),(1.85,-5.62,-5.05,1.05,.20,.23)),
    ],parent='face_details',pose=(0,0,0,0,0,.115)))
    P.append(part('eyelid_left',[cube((128,64),(-3.82,-4.86,-4.99,3.28,3.32,.13))],parent='face_details'))
    P.append(part('eyelid_right',[cube((128,64),(.54,-4.86,-4.99,3.28,3.32,.13))],parent='face_details'))

    # Short face-framing moss bangs bridge the cap/hair to the cheeks without covering the eyes.
    P.append(part('face_bangs',[
        cube((160,24),(-4.55,-6.08,-5.08,.72,2.30,.64)), cube((0,96),(-3.65,-6.18,-5.10,.58,1.72,.60)),
        cube((160,24),(-2.72,-6.24,-5.07,.52,1.24,.58)), cube((160,24),(2.20,-6.24,-5.07,.52,1.24,.58)),
        cube((0,96),(3.07,-6.18,-5.10,.58,1.72,.60)), cube((160,24),(3.83,-6.08,-5.08,.72,2.30,.64)),
    ],parent='face_details'))

    # Six true spring-chain locks: side/front/back on both sides. Every visible hanging hair family is
    # segmented root->mid->tip, so front/back strands no longer fake physics with one rigid part.
    hair_specs=[
        ('hair_left', -4.85,-5.65,.25, .12, 2.75,5.0,4.55),
        ('hair_right', 4.85,-5.65,.25,-.12, 2.75,5.1,4.65),
        ('hair_front_left',-3.75,-5.30,-3.95,.15,2.15,4.45,4.05),
        ('hair_front_right',3.75,-5.30,-3.95,-.15,2.15,4.55,4.10),
        ('hair_back_left',-3.95,-5.35,3.75,.13,2.35,4.70,4.25),
        ('hair_back_right',3.95,-5.35,3.75,-.13,2.35,4.80,4.30),
    ]
    for stem,x,y,z,rz,width,mid_len,tip_len in hair_specs:
        root=f'{stem}_root'; mid=f'{stem}_mid'; tip=f'{stem}_tip'
        P.append(part(root,[
            cube((160,0),(-width/2,-1.0,-.75,width,4.75,1.50)),
            cube((0,64),(-width*.27,-.55,.55,width*.54,4.20,.84)),
            cube((0,96),(-width*.55,.35,-.32,width*.24,3.10,.66)),
            cube((160,24),(width*.30,.92,-.26,width*.20,2.48,.58)),
        ],pose=(x,y,z,0,0,rz)))
        P.append(part(mid,[
            cube((160,10),(-width*.40,-.25,-.67,width*.80,mid_len,1.34)),
            cube((0,72),(-width*.23,.12,.51,width*.46,max(3.6,mid_len-.55),.74)),
            cube((0,104),(-width*.49,.72,-.24,width*.22,max(2.80,mid_len-1.35),.60)),
            cube((160,26),(width*.24,1.12,-.34,width*.18,max(2.25,mid_len-1.80),.54)),
        ],parent=root,pose=(0,3.45,0,0,0,rz*.62)))
        P.append(part(tip,[
            cube((160,20),(-width*.31,-.10,-.59,width*.62,tip_len,1.18)),
            cube((0,80),(-width*.18,.42,.44,width*.36,max(3.1,tip_len-.65),.64)),
            cube((0,112),(-width*.43,.90,-.20,width*.20,max(2.20,tip_len-1.55),.52)),
            cube((160,28),(width*.22,1.40,-.28,width*.16,max(1.70,tip_len-2.05),.48)),
        ],parent=mid,pose=(0,max(3.45,mid_len-.9),0,0,0,rz*.45)))

    # Torso fungal garden: clustered moss, bark, front/side/back shelf fungi and mini red caps.
    P.append(part('body_details',[
        cube((0,64),(-3.45,-19.35,-2.46,1.18,8.05,.44)), cube((0,72),(2.18,-17.35,-2.47,1.05,6.45,.44)),
        cube((0,80),(-.58,-18.05,-2.48,.86,5.15,.40)), cube((0,88),(3.62,-15.2,-1.20,.42,4.75,1.10)),
        cube((192,64),(-1.72,-15.45,-2.50,3.25,2.85,.40)), cube((192,72),(2.48,-12.35,-2.50,1.62,2.15,.38)),
        cube((192,80),(-4.02,-11.25,-1.65,1.25,2.55,.36)), cube((192,88),(-.75,-9.95,2.05,2.05,1.55,.34)),
        # front + side shelf tiers
        cube((64,64),(-4.65,-16.25,-2.62,2.10,.58,2.45)), cube((64,70),(2.82,-13.65,-2.15,1.90,.54,2.20)),
        cube((64,76),(-4.42,-12.78,-1.52,1.82,.50,2.02)), cube((64,82),(2.95,-9.98,-1.52,1.65,.46,1.90)),
        cube((64,88),(-2.85,-18.05,1.65,2.05,.50,1.65)), cube((64,94),(1.65,-15.55,1.72,1.85,.46,1.50)),
        # central hero shroom
        cube((80,24),(-.48,-11.85,-2.82,.96,2.30,.96)), cube((0,22),(-1.25,-12.34,-3.38,2.50,.62,2.10)),
        cube((144,8),(-.76,-12.54,-3.53,1.18,.20,.86)),
        # right-side shroom
        cube((80,24),(2.68,-16.18,-2.78,.76,1.82,.76)), cube((0,22),(2.04,-16.58,-3.22,1.95,.52,1.65)),
        # tiny rear/side shroom
        cube((80,24),(-3.45,-9.65,1.72,.60,1.40,.60)), cube((0,22),(-3.92,-9.98,1.35,1.52,.43,1.30)),
        # reference-like right shoulder cluster: visible stem, cream undercap, red cap, white relief spot
        cube((128,72),(3.72,-11.55,-2.42,.78,1.95,.78)), cube((128,72),(3.24,-11.92,-2.90,1.82,.18,1.58)),
        cube((0,22),(3.04,-12.28,-3.10,2.22,.48,1.98)), cube((144,8),(3.65,-12.45,-3.25,.78,.18,.62)),
        cube((64,100),(2.92,-9.15,-1.65,1.85,.44,1.86)),
    ]))

    # Chest details stay on Pie's live breast bone, so all fungi inherit its breathing/gait animation.
    P.append(part('chest_details',[
        cube((0,64),(-3.62,-2.20,-2.58,1.00,3.72,.40)), cube((0,72),(-.28,-2.05,-2.60,.76,2.95,.36)),
        cube((0,80),(3.00,-1.35,-2.05,.38,2.55,1.02)), cube((192,64),(1.58,-1.92,-2.62,1.98,1.52,.38)),
        cube((64,64),(-4.05,-.28,-2.70,1.75,.48,2.05)), cube((64,70),(2.62,.12,-2.70,1.52,.45,1.84)),
        cube((64,76),(-1.35,1.02,-2.66,1.45,.42,1.62)),
        cube((80,24),(2.50,-.80,-2.98,.82,1.92,.82)), cube((0,22),(1.78,-1.26,-3.30,2.18,.55,1.72)),
        cube((144,8),(2.10,-1.43,-3.44,1.00,.18,.74)),
        cube((80,24),(-2.52,.02,-2.94,.62,1.40,.62)), cube((0,22),(-3.05,-.30,-3.20,1.70,.45,1.38)),
        cube((80,24),(.15,1.25,-2.82,.48,1.10,.48)), cube((0,22),(-.22,1.02,-3.10,1.18,.36,1.02)),
    ]))

    # Four individually staggered overgrown legs. Dark rooted geometry, moss fingers, shelves and red
    # sprouts deliberately climb upward instead of forming a clean horizontal gradient.
    leg_specs=[(1,-1),(2,1),(3,-1),(4,1)]
    for i,side in leg_specs:
        outer_x = -4.58 if side < 0 else -1.20
        inner_x = -1.98 if side < 0 else -4.30
        mushroom_x = -3.25 if side < 0 else -1.08
        cubes=[
            cube((192,64),(-4.35,-8.15,1.48,4.62,2.72,4.72)),
            cube((192,80),(-4.18,-6.18,1.32,1.35,2.25,4.92)),
            cube((0,64),(-4.10,-8.05,1.20,1.28,6.55,.44)),
            cube((0,72),(-1.34,-7.82,5.34,.96,5.15,.38)),
            cube((0,80),(-2.65,-5.85,1.12,.72,4.95,.38)),
            cube((64,64),(outer_x,-6.20,1.00,2.20,.55,2.68)),
            cube((64,70),(inner_x,-4.62,.98,1.82,.50,2.25)),
            cube((64,76),(outer_x+.24,-3.02,.96,1.72,.46,2.00)),
            cube((64,82),(inner_x+.18,-1.75,1.00,1.45,.42,1.75)),
            cube((80,24),(mushroom_x,-5.72,.56,.88,2.18,.88)),
            cube((0,22),(mushroom_x-.66,-6.22,.10,2.18,.60,1.95)),
            cube((144,8),(mushroom_x-.22,-6.42,-.05,.98,.19,.76)),
            # dark pulled-from-ground toe/root pads beneath the soil shell
            cube((224,64),(-4.22,-5.52,1.20,4.30,.68,1.05)),
            cube((224,72),(-4.22,-5.52,5.05,4.30,.68,1.10)),
            cube((224,80),(-4.38,-5.50,2.18,.82,.64,2.92)),
        ]
        if i in (1,3):
            cubes += [
                cube((80,24),(-1.38,-2.92,5.16,.62,1.46,.62)),cube((0,22),(-1.84,-3.26,4.76,1.58,.45,1.36)),
                cube((64,88),(-4.38,-.62,3.62,1.45,.38,1.55)),
            ]
        else:
            cubes += [
                cube((80,24),(-3.60,-3.22,5.12,.62,1.46,.62)),cube((0,22),(-4.08,-3.56,4.72,1.58,.45,1.36)),
                cube((64,88),(-1.42,-.72,3.52,1.42,.38,1.55)),
            ]
        P.append(part(f'leg{i}_details',cubes))

    return {"schema":"mctexintel.voxel_recipe.v1","name":"Shroomboom Details dev5","id":"creeperella:shroomboom_details","texture_size":[256,128],"texture":"shroomboom_details.png","parts":P}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    REF.mkdir(parents=True,exist_ok=True); TOOLS.mkdir(parents=True,exist_ok=True)
    (RES/'textures/entity').mkdir(parents=True,exist_ok=True); (RES/'textures/item').mkdir(parents=True,exist_ok=True)
    body=author_body(); body.save(RES/'textures/entity/shroomboom_creeper.png',optimize=False)
    details=author_details(); details.save(RES/'textures/entity/shroomboom_details.png',optimize=False)
    # Spawn egg uses native pixel art, not a generated concept image.
    egg=Image.new('RGBA',(16,16),(0,0,0,0)); d=ImageDraw.Draw(egg)
    d.rectangle((5,1,10,3),fill=RED[1]); d.rectangle((3,3,12,6),fill=RED[0])
    for r in [(5,2,6,2),(9,4,10,4),(4,4,4,5),(11,3,11,4)]: d.rectangle(r,fill=WHITE[0])
    d.rectangle((6,6,9,12),fill=IVORY[1]); d.rectangle((4,10,6,14),fill=IVORY[2]); d.rectangle((9,10,11,14),fill=IVORY[2])
    d.rectangle((4,13,6,14),fill=SOIL[2]); d.rectangle((9,13,11,14),fill=SOIL[2]); d.point((5,11),fill=MOSS[1]); d.point((10,10),fill=MOSS[0])
    egg.save(RES/'textures/item/shroomboom_creeper_spawn_egg.png')
    rec=recipe(); recipe_path=TOOLS/'shroomboom_detail_recipe.json'; recipe_path.write_text(json.dumps(rec,indent=2),encoding='utf-8')
    bb=REF/'shroomboom_details.bbmodel'; java=JAVA/'ShroomboomDetailModelLayers.java'
    audit_out=REF/'voxel-recipe-audit.json'
    cmd=[sys.executable,'-m','mctexture_intel','voxel-recipe',str(recipe_path),'--java-out',str(java),'--package','dev.herbertofury.creeperella.client','--class-name','ShroomboomDetailModelLayers','--bbmodel-out',str(bb),'--texture','shroomboom_details.png','--audit-out',str(audit_out)]
    env=dict(__import__('os').environ); env['PYTHONPATH']=str(TI)
    subprocess.run(cmd,check=True,env=env,cwd=TI)
    audit=json.loads(audit_out.read_text(encoding='utf-8'))
    if not audit.get('passed'):
        raise RuntimeError(f'voxel recipe audit failed: {audit["uv"]["out_of_bounds_count"]} UV overflow cube(s)')
    if USER_REF.is_file(): shutil.copy2(USER_REF,REF/'Shroomboom.png')
    ref_md='''# Shroomboom reference contract\n\n- User-supplied visual reference: `Shroomboom.png`. It is provenance/reference art only; no image generation is used.\n- Stable Boomshroom remains unchanged. Shroomboom is a separate visual-development variant.\n- Base animation/silhouette authority: Pie/Female Creeperella hierarchy, including chest/breast animation.\n- Target visual motifs from the reference: oversized stepped red/white cap, visible cream gills, dimensional expressive eyes, real 3D eyelashes, moss/vine hair, shelf fungi, mini mushrooms, bark/soil/moss growth from legs into torso.\n- Hair uses six articulated root/mid/tip chains (left/right side, front, and back) with runtime spring/inertia motion plus irregular per-segment moss fringes.\n- Natural spawning stays disabled until visual approval.\n'''
    (REF/'REFERENCE.md').write_text(ref_md,encoding='utf-8')
    critical=[RES/'textures/entity/shroomboom_creeper.png',RES/'textures/entity/shroomboom_details.png',RES/'textures/item/shroomboom_creeper_spawn_egg.png',recipe_path,bb,java,audit_out]
    if (REF/'Shroomboom.png').exists(): critical.append(REF/'Shroomboom.png')
    (REF/'SHA256SUMS.txt').write_text(''.join(f"{sha(p)}  {p.relative_to(ROOT)}\n" for p in critical),encoding='utf-8')
    print(json.dumps({"body":str(critical[0]),"detail":str(critical[1]),"parts":len(rec['parts']),"cubes":sum(len(p['cubes']) for p in rec['parts']),"bbmodel":str(bb)},indent=2))

if __name__=='__main__': main()
