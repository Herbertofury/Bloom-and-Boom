#!/usr/bin/env python3
import sys, math
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
sys.path.insert(0,'/mnt/data/creeperella1416_work/tools')
import render_mobs_visual_qa as r
OUT=Path('/mnt/data/Creeperella-1.4.16-Trials');OUT.mkdir(parents=True,exist_ok=True)
BG=(8,13,24,255);W,H=320,320;BASE=278
try:F=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
except:F=ImageFont.load_default()
MAP={'leftLeg':('leftlegsub2','leftfoot3',False),'rightLeg':('rightlegsub2','rightfoot3',False),'leftLegback':('leftlegsub','leftfoot2',True),'rightLegback':('rightlegsub','rightfoot2',True)}
def P(root,*p):return r.find(root,*p)
def solve(hind,ty,tz):
 udy,udz=5.25,1.75;ldy,ldz=(5.05,-.25) if hind else (3.0,0.0)
 l1=math.hypot(udy,udz);l2=math.hypot(ldy,ldz);a1=math.atan2(udz,udy);a2=math.atan2(ldz,ldy)
 d=math.hypot(ty,tz);d=max(abs(l1-l2)+.08,min(l1+l2-.08,d));ck=max(-1,min(1,(d*d-l1*l1-l2*l2)/(2*l1*l2)));k=math.acos(ck);ta=math.atan2(tz,ty);ua=ta-math.atan2(l2*math.sin(k),l1+l2*math.cos(k))-a1;la=k+a1-a2;pa=-(ua+la);return ua,la,pa
def ik(root,n,ty,tz,dx=0,dy=0,dz=0,ry=0,rz=0):
 ln,fn,hind=MAP[n];leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn);ua,la,pa=solve(hind,ty,tz);leg.x+=dx;leg.y+=dy;leg.z+=dz;leg.rx=ua;leg.ry=ry;leg.rz=rz;lo.rx=la;fo.rx=pa

def ground():
 root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',40,0,0,0,0,cat_motion='idle');_,pts=r.build_polygons(root,tex,tw,th,0,0,subdivide=False);return float(pts[:,1].min())
G=ground()
def render(root,tex,tw,th,yaw,label):
 _,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=False);mnx,mxx=pts[:,0].min(),pts[:,0].max();mny,mxy=pts[:,1].min(),pts[:,1].max();sc=min((W-20)/max(mxx-mnx,1),(BASE-36)/max(mxy-G,1));xo=W/2-(mnx+mxx)/2*sc;yo=BASE+G*sc
 can=np.zeros((H,W,4),dtype=np.uint8);can[:]=np.array(BG);im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);d.line((10,BASE,W-10,BASE),fill=(110,145,200,255),width=2);can=np.array(im);z=np.full((H,W),np.inf);polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=True)
 for _,q,rgba in polys:
  pp=np.array([[xo+p[0]*sc,yo-p[1]*sc,p[2]] for p in q]);r._raster_triangle(can,z,pp[[0,1,2]],rgba);r._raster_triangle(can,z,pp[[0,2,3]],rgba)
 im=Image.fromarray(can,'RGBA');ImageDraw.Draw(im).text((8,8),label,font=F,fill=(240,245,255));return im

def sprawl(root,k):
 # full belly-down sploot: front legs straight forward, hind legs straight back, all near-parallel to ground
 w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head')
 vals=[
  (1.95,.16,.42,-.12,1.55,-7.45,1.80,9.40,.20,.30,.06),
  (2.10,.14,.48,-.14,1.30,-7.65,1.55,9.65,.26,.36,.04),
  (2.25,.12,.52,-.16,1.10,-7.80,1.30,9.85,.32,.44,.03),
  (1.85,.18,.38,-.10,1.75,-7.30,2.05,9.20,.16,.26,.08),
 ][k]
 wy,bp,uy,up,fy,fz,hy,hz,fx,hx,roll=vals
 w.y+=wy;b.y+=1.25;b.rx+=bp;u.y+=uy;u.rx+=up;h.xRot if False else None
 h.rx+=.02
 ik(root,'leftLeg',fy,fz,dx=fx,dy=.10,rz=roll);ik(root,'rightLeg',fy,fz,dx=-fx,dy=.10,rz=-roll)
 ik(root,'leftLegback',hy,hz,dx=hx,dy=.12,rz=roll*.65);ik(root,'rightLegback',hy,hz,dx=-hx,dy=.12,rz=-roll*.65)
 t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.z+=.10;t.rx=.04;t.ry=0;t.rz=0;t2.rx=.10;t2.ry=0;t2.rz=0

def rest_leg(root,row):
 n,dx,dy,dz,rx,ry,rz,lrx,frx=row;ln,fn,_=MAP[n];leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn);leg.x+=dx;leg.y+=dy;leg.z+=dz;leg.rx=rx;leg.ry=ry;leg.rz=rz;lo.rx=lrx;fo.rx=frx
ROLL=[.82,.86,.80,.84]; GY=[-2.8239,-3.8517,-2.5893,-3.0833]; BL=[.05,.04,.06,.025];UL=[.025,.02,.03,.01];HL=[.008,.006,.01,.002];BP=[.12,.10,.14,.08];UP=[-.09,-.08,-.10,-.07];HP=[.01,0,.015,-.005];UY=[.29,.27,.31,.23];HY=[-.08,-.02,.08,-.28];HRY=[.14,.16,.12,.22]
LEGS=[[('leftLeg',2.0,1.4,-1.6,-.10,-.20,.72,.50,-.10),('rightLeg',4.0,1.7,-.4,-.58,-.10,.54,1.35,-.35),('leftLegback',2.4,1.6,1.2,.55,.12,.82,1.40,-.45),('rightLegback',4.3,1.8,.4,.28,.06,.60,1.25,-.30)],[('leftLeg',2.8,1.3,-2.2,.05,-.24,.86,.38,-.05),('rightLeg',4.4,1.8,-.2,-.65,-.10,.52,1.42,-.38),('leftLegback',3.0,1.6,1.6,.62,.12,.96,1.46,-.48),('rightLegback',4.7,1.9,.5,.30,.06,.62,1.28,-.30)],[('leftLeg',1.8,1.4,-1.2,-.22,-.16,.70,.78,-.18),('rightLeg',3.8,1.8,-.2,-.62,-.08,.50,1.38,-.35),('leftLegback',2.8,1.7,1.8,.70,.12,1.02,1.50,-.52),('rightLegback',4.6,2.0,.7,.34,.05,.62,1.30,-.32)],[('leftLeg',2.4,1.2,-1.8,-.02,-.22,.78,.46,-.08),('rightLeg',4.2,1.6,-.5,-.52,-.12,.58,1.25,-.30),('leftLegback',2.5,1.5,1.3,.50,.14,.88,1.36,-.40),('rightLegback',4.4,1.8,.4,.25,.06,.60,1.20,-.28)]]
def horse(root,v=3,tailcfg=0):
 w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head');roll=ROLL[v];w.y+=GY[v];w.rz+=roll;b.y+=1.15;b.rx+=BP[v];b.rz+=-roll+BL[v];u.y+=UY[v];u.rx+=UP[v];u.rz+=UL[v]-BL[v];h.y+=HY[v];h.rx+=HP[v];h.ry+=HRY[v];h.rz+=HL[v]-UL[v]
 for row in LEGS[v]:rest_leg(root,row)
 t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2')
 configs=[(.28,-.08,0,.58,-.04,0,0),(.18,.16,.10,.44,.28,.08,.10),(.10,.26,.16,.36,.42,.12,.18),(.22,-.24,-.10,.48,-.38,-.08,.12)]
 rx,ry,rz,tx,ty,tz,z=configs[tailcfg];t.z+=z;t.rx=rx;t.ry=ry;t.rz=rz;t2.rx=tx;t2.ry=ty;t2.rz=tz

for name,func in [('SPRAWL',sprawl)]:
 sheet=Image.new('RGBA',(2*W,4*H),BG)
 for k in range(4):
  for c,(yaw,vn) in enumerate([(-28,'3Q'),(-90,'SIDE')]):
   root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',42,0,0,0,0,cat_motion='sit');func(root,k);sheet.alpha_composite(render(root,tex,tw,th,yaw,f'{name} {k+1} · {vn}'),(c*W,k*H))
 out=OUT/'SPRAWL-sploot-trials.png';sheet.save(out);print(out)

sheet=Image.new('RGBA',(3*W,4*H),BG)
for k in range(4):
 for c,(yaw,vn) in enumerate([(-28,'3Q'),(-90,'SIDE'),(150,'REAR3Q')]):
  root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',42,0,0,0,0,cat_motion='sit');horse(root,3,k);sheet.alpha_composite(render(root,tex,tw,th,yaw,f'SIDE-LIE tail {k+1} · {vn}'),(c*W,k*H))
out=OUT/'SIDE-LIE-tail-visibility-trials.png';sheet.save(out);print(out)
