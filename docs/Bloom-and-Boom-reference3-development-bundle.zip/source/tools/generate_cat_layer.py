#!/usr/bin/env python3
import json, math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
GEO=ROOT/'reference-assets/cat/creeper.geo.json'
OUT=ROOT/'src/main/java/dev/herbertofury/creeperella/client/CatCreeperModelLayers.java'

def f(v):
    s=f'{float(v):.6f}'.rstrip('0').rstrip('.')
    if '.' not in s: s += '.0'
    return s+'F'

def ident(name):
    out=''.join(c if c.isalnum() or c=='_' else '_' for c in name)
    if out and out[0].isdigit(): out='b_'+out
    return out

def emit_layer(deformation):
    geo=json.load(open(GEO))['minecraft:geometry'][0]
    bones=geo['bones']; by={b['name']:b for b in bones}
    children={}
    for b in bones: children.setdefault(b.get('parent'),[]).append(b)
    lines=[]
    lines += ['        MeshDefinition mesh = new MeshDefinition();','        PartDefinition root = mesh.getRoot();']
    # Required direct children for CreeperModel. The visible Bedrock rig hangs under body.
    lines += [
      '        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 6.0F, 0.0F));',
      '        PartDefinition vanillaBody = root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(0.0F, 24.0F, 0.0F));',
      '        root.addOrReplaceChild("right_hind_leg", CubeListBuilder.create(), PartPose.offset(-2.0F, 18.0F, 4.0F));',
      '        root.addOrReplaceChild("left_hind_leg", CubeListBuilder.create(), PartPose.offset(2.0F, 18.0F, 4.0F));',
      '        root.addOrReplaceChild("right_front_leg", CubeListBuilder.create(), PartPose.offset(-2.0F, 18.0F, -4.0F));',
      '        root.addOrReplaceChild("left_front_leg", CubeListBuilder.create(), PartPose.offset(2.0F, 18.0F, -4.0F));',
    ]
    vars={None:'vanillaBody'}
    def visit(b):
        name=b['name']; var='part_'+ident(name)
        parent=b.get('parent'); pvar=vars[parent]
        piv=b.get('pivot',[0,0,0]); pp=by[parent].get('pivot',[0,0,0]) if parent else [0,0,0]
        cubes=b.get('cubes',[])
        lines.append(f'        CubeListBuilder cubes_{ident(name)} = CubeListBuilder.create();')
        for c in cubes:
            o=c['origin']; sz=c['size']; uv=c.get('uv',[0,0]); inf=float(c.get('inflate',0))+deformation
            lx=o[0]-piv[0]; ly=piv[1]-o[1]-sz[1]; lz=o[2]-piv[2]
            mirror=c.get('mirror',False)
            prefix=f'cubes_{ident(name)}.texOffs({int(uv[0])}, {int(uv[1])})'
            if mirror: prefix += '.mirror()'
            prefix += f'.addBox({f(lx)}, {f(ly)}, {f(lz)}, {f(sz[0])}, {f(sz[1])}, {f(sz[2])}, new CubeDeformation({f(inf)}));'
            lines.append('        '+prefix)
        rot=b.get('rotation',[0,0,0]); deg=math.pi/180
        ox=piv[0]-pp[0]; oy=-(piv[1]-pp[1]); oz=piv[2]-pp[2]
        # Blockbench Bedrock -> Java: X/Z rotations invert with the Y axis flip.
        rx=-rot[0]*deg; ry=rot[1]*deg; rz=-rot[2]*deg
        lines.append(f'        PartDefinition {var} = {pvar}.addOrReplaceChild("{name}", cubes_{ident(name)}, PartPose.offsetAndRotation({f(ox)}, {f(oy)}, {f(oz)}, {f(rx)}, {f(ry)}, {f(rz)}));')
        vars[name]=var
        for ch in children.get(name,[]): visit(ch)
    for b in children.get(None,[]): visit(b)
    lines.append('        return LayerDefinition.create(mesh, 128, 64);')
    return '\n'.join(lines)

text='''package dev.herbertofury.creeperella.client;\n\nimport net.minecraft.client.model.geom.PartPose;\nimport net.minecraft.client.model.geom.builders.CubeDeformation;\nimport net.minecraft.client.model.geom.builders.CubeListBuilder;\nimport net.minecraft.client.model.geom.builders.LayerDefinition;\nimport net.minecraft.client.model.geom.builders.MeshDefinition;\nimport net.minecraft.client.model.geom.builders.PartDefinition;\n\n/** Generated from the user-supplied Bedrock FemaleCreeper.mcpack geometry. */\npublic final class CatCreeperModelLayers {\n    private CatCreeperModelLayers() {}\n\n    public static LayerDefinition createCatLayer() {\n'''+emit_layer(0.0)+'''\n    }\n\n    public static LayerDefinition createCatChargeLayer() {\n'''+emit_layer(0.25)+'''\n    }\n}\n'''
OUT.write_text(text)
print(OUT)
