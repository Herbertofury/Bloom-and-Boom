#!/usr/bin/env python3
import sys,math
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
sys.path.insert(0,'/mnt/data/creeperella1416_work/tools')
import render_mobs_visual_qa as r
OUT=Path('/mnt/data/Creeperella-1.4.16-Trials');BG=(8,13,24,255);W=330;H=330;BASE=282
try:F=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
except:F=ImageFont.load_default()
MAP={'leftLeg':('leftlegsub2','leftfoot3',False),'rightLeg':('rightlegsub2','rightfoot3',False),'leftLegback':('leftlegsub','leftfoot2',True),'rightLegback':('rightlegsub','rightfoot2',True)}
def P(root,*p):return r.find(root,*p)
def solve(h,ty,tz):
 udy,udz=5.25,1.75;ldy,ldz=(5.05,-.25) if h else (3,0);l1=math.hypot(udy,udz);l2=math.hypot(ldy,ldz);a1=math.atan2(udz,udy);a2=math.atan2(ldz,ldy);d=max(abs(l1-l2)+.08,min(l1+l2-.08,math.hypot(ty,tz)));k=math.acos(max(-1,min(1,(d*d-l1*l1-l2*l2)/(2*l1*l2))));ta=math.atan2(tz,ty);ua=ta-math.atan2(l2*math.sin(k),l1+l2*math.cos(k))-a1;la=k+a1-a2;return ua,la,-(ua+la)
def ik(root,n,ty,tz,dx=0,dy=0,dz=0,ry=0,rz=0):
 ln,fn,h=MAP[n];leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn);ua,la,pa=solve(h,ty,tz);leg.x+=dx;leg.y+=dy;leg.z+=dz;leg.rx=ua;leg.ry=ry;leg.rz=rz;lo.rx=la;fo.rx=pa
def ground():
 root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',40,0,0,0,0,cat_motion='idle');_,pts=r.build_polygons(root,tex,tw,th,0,0,False);return float(pts[:,1].min())
G=ground()
def render(root,tex,tw,th,yaw,label):
 _,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=False);mnx,mxx=pts[:,0].min(),pts[:,0].max();mny,mxy=pts[:,1].min(),pts[:,1].max();sc=min((W-20)/max(mxx-mnx,1),(BASE-36)/max(mxy-G,1));xo=W/2-(mnx+mxx)/2*sc;yo=BASE+G*sc;can=np.zeros((H,W,4),dtype=np.uint8);can[:]=np.array(BG);im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);d.line((10,BASE,W-10,BASE),fill=(110,145,200,255),width=2);can=np.array(im);z=np.full((H,W),np.inf);polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=True)
 for _,q,rgba in polys:
  pp=np.array([[xo+p[0]*sc,yo-p[1]*sc,p[2]] for p in q]);r._raster_triangle(can,z,pp[[0,1,2]],rgba);r._raster_triangle(can,z,pp[[0,2,3]],rgba)
 im=Image.fromarray(can,'RGBA');ImageDraw.Draw(im).text((8,8),label,font=F,fill=(240,245,255));return im

def pose(root,k):
 w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head')
 vals=[
  (2.6,1.05,-.80,-.12,.55,-7.8,.65,9.9,.18),
  (3.0,1.20,-.95,-.15,.35,-7.95,.45,10.1,.12),
  (3.3,1.32,-1.05,-.18,.20,-8.05,.30,10.25,.08),
  (2.8,.92,-.70,-.10,.75,-7.65,.85,9.75,.22),
 ][k]
 wy,bx,ux,hx,fy,fz,hy,hz,roll=vals;w.y+=wy;b.y+=.40;b.rx+=bx;u.y+=.10;u.rx+=ux;h.rx+=hx
 ik(root,'leftLeg',fy,fz,dx=.22,dy=.05,rz=roll);ik(root,'rightLeg',fy,fz,dx=-.22,dy=.05,rz=-roll)
 ik(root,'leftLegback',hy,hz,dx=.30,dy=.05,rz=roll*.5);ik(root,'rightLegback',hy,hz,dx=-.30,dy=.05,rz=-roll*.5)
 t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.rx=-.35;t.ry=0;t.rz=0;t2.rx=-.30;t2.ry=0;t2.rz=0

sheet=Image.new('RGBA',(2*W,4*H),BG)
for k in range(4):
 for c,(yaw,vn) in enumerate([(-28,'3Q'),(-90,'SIDE')]):
  root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',42,0,0,0,0,cat_motion='sit');pose(root,k);sheet.alpha_composite(render(root,tex,tw,th,yaw,f'SPRAWL2 {k+1} · {vn}'),(c*W,k*H))
out=OUT/'SPRAWL2-sploot-trials.png';sheet.save(out);print(out)
