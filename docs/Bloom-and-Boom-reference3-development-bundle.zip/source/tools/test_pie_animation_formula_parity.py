#!/usr/bin/env python3
"""Numerically compare the 1.4.2 Pie native formulas with the supplied CEM expressions.

The source side is evaluated directly from the three supplied JEM files.  The port side is an
independent Python transcription of the formulas used by CreeperellaModel.  Sampling a spread of
idle/walk/look/hurt/aggro states makes sign, phase, constant, and visibility regressions obvious
without requiring a graphical Minecraft client.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
PIE = ROOT / "reference-assets" / "pie"
EPS = 2e-6


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def torad(value: float) -> float:
    return math.radians(value)


def easeinoutsine(value: float, start: float, end: float) -> float:
    x = clamp(value, 0.0, 1.0)
    eased = -(math.cos(math.pi * x) - 1.0) / 2.0
    return start + (end - start) * eased


def easeoutback(value: float, start: float, end: float) -> float:
    x = clamp(value, 0.0, 1.0) - 1.0
    c1 = 1.70158
    c3 = c1 + 1.0
    eased = 1.0 + c3 * x * x * x + c1 * x * x
    return start + (end - start) * eased


def source_channels(path: Path, state: dict[str, float]) -> dict[str, float | bool]:
    data = json.loads(path.read_text(encoding="utf-8"))
    root = next(model for model in data["models"] if model.get("id") == "root")
    blocks = root.get("animations", [])

    var = SimpleNamespace(
        b=state["b"],
        ls=state["ls"],
        idle=state["idle"],
        aggro=state["aggro"],
        hurt=state["hurt"],
        blink=state["blink"],
    )
    env: dict[str, object] = {
        "sin": math.sin,
        "cos": math.cos,
        "abs": abs,
        "pow": pow,
        "pi": math.pi,
        "clamp": clamp,
        "torad": torad,
        "easeinoutsine": easeinoutsine,
        "easeoutback": easeoutback,
        "var": var,
        "limb_speed": state["speed"],
        "head_yaw": state["head_yaw"],
        "head_pitch": state["head_pitch"],
    }
    out: dict[str, float | bool] = {}
    for block in blocks:
        for key, expression in block.items():
            if key.startswith("var."):
                continue
            value = eval(expression, {"__builtins__": {}}, env)  # trusted bundled project asset
            out[key] = value
            target, attr = key.split(".", 1)
            obj = env.setdefault(target, SimpleNamespace())
            setattr(obj, attr, value)
    return out


def port_core(s: dict[str, float]) -> dict[str, float | bool]:
    pi = math.pi
    deg = pi / 180.0
    b = s["b"]
    ls = s["ls"]
    speed = s["speed"]
    idle = s["idle"]
    yaw = clamp(s["head_yaw"], -70.0, 70.0) * deg
    inv_yaw = clamp(-s["head_yaw"], -70.0, 70.0) * deg
    pitch = s["head_pitch"] * deg
    clamped_pitch = clamp(s["head_pitch"], -70.0, 30.0) * deg
    hurt = s["hurt"]
    blink = s["blink"]
    stride = speed + 0.25
    quarter = pi / 2.0
    third = pi / 3.0
    idle_pitch = math.sin(b * 2.0) / (pi * 8.0) * idle

    o: dict[str, float | bool] = {
        "body.tx": -math.sin(b) * pi / 5.0 * idle,
        "body.ty": 5.0 - math.sin(b * 2.0) / 5.0 * idle + math.sin(ls * 2.0) / 2.0 * speed,
        "body.tz": -pitch * pi / 2.0 - 22.5 * deg * pi * pi * speed - hurt * pi,
        "body.rx": pitch / (pi * 2.0) + 22.5 * deg * speed + hurt / pi,
        "body.rz": -math.sin(b) / (pi * 5.0) * idle,
        "body.ry": yaw / 2.0 - math.cos(ls) / pi * (speed + 0.25),
        "breasts.ty": -17.0 + math.cos(b * 2.0) / 3.0 * idle + math.sin(ls * 2.0) / 2.0 * speed,
        "breasts.rx": 22.5 * deg + math.sin(b * 2.0) / (pi * 3.0) * idle - math.cos(ls * 2.0) / pi * speed - hurt / pi * 2.0,
        "breasts.ry": math.sin(ls) / pi * speed,
        "head2.ty": -20.0 + math.cos(b * 2.0) / 5.0 * idle - math.cos(ls * 2.0) / 2.0 * speed,
        "head2.rx": clamped_pitch - pitch / (pi * 2.0) - 22.5 * deg * speed - hurt / pi * 2.0,
        "head2.ry": yaw + inv_yaw / 2.0 + math.cos(ls) / pi * (speed + 0.25),
        "head2.rz": math.cos(b) / (pi * 5.0) * idle + math.sin(ls) / (pi * 2.0) * speed,
        "hair_left.ty": -6.0 + easeinoutsine(s["aggro"], 0.0, 1.0) + math.cos(b * 2.0) / 5.0 * idle + math.cos(ls * 2.0) * speed,
        "hair_left.rx": -hurt / pi,
        "hair_left.rz": math.sin(b) / (pi * 5.0) * idle - math.cos(ls) / (pi * 2.0) * speed,
        "hair_right.ty": -6.0 + easeinoutsine(s["aggro"], 0.0, 1.0) + math.cos(b * 2.0) / 5.0 * idle + math.cos(ls * 2.0) * speed,
        "hair_right.rx": -hurt / pi,
        "hair_right.rz": math.sin(b) / (pi * 5.0) * idle - math.cos(ls) / (pi * 2.0) * speed,
    }

    # Exact four-leg CEM program. These are absolute proxy transforms, not child-mesh deltas.
    o.update({
        "leg1.tx": -2.5 + yaw / 2.0,
        "leg1.ty": 18.0 + clamp(math.cos(0.25 + ls + math.cos(quarter + ls) / 2.0), -3.0, 0.0) * 3.0 * speed + hurt,
        "leg1.tz": 4.0 + yaw - math.sin(b * 2.0) * pi / 16.0 * idle + math.sin(ls - math.sin(third + ls) / 3.0) * 2.0 * stride,
        "leg1.rx": inv_yaw / pi + idle_pitch + (20.0 * deg + math.sin(0.5 + ls + math.cos(quarter + ls) / 2.0) * 2.0 / pi) * stride - hurt / pi,
        "leg1.ry": 10.0 * deg,
        "leg1.rz": -2.0 * deg + yaw / (pi * 2.0),
        "leg2.tx": 2.5 + yaw / 2.0,
        "leg2.ty": 18.0 + clamp(-math.cos(0.25 + ls - math.cos(quarter + ls) / 2.0), -3.0, 0.0) * 3.0 * speed + hurt,
        "leg2.tz": 4.0 + inv_yaw - math.sin(b * 2.0) * pi / 16.0 * idle - math.sin(ls - math.sin(-third + ls) / 3.0) * 2.0 * stride,
        "leg2.rx": yaw / pi + idle_pitch + (20.0 * deg - math.sin(0.5 + ls + math.cos(-quarter + ls) / 2.0) * 2.0 / pi) * stride - hurt / pi,
        "leg2.ry": -10.0 * deg,
        "leg2.rz": 2.0 * deg + yaw / (pi * 2.0),
        "leg3.tx": 2.5 + inv_yaw / 2.0,
        "leg3.ty": 18.0 + clamp(math.cos(0.25 + ls - math.cos(-quarter + ls) / 2.0), -3.0, 0.0) * 3.0 * speed + hurt,
        "leg3.tz": -4.0 + inv_yaw + math.sin(b * 2.0) * pi / 16.0 * idle + math.sin(ls + math.sin(-third + ls) / 3.0) * 2.0 * stride,
        "leg3.rx": yaw / pi - idle_pitch + (20.0 * deg + math.sin(0.5 + ls - math.cos(-quarter + ls) / 2.0) * 2.0 / pi) * stride + hurt / pi,
        "leg3.ry": -10.0 * deg,
        "leg3.rz": 2.0 * deg + inv_yaw / (pi * 2.0),
        "leg4.tx": -2.5 + inv_yaw / 2.0,
        "leg4.ty": 18.0 + clamp(-math.cos(0.25 + ls - math.cos(quarter + ls) / 2.0), -3.0, 0.0) * 3.0 * speed + hurt,
        "leg4.tz": -4.0 + yaw + math.sin(b * 2.0) * pi / 16.0 * idle - math.sin(ls + math.sin(third + ls) / 3.0) * 2.0 * stride,
        "leg4.rx": inv_yaw / pi - idle_pitch + (20.0 * deg - math.sin(0.5 + ls - math.cos(quarter + ls) / 2.0) * 2.0 / pi) * stride + hurt / pi,
        "leg4.ry": 10.0 * deg,
        "leg4.rz": -2.0 * deg + inv_yaw / (pi * 2.0),
    })

    pupil_y = blink + clamp(-s["head_pitch"], -90.0, 0.0) / 180.0
    o.update({
        "l_eye_white.sy": blink,
        "l_pupil.tx": -1.0 + clamp(-s["head_yaw"], 0.0, 90.0) / 180.0,
        "l_pupil.sy": pupil_y,
        "l_pupil.visible": pupil_y >= 0.0,
        "r_eye_white.sy": blink,
        "r_pupil.tx": 1.0 + clamp(-s["head_yaw"], -90.0, 0.0) / 180.0,
        "r_pupil.sy": pupil_y,
        "r_pupil.visible": pupil_y >= 0.0,
        "l_eyebrow.ty": 1.0 - blink,
        "r_eyebrow.ty": 1.0 - blink,
    })
    return o


def port_channels(kind: str, s: dict[str, float]) -> dict[str, float | bool]:
    o = port_core(s)
    pi = math.pi
    deg = pi / 180.0
    b, ls, speed, idle = s["b"], s["ls"], s["speed"], s["idle"]
    pitch = s["head_pitch"] * deg
    hurt = s["hurt"]
    if kind in {"bunny", "bee"}:
        o.update({
            "tail.rx": 22.5 * deg + 20.0 * deg * (easeinoutsine(s["aggro"], 0.0, 1.0)),
            "tail.ry": math.sin(b) * 2.0 / pi * idle - math.sin(ls) * 2.0 / pi * speed,
            "left_ear.rx": pitch / 3.0 + hurt / pi * 3.0,
            "left_ear.rz": 10.0 * deg + 20.0 * deg * easeoutback(s["aggro"], 0.0, 1.0) + math.cos(b) / (pi * 2.0) * idle - math.cos(ls) * 2.0 / pi * speed,
            "right_ear.rx": pitch / 3.0 + hurt / pi * 3.0,
            "right_ear.rz": -10.0 * deg - 20.0 * deg * easeoutback(s["aggro"], 0.0, 1.0) + math.cos(b) / (pi * 2.0) * idle - math.cos(ls) * 2.0 / pi * speed,
        })
    if kind == "bunny":
        pf = clamp(s["head_pitch"] / 90.0 * 2.0 + 1.0, -1.0, 1.25)
        o.update({
            "right_ear2.rx": 90.0 * deg + pitch / 3.0 + math.cos(b * 2.0) / pi * (idle * pf) - math.sin(ls) * 2.0 / pi * (speed * pf) + hurt / pi * 3.0,
            "right_ear2.rz": math.cos(b) / pi * idle - math.sin(ls) * 2.0 / pi * speed,
        })
    if kind == "bee":
        o.update({
            "left_wings.rx": 22.5 * deg,
            "left_wings.ry": -22.5 * deg + math.sin(b * 2.0) / pi * idle + math.sin(ls * 2.0) * 2.0 / pi * speed + math.cos(ls) / pi * speed,
            "left_wings.rz": -22.5 * deg,
            "right_wings.ry": 22.5 * deg - math.sin(b * 2.0) / pi * idle - math.sin(ls * 2.0) * 2.0 / pi * speed + math.cos(ls) / pi * speed,
            "right_wings.rz": 22.5 * deg,
        })
    return o


SAMPLES = [
    dict(b=1.37, ls=1.37, speed=0.0, idle=1.0, head_yaw=0.0, head_pitch=0.0, hurt=0.0, aggro=0.0, blink=1.0),
    dict(b=2.91, ls=4.22, speed=0.18, idle=0.46, head_yaw=34.0, head_pitch=-22.0, hurt=0.0, aggro=0.35, blink=0.42),
    dict(b=4.18, ls=7.03, speed=0.62, idle=0.0, head_yaw=-58.0, head_pitch=27.0, hurt=0.31, aggro=0.75, blink=0.03),
    dict(b=5.73, ls=9.81, speed=1.0, idle=0.0, head_yaw=95.0, head_pitch=-84.0, hurt=-0.22, aggro=1.0, blink=0.0),
]


def compare(kind: str, file_name: str) -> int:
    checked = 0
    for sample_i, state in enumerate(SAMPLES):
        src = source_channels(PIE / file_name, state)
        port = port_channels(kind, state)
        missing = sorted(set(src) - set(port))
        if missing:
            raise SystemExit(f"FAIL: {kind} port missing channels: {missing}")
        for key, expected in src.items():
            actual = port[key]
            if isinstance(expected, bool):
                if actual is not expected:
                    raise SystemExit(f"FAIL: {kind} sample {sample_i} {key}: {actual!r} != {expected!r}")
            elif not math.isclose(float(actual), float(expected), rel_tol=0.0, abs_tol=EPS):
                raise SystemExit(
                    f"FAIL: {kind} sample {sample_i} {key}: port={actual:.9f} source={expected:.9f}"
                )
            checked += 1
    return checked


def main() -> None:
    total = 0
    total += compare("female", "creeper.jem")
    total += compare("bunny", "creeper2.jem")
    total += compare("bee", "creeper3.jem")
    print(f"PASS: {total} sampled Pie channel evaluations match supplied CEM formulas")
    print("PASS: body/head counter-motion, four-leg phase gait, blink/gaze, Bunny ears/tail, and Bee wings are numerically source-faithful")


if __name__ == "__main__":
    main()
