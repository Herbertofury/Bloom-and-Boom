#!/usr/bin/env python3
"""UV-aware surface finishing from verified vanilla-derived atlas. No AI image generation."""
from pathlib import Path
from PIL import Image,ImageStat
R=Path(__file__).resolve().parents[1];T=R/'src/main/resources/assets/creeperella/textures/entity';V=R/'.mvf-generated/vanilla'
# Shared Pie cuboid UV rectangles; positions/deformation/animation remain untouched.
CUBES=[(0,0,8,8,8,False),(0,16,8,8,8,False),(32,0,6,8,4,False),(32,12,6,8,4,False),(52,0,8,4,4,False),(52,8,8,4,4,False),(76,0,8,4,4,False),(76,8,8,4,4,False)]+[(u,52,4,8,4,True) for u in range(0,128,16)]
for name,material,iriscolor in [('nacrella','pearlescent',(137,91,197)),('verdalia','verdant',(76,170,75)),('mariglow','ochre',(224,151,32))]:
 im=Image.open(T/f'{name}_creeper.png').convert('RGBA');glow=Image.open(T/f'{name}_creeper_e.png').convert('RGBA');scale=im.width//128;vanilla=Image.open(V/f'{material}_froglight_side.png').convert('RGB');mean=ImageStat.Stat(vanilla).mean
 for u,v,w,h,d,foot in CUBES:
  faces=[(u+d,v,w,d,False),(u+d+w,v,w,d,False),(u,v+d,d,h,True),(u+d,v+d,w,h,True),(u+d+w,v+d,d,h,True),(u+2*d+w,v+d,w,h,True)]
  for fx,fy,fw,fh,vertical in faces:
   for y in range(fh*scale):
    for x in range(fw*scale):
     px,py=fx*scale+x,fy*scale+y
     if px>=im.width or py>=im.height:continue
     old=im.getpixel((px,py))
     if not old[3]:continue
     ux,uy=px//scale,py//scale
     if (26<=ux<29 and 20<=uy<25) or (8<=ux<16 and 8<=uy<16 and max(old[:3])<82):continue
     edge=min(x,fw*scale-1-x)/max(1,fw*scale/2);height=y/max(1,fh*scale-1)
     shade=0.72+0.22*min(1,edge*3)
     if not vertical:shade=0.95
     shade+=0.025 if x%(scale*2)==scale else -0.008
     if foot and vertical and height>0.76:shade*=max(0.13,1-(height-0.76)*3.8)
     sample=vanilla.getpixel((int(x*16/(fw*scale)),int(y*16/(fh*scale))))
     rgb=tuple(max(0,min(255,round((mean[k]*0.73+sample[k]*0.27)*shade))) for k in range(3))
     im.putpixel((px,py),(*rgb,old[3]));glow.putpixel((px,py),(*(round(c*0.13) for c in rgb),old[3]))
 im.save(T/f'{name}_creeper.png');glow.save(T/f'{name}_creeper_e.png')
 # Dedicated colored iris; white highlights are real separate mesh glints, not a white iris tile.
 iris=Image.new('RGBA',(64,64))
 for y in range(64):
  for x in range(64):
   delta=8 if y%8<4 else -12
   iris.putpixel((x,y),(*(max(0,min(255,c+delta)) for c in iriscolor),255))
 iris.save(T/f'{name}_face_iris.png')
 print(name,'UV panels and colored iris finished',im.size)
