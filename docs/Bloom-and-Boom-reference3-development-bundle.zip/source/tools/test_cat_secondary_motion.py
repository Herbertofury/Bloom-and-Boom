#!/usr/bin/env python3
"""Compatibility entry point for the Creeperella 1.4.8 Cat locomotion/state regression gate."""
from test_cat_aaa_gait import main

if __name__ == '__main__':
    main()
