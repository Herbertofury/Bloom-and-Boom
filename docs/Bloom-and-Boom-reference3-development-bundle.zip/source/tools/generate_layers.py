import json, math, re, copy
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / 'reference-assets'
OUT = ROOT / 'src/main/java/dev/herbertofury/creeperella/client/CreeperellaModelLayers.java'
OUT.parent.mkdir(parents=True, exist_ok=True)

FILES = {
    'female': WORK/'pie/creeper.jem',
    'bunny': WORK/'pie/creeper2.jem',
    'bee': WORK/'pie/creeper3.jem',
    'female_charge': WORK/'pie/creeper_charge.jem',
    'bunny_charge': WORK/'pie/creeper_charge2.jem',
    'bee_charge': WORK/'pie/creeper_charge3.jem',
}

PIVOTS = {
    'head': (0.0, 6.0, 0.0),
    'body': (0.0, 6.0, 0.0),
    'leg1': (-2.0, 18.0, 4.0),
    'leg2': (2.0, 18.0, 4.0),
    'leg3': (-2.0, 18.0, -4.0),
    'leg4': (2.0, 18.0, -4.0),
}
MAP = {
    'head': 'head', 'body':'body',
    'leg1':'right_hind_leg', 'leg2':'left_hind_leg',
    'leg3':'right_front_leg', 'leg4':'left_front_leg'
}

def f(v):
    if abs(v) < 1e-8: v = 0.0
    s = f'{v:.6f}'.rstrip('0').rstrip('.')
    if s == '-0': s='0'
    if '.' not in s: s += '.0'
    return s+'F'

def sanitize(s):
    s = re.sub(r'[^A-Za-z0-9_]', '_', s or 'part')
    if s and s[0].isdigit(): s = 'p_'+s
    return s

def prep_pose(part):
    inv = part.get('invertAxis','')
    tr = list(part.get('translate',[0,0,0]))
    while len(tr)<3: tr.append(0)
    rot = list(part.get('rotate',[0,0,0]))
    while len(rot)<3: rot.append(0)
    for i, ax in enumerate('xyz'):
        if ax in inv: tr[i] = -tr[i]
        if ax in inv: rot[i] = -rot[i]
        rot[i] = math.radians(rot[i])
    return tr, rot

def prep_box(box, inv):
    c = list(box['coordinates'])
    x,y,z,w,h,d = map(float,c)
    if 'x' in inv: x = -x-w
    if 'y' in inv: y = -y-h
    if 'z' in inv: z = -z-d
    return x,y,z,w,h,d

def cube_code(box, inv, indent, force_thin_planes=False):
    x,y,z,w,h,d = prep_box(box, inv)
    tex = box.get('textureOffset')
    comment = ''
    if not tex:
        # CEM per-face UV cannot be represented exactly by vanilla CubeListBuilder.
        # Choose the first meaningful face origin and keep the geometry. For the
        # supplied Cherry model this is one zero-width decorative branch plane.
        for key in ('uvEast','uvWest','uvNorth','uvSouth','uvUp','uvDown'):
            uv=box.get(key)
            if uv and len(uv)>=2:
                tex=[uv[0],uv[1]]; comment=' /* per-face CEM UV approximated at face origin */'; break
    if not tex: tex=[0,0]
    add = float(box.get('sizeAdd',0.0))
    if 'sizesAdd' in box and len(box['sizesAdd']) == 3:
        sx,sy,sz=box['sizesAdd']
        # CubeDeformation in 1.20.1 is uniform; supplied packs do not use sizesAdd.
        add=max(float(sx),float(sy),float(sz))
    # Preserve zero-thickness decorative planes. A tiny thickness avoids them
    # disappearing on vanilla's cuboid path while remaining visually equivalent.
    if force_thin_planes:
        if w == 0: w = 0.01
        if h == 0: h = 0.01
        if d == 0: d = 0.01
    else:
        if w == 0 and not box.get('textureOffset'): w = 0.01
        if h == 0 and not box.get('textureOffset'): h = 0.01
        if d == 0 and not box.get('textureOffset'): d = 0.01
    return f'{indent}.texOffs({int(tex[0])}, {int(tex[1])}).addBox({f(x)}, {f(y)}, {f(z)}, {f(w)}, {f(h)}, {f(d)}, new CubeDeformation({f(add)})){comment}'

def emit_part(lines, parent_var, part, varname, tex_size, pose_override=None, depth=0, force_thin_planes=False):
    inv = part.get('invertAxis','')
    tr, rot = prep_pose(part)
    if pose_override is not None:
        tr, rot = pose_override
    builder = 'CubeListBuilder.create()'
    boxes = part.get('boxes',[]) or []
    if boxes:
        # emit chain in a temporary CubeListBuilder variable for readability
        bvar = varname + 'Cubes'
        lines.append(f'        CubeListBuilder {bvar} = CubeListBuilder.create()')
        for box in boxes:
            lines.append(cube_code(box, inv, '                ', force_thin_planes))
        lines[-1] += ';'
        builder = bvar
    pose = f'PartPose.offsetAndRotation({f(tr[0])}, {f(tr[1])}, {f(tr[2])}, {f(rot[0])}, {f(rot[1])}, {f(rot[2])})'
    lines.append(f'        PartDefinition {varname} = {parent_var}.addOrReplaceChild("{sanitize(part.get("id",varname))}", {builder}, {pose});')
    for idx, sub in enumerate(part.get('submodels',[]) or []):
        emit_part(lines, varname, sub, f'{varname}_{sanitize(sub.get("id",str(idx)))}_{idx}', tex_size, None, depth+1, force_thin_planes)
    return varname

def generate_method(name, data, force_thin_planes=False):
    tex_size = data.get('textureSize',[64,32])
    models = [copy.deepcopy(m) for m in data.get('models',[]) if m.get('part') in MAP]
    bypart = {m.get('part'):m for m in models}
    lines=[f'    public static LayerDefinition {name}() {{', '        MeshDefinition mesh = new MeshDefinition();', '        PartDefinition root = mesh.getRoot();']
    parent_vars={}
    for part in ('head','body','leg1','leg2','leg3','leg4'):
        target=MAP[part]
        pivot=PIVOTS[part]
        v='vanilla_'+target
        lines.append(f'        PartDefinition {v} = root.addOrReplaceChild("{target}", CubeListBuilder.create(), PartPose.offset({f(pivot[0])}, {f(pivot[1])}, {f(pivot[2])}));')
        parent_vars[part]=v
    lines.append('')

    # Pie packs model their visible head as body/head2. Detach it and attach it
    # to the actual vanilla head pivot so vanilla look animation rotates it.
    body=bypart.get('body')
    detached_head=None
    if body:
        subs=body.get('submodels',[]) or []
        for i,sub in enumerate(list(subs)):
            if sub.get('id') == 'head2':
                detached_head=copy.deepcopy(sub)
                del subs[i]
                body['submodels']=subs
                break
    if detached_head is not None:
        btr,brot=prep_pose(body)
        htr,hrot=prep_pose(detached_head)
        combined=([btr[i]+htr[i] for i in range(3)], [brot[i]+hrot[i] for i in range(3)])
        emit_part(lines,parent_vars['head'],detached_head,'custom_head2',tex_size,combined, force_thin_planes=force_thin_planes)
    elif 'head' in bypart:
        emit_part(lines,parent_vars['head'],bypart['head'],'custom_head',tex_size, force_thin_planes=force_thin_planes)

    for part in ('body','leg1','leg2','leg3','leg4'):
        if part in bypart:
            emit_part(lines,parent_vars[part],bypart[part],f'custom_{part}',tex_size, force_thin_planes=force_thin_planes)
    lines.append(f'        return LayerDefinition.create(mesh, {int(tex_size[0])}, {int(tex_size[1])});')
    lines.append('    }')
    return '\n'.join(lines)

header='''package dev.herbertofury.creeperella.client;

import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Vanilla ModelPart layers generated from the user-supplied OptiFine CEM models.
 * This removes any runtime OptiFine/EMF/ETF dependency while preserving the supplied geometry.
 * Generated by creeperella_work/generate_layers.py.
 */
public final class CreeperellaModelLayers {
    private CreeperellaModelLayers() {}

'''
if __name__ == '__main__':
    methods=[]
    for name,path in FILES.items():
        data=json.loads(path.read_text(encoding='utf-8'))
        if name == 'cherry_charge':
            def puff(part):
                for box in part.get('boxes',[]) or []:
                    box['sizeAdd'] = float(box.get('sizeAdd', 0.0)) + 0.5
                for sub in part.get('submodels',[]) or []:
                    puff(sub)
            for part in data.get('models',[]):
                puff(part)
        methods.append(generate_method('create' + ''.join(x.capitalize() for x in name.split('_')) + 'Layer', data, force_thin_planes=name.startswith('cherry')))

    OUT.write_text(header+'\n\n'.join(methods)+'\n}\n',encoding='utf-8')
    print(OUT)
    print('bytes',OUT.stat().st_size)
