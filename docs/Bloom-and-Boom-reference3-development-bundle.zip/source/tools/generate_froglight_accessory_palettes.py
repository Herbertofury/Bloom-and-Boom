from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
TEX = ROOT / 'src/main/resources/assets/creeperella/textures/entity'

PALETTES = {
    'verdalia': {
        'outer': [(74,139,72),(105,172,98),(148,207,138),(205,235,199)],
        'inner': [(47,111,51),(76,145,72),(111,181,101),(171,218,160)],
        'leaf':  [(31,70,37),(47,94,49),(67,119,62),(99,151,90)],
        'glow':  [(39,121,49),(57,154,64),(88,187,91),(142,220,140)],
        'iris':  [(19,66,28),(34,124,47),(57,191,75),(143,244,149),(240,255,240)],
    },
    'mariglow': {
        'outer': [(173,110,24),(207,142,32),(232,180,59),(245,220,135)],
        'inner': [(142,81,18),(178,111,21),(211,146,32),(234,190,78)],
        'leaf':  [(46,60,34),(66,82,40),(92,105,50),(127,137,67)],
        'glow':  [(157,88,18),(190,114,21),(218,145,34),(239,186,77)],
        'iris':  [(90,50,8),(157,91,13),(227,151,30),(255,218,91),(255,251,215)],
    },
}


def shade_band(im, x0, colors):
    for y in range(64):
        for x in range(x0, x0 + 16):
            lx = x - x0
            edge = min(lx, 15 - lx)
            cell = ((x // 2) + (y // 2)) % 4
            if edge <= 1:
                idx = 0
            elif cell == 0:
                idx = 3
            elif cell in (1, 3):
                idx = 2
            else:
                idx = 1
            if lx % 7 == 3 and y % 6 in (0, 1):
                idx = max(0, idx - 1)
            im.putpixel((x, y), (*colors[idx], 255))


def glow_band(im, x0, colors):
    for y in range(64):
        for x in range(x0, x0 + 16):
            lx = x - x0
            dx = min(lx % 8, 7 - (lx % 8))
            dy = min(y % 8, 7 - (y % 8))
            idx = 2 if dx >= 1 and dy >= 1 else 1
            if (lx % 8 in (3, 4) and y % 8 in (3, 4)) or (lx + y) % 17 == 0:
                idx = 3
            im.putpixel((x, y), (*colors[idx], 255))


def iris_texture(colors):
    im = Image.new('RGBA', (64, 64), (*colors[1], 255))
    for y in range(64):
        for x in range(64):
            xx = x % 8
            yy = y % 8
            edge = min(xx, 7 - xx, yy, 7 - yy)
            if edge == 0:
                c = colors[0]
            elif xx in (2, 3) and yy in (1, 2):
                c = colors[4]
            elif xx in (3, 4) and yy in (3, 4):
                c = colors[3]
            elif yy >= 4:
                c = colors[1]
            else:
                c = colors[2]
            im.putpixel((x, y), (*c, 255))
    return im


def generate_nacrella():
    # Calibrated around the actual Pearlescent Froglight hues but held a step darker / richer
    # so the accessory set stops reading as glossy plastic.
    outer = [(212,191,200),(226,211,211),(249,244,243),(255,254,253)]
    inner = [(194,164,195),(212,191,200),(239,230,225),(249,244,243)]
    leaf  = [(92,76,116),(111,93,135),(132,113,156),(162,141,183)]
    glow  = [(103,73,144),(129,96,171),(161,126,201),(214,188,236)]
    irisc = [(47,32,69),(93,65,126),(140,104,176),(196,167,223),(247,240,255)]

    acc = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    for y in range(64):
        for x in range(64):
            band = x // 16
            lx = x % 16
            xx = lx % 8
            yy = y % 8
            edge = min(xx, 7 - xx, yy, 7 - yy)
            if band == 0:
                colors = outer
                c = colors[0] if edge == 0 else colors[1] if edge == 1 else colors[3] if (xx in (3, 4) and yy in (2, 3)) else colors[2]
            elif band == 1:
                colors = inner
                c = colors[0] if edge == 0 else colors[1] if yy < 2 or xx in (0, 7) else colors[3] if (xx in (3, 4) and yy in (3, 4)) else colors[2]
            elif band == 2:
                colors = leaf
                e = min(lx, 15 - lx)
                c = colors[0] if e < 2 else colors[1] if e < 4 else colors[2]
                if (lx % 8 == 3 and yy in (3, 4)) or ((lx + y) % 13 == 0):
                    c = colors[3]
            else:
                colors = glow
                dx = min(xx, 7 - xx)
                dy = min(yy, 7 - yy)
                c = colors[3] if dx >= 2 and dy >= 2 else colors[2] if dx >= 1 and dy >= 1 else colors[1]
                if dx == 0 and dy == 0:
                    c = colors[0]
            acc.putpixel((x, y), (*c, 255))
    acc.save(TEX / 'nacrella_accessories.png', optimize=True)

    em = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    for y in range(64):
        for x in range(48, 64):
            xx = (x - 48) % 8
            yy = y % 8
            dx = min(xx, 7 - xx)
            dy = min(yy, 7 - yy)
            if dx >= 1 and dy >= 1:
                c = glow[3] if dx >= 2 and dy >= 2 else glow[2]
                em.putpixel((x, y), (*c, 255))
    em.save(TEX / 'nacrella_accessories_e.png', optimize=True)

    iris = Image.new('RGBA', (64, 64), (*glow[1], 255))
    for y in range(64):
        for x in range(64):
            xx = x % 8
            yy = y % 8
            edge = min(xx, 7 - xx, yy, 7 - yy)
            if edge == 0:
                c = irisc[0]
            elif xx in (3, 4) and yy in (2, 3):
                c = irisc[4]
            elif xx in (2, 5) or yy in (1, 6):
                c = irisc[3]
            elif yy < 3:
                c = irisc[2]
            else:
                c = irisc[1]
            iris.putpixel((x, y), (*c, 255))
    iris.save(TEX / 'nacrella_face_iris.png', optimize=True)


generate_nacrella()
for name, p in PALETTES.items():
    base = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    shade_band(base, 0, p['outer'])
    shade_band(base, 16, p['inner'])
    shade_band(base, 32, p['leaf'])
    glow_band(base, 48, p['glow'])
    base.save(TEX / f'{name}_accessories.png', optimize=True)

    em = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    glow_band(em, 48, p['glow'])
    em.save(TEX / f'{name}_accessories_e.png', optimize=True)

    iris_texture(p['iris']).save(TEX / f'{name}_face_iris.png', optimize=True)

print('generated deterministic Froglight accessory + iris palettes, including Minecraft-style nacrella refresh')
