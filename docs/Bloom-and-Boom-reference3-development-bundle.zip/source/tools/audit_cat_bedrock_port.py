#!/usr/bin/env python3
"""Independent QA gate for the FemaleCreeper Bedrock -> Forge Java port.

The conversion expectations here are intentionally separate from the generator. They are derived
from the composition of Blockbench's Bedrock geometry importer and Minecraft Java 1.17+ entity
exporter (with the Java Y-flip used by this rig):

  Java local bone offset = (dx, -dy, dz), where d* is Bedrock pivot delta to parent.
  Root Bedrock pivot is relative to Java model Y=24, so its wrapper-local offset is (x, -y, z).
  Java bind rotations retain all authored Bedrock signs.
  Java local cube = (origin.x-pivot.x,
                     -(origin.y+size.y-pivot.y),
                     origin.z-pivot.z).

Animation rotations likewise retain authored Bedrock signs after Blockbench import/export. Java
ModelPart position Y is down, so direct ModelPart translation uses negative Bedrock animation Y.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REF = ROOT / "reference-assets/cat"
JAVA_MODEL = ROOT / "src/main/java/dev/herbertofury/creeperella/client/CatCreeperModelLayers.java"
JAVA_ANIM = ROOT / "src/main/java/dev/herbertofury/creeperella/client/CatCreeperSourceAnimation.java"
CREEPER_MODEL = ROOT / "src/main/java/dev/herbertofury/creeperella/client/CreeperellaModel.java"
TEXTURES = ROOT / "src/main/resources/assets/creeperella/textures/entity"

EXPECTED_SHA256 = {
    "creeper.geo.json": "738081fcdb99d5200ce01f9c58283cd693cc78868decdeac6e7249ff1e6bda10",
    "creeper_charged.geo.json": "cc2095ce5d9d11a8efb2dfb433f74f126e3398bfe6efcbabb7b9c2de1b394168",
    "creeper.animation.json": "aaaa5b007956a264e099b76b71b4e1808c194e4be7a74af8a1c34f68a04f63a7",
    "creeper.png": "220e9c4000e3d2a1b752af36e041f0266661d0f91bc1a77875df66784a5f693a",
    "creeper_armor.png": "dfcd53cb643b5d305bc31d9380f2156c546d28bc3fe2e57cff47eaa55f6fea4b",
}

NUM = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?F?"
EPS = 2.0e-5


def f(v: str) -> float:
    return float(v.rstrip("Ff"))


def close(a: float, b: float, label: str) -> None:
    if abs(a - b) > EPS:
        raise AssertionError(f"{label}: expected {b:.8f}, got {a:.8f}")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_geo(name: str):
    doc = json.loads((REF / name).read_text(encoding="utf-8"))
    geo = doc["minecraft:geometry"][0]
    return geo["description"], geo["bones"]


def method_section(text: str, name: str) -> str:
    m = re.search(r"public\s+static\s+LayerDefinition\s+" + re.escape(name) + r"\s*\(\s*\)\s*\{", text)
    if not m:
        raise AssertionError(f"Missing generated method {name}")
    depth, i = 1, m.end()
    while i < len(text) and depth:
        depth += (text[i] == "{") - (text[i] == "}")
        i += 1
    if depth:
        raise AssertionError(f"Unbalanced method {name}")
    return text[m.end():i-1]


def parse_generated(section: str):
    cubes: dict[str, list[dict]] = {}
    current_mirror: dict[str, bool] = {}
    # Every generated cube is one statement, which makes the parser deliberately strict.
    cube_re = re.compile(
        r"(cubes_[A-Za-z0-9_]+)\.texOffs\((\d+),\s*(\d+)\)\.mirror\((true|false)\)\.addBox\("
        rf"({NUM}),\s*({NUM}),\s*({NUM}),\s*({NUM}),\s*({NUM}),\s*({NUM}),\s*"
        rf"new CubeDeformation\(({NUM})\)\)"
    )
    for m in cube_re.finditer(section):
        b, u, v, mir, x, y, z, dx, dy, dz, deform = m.groups()
        cubes.setdefault(b, []).append({
            "uv": [int(u), int(v)], "mirror": mir == "true",
            "box": [f(x), f(y), f(z), f(dx), f(dy), f(dz)], "inflate": f(deform)
        })

    parts = {}
    part_re = re.compile(
        rf"PartDefinition\s+(part_[A-Za-z0-9_]+)\s*=\s*([A-Za-z0-9_]+)\.addOrReplaceChild\("
        rf'"([^"]+)",\s*(cubes_[A-Za-z0-9_]+),\s*PartPose\.offsetAndRotation\('
        rf"({NUM}),\s*({NUM}),\s*({NUM}),\s*({NUM}),\s*({NUM}),\s*({NUM})\)\)"
    )
    for m in part_re.finditer(section):
        var, parent_var, name, builder, x, y, z, rx, ry, rz = m.groups()
        parts[name] = {
            "var": var, "parent_var": parent_var, "builder": builder,
            "pose": [f(x), f(y), f(z), f(rx), f(ry), f(rz)], "cubes": cubes.get(builder, [])
        }
    return parts


def audit_geometry(method: str, source_name: str) -> int:
    text = JAVA_MODEL.read_text(encoding="utf-8")
    generated = parse_generated(method_section(text, method))
    desc, bones = load_geo(source_name)
    if len(generated) != len(bones):
        raise AssertionError(f"{method}: generated {len(generated)} authored parts, source has {len(bones)} bones")
    by_name = {b["name"]: b for b in bones}
    pivots = {n: b.get("pivot", [0, 0, 0]) for n, b in by_name.items()}

    cube_count = 0
    for bone in bones:
        name = bone["name"]
        got = generated.get(name)
        if got is None:
            raise AssertionError(f"{method}: missing bone {name}")
        pivot = [float(x) for x in bone.get("pivot", [0, 0, 0])]
        parent = bone.get("parent")
        if parent:
            pp = [float(x) for x in pivots[parent]]
            expected_offset = [pivot[0]-pp[0], -(pivot[1]-pp[1]), pivot[2]-pp[2]]
            expected_parent_var = "part_" + re.sub(r"[^A-Za-z0-9_]", "_", parent)
        else:
            # Authored roots are nested under the required vanilla CreeperModel body at Y=24.
            expected_offset = [pivot[0], -pivot[1], pivot[2]]
            expected_parent_var = "vanillaBody"
        rot = [math.radians(float(x)) for x in bone.get("rotation", [0, 0, 0])]
        for i, (actual, exp) in enumerate(zip(got["pose"], expected_offset + rot)):
            close(actual, exp, f"{method}:{name}:pose[{i}]")
        if got["parent_var"] != expected_parent_var:
            raise AssertionError(f"{method}:{name}: expected parent {expected_parent_var}, got {got['parent_var']}")

        source_cubes = bone.get("cubes", [])
        if len(got["cubes"]) != len(source_cubes):
            raise AssertionError(f"{method}:{name}: generated {len(got['cubes'])} cubes, source has {len(source_cubes)}")
        bone_mirror = bool(bone.get("mirror", False))
        for ci, (gc, sc) in enumerate(zip(got["cubes"], source_cubes)):
            origin = [float(x) for x in sc["origin"]]
            size = [float(x) for x in sc["size"]]
            exp_box = [
                origin[0]-pivot[0],
                -(origin[1]+size[1]-pivot[1]),
                origin[2]-pivot[2],
                size[0], size[1], size[2],
            ]
            for i, (actual, exp) in enumerate(zip(gc["box"], exp_box)):
                close(actual, exp, f"{method}:{name}:cube{ci}:box[{i}]")
            if gc["uv"] != [int(sc["uv"][0]), int(sc["uv"][1])]:
                raise AssertionError(f"{method}:{name}:cube{ci}: UV mismatch")
            exp_mirror = bool(sc.get("mirror", bone_mirror))
            if gc["mirror"] != exp_mirror:
                raise AssertionError(f"{method}:{name}:cube{ci}: mirror expected {exp_mirror}, got {gc['mirror']}")
            close(gc["inflate"], float(sc.get("inflate", 0.0)), f"{method}:{name}:cube{ci}:inflate")
            cube_count += 1

    # Texture declaration must remain exact too.
    if f"LayerDefinition.create(mesh, {int(desc['texture_width'])}, {int(desc['texture_height'])})" not in method_section(text, method):
        raise AssertionError(f"{method}: texture dimensions do not match source")
    return cube_count


def audit_assets() -> None:
    for name, expected in EXPECTED_SHA256.items():
        actual = sha256(REF / name)
        if actual != expected:
            raise AssertionError(f"Reference asset {name} hash changed: {actual}")
    if sha256(TEXTURES / "cat_creeper.png") != EXPECTED_SHA256["creeper.png"]:
        raise AssertionError("Packaged Cat base texture is not byte-identical to FemaleCreeper.mcpack")
    if sha256(TEXTURES / "cat_creeper_charge.png") != EXPECTED_SHA256["creeper_armor.png"]:
        raise AssertionError("Packaged Cat charged texture is not byte-identical to FemaleCreeper.mcpack")


def audit_animation() -> None:
    doc = json.loads((REF / "creeper.animation.json").read_text(encoding="utf-8"))
    anim = doc["animations"]["animation.creeper.legs"]
    if abs(float(anim["animation_length"]) - 8.0417) > 1e-6:
        raise AssertionError("Unexpected Cat source animation length")
    java = JAVA_ANIM.read_text(encoding="utf-8")
    # Direct ModelPart translation must invert only Y. Rotation channels must keep source signs.
    required = [
        "bodyYOffset(float seconds) { return -linear",
        "upperXOffset(float seconds) { return catmull",
        "upperYOffset(float seconds) { return -catmull",
        "upperZRot(float seconds) { return catmull",
        "breastXRot(float seconds) { return linear",
        "headZRot(float seconds) { return catmull",
        "earLZRot(float seconds) { return linear",
        "earRZRot(float seconds) { return linear",
        "tailXRot(float seconds) { return linear",
        "tail2XRot(float seconds) { return linear",
    ]
    for needle in required:
        if needle not in java:
            raise AssertionError(f"Animation axis/sign gate missing: {needle}")
    forbidden = [
        "upperZRot(float seconds) { return -",
        "tailXRot(float seconds) { return -",
        "tail2XRot(float seconds) { return -",
    ]
    for needle in forbidden:
        if needle in java:
            raise AssertionError(f"Regressed Cat rotation sign: {needle}")

    model = CREEPER_MODEL.read_text(encoding="utf-8")
    # 1.4.8 keeps the authored Bedrock idle/secondary channels exact while adding a
    # server-authoritative motion state machine, client state blending, bounded feline IK, and
    # interruptible personality idles on the existing authored bones.
    required_gait = [
        'CatVisualState visual = updateCatVisualState(entity, limbSwing, ageInTicks);',
        'float movementGate = smoothStep(0.015F, 0.20F, movement);',
        'float stanceFraction = creepN * 0.76F + walkN * 0.68F + runN * 0.50F;',
        'animateCatLegIk(child(waist, "leftLeg"), "leftlegsub2", "leftfoot3"',
        'animateCatLegIk(child(waist, "rightLeg"), "rightlegsub2", "rightfoot3"',
        'animateCatLegIk(child(waist, "leftLegback"), "leftlegsub", "leftfoot2"',
        'animateCatLegIk(child(waist, "rightLegback"), "rightlegsub", "rightfoot2"',
        'float cosKnee = Mth.clamp',
        'upperAngle = Mth.clamp',
        'lowerAngle = Mth.clamp',
        'float pawAngle = Mth.clamp',
        'tail.yRot += Mth.sin(phase - 0.70F) * (0.035F * creepN + 0.055F * walkN + 0.080F * runN) * gait;',
        'tail2.yRot += Mth.sin(phase - 1.30F) * (0.060F * creepN + 0.095F * walkN + 0.130F * runN) * gait;',
        'animateCatPersonalityIdle(entity, waist, body, catHead, tail, tail2, earL, earR, ageInTicks, idleGate);',
        'case PAW_LIFT ->',
        'case TAIL_WAG ->',
        'case CURIOUS_LOOK ->',
        'case KNEAD ->',
    ]
    for line in required_gait:
        if line not in model:
            raise AssertionError(f"Cat AAA state/animation gate missing: {line}")
    cat_section = model[model.index("private void animateCatSource"):model.index("private void animateCherryRemake")]
    if "tail.zRot" in cat_section or "tail2.zRot" in cat_section:
        raise AssertionError("Cat 1.4.8 should not introduce tail roll; bounded balance/personality yaw is intentional")


def main() -> None:
    audit_assets()
    base_cubes = audit_geometry("createCatLayer", "creeper.geo.json")
    charge_cubes = audit_geometry("createCatChargeLayer", "creeper_charged.geo.json")
    audit_animation()
    print(f"PASS: FemaleCreeper reference hashes exact ({len(EXPECTED_SHA256)} assets)")
    print(f"PASS: Bedrock -> Java base geometry exact ({base_cubes} cubes)")
    print(f"PASS: Bedrock -> Java charged geometry exact ({charge_cubes} cubes)")
    print("PASS: authored source animation axis/sign semantics retained; locomotion/state/idles layer onto bounded feline IK")

    # The Bedrock animation contains legacy targets that the shipped geometry itself no longer has.
    # Account for them explicitly so nobody later mistakes them for accidentally dropped Java parts.
    doc = json.loads((REF / "creeper.animation.json").read_text(encoding="utf-8"))
    anim_bones = set(doc["animations"]["animation.creeper.legs"]["bones"])
    _, base_bones = load_geo("creeper.geo.json")
    geom_bones = {b["name"] for b in base_bones}
    absent = anim_bones - geom_bones
    expected_absent = {"Leftarm","Rightarm","acc","acc2","arms","blink","blink2","eyebrow","eyebrow2","eyebrowL","eyebrowR","hair","hair2","hairpin","white","white2"}
    if absent != expected_absent:
        raise AssertionError(f"Unexpected Cat legacy animation/geometry mismatch: {sorted(absent)}")
    if doc["animations"]["animation.creeper.legs"]["bones"]["white"] != doc["animations"]["animation.creeper.legs"]["bones"]["white2"]:
        raise AssertionError("Cat legacy left/right white blink pulses unexpectedly differ")
    model_text = CREEPER_MODEL.read_text(encoding="utf-8")
    if 'setEyeBlink(child(catHead, "eye1"), blinkAmount);' not in model_text or 'setEyeBlink(child(catHead, "eye2"), blinkAmount);' not in model_text:
        raise AssertionError("Cat legacy source blink pulse is not routed to both actual shipped eye bones")
    print(f"PASS: Cat animation target accounting exact: {len(anim_bones)} authored targets, {len(expected_absent)} legacy targets absent from the shipped geometry and explicitly accounted for")

    print("PASS: 1.4.8 creep/walk/run + personality layer present with bounded tail yaw and no tail roll")


if __name__ == "__main__":
    main()
