#!/usr/bin/env python3
"""Permanent exact-byte + semantic completeness gate for the three user-supplied Creeper source packs.

The source-packs mirror is intentionally complete. Source-authored content is either ported directly or
adapted into standalone creeperella:* content; metadata/selector files remain exact archival inputs.
"""
from __future__ import annotations
import hashlib, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'reference-assets'/'source-packs'
EXPECTED={'pie': {'assets/minecraft/items/creeper_spawn_egg.json': '22dce5bbf76c0b674a72182a09440b995f86bd8b9e4c590b0c5f4541e8aa879b', 'assets/minecraft/models/item/bee.json': 'c6e53a380d65b75146f8e7916daf423a37fa333785d7ebced9fc0b67094f54f8', 'assets/minecraft/models/item/bunny.json': '34630ec1f60c731d8224eb5f7ed3cdd19aca6452a18281ec13db3bb3e87a5754', 'assets/minecraft/optifine/cem/creeper.jem': 'b0decaf8772e67e16ab9d2f9e594665ad65935008e01e2a3e408fe6c8745340a', 'assets/minecraft/optifine/cem/creeper.properties': 'a2a6de913cd0be6b70ba2e4978230c1a93be7a5f223ba454784d461870263e30', 'assets/minecraft/optifine/cem/creeper2.jem': '3cf7459c5886825c9ff8c65d6f3d387391170321126c433d48eb1c98c33dd903', 'assets/minecraft/optifine/cem/creeper3.jem': '539eafc3d7f30686adc8ffdf58d60a9ebf238722ed6baef2697ee83d7b69dd54', 'assets/minecraft/optifine/cem/creeper_charge.jem': 'db2122bb5e39817e8a067397a54b370653695be8ba3e113dd41b9a3edd0fe833', 'assets/minecraft/optifine/cem/creeper_charge.properties': 'a2a6de913cd0be6b70ba2e4978230c1a93be7a5f223ba454784d461870263e30', 'assets/minecraft/optifine/cem/creeper_charge2.jem': 'd667dc73c19915121e6ae0de62425ccc44d1927dd3abd501ba8741e9dbcabc99', 'assets/minecraft/optifine/cem/creeper_charge3.jem': '2549e19fbc31b307a582130662a5d2416b20cbc9d7c5971dbee5aaaf7b865021', 'assets/minecraft/textures/entity/creeper.png': '869cb2b5ac4cdf42f68f2de2e784abd8b97ffac2a2a63011f339a15b5a6c2abb', 'assets/minecraft/textures/entity/creeper.properties': 'f3066182dd71b7e269b997d55f8efdfbdd0d176a6b022a5ea24a8a42ae0cf423', 'assets/minecraft/textures/entity/creeper2.png': 'c43f7ef542365ebaef4a812155590264440001b0947d382c5bbcfd233823a8d4', 'assets/minecraft/textures/entity/creeper3.png': '164a8e34d9b03c03c5bc28447e4756a5c580a2ffdb42a68cfd229d25745b8d46', 'assets/minecraft/textures/entity/creeper_charge.png': 'a43d65fa5663b955bac3d9865ce298e2a90fe3533b80c02483fc92e351d961ed', 'assets/minecraft/textures/item/bee.png': '64fe7c8a410a4317f584765afcb98f4397f367a0f0bec6dbeaf0865adf84163d', 'assets/minecraft/textures/item/bunny.png': '81c8c6db0ff013a4ad459ab7856486068e2977922f423ea769f27d779972e23e', 'assets/minecraft/textures/item/creeper_spawn_egg.png': '475a5fcfa6138dc00f58f77bbe99813043fbcdee97eda632655f535166251187', 'pack.mcmeta': '5f8882bcbef6603cbfe14c199549028fbc52808d06309dfde020d6e4a61d0eaf', 'pack.png': '14b8f2029098731d53cb0b4ab744a762fae78b821acf7ffbbbcd0d24af7686a1'}, 'cherry': {'assets/minecraft/lang/en_us.json': '9027c56e1e312384d01e5824aa290fa80f601c7598cd58c908a155740e115c7b', 'assets/minecraft/lang/ru_ru.json': '87defdaa8a80dd87b32b2fe1719229446eb938f4f59119da359f4f5bdb475de7', 'assets/minecraft/models/block/tnt.json': '9a255585ce5da0e87d79b52cf3d07efd66884cbbc5b3661f7241de3a917a9fd7', 'assets/minecraft/optifine/cem/creeper.jem': '3dd398395c4361116fe49c988e5e0ab6ec8d03e1d732a51bec6c978ef23773eb', 'assets/minecraft/optifine/cem/creeper_cherry.png': 'f616daad6e1aa1f9b9b81041cd8823aa17faa4eeb8d4e00801a1547328cf1bdb', 'assets/minecraft/optifine/cem/creeper_cherry_e.png': '6c9fd43932027464ed7f97718b94372d2ea5e247e94348750cf367f85f6262aa', 'assets/minecraft/optifine/cem/head_creeper.jem': '1d41e777eff7deaa839d77f3ce88d95890068191710b35273a719459cf28001a', 'assets/minecraft/textures/block/tnt/tnt.png': 'aa074bbce564babbafdf556e811b917a028d0cd0b9079eff21fd06927c65a49b', 'assets/minecraft/textures/item/gunpowder.png': 'b1da181df7d143b8ce96596854ece249e20c9ea1bed88a91eb6a17e3b773191b', 'assets/minecraft/textures/painting/creebet.png': '672a7d0b591eedef2cbb653d125517d50a16c6a6db81bea6d29e43f556dbeb1a', 'pack.mcmeta': '3ac96cd3993bdfacf81a5b6c8f36b04b83e16f0661bfb757153a7d6852647b8f', 'pack.png': '4f512e3e71687810efb0fbd371eea6585f2f0414312a25423692d76c57aa869e'}, 'cat': {'animations/creeper.animation.json': 'aaaa5b007956a264e099b76b71b4e1808c194e4be7a74af8a1c34f68a04f63a7', 'credit.txt': 'e516f5d6b069ff79a0d359c7ec2a7286efa50e12bd4757aeb9a4f0f11672e4c9', 'entity/creeper.entity.json': '0cd13672453d55d219c0fd07323e15094bddad6144255e09848d5f6c351cb2e6', 'entity/creeper.entity.json.bak': '4c196331ca96e69a12f4510eb5f1ccc20afef6364d49790e0c53ab0f254e8644', 'manifest.json': '5af681c1f4c58ef77090307cd8fe98f519efa97c33c0accb09e318451ce228b5', 'models/entity/creeper.geo.json': '738081fcdb99d5200ce01f9c58283cd693cc78868decdeac6e7249ff1e6bda10', 'models/entity/creeper_charged.geo.json': 'cc2095ce5d9d11a8efb2dfb433f74f126e3398bfe6efcbabb7b9c2de1b394168', 'pack_icon.png': '9d080faea6a183b5724c6af49d9d4774b057493f0dbeb3554f7e12862db6e10b', 'render_controllers/creeper.render_controllers.json': '6013e4d57dbb5e6bcf026b92b0676181be0486b62abd46628091deb3217cd1f1', 'render_controllers/creeper_armor.render_controllers.json': 'a6a94c3e6f336971d78eb70766ae85487a937b8d407e87c4028e7d442adaaa4b', 'textures/entity/creeper/creeper.png': '220e9c4000e3d2a1b752af36e041f0266661d0f91bc1a77875df66784a5f693a', 'textures/entity/creeper/creeper_armor.png': 'dfcd53cb643b5d305bc31d9380f2156c546d28bc3fe2e57cff47eaa55f6fea4b'}}

BASES={
  'pie': SOURCE/'pie',
  'cherry': SOURCE/'cherry',
  'cat': SOURCE/'cat'/'FemaleCreeper',
}

def sha(p:Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()

def fail(msg): raise SystemExit('FAIL: '+msg)

for pack, expected in EXPECTED.items():
    base=BASES[pack]
    actual={str(p.relative_to(base)).replace('\\','/'):sha(p) for p in sorted(base.rglob('*')) if p.is_file()}
    if actual != expected:
        missing=sorted(set(expected)-set(actual)); extra=sorted(set(actual)-set(expected))
        bad=sorted(k for k in set(expected)&set(actual) if expected[k]!=actual[k])
        fail(f'{pack} source mirror drift: missing={missing}, extra={extra}, hash_mismatch={bad}')
    print(f'PASS: {pack} full source-pack mirror exact ({len(expected)} files)')

# None of the supplied packs contains a particle or sound asset. This makes "zero missing source particles"
# a testable statement instead of an assumption.
all_rel=[f'{pack}/{rel}' for pack,items in EXPECTED.items() for rel in items]
particle=[p for p in all_rel if '/particle' in p.lower() or p.lower().endswith('particles.json')]
sounds=[p for p in all_rel if '/sound' in p.lower() or p.lower().endswith('sounds.json')]
if particle: fail(f'unexpected source particle assets now exist: {particle}')
if sounds: fail(f'unexpected source sound assets now exist: {sounds}')
print('PASS: supplied packs contain 0 particle assets and 0 sound assets; there are none to omit')

# Exact active-byte mappings for source assets that are supposed to become Creeperella runtime resources.
MAP={
 'pie/assets/minecraft/textures/entity/creeper.png':'src/main/resources/assets/creeperella/textures/entity/female_creeper.png',
 'pie/assets/minecraft/textures/entity/creeper2.png':'src/main/resources/assets/creeperella/textures/entity/bunny_creeper.png',
 'pie/assets/minecraft/textures/entity/creeper3.png':'src/main/resources/assets/creeperella/textures/entity/bee_creeper.png',
 'pie/assets/minecraft/textures/entity/creeper_charge.png':'src/main/resources/assets/creeperella/textures/entity/pie_charge.png',
 'pie/assets/minecraft/textures/item/creeper_spawn_egg.png':'src/main/resources/assets/creeperella/textures/item/female_creeper_spawn_egg.png',
 'pie/assets/minecraft/textures/item/bunny.png':'src/main/resources/assets/creeperella/textures/item/bunny_creeper_spawn_egg.png',
 'pie/assets/minecraft/textures/item/bee.png':'src/main/resources/assets/creeperella/textures/item/bee_creeper_spawn_egg.png',
 'cherry/assets/minecraft/optifine/cem/creeper_cherry.png':'src/main/resources/assets/creeperella/textures/entity/cherry_creeper.png',
 'cherry/assets/minecraft/optifine/cem/creeper_cherry_e.png':'src/main/resources/assets/creeperella/textures/entity/cherry_creeper_e.png',
 'cherry/assets/minecraft/textures/block/tnt/tnt.png':'src/main/resources/assets/creeperella/textures/block/cherry_tnt/tnt.png',
 'cherry/assets/minecraft/textures/item/gunpowder.png':'src/main/resources/assets/creeperella/textures/item/cherry_gunpowder.png',
 'cherry/assets/minecraft/textures/painting/creebet.png':'src/main/resources/assets/creeperella/textures/painting/cherry_creebet.png',
 'cat/textures/entity/creeper/creeper.png':'src/main/resources/assets/creeperella/textures/entity/cat_creeper.png',
 'cat/textures/entity/creeper/creeper_armor.png':'src/main/resources/assets/creeperella/textures/entity/cat_creeper_charge.png',
}
for src,dst in MAP.items():
    pack,rel=src.split('/',1); base=BASES[pack]
    a=base/rel; b=ROOT/dst
    if not b.exists() or sha(a)!=sha(b): fail(f'active-byte mapping mismatch: {src} -> {dst}')
print(f'PASS: {len(MAP)}/{len(MAP)} active texture/egg/standalone sidecar mappings are exact source bytes')

# Exact curated source-of-truth copies used by generators/auditors.
CURATED={
 'pie/assets/minecraft/optifine/cem/creeper.jem':'reference-assets/pie/creeper.jem',
 'pie/assets/minecraft/optifine/cem/creeper2.jem':'reference-assets/pie/creeper2.jem',
 'pie/assets/minecraft/optifine/cem/creeper3.jem':'reference-assets/pie/creeper3.jem',
 'pie/assets/minecraft/optifine/cem/creeper_charge.jem':'reference-assets/pie/creeper_charge.jem',
 'pie/assets/minecraft/optifine/cem/creeper_charge2.jem':'reference-assets/pie/creeper_charge2.jem',
 'pie/assets/minecraft/optifine/cem/creeper_charge3.jem':'reference-assets/pie/creeper_charge3.jem',
 'cherry/assets/minecraft/optifine/cem/creeper.jem':'reference-assets/cherry/creeper.jem',
 'cherry/assets/minecraft/optifine/cem/head_creeper.jem':'reference-assets/cherry/head_creeper.jem',
 'cat/animations/creeper.animation.json':'reference-assets/cat/creeper.animation.json',
 'cat/entity/creeper.entity.json':'reference-assets/cat/creeper.entity.json',
 'cat/models/entity/creeper.geo.json':'reference-assets/cat/creeper.geo.json',
 'cat/models/entity/creeper_charged.geo.json':'reference-assets/cat/creeper_charged.geo.json',
 'cat/render_controllers/creeper.render_controllers.json':'reference-assets/cat/creeper.render_controllers.json',
 'cat/render_controllers/creeper_armor.render_controllers.json':'reference-assets/cat/creeper_armor.render_controllers.json',
}
for src,dst in CURATED.items():
    pack,rel=src.split('/',1); a=BASES[pack]/rel; b=ROOT/dst
    if not b.exists() or sha(a)!=sha(b): fail(f'curated source mapping mismatch: {src} -> {dst}')
print(f'PASS: {len(CURATED)}/{len(CURATED)} generator/audit source mappings are exact source bytes')

# Behavioral render semantics that cannot be represented by byte-copy alone.
model=(ROOT/'src/main/java/dev/herbertofury/creeperella/client/CreeperellaModel.java').read_text()
renderer=(ROOT/'src/main/java/dev/herbertofury/creeperella/client/CreeperellaRenderer.java').read_text()
power=(ROOT/'src/main/java/dev/herbertofury/creeperella/client/CreeperellaPowerLayer.java').read_text()
glow=(ROOT/'src/main/java/dev/herbertofury/creeperella/client/CreeperellaGlowLayer.java').read_text()
required=[
 ('Cat source animation', 'CatCreeperSourceAnimation.' in model),
 ('Cat authored blink pulse', 'CatCreeperSourceAnimation.blinkPulse' in model),
 ('Cat separate charged texture', 'cat_creeper_charge.png' in power),
 ('Creeper swell scale', 'swelling *= swelling;' in renderer and 'swelling * 0.4F' in renderer and 'swelling * 0.1F' in renderer),
 ('Creeper flash overlay', 'swelling * 10.0F' in renderer),
 ('Cherry emissive full-bright layer', 'LightTexture.FULL_BRIGHT' in glow and 'cherry_creeper_e.png' in glow),
 ('Cherry exact body proxy ty', 'vanillaBody.y = 18.0F' in model),
 ('Cherry source face timing', 'ageInTicks / 2.5F' in model),
 ('Pie source-name variants are dedicated entities', all(x in (ROOT/'src/main/java/dev/herbertofury/creeperella/registry/ModEntities.java').read_text() for x in ['FEMALE_CREEPER','BUNNY_CREEPER','BEE_CREEPER'])),
 ('Pie source-name charged variants use dedicated charge layers', all(x in (ROOT/'src/main/java/dev/herbertofury/creeperella/client/ClientEvents.java').read_text() for x in ['FEMALE_CHARGE','BUNNY_CHARGE','BEE_CHARGE'])),
]
for name,ok in required:
    if not ok: fail('missing runtime semantic: '+name)
print(f'PASS: {len(required)}/{len(required)} source render/animation semantics present')


# Cherry source localization is safely namespaced instead of overwriting minecraft:creeper globally.
source_en=json.loads((BASES['cherry']/'assets/minecraft/lang/en_us.json').read_text(encoding='utf-8'))
source_ru=json.loads((BASES['cherry']/'assets/minecraft/lang/ru_ru.json').read_text(encoding='utf-8'))
mod_en=json.loads((ROOT/'src/main/resources/assets/creeperella/lang/en_us.json').read_text(encoding='utf-8'))
mod_ru=json.loads((ROOT/'src/main/resources/assets/creeperella/lang/ru_ru.json').read_text(encoding='utf-8'))
if mod_en.get('entity.creeperella.cherry_creeper') != source_en.get('entity.minecraft.creeper'):
    fail('Cherry en_us entity localization does not preserve source value')
if mod_en.get('item.creperella.cherry_creeper_spawn_egg') is not None:
    fail('typo guard tripped')
if mod_en.get('item.creeperella.cherry_creeper_spawn_egg') != source_en.get('item.minecraft.creeper_spawn_egg'):
    fail('Cherry en_us spawn egg localization does not preserve source value')
if mod_ru.get('entity.creeperella.cherry_creeper') != source_ru.get('entity.minecraft.creeper'):
    fail('Cherry ru_ru entity localization does not preserve source value')
if mod_ru.get('item.creeperella.cherry_creeper_spawn_egg') != source_ru.get('item.minecraft.creeper_spawn_egg'):
    fail('Cherry ru_ru spawn egg localization does not preserve source value')
if mod_en.get('block.creeperella.cherry_creeper_head') != source_en.get('block.minecraft.creeper_head'):
    fail('Cherry en_us head localization does not preserve source value')
if mod_ru.get('block.creeperella.cherry_creeper_head') != source_ru.get('block.minecraft.creeper_head'):
    fail('Cherry ru_ru head localization does not preserve source value')
print('PASS: Cherry en_us + ru_ru mob/spawn-egg/head localization preserved under standalone mod namespace')

# The Cherry pack authored global replacements. Creeperella turns them into namespaced standalone content.
# For TNT, preserve the exact 64x64 source atlas and its visual face result, but intentionally use vanilla
# TNT cube geometry rather than blindly carrying a format-specific Blockbench UV adapter into the mod.
src_tnt=json.loads((BASES['cherry']/'assets/minecraft/models/block/tnt.json').read_text(encoding='utf-8'))
runtime_tnt=json.loads((ROOT/'src/main/resources/assets/creeperella/models/block/cherry_tnt.json').read_text(encoding='utf-8'))
if len(src_tnt.get('elements',[])) != 1 or src_tnt['elements'][0].get('from') != [0,0,0] or src_tnt['elements'][0].get('to') != [16,16,16]:
    fail('source Cherry TNT is no longer a vanilla-size one-cube UV adapter')
if runtime_tnt.get('parent') != 'minecraft:block/cube_bottom_top':
    fail('standalone Cherry TNT is not using vanilla cube_bottom_top geometry')
if runtime_tnt.get('textures') != {
    'side':'creeperella:block/cherry_tnt_side',
    'top':'creeperella:block/cherry_tnt_top',
    'bottom':'creeperella:block/cherry_tnt_bottom',
    'particle':'creeperella:block/cherry_tnt_side',
}:
    fail('standalone Cherry TNT vanilla face mapping drift')
for face in ['cherry_tnt_side.png','cherry_tnt_top.png','cherry_tnt_bottom.png']:
    if not (ROOT/'src/main/resources/assets/creeperella/textures/block'/face).exists():
        fail('missing derived Cherry TNT vanilla face: '+face)
print('PASS: Cherry TNT preserves source art semantically on vanilla TNT cube geometry; source adapter JSON stays exact in provenance mirror')

# Explicitly prove the global source replacements became dedicated runtime content instead of being
# silently discarded or applied to minecraft:* resources.
standalone_checks={
 'Cherry Gunpowder item':'CHERRY_GUNPOWDER',
 'Cherry TNT block':'CHERRY_TNT',
 'Cherry Creeper Head':'CHERRY_CREEPER_HEAD',
 'Cherry Creebet painting':'CHERRY_CREEBET_PAINTING',
}
items_java=(ROOT/'src/main/java/dev/herbertofury/creeperella/registry/ModItems.java').read_text()
for name,symbol in standalone_checks.items():
    if symbol not in items_java: fail(f'missing standalone runtime registration: {name}')
if (ROOT/'src/main/resources/assets/minecraft').exists():
    fail('active assets/minecraft override directory exists; standalone port must not globally reskin vanilla')
print(f'PASS: {len(standalone_checks)}/{len(standalone_checks)} Cherry global replacements are dedicated creeperella:* content; vanilla namespace untouched')

# Only packaging/selection/back-up inputs remain archival-only. Author-intended visible/gameplay sidecars
# from Cherry are no longer in this list: they are standalone creeperella:* content above.
MIRROR_ONLY=[
 'pie/pack.mcmeta','pie/pack.png','pie/assets/minecraft/items/creeper_spawn_egg.json',
 'pie/assets/minecraft/models/item/bee.json','pie/assets/minecraft/models/item/bunny.json',
 'pie/assets/minecraft/textures/entity/creeper.properties',
 'cherry/pack.mcmeta','cherry/pack.png',
 'cat/pack_icon.png','cat/entity/creeper.entity.json.bak','cat/manifest.json','cat/credit.txt',
]
for item in MIRROR_ONLY:
    pack,rel=item.split('/',1)
    if rel not in EXPECTED[pack]: fail('archive-only declaration missing from source manifest: '+item)
print(f'PASS: {len(MIRROR_ONLY)} packaging/selector/backup files retained exact as archival inputs; gameplay/visual sidecars are not discarded')
print(f'PASS: full uploaded source-pack inventory accounted for: {sum(map(len,EXPECTED.values()))}/{sum(map(len,EXPECTED.values()))} files')
