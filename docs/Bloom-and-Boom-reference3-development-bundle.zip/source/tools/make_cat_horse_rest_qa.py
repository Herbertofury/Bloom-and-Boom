#!/usr/bin/env python3
from __future__ import annotations
import math, sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import render_mobs_visual_qa as r

OUT = Path('/mnt/data/Creeperella-1.4.14-Cat-Upright-Horse-Rest-QA')
OUT.mkdir(parents=True, exist_ok=True)
BG=(8,13,24,255)
W,H=360,320
BASE=275
FRAMES=6
try:
    FONT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',14)
    SMALL=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)
except Exception:
    FONT=ImageFont.load_default(); SMALL=ImageFont.load_default()

def P(root,*path): return r.find(root,*path)
MAP={'leftLeg':('leftlegsub2','leftfoot3'),'rightLeg':('rightlegsub2','rightfoot3'),'leftLegback':('leftlegsub','leftfoot2'),'rightLegback':('rightlegsub','rightfoot2')}
ROLL=[0.82,0.86,0.80,0.84]
GROUND_Y=[-2.8239,-3.8517,-2.5893,-3.0833]
BODY_LEAN=[0.050,0.040,0.060,0.025]
UPPER_LEAN=[0.025,0.020,0.030,0.010]
HEAD_LEAN=[0.008,0.006,0.010,0.002]
BODY_PITCH=[0.12,0.10,0.14,0.08]
UPPER_PITCH=[-0.09,-0.08,-0.10,-0.07]
HEAD_PITCH=[0.010,0.000,0.015,-0.005]
UPPER_Y=[0.29,0.27,0.31,0.23]
HEAD_Y=[-0.08,-0.02,0.08,-0.28]
HEAD_RY=[0.14,0.16,0.12,0.22]
LEGS=[
 [('leftLeg',2.0,1.4,-1.6,-.10,-.20,.72,.50,-.10),('rightLeg',4.0,1.7,-.4,-.58,-.10,.54,1.35,-.35),('leftLegback',2.4,1.6,1.2,.55,.12,.82,1.40,-.45),('rightLegback',4.3,1.8,.4,.28,.06,.60,1.25,-.30)],
 [('leftLeg',2.8,1.3,-2.2,.05,-.24,.86,.38,-.05),('rightLeg',4.4,1.8,-.2,-.65,-.10,.52,1.42,-.38),('leftLegback',3.0,1.6,1.6,.62,.12,.96,1.46,-.48),('rightLegback',4.7,1.9,.5,.30,.06,.62,1.28,-.30)],
 [('leftLeg',1.8,1.4,-1.2,-.22,-.16,.70,.78,-.18),('rightLeg',3.8,1.8,-.2,-.62,-.08,.50,1.38,-.35),('leftLegback',2.8,1.7,1.8,.70,.12,1.02,1.50,-.52),('rightLegback',4.6,2.0,.7,.34,.05,.62,1.30,-.32)],
 [('leftLeg',2.4,1.2,-1.8,-.02,-.22,.78,.46,-.08),('rightLeg',4.2,1.6,-.5,-.52,-.12,.58,1.25,-.30),('leftLegback',2.5,1.5,1.3,.50,.14,.88,1.36,-.40),('rightLegback',4.4,1.8,.4,.25,.06,.60,1.20,-.28)]
]
LABELS=['A · calm upright rest','B · watchful upright rest','C · relaxed vigilant rest','D · high-alert upright rest']

def pose_leg(root,row):
    n,dx,dy,dz,rx,ry,rz,lrx,frx=row
    ln,fn=MAP[n]; leg=P(root,'body','waist',n); low=P(root,'body','waist',n,ln); foot=P(root,'body','waist',n,ln,fn)
    leg.x += dx; leg.y += dy; leg.z += dz
    leg.rx=rx; leg.ry=ry; leg.rz=rz; low.rx=lrx; foot.rx=frx

def apply_horse_rest(root,v):
    waist=P(root,'body','waist'); body=P(root,'body','waist','Body'); upper=P(root,'body','waist','Body','Upperbody'); head=P(root,'body','waist','Body','Upperbody','head')
    tail=P(root,'body','waist','Body','tail'); tail2=P(root,'body','waist','Body','tail','tail2')
    roll=ROLL[v]
    waist.y += GROUND_Y[v]; waist.rz += roll
    # Same 1.4.14 pose math as CreeperellaModel.java: the lower body remains horse-rested,
    # while the torso/head cancel almost all of the side roll and forward bend.
    body.y += 1.15; body.rx += BODY_PITCH[v]; body.rz += -roll + BODY_LEAN[v]
    upper.y += UPPER_Y[v]; upper.rx += UPPER_PITCH[v]; upper.rz += UPPER_LEAN[v]-BODY_LEAN[v]
    head.y += HEAD_Y[v]; head.rx += HEAD_PITCH[v]; head.ry += HEAD_RY[v]; head.rz += HEAD_LEAN[v]-UPPER_LEAN[v]
    for row in LEGS[v]: pose_leg(root,row)
    tail.rx=0.28; tail.ry=-0.08; tail.rz=0.0
    if tail2:
        tail2.rx=0.58; tail2.ry=-0.04; tail2.rz=0.0

def standing_ground(age):
    root,tex,tw,th=r.load_variant('cat'); r.apply_anim(root,'cat',age,0,0,0,0,cat_motion='idle')
    _,pts=r.build_polygons(root,tex,tw,th,yaw=0,pitch=0,subdivide=False)
    return float(pts[:,1].min())
GROUND=standing_ground(40.0)

def bounds_for_yaw(yaw):
    xs=[];ys=[]
    for v in range(4):
        for i in range(FRAMES):
            root,tex,tw,th=r.load_variant('cat'); r.apply_anim(root,'cat',40+i*.65,0,0,0,0,cat_motion='sit'); apply_horse_rest(root,v)
            _,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=4,subdivide=False)
            xs.extend([float(pts[:,0].min()),float(pts[:,0].max())]); ys.extend([float(pts[:,1].min()),float(pts[:,1].max())])
    return min(xs),max(xs),min(ys),max(ys)
BOUNDS={yaw:bounds_for_yaw(yaw) for yaw in (-28,-90)}

def render(root,tex,tw,th,yaw,label):
    minx,maxx,miny,maxy=BOUNDS[yaw]
    scale=min((W-24)/max(maxx-minx,1),(BASE-35)/max(maxy-GROUND,1))
    xoff=W/2-(minx+maxx)/2*scale
    yoff=BASE+GROUND*scale
    canvas=np.zeros((H,W,4),dtype=np.uint8); canvas[:]=np.array(BG,dtype=np.uint8)
    im=Image.fromarray(canvas,'RGBA'); d=ImageDraw.Draw(im)
    d.rounded_rectangle((12,BASE-4,W-12,BASE+9),radius=7,fill=(12,22,40,230))
    d.line((12,BASE,W-12,BASE),fill=(115,145,195,255),width=2)
    canvas=np.array(im); zbuf=np.full((H,W),np.inf)
    polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=4,subdivide=True)
    for _,q,rgba in polys:
        pp=np.array([[xoff+p[0]*scale,yoff-p[1]*scale,p[2]] for p in q],dtype=float)
        r._raster_triangle(canvas,zbuf,pp[[0,1,2]],rgba); r._raster_triangle(canvas,zbuf,pp[[0,2,3]],rgba)
    im=Image.fromarray(canvas,'RGBA'); d=ImageDraw.Draw(im)
    bb=d.textbbox((0,0),label,font=FONT); tx=(W-(bb[2]-bb[0]))//2
    d.rounded_rectangle((tx-7,8,tx+(bb[2]-bb[0])+7,31),radius=7,fill=(15,22,38,225),outline=(105,125,165,255))
    d.text((tx,11),label,font=FONT,fill=(241,244,255))
    d.text((14,BASE+11),'Minecraft ground plane',font=SMALL,fill=(175,198,235))
    return im

outputs=[]; deltas=[]
for v,label in enumerate(LABELS):
    for yaw,vname in [(-28,'3Q'),(-90,'SIDE')]:
        frames=[]
        for i in range(FRAMES):
            age=40+i*.65
            root,tex,tw,th=r.load_variant('cat'); r.apply_anim(root,'cat',age,0,0,0,0,cat_motion='sit'); apply_horse_rest(root,v)
            if yaw==-28:
                _,pts=r.build_polygons(root,tex,tw,th,yaw=0,pitch=0,subdivide=False)
                deltas.append((v,i,float(pts[:,1].min()-standing_ground(age))))
            frames.append(render(root,tex,tw,th,yaw,f'{label} · {vname}'))
        p=OUT/f'Cat-Creeper-1.4.14-UPRIGHT-HORSE-REST-{chr(65+v)}-{vname}.gif'
        frames[0].save(p,save_all=True,append_images=frames[1:],duration=120,loop=0,disposal=2); outputs.append(p)

sheet=Image.new('RGBA',(2*W,4*H),BG)
for v,label in enumerate(LABELS):
    for c,(yaw,vname) in enumerate([(-28,'3Q'),(-90,'SIDE')]):
        root,tex,tw,th=r.load_variant('cat'); r.apply_anim(root,'cat',42.1,0,0,0,0,cat_motion='sit'); apply_horse_rest(root,v)
        sheet.alpha_composite(render(root,tex,tw,th,yaw,f'{label} · {vname}'),(c*W,v*H))
sheet_path=OUT/'Cat-Creeper-1.4.14-Upright-Horse-Rest-Ground-QA.png'; sheet.save(sheet_path); outputs.append(sheet_path)

lines=[f'standing_ground_y={GROUND:.6f}']
for v,label in enumerate(LABELS):
    vals=[d for vv,i,d in deltas if vv==v]
    lines.append(f'{label}: bottom_delta_min={min(vals):.6f} max={max(vals):.6f}')
(OUT/'GROUND_QA.txt').write_text('\n'.join(lines)+'\n')
(OUT/'README.md').write_text('''# Creeperella 1.4.14 Cat upright alert horse-rest QA\n\nDeterministic renders from the actual Cat Creeper model, texture, source animation curves, and the same pose constants used by `CreeperellaModel.java`. No image generation is used.\n\n1.4.14 keeps the lower-body horse-rest arrangement but straightens the chest/head into a Creeper-like upright silhouette. Lateral lean is intentionally tiny and the forward bend is reduced to a subtle comfortable posture. The blue line is fixed from the normal standing Cat Creeper paw-bottom plane and is not snapped to each frame.\n''')
print('\n'.join(map(str,outputs)))
print((OUT/'GROUND_QA.txt').read_text())
