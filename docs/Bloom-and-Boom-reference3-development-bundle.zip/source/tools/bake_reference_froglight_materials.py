#!/usr/bin/env python3
"""Map verified vanilla Froglight materials into the existing Pie UV contract.
No generated art. Run only with the original Minecraft textures available locally.
"""
from pathlib import Path
from PIL import Image, ImageStat
import hashlib,json
R=Path(__file__).resolve().parents[1];T=R/'src/main/resources/assets/creeperella/textures/entity';S=R/'reference-assets/froglight/polish23-body-source';V=R/'.mvf-generated/vanilla'
EXPECTED={'ochre':'f20f9fbd0582de93e891385d725729ebbffba0d97116b4540ca6f081adf90868','verdant':'9343dcdad98fbfcd0fb7df2b7391ce23e504180ebc5199ca57635b33814707c3','pearlescent':'afa493722c71327c5e7cdb63ded521636424918564b01ae7014f7ee835e58092'}
receipt={}
for name,material in [('mariglow','ochre'),('verdalia','verdant'),('nacrella','pearlescent')]:
 sidepath=V/f'{material}_froglight_side.png';assert hashlib.sha256(sidepath.read_bytes()).hexdigest()==EXPECTED[material]
 side=Image.open(sidepath).convert('RGBA');top=Image.open(V/f'{material}_froglight_top.png').convert('RGBA');src=Image.open(S/f'{name}_creeper.png').convert('RGBA');scale=4;out=Image.new('RGBA',(src.width*scale,src.height*scale));glow=Image.new('RGBA',out.size);mean=ImageStat.Stat(side.convert('RGB')).mean
 for y in range(out.height):
  for x in range(out.width):
   ux,uy=x//scale,y//scale
   p=src.getpixel((ux,uy))
   if not p[3]:continue
   # Keep tiny native eye swatches and dark authored face details; custom reference eye geometry covers the eye band.
   if (26<=ux<29 and 20<=uy<25) or (8<=ux<16 and 8<=uy<16 and max(p[:3])<82):
    out.putpixel((x,y),p);continue
   tex=top if uy<8 else side;rgb=tex.getpixel((x%16,y%16))[:3]
   # restrained albedo and low-energy matching glow; no scattered invented body spots
   rgb=tuple(round((mean[k]*0.82+rgb[k]*0.18)*0.88 + (2 if x%12 in (5,6) else -1)) for k in range(3))
   out.putpixel((x,y),(*rgb,p[3]))
   glow.putpixel((x,y),(*(round(c*0.14) for c in rgb),p[3]))
 out.save(T/f'{name}_creeper.png');glow.save(T/f'{name}_creeper_e.png')
 face=Image.new('RGBA',(64,64))
 for y in range(64):
  for x in range(64):
   rgb=top.getpixel(((x//4)%16,(y//4)%16))[:3];face.putpixel((x,y),(*(round(c*0.90) for c in rgb),255))
 face.save(T/f'{name}_face_skin.png')
 receipt[name]={'material':material,'vanilla_side_sha256':EXPECTED[material],'atlas_sha256':hashlib.sha256((T/f'{name}_creeper.png').read_bytes()).hexdigest(),'coverage':sum(p[3]>0 for p in out.getdata()),'uv_scale':scale,'ai_generated':False}
(R/'reference-material-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))

# Hand-authored reference material tiles. No image generation; bright tile interiors
# prevent subpixel flower cubes from sampling only a dark edge.
PALETTES={
 'nacrella':[(168,133,215),(226,205,249),(111,80,151),(231,211,255)],
 'mariglow':[(229,181,57),(255,224,140),(109,115,47),(255,235,175)],
 'verdalia':[(159,213,114),(221,249,190),(62,120,67),(214,255,180)]}
for name,colors in PALETTES.items():
 acc=Image.new('RGBA',(64,64));em=Image.new('RGBA',(64,64))
 for y in range(64):
  for x in range(64):
   band=x//16;rgb=colors[band];delta=(-5,0,4,1)[((x//3)+(y//3))%4]
   acc.putpixel((x,y),(*(max(0,min(255,c+delta)) for c in rgb),255))
   if band==3:em.putpixel((x,y),(*rgb,255))
 acc.save(T/f'{name}_accessories.png');em.save(T/f'{name}_accessories_e.png')
