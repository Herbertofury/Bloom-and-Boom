#!/usr/bin/env python3
"""Static + pure-state regression gate for Creeperella Cat behavior orchestration.

This does not pretend to replace a Forge runtime test. It makes the design contract executable:
server-authoritative state sync only on transitions, bounded path refresh, notice hysteresis,
follow catch-up tiers, and interruptible idle scheduling must remain present in source.
"""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ENTITY=(ROOT/'src/main/java/dev/herbertofury/creeperella/entity/CreeperellaEntity.java').read_text()
MODEL=(ROOT/'src/main/java/dev/herbertofury/creeperella/client/CreeperellaModel.java').read_text()
CONFIG=(ROOT/'src/main/java/dev/herbertofury/creeperella/config/CreeperellaConfig.java').read_text()
MOTION=(ROOT/'src/main/java/dev/herbertofury/creeperella/entity/CatCreeperMotionState.java').read_text()
IDLE=(ROOT/'src/main/java/dev/herbertofury/creeperella/entity/CatCreeperIdleAnimation.java').read_text()


def require(text,needle,label):
    assert needle in text, f'missing {label}: {needle}'

# Source-level orchestration invariants.
for state in ('IDLE','CREEP','WALK','RUN','SWELL','SIT','REFORM'):
    require(MOTION,state,f'motion state {state}')
for clip in ('PAW_LIFT','TAIL_WAG','CURIOUS_LOOK','KNEAD'):
    require(IDLE,clip,f'idle clip {clip}')
for needle,label in (
    ('DATA_CAT_MOTION','synced motion byte'),
    ('DATA_CAT_IDLE','synced idle byte'),
    ('DATA_CAT_ANIM_START_TICK','synced animation start tick'),
    ('if (current == state)', 'transition-only motion sync guard'),
    ('this.tickCount % 8 == 0', 'bounded wild navigation refresh'),
    ('player.hasLineOfSight(this)', 'visibility gate'),
    ('CAT_NOTICE_MEMORY_TICKS', 'notice hysteresis'),
    ('CAT_AMBUSH_DISTANCE', 'ambush transition'),
    ('CAT_FOLLOW_RUN_DISTANCE', 'follower catch-up tier'),
    ('CAT_FOLLOW_RUN_EXIT_DISTANCE', 'follower catch-up hysteresis exit'),
    ('this.getDeltaMovement().horizontalDistanceSqr() < 9.0E-4D', 'true-still idle gate'),
    ('this.hurtTime <= 0', 'damage interrupt'),
    ('this.getSwellDir() <= 0', 'swell interrupt'),
    ('triggerCatAffectionIdle', 'interaction-triggered personality'),
    ('selectCatIdle()', 'personality repeat guard'),
): require(ENTITY,needle,label)
for needle,label in (
    ('alpha = 1.0F - (float)Math.exp(-dt * 0.42F)', 'client transition blend'),
    ('state.creep * 0.56F', 'creep cadence'),
    ('1.58F', 'run cadence'),
    ('animateCatLegIk', 'procedural IK'),
    ('animateCatPersonalityIdle', 'personality layer'),
): require(MODEL,needle,label)
for needle,label in (
    ('creepNavigationSpeed", 0.62D', 'creep nav default'),
    ('walkNavigationSpeed", 1.00D', 'walk nav default'),
    ('runNavigationSpeed", 1.45D', 'run nav default'),
    ('followRunExitDistance", 8.0D', 'follow run hysteresis default'),
    ('noticeMemoryTicks", 60', 'notice memory default'),
    ('idleMinCooldownTicks", 80', 'idle cooldown minimum'),
    ('idleMaxCooldownTicks", 220', 'idle cooldown maximum'),
): require(CONFIG,needle,label)

# Pure behavior simulation of the load-bearing transitions. Mirrors the server decision rules.
def wild_state(distance, noticed, memory, hurt=False, ambush=4.25, memory_reset=60):
    if hurt or distance <= ambush:
        return 'RUN', memory_reset
    if noticed:
        memory=memory_reset
    elif memory>0:
        memory-=1
    return ('CREEP' if memory<=0 else 'RUN'), memory

state,mem=wild_state(12.0,False,0)
assert (state,mem)==('CREEP',0)
state,mem=wild_state(12.0,True,0)
assert (state,mem)==('RUN',60)
for _ in range(59):
    state,mem=wild_state(12.0,False,mem)
assert state=='RUN' and mem==1
state,mem=wild_state(12.0,False,mem)
assert state=='CREEP' and mem==0
assert wild_state(3.5,False,0)[0]=='RUN'
assert wild_state(12.0,False,0,hurt=True)[0]=='RUN'


def follower_state(distance,running=False,nav_active=True,stop=3.0,run_start=10.0,run_exit=8.0):
    if not nav_active or distance<=stop:return 'IDLE',False
    if running:
        running=distance>min(run_start,run_exit)
    elif distance>run_start:
        running=True
    return ('RUN' if running else 'WALK'),running

assert follower_state(2.5)==('IDLE',False)
assert follower_state(7.0)==('WALK',False)
state,running=follower_state(12.0); assert (state,running)==('RUN',True)
state,running=follower_state(9.0,running); assert (state,running)==('RUN',True)
state,running=follower_state(7.5,running); assert (state,running)==('WALK',False)

print('PASS: server Cat motion/idle sync contract present in source')
print('PASS: motion sync is transition-only; no per-tick animation packet contract')
print('PASS: wild navigation refresh is bounded; notice memory prevents creep/run flicker')
print('PASS: unnoticed target -> CREEP; noticed/hurt/ambush target -> RUN')
print('PASS: follower distance tiers -> IDLE / WALK / RUN with 10->8 block hysteresis')
print('PASS: personality idles require stillness and are interruptible by damage/target/swell/movement')
print('PASS: client model keeps state blending, cadence tiers, procedural IK and personality layer')
