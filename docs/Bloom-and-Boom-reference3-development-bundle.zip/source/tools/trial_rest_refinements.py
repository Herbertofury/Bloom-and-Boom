#!/usr/bin/env python3
import sys, math
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
sys.path.insert(0,'/mnt/data/creeperella1415_work/tools')
import render_mobs_visual_qa as r
OUT=Path('/mnt/data/Creeperella-1.4.15-Rest-Trials'); OUT.mkdir(parents=True,exist_ok=True)
BG=(8,13,24,255);W,H=300,300;BASE=255
try: FONT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',13);SMALL=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
except: FONT=ImageFont.load_default();SMALL=ImageFont.load_default()
MAP={'leftLeg':('leftlegsub2','leftfoot3'),'rightLeg':('rightlegsub2','rightfoot3'),'leftLegback':('leftlegsub','leftfoot2'),'rightLegback':('rightlegsub','rightfoot2')}
def P(root,*p): return r.find(root,*p)
def leg(root,n,dx,dy,dz,rx,ry,rz,lrx,frx):
 ln,fn=MAP[n];a=P(root,'body','waist',n);b=P(root,'body','waist',n,ln);c=P(root,'body','waist',n,ln,fn);a.x+=dx;a.y+=dy;a.z+=dz;a.rx=rx;a.ry=ry;a.rz=rz;b.rx=lrx;c.rx=frx

def tail(root,root_rx,root_ry,tip_rx,tip_ry,root_z=0):
 a=P(root,'body','waist','Body','tail');b=P(root,'body','waist','Body','tail','tail2');a.rx=root_rx;a.ry=root_ry;a.z+=root_z;b.rx=tip_rx;b.ry=tip_ry

def sit(root,k):
 body=P(root,'body','waist','Body');upper=P(root,'body','waist','Body','Upperbody');head=P(root,'body','waist','Body','Upperbody','head')
 vals=[
  (0.65,.16,.20,-.08, .55,1.35,-.55, .90,1.50,-.65, .20,.18,.58,.12),
  (0.90,.12,.26,-.09, .45,1.50,-.62, 1.10,1.62,-.72, .22,.14,.62,.10),
  (1.05,.10,.34,-.10, .35,1.65,-.70, 1.25,1.72,-.78, .24,.12,.66,.08),
  (0.80,.14,.30,-.08, .50,1.42,-.58, 1.05,1.58,-.68, .20,.10,.60,.06),
 ][k]
 by,bp,uy,up, fz,fy,fr, hz,hy,hr, trx,try_,ttx,tty=vals
 body.y+=by;body.rx+=bp;upper.y+=uy;upper.rx+=up;head.rx-=.01
 for s,n in [(1,'leftLeg'),(-1,'rightLeg')]: leg(root,n,.25*s,fy,fz,-.30,0,.04*s,1.05,fr)
 for s,n in [(1,'leftLegback'),(-1,'rightLegback')]: leg(root,n,.95*s,hy,-hz,.62,0,.12*s,1.38,hr)
 tail(root,trx,try_,ttx,tty,.18)

def loaf(root,k):
 body=P(root,'body','waist','Body');upper=P(root,'body','waist','Body','Upperbody');head=P(root,'body','waist','Body','Upperbody','head')
 vals=[
  (1.20,.14,.45,-.10, .70,1.55,1.20,-.92,1.82,-.90, .45,1.78,-.55,.75,1.62,-.98),
  (1.40,.11,.50,-.09, .55,1.70,1.35,-1.00,1.95,-.98, .38,1.88,-.65,.82,1.72,-1.05),
  (1.55,.08,.52,-.08, .42,1.78,1.48,-1.08,2.02,-1.02, .30,1.95,-.72,.88,1.80,-1.08),
  (1.30,.12,.46,-.09, .60,1.64,1.30,-.96,1.90,-.95, .40,1.84,-.60,.80,1.68,-1.02),
 ][k]
 by,bp,uy,up, fx,fy,fz,fr,fl,ff,hx,hy,hz,hr,hl,hf=vals
 body.y+=by;body.rx+=bp;upper.y+=uy;upper.rx+=up;head.y+=.10;head.rx+=.02
 for s,n in [(1,'leftLeg'),(-1,'rightLeg')]: leg(root,n,fx*s,fy,fz,fr,0,.04*s,fl,ff)
 for s,n in [(1,'leftLegback'),(-1,'rightLegback')]: leg(root,n,hx*s,hy,hz,hr,0,.05*s,hl,hf)
 tail(root,.30,.12,.68,.18,.05)

def sprawl(root,k):
 body=P(root,'body','waist','Body');upper=P(root,'body','waist','Body','Upperbody');head=P(root,'body','waist','Body','Upperbody','head')
 vals=[
  (1.20,.22,.28,-.08, 1.20,1.50,-.70,-.46,.22,.42,.98,-.28, 1.60,1.75,.80,.32,.10,.52,.98,-.30),
  (1.35,.18,.30,-.07, 1.50,1.60,-.85,-.42,.18,.50,.92,-.22, 1.95,1.85,.95,.36,.08,.60,.92,-.24),
  (1.50,.15,.30,-.06, 1.75,1.68,-1.00,-.38,.14,.56,.88,-.18, 2.25,1.95,1.10,.40,.06,.66,.88,-.20),
  (1.30,.19,.28,-.07, 1.40,1.55,-.80,-.44,.18,.46,.95,-.24, 1.80,1.82,.90,.34,.08,.56,.95,-.26),
 ][k]
 by,bp,uy,up,fx,fy,fz,fr,fry,frz,fl,ff,hx,hy,hz,hr,hry,hrz,hl,hf=vals
 body.y+=by;body.rx+=bp;upper.y+=uy;upper.rx+=up;head.rx+=.01
 for s,n in [(1,'leftLeg'),(-1,'rightLeg')]: leg(root,n,fx*s,fy,fz,fr,fry*s,frz*s,fl,ff)
 for s,n in [(1,'leftLegback'),(-1,'rightLegback')]: leg(root,n,hx*s,hy,hz,hr,hry*s,hrz*s,hl,hf)
 tail(root,.14,0,.34,0,.25)

def ground():
 root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',40,0,0,0,0,cat_motion='idle');_,pts=r.build_polygons(root,tex,tw,th,0,0,subdivide=False);return float(pts[:,1].min())
G=ground()
def render(root,tex,tw,th,yaw,label):
 _,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=False);minx,maxx=pts[:,0].min(),pts[:,0].max();miny,maxy=pts[:,1].min(),pts[:,1].max();scale=min((W-20)/max(maxx-minx,1),(BASE-36)/max(maxy-G,1));xoff=W/2-(minx+maxx)/2*scale;yoff=BASE+G*scale
 canvas=np.zeros((H,W,4),dtype=np.uint8);canvas[:]=np.array(BG);im=Image.fromarray(canvas,'RGBA');d=ImageDraw.Draw(im);d.line((10,BASE,W-10,BASE),fill=(110,145,200,255),width=2);canvas=np.array(im);z=np.full((H,W),np.inf)
 polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=True)
 for _,q,rgba in polys:
  pp=np.array([[xoff+p[0]*scale,yoff-p[1]*scale,p[2]] for p in q]);r._raster_triangle(canvas,z,pp[[0,1,2]],rgba);r._raster_triangle(canvas,z,pp[[0,2,3]],rgba)
 im=Image.fromarray(canvas,'RGBA');d=ImageDraw.Draw(im);d.text((8,8),label,font=SMALL,fill=(240,245,255));return im
for name,pose in [('SIT',sit),('LOAF',loaf),('SPRAWL',sprawl)]:
 sheet=Image.new('RGBA',(2*W,4*H),BG)
 for k in range(4):
  for c,(yaw,vn) in enumerate([(-28,'3Q'),(-90,'SIDE')]):
   root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',42,0,0,0,0,cat_motion='sit');pose(root,k);sheet.alpha_composite(render(root,tex,tw,th,yaw,f'{name} candidate {k+1} · {vn}'),(c*W,k*H))
 sheet.save(OUT/f'{name}-trials.png')
 print(OUT/f'{name}-trials.png')
