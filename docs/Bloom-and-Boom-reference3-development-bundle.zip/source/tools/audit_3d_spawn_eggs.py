#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, subprocess, sys
from pathlib import Path
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'src/main/resources/assets/creeperella'
MODEL=RES/'models/item/3d'
ITEM=RES/'textures/item'
EXPECTED={
 'female_creeper_spawn_egg.png':'475a5fcfa6138dc00f58f77bbe99813043fbcdee97eda632655f535166251187',
 'bunny_creeper_spawn_egg.png':'81c8c6db0ff013a4ad459ab7856486068e2977922f423ea769f27d779972e23e',
 'bee_creeper_spawn_egg.png':'64fe7c8a410a4317f584765afcb98f4397f367a0f0bec6dbeaf0865adf84163d',
 'cherry_creeper_spawn_egg.png':'391c89f344f5b286539e696cbff107e0247afbd9e6adabfb1d2a60e26f2ba60f',
 'blossom_creeper_spawn_egg.png':'391c89f344f5b286539e696cbff107e0247afbd9e6adabfb1d2a60e26f2ba60f',
 'boomshroom_creeper_spawn_egg.png':'b896b7e78638d10c2d1804b2c61d7bb6dc3524b13e4d5ce1daadb61c5026593e',
}
KINDS=['female','bunny','bee','cherry','blossom','cat','boomshroom','cinderella','mariglow','verdalia','nacrella','shroomboom']

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def audit():
    errors=[]
    for name,h in EXPECTED.items():
        p=ITEM/name
        if not p.exists(): errors.append(f'missing 2D sprite {name}'); continue
        if Image.open(p).size!=(16,16): errors.append(f'wrong 2D size {name}')
        if sha(p)!=h: errors.append(f'2D sprite hash changed {name}: {sha(p)}')
    if (ITEM/'3d').exists() and any((ITEM/'3d').iterdir()):
        errors.append('retired textures/item/3d material tiles still present')
    model_files=sorted(MODEL.glob('*.json'))
    expected_states=len(KINDS)*4
    if len(model_files)!=expected_states: errors.append(f'expected {expected_states} 3D model states, got {len(model_files)}')
    for kind in KINDS:
        item=f'{kind}_creeper_spawn_egg'
        idle=MODEL/f'{item}_idle.json'
        if not idle.exists(): errors.append(f'missing {idle.name}'); continue
        d=json.loads(idle.read_text())
        if d.get('textures',{}).get('egg')!=f'creeperella:item/{item}': errors.append(f'{idle.name} does not directly use exact 2D egg texture')
        if '#entity' in idle.read_text() or any(str(v).startswith('creeperella:entity/') for v in d.get('textures',{}).values()):
            errors.append(f'{idle.name} leaks an entity texture into the block/item atlas')
        if kind in ('cherry','blossom'):
            leaf=ITEM/f'{item}_leaf.png'
            if d.get('textures',{}).get('leaf')!=f'creeperella:item/{item}_leaf': errors.append(f'{idle.name} missing atlas-safe source leaf swatch')
            if not leaf.exists() or Image.open(leaf).size!=(16,16): errors.append(f'{item} source leaf swatch missing or wrong size')
        if 'rethoughted_spawn_eggs' in idle.read_text().lower(): errors.append(f'reference asset path leaked into {idle.name}')
        n=len(d.get('elements',[]))
        if not (20 <= n <= 100): errors.append(f'{idle.name} unexpected element count {n}')
        for el in d.get('elements',[]):
            for v in el.get('from',[])+el.get('to',[]):
                if not (-16.0 <= float(v) <= 32.0): errors.append(f'{idle.name} element bound {v} outside Minecraft model limits')
            for face in el.get('faces',{}).values():
                tex=face.get('texture','')
                if tex not in ('#egg','#leaf'): errors.append(f'{idle.name} unexpected texture ref {tex}')
        for state in ('sway_left','sway_right','blink'):
            p=MODEL/f'{item}_{state}.json'; c=json.loads(p.read_text())
            if c.get('parent')!=f'creeperella:item/3d/{item}_idle': errors.append(f'{p.name} does not inherit idle geometry')
            if c.get('elements'): errors.append(f'{p.name} redundantly duplicates geometry')
        base=RES/'models/item'/f'{item}.json'; b=json.loads(base.read_text())
        expected_layer0 = 'creeperella:item/cherry_creeper_spawn_egg' if kind == 'blossom' else f'creeperella:item/{item}'
        if b.get('textures',{}).get('layer0')!=expected_layer0: errors.append(f'{base.name} 2D fallback changed')
        if len(b.get('overrides',[]))!=4: errors.append(f'{base.name} override count != 4')
        if kind == 'blossom':
            models=[o.get('model','') for o in b.get('overrides',[])]
            if not all(m.startswith('creeperella:item/3d/cherry_creeper_spawn_egg_') for m in models):
                errors.append('legacy Blossom spawn egg does not fully alias Cherry 3D states')
    for generated in ('cinderella_creeper_spawn_egg.png','mariglow_creeper_spawn_egg.png','verdalia_creeper_spawn_egg.png','nacrella_creeper_spawn_egg.png','shroomboom_creeper_spawn_egg.png'):
        gp=ITEM/generated
        if not gp.exists(): errors.append(f'missing generated 2D sprite {generated}')
        elif Image.open(gp).size!=(16,16): errors.append(f'wrong generated 2D size {generated}')
    if errors:
        print('FAIL')
        for e in errors: print(' -',e)
        return 1
    print(f'PASS: protected 6/6 legacy 2D hashes unchanged; generated Cinderella/Mariglow/Verdalia/Nacrella/Shroomboom sprites valid; {expected_states}/{expected_states} registered model states valid; legacy Blossom egg aliases Cherry; Boomshroom egg is native 3D; no generic material tiles')
    return 0

if __name__=='__main__': sys.exit(audit())
