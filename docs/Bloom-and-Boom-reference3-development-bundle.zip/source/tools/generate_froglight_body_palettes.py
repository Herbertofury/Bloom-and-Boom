from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
TEX = ROOT / 'src/main/resources/assets/creeperella/textures/entity'
SRC = ROOT / 'reference-assets/froglight/polish23-body-source'
VANILLA = ROOT / '.mvf-generated/vanilla'

# Generic bright-stage-safe ramps retained for non-pearlescent sisters.
RAMPS = {
    'verdalia': [
        (63, 96, 66), (88, 126, 91), (119, 158, 122),
        (155, 194, 159), (202, 226, 205),
    ],
    'mariglow': [
        (103, 82, 35), (139, 113, 50), (174, 146, 72),
        (207, 180, 104), (232, 215, 158),
    ],
}

FACE_BASE = {
    'verdalia': (190, 217, 193),
    'mariglow': (220, 203, 142),
}


def luminance(rgb):
    r, g, b = rgb
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def ramp_sample(ramp, t):
    t = max(0.0, min(1.0, t))
    pos = t * (len(ramp) - 1)
    i = int(pos)
    if i >= len(ramp) - 1:
        return ramp[-1]
    f = pos - i
    a, b = ramp[i], ramp[i + 1]
    return tuple(round(a[k] * (1.0 - f) + b[k] * f) for k in range(3))


def _load_pearlescent_palettes():
    side = Image.open(VANILLA / 'pearlescent_froglight_side.png').convert('RGBA')
    top = Image.open(VANILLA / 'pearlescent_froglight_top.png').convert('RGBA')
    vanilla = []
    for p in side.getdata():
        if p[3] and p[:3] not in vanilla:
            vanilla.append(p[:3])
    vanilla = sorted(vanilla, key=luminance)
    # Calibrated darker pearl ramp: recognizably Minecraft pearlescent Froglight, but not paper-white.
    darkened = []
    for r, g, b in vanilla:
        darkened.append((
            max(0, min(255, round(r * 0.88 - 6))),
            max(0, min(255, round(g * 0.88 - 8))),
            max(0, min(255, round(b * 0.90 - 2))),
        ))
    remap = {src: dst for src, dst in zip(vanilla, darkened)}
    return side, top, darkened, remap


PEARL_SIDE, PEARL_TOP, PEARL_RAMP, PEARL_REMAP = _load_pearlescent_palettes()


def remap_nacrella():
    src = Image.open(SRC / 'nacrella_creeper.png').convert('RGBA')
    out = src.copy()

    def pearl_style(x, y):
        sample = (PEARL_TOP if (y < 16 or ((x // 8) + (y // 8)) % 5 == 0) else PEARL_SIDE).getpixel((x % 16, y % 16))[:3]
        return PEARL_REMAP.get(sample, PEARL_RAMP[3])

    for y in range(src.height):
        for x in range(src.width):
            r, g, b, a = src.getpixel((x, y))
            if a == 0:
                continue
            lum = luminance((r, g, b))
            # Preserve mouth / deliberate dark source details exactly.
            if lum < 75:
                continue
            base = ramp_sample(PEARL_RAMP, (lum - 75.0) / 175.0)
            style = pearl_style(x, y)
            nr = round(base[0] * 0.64 + style[0] * 0.36)
            ng = round(base[1] * 0.64 + style[1] * 0.36)
            nb = round(base[2] * 0.60 + style[2] * 0.40)

            # Keep just a trace of local source chroma/detail.
            residual = (r - lum, g - lum, b - lum)
            nr = max(0, min(255, round(nr + residual[0] * 0.05)))
            ng = max(0, min(255, round(ng + residual[1] * 0.05)))
            nb = max(0, min(255, round(nb + residual[2] * 0.07)))

            # Minecraft-style froglight ribbing: darker side seams, lighter central ribs.
            rib = x % 16
            if rib in (0, 15):
                band_delta = -8
            elif rib in (1, 14):
                band_delta = -5
            elif rib in (6, 7, 8, 9):
                band_delta = 4
            else:
                band_delta = 0
            micro = (-4, -1, 2, 0)[((x // 2) + (y // 2)) & 3]
            lower_body = -4 if y > src.height * 0.55 else 0
            nr = max(0, min(236, nr + band_delta + micro + lower_body))
            ng = max(0, min(230, ng + band_delta + micro + lower_body))
            nb = max(0, min(240, nb + band_delta + micro + lower_body + 1))
            out.putpixel((x, y), (nr, ng, nb, a))
    out.save(TEX / 'nacrella_creeper.png', optimize=True)

    # Face skin now directly echoes the pearlescent top/side material instead of a near-flat pastel sticker.
    face = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    for yy in range(64):
        for xx in range(64):
            sp = PEARL_REMAP[PEARL_SIDE.getpixel(((xx // 4) % 16, (yy // 4) % 16))[:3]]
            tp = PEARL_REMAP[PEARL_TOP.getpixel(((xx // 4) % 16, (yy // 4) % 16))[:3]]
            c = tuple(round(sp[k] * 0.35 + tp[k] * 0.65) for k in range(3))
            dx = abs(xx - 31.5) / 31.5
            dy = abs(yy - 31.5) / 31.5
            lift = max(0.0, 1.0 - (dx * dx + dy * dy) ** 0.5)
            phase = ((xx // 2) + (yy // 2)) & 3
            nr = min(238, round(c[0] + 12 * lift + 14 + (-2, -1, 1, 0)[phase]))
            ng = min(232, round(c[1] + 11 * lift + 14 + (-2, -1, 1, 0)[phase]))
            nb = min(242, round(c[2] + 10 * lift + 15 + (-2, -1, 2, 0)[phase]))
            face.putpixel((xx, yy), (nr, ng, nb, 255))
    face.save(TEX / 'nacrella_face_skin.png', optimize=True)


def remap_generic(name):
    src = Image.open(SRC / f'{name}_creeper.png').convert('RGBA')
    out = src.copy()
    ramp = RAMPS[name]
    for y in range(src.height):
        for x in range(src.width):
            r, g, b, a = src.getpixel((x, y))
            if a == 0:
                continue
            lum = luminance((r, g, b))
            if lum < 105:
                continue
            t = (lum - 105.0) / 150.0
            t = t * t * (3.0 - 2.0 * t)
            nr, ng, nb = ramp_sample(ramp, t)
            residual = (r - lum, g - lum, b - lum)
            nr = max(0, min(255, round(nr + residual[0] * 0.10)))
            ng = max(0, min(255, round(ng + residual[1] * 0.10)))
            nb = max(0, min(255, round(nb + residual[2] * 0.10)))
            phase = ((x // 2) + (y // 2)) & 3
            delta = (-7, -2, 3, 6)[phase]
            nr = max(0, min(255, nr + delta))
            ng = max(0, min(255, ng + delta))
            nb = max(0, min(255, nb + delta))
            out.putpixel((x, y), (nr, ng, nb, a))
    out.save(TEX / f'{name}_creeper.png', optimize=True)

    fr, fg, fb = FACE_BASE[name]
    face = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    for yy in range(64):
        for xx in range(64):
            phase = ((xx // 4) + (yy // 4)) & 3
            delta = (-7, -2, 3, 7)[phase]
            face.putpixel((xx, yy), (
                max(0, min(255, fr + delta)),
                max(0, min(255, fg + delta)),
                max(0, min(255, fb + delta)),
                255,
            ))
    face.save(TEX / f'{name}_face_skin.png', optimize=True)


remap_nacrella()
for variant in ('verdalia', 'mariglow'):
    remap_generic(variant)

print('generated Froglight body + face palettes with Minecraft pearlescent reference for nacrella and stable generic ramps for verdalia/mariglow')
