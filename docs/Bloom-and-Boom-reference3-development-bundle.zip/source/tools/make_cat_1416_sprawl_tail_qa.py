#!/usr/bin/env python3
from __future__ import annotations
import math, sys, shutil
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import render_mobs_visual_qa as r

OUT=Path('/mnt/data/Creeperella-1.4.16-Cat-Sprawl-Tail-QA');OUT.mkdir(parents=True,exist_ok=True)
BEFORE=OUT/'BEFORE-1.4.15'; AFTER=OUT/'AFTER-1.4.16'; BEFORE.mkdir(exist_ok=True);AFTER.mkdir(exist_ok=True)
BG=(8,13,24,255);W,H=340,340;BASE=295;FRAMES=12
try:
    FONT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',14)
    SMALL=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
except Exception:
    FONT=ImageFont.load_default();SMALL=ImageFont.load_default()
MAP={'leftLeg':('leftlegsub2','leftfoot3',False),'rightLeg':('rightlegsub2','rightfoot3',False),'leftLegback':('leftlegsub','leftfoot2',True),'rightLegback':('rightlegsub','rightfoot2',True)}
def P(root,*p): return r.find(root,*p)
def solve_ik(hind,ty,tz):
    udy,udz=5.25,1.75;ldy,ldz=(5.05,-.25) if hind else (3.0,0.0)
    l1=math.hypot(udy,udz);l2=math.hypot(ldy,ldz);a1=math.atan2(udz,udy);a2=math.atan2(ldz,ldy)
    d=max(abs(l1-l2)+.08,min(l1+l2-.08,math.hypot(ty,tz)));k=math.acos(max(-1,min(1,(d*d-l1*l1-l2*l2)/(2*l1*l2))))
    ta=math.atan2(tz,ty);ua=ta-math.atan2(l2*math.sin(k),l1+l2*math.cos(k))-a1;la=k+a1-a2;return ua,la,-(ua+la)
def leg_ik(root,n,ty,tz,dx,dy,dz,yaw,roll):
    ln,fn,hind=MAP[n];leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn);ua,la,pa=solve_ik(hind,ty,tz)
    leg.x+=dx;leg.y+=dy;leg.z+=dz;leg.rx=ua;leg.ry=yaw;leg.rz=roll;lo.rx=la;fo.rx=pa
def leg_adv(root,n,upper,lower,paw,yaw=0,roll=0):
    ln,fn,_=MAP[n];leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn);leg.rx=upper;leg.ry=yaw;leg.rz=roll;lo.rx=lower;fo.rx=paw
def rest_leg(root,row):
    n,dx,dy,dz,rx,ry,rz,lrx,frx=row;ln,fn,_=MAP[n];leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn)
    leg.x+=dx;leg.y+=dy;leg.z+=dz;leg.rx=rx;leg.ry=ry;leg.rz=rz;lo.rx=lrx;fo.rx=frx

def old_sprawl(root,v=0):
    side=1 if v%2==0 else -1;w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head')
    w.y+=.89;b.y+=1.40;b.rx+=.16;u.y+=.28;u.rx-=.08;h.rx+=.01;h.rz+=side*.035
    leg_ik(root,'leftLeg',6.90,-1.60,1.50,.35,0,.18,.42);leg_ik(root,'rightLeg',6.90,-1.60,-1.50,.35,0,-.18,-.42)
    leg_ik(root,'leftLegback',7.00,1.60,2.00,.50,0,.08,.42);leg_ik(root,'rightLegback',7.00,1.60,-2.00,.50,0,-.08,-.42)
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.z+=.16;t.rx=.24;t.ry=0;t2.rx=.50;t2.ry=side*.10

def sit2(root,v=0): old_sprawl(root,v)
def new_sprawl(root,v=0):
    side=1 if v%2==0 else -1;w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head')
    w.y+=6.28;b.y+=.30;b.rx+=1.48;u.y+=.05;u.rx-=1.18;h.rx-=.28;h.rz+=side*.020
    leg_adv(root,'leftLeg',-1.46,.02,-.02,0,.03);leg_adv(root,'rightLeg',-1.46,.02,-.02,0,-.03)
    leg_adv(root,'leftLegback',1.34,.02,-.02,0,.015);leg_adv(root,'rightLegback',1.34,.02,-.02,0,-.015)
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.z+=.10;t.rx=-.50;t.ry=0;t.rz=0;t2.rx=-.15;t2.ry=0;t2.rz=0

# 1.4.15 approved side-lie / horse-rest body and tail, unchanged.
ROLL=[.82,.86,.80,.84];GY=[-2.8239,-3.8517,-2.5893,-3.0833];BL=[.05,.04,.06,.025];UL=[.025,.02,.03,.01];HL=[.008,.006,.01,.002];BP=[.12,.10,.14,.08];UP=[-.09,-.08,-.10,-.07];HP=[.01,0,.015,-.005];UY=[.29,.27,.31,.23];HY=[-.08,-.02,.08,-.28];HRY=[.14,.16,.12,.22]
LEGS=[[('leftLeg',2.0,1.4,-1.6,-.10,-.20,.72,.50,-.10),('rightLeg',4.0,1.7,-.4,-.58,-.10,.54,1.35,-.35),('leftLegback',2.4,1.6,1.2,.55,.12,.82,1.40,-.45),('rightLegback',4.3,1.8,.4,.28,.06,.60,1.25,-.30)],[('leftLeg',2.8,1.3,-2.2,.05,-.24,.86,.38,-.05),('rightLeg',4.4,1.8,-.2,-.65,-.10,.52,1.42,-.38),('leftLegback',3.0,1.6,1.6,.62,.12,.96,1.46,-.48),('rightLegback',4.7,1.9,.5,.30,.06,.62,1.28,-.30)],[('leftLeg',1.8,1.4,-1.2,-.22,-.16,.70,.78,-.18),('rightLeg',3.8,1.8,-.2,-.62,-.08,.50,1.38,-.35),('leftLegback',2.8,1.7,1.8,.70,.12,1.02,1.50,-.52),('rightLegback',4.6,2.0,.7,.34,.05,.62,1.30,-.32)],[('leftLeg',2.4,1.2,-1.8,-.02,-.22,.78,.46,-.08),('rightLeg',4.2,1.6,-.5,-.52,-.12,.58,1.25,-.30),('leftLegback',2.5,1.5,1.3,.50,.14,.88,1.36,-.40),('rightLegback',4.4,1.8,.4,.25,.06,.60,1.20,-.28)]]
def side_lie(root,v=3):
    w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head');roll=ROLL[v]
    w.y+=GY[v];w.rz+=roll;b.y+=1.15;b.rx+=BP[v];b.rz+=-roll+BL[v];u.y+=UY[v];u.rx+=UP[v];u.rz+=UL[v]-BL[v];h.y+=HY[v];h.rx+=HP[v];h.ry+=HRY[v];h.rz+=HL[v]-UL[v]
    for row in LEGS[v]:rest_leg(root,row)
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.rx=.28;t.ry=-.08;t2.rx=.58;t2.ry=-.04

def standing_ground():
    root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',40,0,0,0,0,cat_motion='idle');_,pts=r.build_polygons(root,tex,tw,th,0,0,subdivide=False);return float(pts[:,1].min())
GROUND=standing_ground()
def render(root,tex,tw,th,yaw,label,pitch=5):
    _,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=pitch,subdivide=False);mnx,mxx=pts[:,0].min(),pts[:,0].max();mny,mxy=pts[:,1].min(),pts[:,1].max();sc=min((W-24)/max(mxx-mnx,1),(BASE-38)/max(mxy-GROUND,1));xo=W/2-(mnx+mxx)/2*sc;yo=BASE+GROUND*sc
    can=np.zeros((H,W,4),dtype=np.uint8);can[:]=np.array(BG,dtype=np.uint8);im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);d.rounded_rectangle((12,BASE-4,W-12,BASE+8),radius=6,fill=(12,22,40,230));d.line((12,BASE,W-12,BASE),fill=(115,145,195,255),width=2);can=np.array(im);z=np.full((H,W),np.inf)
    polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=pitch,subdivide=True)
    for _,q,rgba in polys:
        pp=np.array([[xo+p[0]*sc,yo-p[1]*sc,p[2]] for p in q],dtype=float);r._raster_triangle(can,z,pp[[0,1,2]],rgba);r._raster_triangle(can,z,pp[[0,2,3]],rgba)
    im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);bb=d.textbbox((0,0),label,font=SMALL);tx=(W-(bb[2]-bb[0]))//2;d.rounded_rectangle((tx-6,8,tx+(bb[2]-bb[0])+6,29),radius=6,fill=(15,22,38,225),outline=(105,125,165,255));d.text((tx,11),label,font=SMALL,fill=(241,244,255));return im
def pose_frame(pose,v=0,age=42):
    root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',age,0,0,0,0,cat_motion='sit');pose(root,v);return root,tex,tw,th
def save_gif(path,pose,v,label,yaw=-28):
    frames=[]
    for i in range(FRAMES):
        root,tex,tw,th=pose_frame(pose,v,40+i*.75);frames.append(render(root,tex,tw,th,yaw,label))
    frames[0].save(path,save_all=True,append_images=frames[1:],duration=110,loop=0,disposal=2,optimize=False)

# Before/after + renamed preservation sheet.
sheet=Image.new('RGBA',(2*W,3*H),BG)
for row,(left_pose,left_label,right_pose,right_label) in enumerate([
    (old_sprawl,'1.4.15 · old SPRAWL',sit2,'1.4.16 · SIT 2 · preserved'),
    (old_sprawl,'1.4.15 · old SPRAWL',new_sprawl,'1.4.16 · NEW GOOFY SPRAWL'),
    (side_lie,'SIDE-LIE · 3Q · tail occluded',side_lie,'SIDE-LIE · rear 3Q · tail visible')]):
    root,tex,tw,th=pose_frame(left_pose,0 if row<2 else 3);sheet.alpha_composite(render(root,tex,tw,th,-28,left_label),(0,row*H))
    root,tex,tw,th=pose_frame(right_pose,0 if row<2 else 3);sheet.alpha_composite(render(root,tex,tw,th,-28 if row<2 else 150,right_label),(W,row*H))
hero=OUT/'Creeperella-1.4.15-vs-1.4.16-Sprawl-Sit2-Tail.png';sheet.save(hero)

# Side-lie with tail: four angles and a deterministic camera turntable.
views=[(-28,'3Q'),(-90,'SIDE'),(150,'REAR 3Q'),(180,'BACK')]
tail_sheet=Image.new('RGBA',(2*W,2*H),BG)
for i,(yaw,name) in enumerate(views):
    root,tex,tw,th=pose_frame(side_lie,3);tail_sheet.alpha_composite(render(root,tex,tw,th,yaw,f'SIDE-LIE + TAIL · {name}'),((i%2)*W,(i//2)*H))
tail_png=AFTER/'Cat-Creeper-1.4.16-SIDE-LIE-Tail-Multiangle.png';tail_sheet.save(tail_png)
turn=[]
for i in range(24):
    yaw=-28+i*(360/24);root,tex,tw,th=pose_frame(side_lie,3,40+i*.25);turn.append(render(root,tex,tw,th,yaw,'SIDE-LIE · TAIL TURNTABLE'))
tail_gif=AFTER/'Cat-Creeper-1.4.16-SIDE-LIE-Tail-Turntable.gif';turn[0].save(tail_gif,save_all=True,append_images=turn[1:],duration=105,loop=0,disposal=2,optimize=False)

# New sprawl and Sit 2 inspection.
for name,pose in [('SIT-2',sit2),('SPRAWL',new_sprawl)]:
    save_gif(AFTER/f'Cat-Creeper-1.4.16-{name}-3Q.gif',pose,0,f'1.4.16 · {name} · 3Q',-28)
    save_gif(AFTER/f'Cat-Creeper-1.4.16-{name}-SIDE.gif',pose,0,f'1.4.16 · {name} · SIDE',-90)
    s=Image.new('RGBA',(2*W,H),BG)
    for c,(yaw,vn) in enumerate([(-28,'3Q'),(-90,'SIDE')]):
        root,tex,tw,th=pose_frame(pose,0);s.alpha_composite(render(root,tex,tw,th,yaw,f'{name} · {vn}'),(c*W,0))
    s.save(AFTER/f'Cat-Creeper-1.4.16-{name}-Multiangle.png')

# Preserve 1.4.15 representative old-sprawl GIF.
save_gif(BEFORE/'Cat-Creeper-1.4.15-SPRAWL.gif',old_sprawl,0,'BEFORE · 1.4.15 SPRAWL',-28)

# Fixed-ground and tail presence report.
lines=[f'standing_ground_y={GROUND:.6f}']
for name,pose,count in [('SIT_2',sit2,2),('SPRAWL',new_sprawl,2),('SIDE_LIE',side_lie,4)]:
    ds=[]
    for v in range(count):
        root,tex,tw,th=pose_frame(pose,v);_,pts=r.build_polygons(root,tex,tw,th,0,0,subdivide=False);ds.append(float(pts[:,1].min()-GROUND))
    lines.append(f'{name}: bottom_delta_min={min(ds):.6f} max={max(ds):.6f}')
# Tail cubes remain present in source geometry and transformed render.
root,tex,tw,th=pose_frame(side_lie,3);tail=P(root,'body','waist','Body','tail');tail2=P(root,'body','waist','Body','tail','tail2')
lines.append(f'SIDE_LIE_tail_parts=tail:{int(tail is not None)} tail2:{int(tail2 is not None)}')
(AFTER/'GROUND_AND_TAIL_QA.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')

(OUT/'README.md').write_text('''# Creeperella 1.4.16 Cat sprawl + tail QA\n\nDeterministic project renders only. No generative image model was used.\n\n## 1.4.16 changes\n- The 1.4.15 SPRAWL pose is preserved as a new owner-command rest state named **Sit 2**.\n- **Sprawl** is rebuilt as a goofy full sploot: both forelegs extend almost straight forward and both hind legs extend almost straight backward, nearly parallel to the Minecraft ground plane.\n- The approved SIDE_LIE / horse-rest body pose and tail transforms are unchanged. The prior 3Q card simply occluded the tail behind the haunches; a multi-angle sheet and camera turntable now make the actual tail visible.\n- Full 1.4.15 source rollback is bundled under `pose-history/1.4.15-before/`.\n''',encoding='utf-8')
print(hero);print(tail_png);print(tail_gif);print((AFTER/'GROUND_AND_TAIL_QA.txt').read_text())
