#!/usr/bin/env python3
"""Creeperella 1.4.8 Cat state/idle/clipping regression gate.

Exercises the deterministic mirror of the production Cat model across creep, walk,
run, sit, swell, and every personality idle. The gate intentionally rejects the
screenshot-class regressions that motivated the locomotion rewrite: folded distal
legs entering the torso, paws swapping body sides, discontinuous foot trajectories,
and tail tunneling.
"""
from __future__ import annotations
import math
import os
import sys
from pathlib import Path

# Tiny 4x4 QA matrices become dramatically slower when BLAS fans each operation across a
# many-core host. Pin the numerical backend to one thread before NumPy imports; this changes no
# sampled points or tolerances and keeps the exact 17,328-sample gate consistently fast.
for _var in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_var] = "1"

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import render_mobs_visual_qa as r


def world_matrices(root):
    mats = {}
    def walk(p, parent):
        m = parent @ r.local_matrix(p)
        mats[p.name] = (p, m)
        for ch in p.children:
            walk(ch, m)
    walk(root, np.eye(4))
    return mats


def cube_samples(part, matrix, distal_only=False):
    out=[]
    for c in part.cubes:
        x0,x1=c.x-c.deform,c.x+c.dx+c.deform
        y0,y1=c.y-c.deform,c.y+c.dy+c.deform
        z0,z1=c.z-c.deform,c.z+c.dz+c.deform
        ys=[(y0+y1)*0.5,y1] if distal_only else [y0,(y0+y1)*0.5,y1]
        for x in [x0,(x0+x1)*0.5,x1]:
            for y in ys:
                for z in [z0,(z0+z1)*0.5,z1]:
                    q=matrix@np.array([x,y,z,1.0])
                    out.append(q[:3])
    return out


def inside_core(point_world, torso_inverse, torso_part, margin=0.55):
    # The torso transform is constant for every sampled lower-leg/paw point in one validation
    # frame. Computing its inverse once per frame preserves exact math/sample coverage while
    # eliminating tens of thousands of identical np.linalg.inv calls.
    q=(torso_inverse@np.array([*point_world,1.0]))[:3]
    for c in torso_part.cubes:
        x0,x1=c.x-c.deform+margin,c.x+c.dx+c.deform-margin
        y0,y1=c.y-c.deform+margin,c.y+c.dy+c.deform-margin
        z0,z1=c.z-c.deform+margin,c.z+c.dz+c.deform-margin
        if x0<x1 and y0<y1 and z0<z1 and x0<=q[0]<=x1 and y0<=q[1]<=y1 and z0<=q[2]<=z1:
            return True
    return False


LEGS = {
    'leftLeg': ('leftlegsub2','leftfoot3', False, +1),
    'rightLeg': ('rightlegsub2','rightfoot3', False, -1),
    'leftLegback': ('leftlegsub','leftfoot2', True, +1),
    'rightLegback': ('rightlegsub','rightfoot2', True, -1),
}

CADENCE = {'creep':0.56, 'walk':1.0, 'run':1.58}
AMOUNTS = {
    'creep': (0.10,0.18,0.30,0.46),
    'walk': (0.20,0.38,0.62,0.82),
    'run': (0.42,0.64,0.84,1.00),
}


def validate_pose(root, label, strict_ik=False):
    mats=world_matrices(root)
    torso, torso_m=mats['Body']
    upper_torso, upper_m=mats['Upperbody']
    torso_inv=np.linalg.inv(torso_m)
    upper_inv=np.linalg.inv(upper_m)
    centers={}
    for leg_name,(lower_name,foot_name,hind,side) in LEGS.items():
        leg,_=mats[leg_name]; lower,lower_m=mats[lower_name]; foot,foot_m=mats[foot_name]
        assert all(math.isfinite(v) for v in (leg.rx,leg.ry,leg.rz,lower.rx,lower.ry,lower.rz,foot.rx,foot.ry,foot.rz)), (label,leg_name,'nonfinite')
        if strict_ik:
            upper_min=-1.02 if hind else -0.96
            upper_max=0.24 if hind else 0.26
            lower_min=0.38 if hind else 0.36
            lower_max=1.42 if hind else 1.36
            assert upper_min-1e-6 <= leg.rx <= upper_max+1e-6, (label,leg_name,'upper',leg.rx)
            assert lower_min-1e-6 <= lower.rx <= lower_max+1e-6, (label,leg_name,'lower',lower.rx)
            assert -0.92-1e-6 <= foot.rx <= 0.46+1e-6, (label,leg_name,'paw',foot.rx)
        else:
            # Bind/idle/sit clips may legitimately keep an unbent lower joint at 0. The broader
            # anatomical envelope still rejects screenshot-class folds while the volume test below
            # catches actual geometry penetration.
            assert -1.08 <= leg.rx <= 0.35, (label,leg_name,'upper broad',leg.rx)
            assert -0.08 <= lower.rx <= 1.48, (label,leg_name,'lower broad',lower.rx)
            assert -0.98 <= foot.rx <= 0.52, (label,leg_name,'paw broad',foot.rx)

        for pt in cube_samples(lower,lower_m)+cube_samples(foot,foot_m):
            assert not inside_core(pt,torso_inv,torso,0.62), (label,leg_name,'Body',pt)
            assert not inside_core(pt,upper_inv,upper_torso,0.50), (label,leg_name,'Upperbody',pt)

        fpts=np.array(cube_samples(foot,foot_m))
        center=fpts.mean(axis=0)
        assert center[0]*side > 1.00, (label,leg_name,'centerline',center)
        centers[leg_name]=center

    tail2,tail2_m=mats['tail2']
    for pt in cube_samples(tail2,tail2_m):
        assert not inside_core(pt,torso_inv,torso,0.75), (label,'tail2','Body',pt)
    return mats, centers


def main():
    root,*_=r.load_variant('cat')
    total_leg_samples=0
    max_jump=0.0

    # Locomotion: cover full normalized gait phase for each motion state rather than relying on
    # one shared limbSwing cadence. This validates slow stalk, normal walk and full run separately.
    for motion,amounts in AMOUNTS.items():
        cadence=CADENCE[motion]
        for amount in amounts:
            prev={}
            for i in range(361):
                phase=math.tau*i/360.0
                limb=phase/(0.6662*cadence)
                age=20.0+i*0.17
                r.apply_anim(root,'cat',age,limb,amount,0.0,0.0,cat_motion=motion)
                _,centers=validate_pose(root,f'{motion}:{amount:.2f}:{phase:.5f}', strict_ik=True)
                for leg_name,center in centers.items():
                    if leg_name in prev:
                        jump=float(np.linalg.norm(center-prev[leg_name]))
                        max_jump=max(max_jump,jump)
                        assert jump < 0.18, (motion,leg_name,'discontinuity',amount,phase,jump)
                    prev[leg_name]=center
                    total_leg_samples+=1

    # Non-locomotion presentation modes are also forbidden from bypassing the clipping contract.
    sit_tail_lateral_max=0.0
    sit_tail_back_min=float('inf')
    sit_tail_floor_clearance_min=float('inf')
    for motion in ('sit','swell'):
        for i in range(73):
            age=40.0+i*0.15
            r.apply_anim(root,'cat',age,0.0,0.0,0.0,0.0,cat_motion=motion)
            mats,_=validate_pose(root,f'{motion}:{i}', strict_ik=False)
            if motion=='sit':
                tail,tail_m=mats['tail']; tail2,tail2_m=mats['tail2']
                pivot=(tail_m@np.array([0.0,0.0,0.0,1.0]))[:3]
                tip=(tail2_m@np.array([0.0,8.8,0.0,1.0]))[:3]
                sit_tail_lateral_max=max(sit_tail_lateral_max,abs(float(tip[0]-pivot[0])))
                sit_tail_back_min=min(sit_tail_back_min,float(tip[2]-pivot[2]))
                foot_points=[]
                for foot_name in ('leftfoot3','rightfoot3','leftfoot2','rightfoot2'):
                    foot,foot_m=mats[foot_name]
                    foot_points.extend(cube_samples(foot,foot_m))
                ground_y=np.array(foot_points)[:,1].max()
                tail_points=np.array(cube_samples(tail,tail_m)+cube_samples(tail2,tail2_m))
                sit_tail_floor_clearance_min=min(sit_tail_floor_clearance_min,float(ground_y-tail_points[:,1].max()))
                assert abs(tail.ry) < 1e-6 and abs(tail.rz) < 1e-6, ('sit tail root must stay sagittal',tail.ry,tail.rz)
                assert abs(tail2.ry) < 1e-6 and abs(tail2.rz) < 1e-6, ('sit tail tip must stay sagittal',tail2.ry,tail2.rz)

    assert sit_tail_lateral_max < 0.05, ('sit tail lateral spear',sit_tail_lateral_max)
    assert sit_tail_back_min > 12.0, ('sit tail must trail behind rump',sit_tail_back_min)
    assert sit_tail_floor_clearance_min > 4.0, ('sit tail floor collision',sit_tail_floor_clearance_min)

    # Personality idles: sample both deterministic handedness choices and every point in the clip.
    idle_durations={'paw_lift':58.0,'tail_wag':72.0,'curious_look':62.0,'knead':80.0}
    idle_peaks={k:0.0 for k in idle_durations}
    for idle,duration in idle_durations.items():
        for left in (False,True):
            for i in range(241):
                elapsed=duration*i/240.0
                r.apply_anim(root,'cat',80.0+elapsed,0.0,0.0,0.0,0.0,
                             cat_motion='idle',cat_idle=idle,cat_idle_elapsed=elapsed,cat_left=left)
                mats,_=validate_pose(root,f'{idle}:{left}:{elapsed:.4f}', strict_ik=False)
                if idle=='paw_lift':
                    leg=mats['leftLeg' if left else 'rightLeg'][0]
                    idle_peaks[idle]=max(idle_peaks[idle],abs(leg.rx-leg.base[3]))
                elif idle=='tail_wag':
                    tail=mats['tail'][0]; tail2=mats['tail2'][0]
                    idle_peaks[idle]=max(idle_peaks[idle],abs(tail.ry-tail.base[4])+abs(tail2.ry-tail2.base[4]))
                elif idle=='curious_look':
                    head=mats['head'][0]
                    idle_peaks[idle]=max(idle_peaks[idle],abs(head.ry-head.base[4])+abs(head.rz-head.base[5]))
                elif idle=='knead':
                    ll=mats['leftLeg'][0]; rr=mats['rightLeg'][0]
                    idle_peaks[idle]=max(idle_peaks[idle],abs(ll.rx-rr.rx))

    assert idle_peaks['paw_lift'] > 0.35, idle_peaks
    assert idle_peaks['tail_wag'] > 0.30, idle_peaks
    assert idle_peaks['curious_look'] > 0.25, idle_peaks
    assert idle_peaks['knead'] > 0.15, idle_peaks

    # Gait at exact zero movement must collapse to the authored source/bind leg pose, regardless of state.
    for motion in ('idle','creep','walk','run'):
        for phase in (0.0,0.7,1.8,3.2,5.6):
            r.apply_anim(root,'cat',42.0,phase/0.6662,0.0,0.0,0.0,cat_motion=motion)
            mats=world_matrices(root)
            for leg_name,(lower_name,foot_name,_,_) in LEGS.items():
                leg,_=mats[leg_name]; lower,_=mats[lower_name]; foot,_=mats[foot_name]
                assert abs(leg.rx-leg.base[3]) < 1e-9, (motion,leg_name,'upper idle reset')
                assert abs(lower.rx-lower.base[3]) < 1e-9, (motion,leg_name,'lower idle reset')
                assert abs(foot.rx-foot.base[3]) < 1e-9, (motion,leg_name,'paw idle reset')

    print(f'PASS: {total_leg_samples} locomotion leg-phase samples across creep/walk/run')
    print('PASS: sit + swell presentation modes do not create distal torso penetrations')
    print(f'PASS: seated tail stays sagittal/rearward with floor clearance; lateral={sit_tail_lateral_max:.5f}, rear={sit_tail_back_min:.5f}, clearance={sit_tail_floor_clearance_min:.5f}')
    print('PASS: all four personality idles sampled for both handedness choices without distal clipping')
    print('PASS: personality clips have non-trivial visible motion:', ', '.join(f'{k}={v:.3f}' for k,v in idle_peaks.items()))
    print('PASS: paw centers never cross body sides')
    print(f'PASS: continuous planted-foot trajectories; max frame-step paw delta={max_jump:.5f}')
    print('PASS: tail2 never tunnels through torso core')
    print('PASS: zero-motion locomotion collapses cleanly to authored bind/source leg pose')


if __name__=='__main__':
    main()
