#!/usr/bin/env python3
from audit_cherry_blossom_merge import main
if __name__ == "__main__":
    raise SystemExit(main())
