#!/usr/bin/env python3
"""Deterministic Boomshroom visual QA from actual Bloom & Boom source.

No image generation. Uses the Cherry-derived runtime ModelPart layer, Boomshroom textures,
and the exact Boomshroom cap/greeting formulas from the Java runtime.
"""
from __future__ import annotations
import copy, math, sys, multiprocessing as mp
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
from render_mobs_visual_qa import (
    parse_layer, apply_anim, build_polygons, _raster_triangle, find, Cube, Part
)

BODY_JAVA = ROOT / 'src/main/java/dev/herbertofury/creeperella/client/CherryRemakeModelLayers.java'
BODY_TEX = ROOT / 'src/main/resources/assets/creeperella/textures/entity/boomshroom_creeper.png'
CAP_TEX = ROOT / 'src/main/resources/assets/creeperella/textures/entity/boomshroom_cap.png'

DEG = math.pi / 180.0


def font(size: int, bold: bool = True):
    p = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    try:
        return ImageFont.truetype(p, size)
    except OSError:
        return ImageFont.load_default()


def strip_cubes(p: Part):
    p.cubes = []
    for c in p.children:
        strip_cubes(c)


def make_cap_part(age: float, greet: float) -> Part:
    cap = Part('cap', x=0.0, y=-8.0, z=0.0)
    # Exact BoomshroomCapLayer.createLayer() geometry / UVs.
    cap.cubes = [
        Cube(0, 0, -7, -6, -7, 14, 6, 14, 0.0, False),
        Cube(0, 108, -7, -6, -7, 14, 6, 14, 2.0, False),
    ]
    # Exact Java idle motion.
    idle = math.sin(age / 9.0)
    cap.rz += idle * 1.15 * DEG
    cap.y -= (math.cos(age / 7.5) + 1.0) * 0.045
    # Exact Java greeting cap motion.
    if greet > 0.0:
        g = max(0.0, min(1.0, greet))
        arc = math.sin(g * math.pi)
        overshoot = math.sin(g * math.pi * 2.0) * (1.0 - g)
        cap.x += arc * 0.72
        cap.y -= arc * 0.95
        cap.rx += arc * 8.5 * DEG
        cap.rz -= (arc * 29.0 + overshoot * 5.0) * DEG
    return cap


def setup_frame(root: Part, age: float, limb_swing: float, amount: float, greet: float = 0.0):
    # Boomshroom intentionally uses the Cherry runtime rig/animation family.
    apply_anim(root, 'cherry', age, limb_swing, amount, 0.0, 0.0)
    head = find(root, 'body', 'body', 'body_cherry_rotation', 'body_cherry', 'head_cherry')
    if head is not None and greet > 0.0:
        g = max(0.0, min(1.0, greet))
        arc = math.sin(g * math.pi)
        # Exact CreeperellaModel Boomshroom greeting addition.
        head.rx += arc * 8.0 * DEG
        head.rz -= arc * 3.5 * DEG

    cap_root = copy.deepcopy(root)
    strip_cubes(cap_root)
    cap_head = find(cap_root, 'body', 'body', 'body_cherry_rotation', 'body_cherry', 'head_cherry')
    if cap_head is None:
        raise RuntimeError('Boomshroom cap anchor hierarchy missing')
    cap = make_cap_part(age, greet)
    cap.parent = cap_head
    cap_head.children.append(cap)
    return cap_root


def combined_points(root: Part, body_tex: Image.Image, cap_tex: Image.Image, age, ls, amount, greet, yaw, pitch):
    cap_root = setup_frame(root, age, ls, amount, greet)
    _, body_pts = build_polygons(root, body_tex, 64, 64, yaw, pitch, subdivide=False)
    _, cap_pts = build_polygons(cap_root, cap_tex, 128, 128, yaw, pitch, subdivide=False)
    if len(body_pts) and len(cap_pts):
        return np.vstack([body_pts, cap_pts])
    return body_pts if len(body_pts) else cap_pts


def compute_view(root, body_tex, cap_tex, specs, size, yaw=0.0, pitch=0.0):
    mins = np.array([1e9, 1e9], float)
    maxs = np.array([-1e9, -1e9], float)
    for age, ls, amount, greet in specs:
        pts = combined_points(root, body_tex, cap_tex, age, ls, amount, greet, yaw, pitch)
        if len(pts):
            mins = np.minimum(mins, pts[:, :2].min(axis=0))
            maxs = np.maximum(maxs, pts[:, :2].max(axis=0))
    center = (mins + maxs) / 2.0
    span = maxs - mins
    w, h = size
    scale = min((w - 52) / max(span[0], 1.0), (h - 52) / max(span[1], 1.0))
    return center, scale


def render_model(root, body_tex, cap_tex, age, ls, amount, greet, view, size=(560, 650), yaw=0.0, pitch=0.0):
    cap_root = setup_frame(root, age, ls, amount, greet)
    body_polys, _ = build_polygons(root, body_tex, 64, 64, yaw, pitch, subdivide=True)
    cap_polys, _ = build_polygons(cap_root, cap_tex, 128, 128, yaw, pitch, subdivide=True)
    center, scale = view
    w, h = size
    canvas = np.zeros((h, w, 4), dtype=np.uint8)
    zbuf = np.full((h, w), np.inf, dtype=float)
    # Shared depth buffer: cap/body occlude each other correctly.
    for _depth, q, rgba in body_polys + cap_polys:
        pts = np.array([[w / 2 + (p[0] - center[0]) * scale,
                         h / 2 - (p[1] - center[1]) * scale,
                         p[2]] for p in q], dtype=float)
        _raster_triangle(canvas, zbuf, pts[[0, 1, 2]], rgba)
        _raster_triangle(canvas, zbuf, pts[[0, 2, 3]], rgba)
    return Image.fromarray(canvas, 'RGBA')


def grid_bg(size):
    w, h = size
    im = Image.new('RGBA', size, (18, 21, 27, 255))
    d = ImageDraw.Draw(im, 'RGBA')
    for x in range(0, w, 32):
        d.line((x, 0, x, h), fill=(255, 255, 255, 9), width=1)
    for y in range(0, h, 32):
        d.line((0, y, w, y), fill=(255, 255, 255, 9), width=1)
    return im


def card(model: Image.Image, label: str, size=(640, 760)):
    bg = grid_bg(size)
    d = ImageDraw.Draw(bg, 'RGBA')
    d.rounded_rectangle((14, 14, size[0]-14, size[1]-14), radius=18,
                        fill=(29, 33, 41, 236), outline=(255,255,255,28), width=2)
    d.text((26, 24), 'BOOMSHROOM', font=font(28), fill=(246,248,250,255))
    d.text((27, 61), label, font=font(13, False), fill=(180,190,205,255))
    d.text((27, 86), 'ACTUAL SOURCE RENDER · NO IMAGE GENERATION', font=font(11, False), fill=(139,205,149,255))
    # Pixel-art-aware: source raster is already high-resolution polygon output; don't resample unless required.
    x = (size[0] - model.width) // 2
    y = 104 + (size[1] - 118 - model.height) // 2
    bg.alpha_composite(model, (x, y))
    return bg.convert('RGB')


def save_gif(frames, path: Path, fps: int):
    duration = int(round(1000 / fps))
    frames[0].save(path, save_all=True, append_images=frames[1:], duration=duration,
                   loop=0, optimize=True, disposal=2)


_W_ROOT = _W_BODY = _W_CAP = _W_VIEW = _W_LABEL = _W_YAW = _W_PITCH = None
_W_SIZE = (480, 560)

def _render_sequence_worker(spec):
    age, ls, amount, greet = spec
    m = render_model(_W_ROOT, _W_BODY, _W_CAP, age, ls, amount, greet, _W_VIEW, _W_SIZE, _W_YAW, _W_PITCH)
    return card(m, _W_LABEL)

def make_sequence(root, body_tex, cap_tex, specs, out_path, label, fps, yaw=0.0, pitch=0.0):
    global _W_ROOT, _W_BODY, _W_CAP, _W_VIEW, _W_LABEL, _W_YAW, _W_PITCH
    model_size = _W_SIZE
    view = compute_view(root, body_tex, cap_tex, specs, model_size, yaw, pitch)
    _W_ROOT, _W_BODY, _W_CAP = root, body_tex, cap_tex
    _W_VIEW, _W_LABEL, _W_YAW, _W_PITCH = view, label, yaw, pitch
    workers = max(2, min(8, (mp.cpu_count() or 4)))
    with mp.get_context('fork').Pool(processes=workers) as pool:
        frames = pool.map(_render_sequence_worker, specs, chunksize=1)
    save_gif(frames, out_path, fps)
    return frames, view


def main():
    out = Path(sys.argv[1] if len(sys.argv) > 1 else '/mnt/data/Boomshroom-Visual-QA')
    out.mkdir(parents=True, exist_ok=True)
    root, tw, th = parse_layer(BODY_JAVA, 'createCherryLayer')
    if (tw, th) != (64, 64):
        raise RuntimeError(f'Unexpected Boomshroom donor layer atlas: {(tw,th)}')
    body_tex = Image.open(BODY_TEX).convert('RGBA')
    cap_tex = Image.open(CAP_TEX).convert('RGBA')

    # True straight-on neutral/idle checkpoint. yaw=0, pitch=0.
    neutral_age = 7.0 * math.pi / 2.0
    neutral_specs = [(neutral_age, 0.0, 0.0, 0.0)]
    neutral_view = compute_view(root, body_tex, cap_tex, neutral_specs, (560,650), 0, 0)
    neutral_model = render_model(root, body_tex, cap_tex, neutral_age, 0.0, 0.0, 0.0,
                                 neutral_view, (560,650), 0, 0)
    card(neutral_model, 'TRUE FRONT · YAW 0° · PITCH 0°').save(out/'Boomshroom-True-Front.png', optimize=True)

    fps = 8
    # Full Cherry blink cadence + Boomshroom cap idle, stationary.
    idle_n = int(round(5.25 * fps))
    idle_specs = []
    for i in range(idle_n):
        t = i / fps
        age = t * 20.0
        idle_specs.append((age, 0.0, 0.0, 0.0))
    make_sequence(root, body_tex, cap_tex, idle_specs, out/'Boomshroom-Front-Idle-Blink.gif',
                  'TRUE FRONT · IDLE + SOURCE BLINK + CAP SECONDARY MOTION', fps)

    # Exact 30-tick cap-tip greeting plus a short settle tail.
    greet_secs = 2.0
    greet_n = int(round(greet_secs * fps))
    greet_specs = []
    for i in range(greet_n):
        t = i / fps
        age = t * 20.0
        elapsed = min(age, 30.0)
        greet = elapsed / 30.0 if age <= 30.0 else 0.0
        greet_specs.append((age, 0.0, 0.0, greet))
    make_sequence(root, body_tex, cap_tex, greet_specs, out/'Boomshroom-Front-Cap-Tip-Greeting.gif',
                  'TRUE FRONT · AUTHORED CAP-TIP GREETING', fps)

    # Walking sample using exact Cherry-family source equations underneath Boomshroom.
    walk_secs = 3.0
    walk_n = int(round(walk_secs * fps))
    walk_specs = []
    for i in range(walk_n):
        t = i / fps
        age = t * 20.0
        walk_specs.append((age, age * 0.38, 0.34, 0.0))
    make_sequence(root, body_tex, cap_tex, walk_specs, out/'Boomshroom-Front-Walk.gif',
                  'TRUE FRONT · CHERRY-FAMILY WALK + BOOMSHROOM CAP', fps)

    # Four-angle source QA sheet to make camera/orientation unambiguous.
    angles = [('FRONT',0),('3/4',-28),('SIDE',-90),('BACK',-180)]
    cell_w, cell_h = 420, 600
    sheet = Image.new('RGB', (cell_w*4, cell_h+72), (13,16,21))
    sd = ImageDraw.Draw(sheet)
    sd.text((22,16),'Boomshroom 1.5.2 · actual-source multi-angle geometry QA',font=font(25),fill=(246,248,250))
    sd.text((24,48),'Front is yaw 0°. Same model/texture/cap, fixed representative idle checkpoint.',font=font(12,False),fill=(170,180,196))
    for idx,(name,yaw) in enumerate(angles):
        specs=[(neutral_age,0.0,0.0,0.0)]
        view=compute_view(root,body_tex,cap_tex,specs,(390,510),yaw,0)
        m=render_model(root,body_tex,cap_tex,neutral_age,0.0,0.0,0.0,view,(390,510),yaw,0)
        panel=grid_bg((cell_w,cell_h)); pd=ImageDraw.Draw(panel,'RGBA')
        pd.text((14,12),name,font=font(18),fill=(245,247,250,255))
        panel.alpha_composite(m,((cell_w-m.width)//2,54))
        sheet.paste(panel.convert('RGB'),(idx*cell_w,72))
    sheet.save(out/'Boomshroom-Multi-Angle-QA.png',quality=95)

    (out/'README.md').write_text(
        '# Boomshroom deterministic visual QA\n\n'
        'These previews are rasterized from the actual Bloom & Boom 1.5.2 Java model layer, '
        'Boomshroom texture atlas, exact Creeper Overhaul-derived cap geometry/UVs, and the exact '
        'Boomshroom cap-tip formulas in the runtime source. No image generation is used.\n\n'
        '- `Boomshroom-True-Front.png`: yaw 0°, pitch 0°\n'
        '- `Boomshroom-Front-Idle-Blink.gif`: source idle/blink + cap secondary motion\n'
        '- `Boomshroom-Front-Cap-Tip-Greeting.gif`: exact 30-tick cap-tip sequence\n'
        '- `Boomshroom-Front-Walk.gif`: Cherry-family source walk with Boomshroom cap\n'
        '- `Boomshroom-Multi-Angle-QA.png`: front / 3-quarter / side / back orientation proof\n',
        encoding='utf-8')
    print(out)

if __name__ == '__main__':
    main()
