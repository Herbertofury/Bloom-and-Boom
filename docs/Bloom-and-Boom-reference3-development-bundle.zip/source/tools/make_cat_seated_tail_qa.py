#!/usr/bin/env python3
from __future__ import annotations
import math, sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
SRC = HERE.parent
OUT = Path('/mnt/data/Creeperella-1.4.9-Cat-Seated-Tail-QA')
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(HERE))
import render_mobs_visual_qa as r

BG=(8,13,24,255)
FRAMES=12
try:
    FONT = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 15)
    SMALL = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 12)
except Exception:
    FONT = ImageFont.load_default(); SMALL = ImageFont.load_default()

def P(root,*path): return r.find(root,*path)

def render_current(root,tex,tw,th,yaw=-28,pitch=10,size=(300,340),label=''):
    polys,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=pitch,subdivide=False)
    mins=pts[:,:2].min(0); maxs=pts[:,:2].max(0); center=(mins+maxs)/2; span=maxs-mins
    w,h=size; scale=min((w-24)/max(span[0],1),(h-24)/max(span[1],1))
    polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=pitch,subdivide=True)
    canvas=np.zeros((h,w,4),dtype=np.uint8); canvas[:]=np.array(BG,dtype=np.uint8)
    zbuf=np.full((h,w),np.inf,dtype=float)
    for _,q,rgba in polys:
        pp=np.array([[w/2+(v[0]-center[0])*scale,h/2-(v[1]-center[1])*scale,v[2]] for v in q],dtype=float)
        r._raster_triangle(canvas,zbuf,pp[[0,1,2]],rgba)
        r._raster_triangle(canvas,zbuf,pp[[0,2,3]],rgba)
    im=Image.fromarray(canvas,'RGBA')
    if label:
        d=ImageDraw.Draw(im)
        bb=d.textbbox((0,0),label,font=SMALL); twd=bb[2]-bb[0]; x=(w-twd)//2
        d.rounded_rectangle((x-7,8,x+twd+7,29),radius=7,fill=(15,22,38,220),outline=(105,125,165,255),width=1)
        d.text((x,11),label,font=SMALL,fill=(241,244,255,255))
    return im

def blink(root,t):
    b=max(0.0,min(1.0,math.exp(-((t-.20)/.055)**2)+math.exp(-((t-.78)/.055)**2)))
    for n in ('eye1','eye2'):
        e=P(root,'body','waist','Body','Upperbody','head',n)
        if e: e.sy=max(.15,1.0-b*.9); e.y += b*.18

def seated_tail(root,t,wag=False):
    # Mirrors the production 1.4.9 sit-tail solve: zero root yaw/roll, trailing rearward.
    tail=P(root,'body','waist','Body','tail'); tail2=P(root,'body','waist','Body','tail','tail2')
    tail.z=tail.base[2]+.20
    tail.rx=.35; tail.ry=0.0; tail.rz=0.0
    tail2.rx=.75; tail2.ry=0.0; tail2.rz=0.0
    if wag:
        wave=math.sin(t*math.tau)
        # Tiny lateral movement only after the rearward solve; root stays close to sagittal.
        tail.ry = wave*.045
        tail2.ry = math.sin(t*math.tau-.50)*.15

def loaf_pose(root,t):
    core=P(root,'body','waist','Body'); upper=P(root,'body','waist','Body','Upperbody'); head=P(root,'body','waist','Body','Upperbody','head')
    breathe=math.sin(t*math.tau)*.018
    core.y+=3.2; core.z+=1.0; core.rx+=.10+breathe*.6; core.sy=.88
    upper.y+=3.2; upper.z+=.2; upper.rx-=.28-breathe*.4; upper.sy=.92
    head.y+=2.15; head.z-=.15; head.rx+=.18+breathe*.35
    for side in ('left','right'):
        s=1 if side=='left' else -1
        leg=P(root,'body','waist',f'{side}Leg'); low=P(root,'body','waist',f'{side}Leg',f'{side.lower()}legsub2'); foot=P(root,'body','waist',f'{side}Leg',f'{side.lower()}legsub2',f'{side.lower()}foot3')
        leg.x=.58*s; leg.y+=1.55; leg.z+=1.85; leg.rx=-1.28; leg.ry=-.06*s; low.rx=2.05; foot.rx=-1.05
        leg=P(root,'body','waist',f'{side}Legback'); low=P(root,'body','waist',f'{side}Legback',f'{side.lower()}legsub'); foot=P(root,'body','waist',f'{side}Legback',f'{side.lower()}legsub',f'{side.lower()}foot2')
        leg.x=.82*s; leg.y+=1.95; leg.z+=.95; leg.rx=.70; leg.ry=-.03*s; low.rx=1.82; foot.rx=-1.12
    seated_tail(root,t,False)
    blink(root,t)

def side_lie_pose(root,t):
    waist=P(root,'body','waist'); core=P(root,'body','waist','Body'); upper=P(root,'body','waist','Body','Upperbody'); head=P(root,'body','waist','Body','Upperbody','head')
    breathe=math.sin(t*math.tau)*.018
    waist.rz=-1.10; waist.x-=1.0; waist.y+=1.35
    core.rx+=.06+breathe*.5; core.sy=.94
    upper.rx-=.12-breathe*.28; upper.ry+=.05
    head.rx+=.13+breathe*.18; head.ry+=.34+.06*math.sin(t*math.tau); head.rz-=.12; head.y+=.45
    seated_tail(root,t,False)
    blink(root,t)

def make_frames(mode,yaw,label):
    frames=[]
    for i in range(FRAMES):
        t=i/FRAMES
        root,tex,tw,th=r.load_variant('cat')
        if mode in ('sit','wag'):
            r.apply_anim(root,'cat',40+i*.7,0,0,0,0,cat_motion='sit')
            # Renderer already applies the production seated tail; only add bounded wag if requested.
            if mode=='wag': seated_tail(root,t,True)
        else:
            r.apply_anim(root,'cat',40+i*.7,0,0,0,0,cat_motion='idle')
            (loaf_pose if mode=='loaf' else side_lie_pose)(root,t)
        frames.append(render_current(root,tex,tw,th,yaw=yaw,label=label))
    return frames

def save_gif(name,mode,yaw,label):
    frames=make_frames(mode,yaw,label)
    p=OUT/name
    frames[0].save(p,save_all=True,append_images=frames[1:],duration=115,loop=0,disposal=2)
    return p

outputs=[]
for mode,title in [('sit','SIT'),('wag','TAIL WAG SIT'),('loaf','LOAF'),('side_lie','SIDE-LIE')]:
    outputs.append(save_gif(f'Cat-Creeper-1.4.9-{title.replace(" ","-")}-3Q.gif',mode,-28,f'{title} · 3Q'))
    outputs.append(save_gif(f'Cat-Creeper-1.4.9-{title.replace(" ","-")}-Side.gif',mode,-90,f'{title} · SIDE'))

# Four-angle static gate for direction correctness.
yaws=[('FRONT',0),('3Q',-28),('SIDE',-90),('BACK',180)]
states=[('SIT','sit'),('TAIL WAG','wag'),('LOAF','loaf'),('SIDE-LIE','side_lie')]
sheet=Image.new('RGBA',(4*275,4*285),BG)
d=ImageDraw.Draw(sheet)
for row,(title,mode) in enumerate(states):
    for col,(view,yaw) in enumerate(yaws):
        root,tex,tw,th=r.load_variant('cat')
        if mode in ('sit','wag'):
            r.apply_anim(root,'cat',43.0,0,0,0,0,cat_motion='sit')
            if mode=='wag': seated_tail(root,.25,True)
        else:
            r.apply_anim(root,'cat',43.0,0,0,0,0,cat_motion='idle')
            (loaf_pose if mode=='loaf' else side_lie_pose)(root,.25)
        im=render_current(root,tex,tw,th,yaw=yaw,size=(275,285),label=f'{title} · {view}')
        sheet.alpha_composite(im,(col*275,row*285))
sheet_path=OUT/'Cat-Creeper-1.4.9-Seated-Tail-Direction-Multiangle.png'
sheet.save(sheet_path); outputs.append(sheet_path)

(OUT/'README.md').write_text('''# Creeperella 1.4.9 seated-tail QA\n\nDeterministic renders from the real Cat Creeper model/texture and project animation renderer. No generative image model was used.\n\nThe 1.4.9 seated tail solve keeps the tail root in the sagittal plane: root yaw/roll are zero in static sit, the chain leaves the rump rearward/downward, and the distal segment eases toward a rear trail. The tail-wag preview adds only bounded yaw after this rearward solve.\n''')
print('\n'.join(str(p) for p in outputs))
