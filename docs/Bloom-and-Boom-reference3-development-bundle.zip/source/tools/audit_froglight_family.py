#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def need(path,text=None):
    p=ROOT/path
    ok=p.exists() and (text is None or text in p.read_text(errors="ignore"))
    checks.append((str(path),ok))
for name in ("mariglow","verdalia","nacrella"):
    need(Path(f"src/main/resources/assets/creeperella/textures/entity/{name}_creeper.png"))
    need(Path(f"src/main/resources/assets/creeperella/textures/entity/{name}_creeper_e.png"))
    need(Path(f"src/main/resources/assets/creeperella/textures/entity/{name}_accessories.png"))
    need(Path(f"src/main/resources/assets/creeperella/textures/entity/{name}_accessories_e.png"))
    need(Path(f"src/main/resources/assets/creeperella/models/item/{name}_creeper_spawn_egg.json"))
common=(ROOT/"src/main/java/dev/herbertofury/creeperella/event/CommonEvents.java").read_text()
for frog,result in (("TEMPERATE","MARIGLOW"),("COLD","VERDALIA")):
    checks.append((f"frog {frog}->{result}", frog in common and result in common))
checks.append(("frog WARM/default->NACRELLA", "NACRELLA_CREEPER" in common and "CreeperellaKind.NACRELLA" in common))
modbus=(ROOT/"src/main/java/dev/herbertofury/creeperella/event/ModBusEvents.java").read_text()
for n in ("MARIGLOW_CREEPER","VERDALIA_CREEPER","NACRELLA_CREEPER"):
    checks.append((f"natural spawn disabled {n}", n in modbus and "-> false" in modbus))
# Protect stable Boomshroom from this family pass.
boom=ROOT/"src/main/resources/assets/creeperella/textures/entity/boomshroom_creeper.png"
h=hashlib.sha256(boom.read_bytes()).hexdigest()
checks.append(("protected Boomshroom texture", h=="37b72d8e1a11569bc79b743c5c77f90dc539ba9dd251f898de62a580bd5b9dd0"))
for label,ok in checks: print(("PASS" if ok else "FAIL"),label)
if not all(ok for _,ok in checks): sys.exit(1)

# Reference color identity: Pearlescent Nacrella must not use the yellow/green vanilla GLOW ambient particle.
entity_text = (ROOT / "src/main/java/dev/herbertofury/creeperella/entity/CreeperellaEntity.java").read_text()
checks.append(("NACRELLA ambient particle", "case NACRELLA -> this.random.nextBoolean() ? ParticleTypes.ENCHANT : ParticleTypes.END_ROD;" in entity_text))
for label,ok in checks[-1:]: print(("PASS" if ok else "FAIL"),label)
if not checks[-1][1]: sys.exit(1)
print(f"FROGLIGHT_FAMILY_AUDIT PASS checks={len(checks)} boomshroom_sha256={h}")
