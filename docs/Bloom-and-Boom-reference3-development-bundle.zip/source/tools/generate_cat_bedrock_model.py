#!/usr/bin/env python3
"""Generate the Cat Creeper Java LayerDefinition directly from the supplied Bedrock geometry.

Coordinate conversion is the exact composition of Blockbench's Bedrock importer and its
Minecraft Java 1.17+ entity exporter with the Y-flip used by this rig:
- bone PartPose offsets: X/Z keep Bedrock sign; Y is inverted (root Y is additionally +24)
- bone rotations: all three axes keep the authored Bedrock signs after the two codec transforms cancel
- cube origins: absolute Bedrock coordinates become bone-local Java coordinates with Y inverted
- bone-level `mirror` is inherited by cubes unless a cube explicitly overrides it

This matters for the Cat tail: the old 1.4.0 hand port incorrectly negated X/Z rotations, which
rotated the tail through the torso and produced the visible protruding block.
"""
from __future__ import annotations

import json
import math
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE_GEO = ROOT / "reference-assets/cat/creeper.geo.json"
CHARGE_GEO = ROOT / "reference-assets/cat/creeper_charged.geo.json"
OUT = ROOT / "src/main/java/dev/herbertofury/creeperella/client/CatCreeperModelLayers.java"


def java_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_]", "_", name)


def ff(v: float) -> str:
    if abs(v) < 0.0000005:
        v = 0.0
    s = f"{v:.6f}".rstrip("0").rstrip(".")
    if "." not in s:
        s += ".0"
    return s + "F"


def rad(deg: float) -> float:
    return math.radians(deg)


def load_geo(path: Path):
    raw = json.loads(path.read_text(encoding="utf-8"))
    geo = raw["minecraft:geometry"][0]
    return geo["description"], geo["bones"]


def generate_method(method: str, path: Path) -> list[str]:
    desc, bones = load_geo(path)
    tw = int(desc["texture_width"])
    th = int(desc["texture_height"])
    by_name = {b["name"]: b for b in bones}
    pivots = {b["name"]: b.get("pivot", [0, 0, 0]) for b in bones}

    lines = [f"    public static LayerDefinition {method}() {{"]
    lines += [
        "        MeshDefinition mesh = new MeshDefinition();",
        "        PartDefinition root = mesh.getRoot();",
        "        // CreeperModel requires these vanilla top-level children. The authored Bedrock rig lives under body.",
        '        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 6.0F, 0.0F));',
        '        PartDefinition vanillaBody = root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(0.0F, 24.0F, 0.0F));',
        '        root.addOrReplaceChild("right_hind_leg", CubeListBuilder.create(), PartPose.offset(-2.0F, 18.0F, 4.0F));',
        '        root.addOrReplaceChild("left_hind_leg", CubeListBuilder.create(), PartPose.offset(2.0F, 18.0F, 4.0F));',
        '        root.addOrReplaceChild("right_front_leg", CubeListBuilder.create(), PartPose.offset(-2.0F, 18.0F, -4.0F));',
        '        root.addOrReplaceChild("left_front_leg", CubeListBuilder.create(), PartPose.offset(2.0F, 18.0F, -4.0F));',
    ]

    part_vars: dict[str, str] = {}
    for bone in bones:
        name = bone["name"]
        var = "part_" + java_name(name)
        bvar = "cubes_" + java_name(name)
        part_vars[name] = var
        lines.append(f"        CubeListBuilder {bvar} = CubeListBuilder.create();")
        bone_mirror = bool(bone.get("mirror", False))
        pivot = bone.get("pivot", [0, 0, 0])
        for cube in bone.get("cubes", []):
            origin = cube["origin"]
            size = cube["size"]
            uv = cube["uv"]
            inflate = float(cube.get("inflate", 0.0))
            mirror = bool(cube.get("mirror", bone_mirror))
            x = float(origin[0]) - float(pivot[0])
            y = -(float(origin[1]) + float(size[1]) - float(pivot[1]))
            z = float(origin[2]) - float(pivot[2])
            chain = f"{bvar}.texOffs({int(uv[0])}, {int(uv[1])}).mirror({str(mirror).lower()})"
            lines.append(
                "        " + chain + ".addBox(" +
                ", ".join([
                    ff(x), ff(y), ff(z), ff(float(size[0])), ff(float(size[1])), ff(float(size[2]))
                ]) + f", new CubeDeformation({ff(inflate)}));"
            )

        parent_name = bone.get("parent")
        if parent_name:
            parent = part_vars[parent_name]
            pp = pivots[parent_name]
            dx = float(pivot[0]) - float(pp[0])
            dy = -(float(pivot[1]) - float(pp[1]))
            dz = float(pivot[2]) - float(pp[2])
        else:
            parent = "vanillaBody"
            dx = float(pivot[0])
            dy = -float(pivot[1])
            dz = float(pivot[2])

        rot = bone.get("rotation", [0, 0, 0])
        # Blockbench Bedrock import negates X/Y, then Java export negates X/Y again; Z is
        # unchanged by both codecs. Net Bedrock -> Java rotation signs are therefore identical.
        rx = rad(float(rot[0]))
        ry = rad(float(rot[1]))
        rz = rad(float(rot[2]))
        lines.append(
            f'        PartDefinition {var} = {parent}.addOrReplaceChild("{name}", {bvar}, '
            f"PartPose.offsetAndRotation({ff(dx)}, {ff(dy)}, {ff(dz)}, {ff(rx)}, {ff(ry)}, {ff(rz)}));"
        )
    lines += [f"        return LayerDefinition.create(mesh, {tw}, {th});", "    }"]
    return lines


def main() -> None:
    if not CHARGE_GEO.exists():
        raise SystemExit(f"Missing source geometry: {CHARGE_GEO}")
    out = [
        "package dev.herbertofury.creeperella.client;",
        "",
        "import net.minecraft.client.model.geom.PartPose;",
        "import net.minecraft.client.model.geom.builders.CubeDeformation;",
        "import net.minecraft.client.model.geom.builders.CubeListBuilder;",
        "import net.minecraft.client.model.geom.builders.LayerDefinition;",
        "import net.minecraft.client.model.geom.builders.MeshDefinition;",
        "import net.minecraft.client.model.geom.builders.PartDefinition;",
        "",
        "/**",
        " * Deterministically generated from the original user-supplied Bedrock FemaleCreeper.mcpack geometry.",
        " * Do not hand-edit: run tools/generate_cat_bedrock_model.py after replacing the reference geometry.",
        " */",
        "public final class CatCreeperModelLayers {",
        "    private CatCreeperModelLayers() {}",
        "",
    ]
    out.extend(generate_method("createCatLayer", BASE_GEO))
    out.append("")
    out.extend(generate_method("createCatChargeLayer", CHARGE_GEO))
    out.extend(["}", ""])
    OUT.write_text("\n".join(out), encoding="utf-8")
    print(f"Generated {OUT}")


if __name__ == "__main__":
    main()
