#!/usr/bin/env python3
"""Idempotent UV finish from preserved inputs; no image generation or rig changes."""
from pathlib import Path
from PIL import Image
import math
import argparse
import hashlib
import json

R=Path(__file__).resolve().parents[1]
S=R/'reference-assets/froglight/reference3-material-inputs'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir',type=Path,default=R/'src/main/resources/assets/creeperella/textures/entity')
T=parser.parse_args().output_dir
T.mkdir(parents=True,exist_ok=True)
for name,expected in json.loads((S/'SHA256SUMS.json').read_text()).items():
    if hashlib.sha256((S/name).read_bytes()).hexdigest()!=expected:
        raise ValueError(f'Material input changed: {name}')
CUBES=[(0,0,8,8,8,False),(0,16,8,8,8,False),(32,0,6,8,4,False),(32,12,6,8,4,False),(52,0,8,4,4,False),(52,8,8,4,4,False),(76,0,8,4,4,False),(76,8,8,4,4,False)]+[(u,52,4,8,4,True) for u in range(0,128,16)]
for name,tint,leaf in [('nacrella',(249,236,255),(181,144,215)),('verdalia',(240,255,216),(119,179,95)),('mariglow',(255,245,200),(164,170,81))]:
    body=Image.open(S/f'{name}_creeper.png').convert('RGBA')
    glow=Image.open(S/f'{name}_creeper_e.png').convert('RGBA')
    scale=body.width//128
    for u,v,w,h,d,foot in CUBES:
        for fx,fy,fw,fh in [(u,v+d,d,h),(u+d,v+d,w,h),(u+d+w,v+d,d,h),(u+2*d+w,v+d,w,h)]:
            for y in range(fh*scale):
                for x in range(fw*scale):
                    px,py=fx*scale+x,fy*scale+y
                    if px>=body.width or py>=body.height: continue
                    p=body.getpixel((px,py));ux,uy=px//scale,py//scale
                    if not p[3] or (26<=ux<29 and 20<=uy<25) or (8<=ux<16 and 8<=uy<16 and max(p[:3])<82): continue
                    nx=(x+.5)/(fw*scale);ny=(y+.5)/(fh*scale)
                    center=math.exp(-((nx-.52)/.28)**2-((ny-.5)/.6)**2)
                    if foot: center*=max(0,min(1,(.84-ny)/.14))
                    # Broad luminous face centers, retaining the original dark foot tips and pixel grain.
                    rgb=tuple(round(p[k]*(1-.42*center)+tint[k]*.42*center) for k in range(3))
                    body.putpixel((px,py),(*rgb,p[3]))
                    glow.putpixel((px,py),(*(min(255-rgb[k],round(13+50*center)) for k in range(3)),p[3]))
    body.save(T/f'{name}_creeper.png');glow.save(T/f'{name}_creeper_e.png')
    skin=Image.open(S/f'{name}_face_skin.png').convert('RGBA')
    for y in range(skin.height):
        for x in range(skin.width):
            p=skin.getpixel((x,y))
            skin.putpixel((x,y),(*(round(p[k]*.80+tint[k]*.20) for k in range(3)),p[3]))
    skin.save(T/f'{name}_face_skin.png')
    acc=Image.open(S/f'{name}_accessories.png').convert('RGBA');s=acc.width//64
    for y in range(acc.height):
        for x in range(32*s,48*s):
            grain=((x//4+y//5)%5-2)*3
            acc.putpixel((x,y),(*(max(0,min(255,c+grain)) for c in leaf),255))
    acc.save(T/f'{name}_accessories.png')
    print(name,'luminous center panels and reference-tinted foliage finished')
