#!/usr/bin/env python3
import sys, math
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np
sys.path.insert(0,'/mnt/data/creeperella1415_work/tools')
import render_mobs_visual_qa as r
import trial_rest_ik as t
OUT=Path('/mnt/data/Creeperella-1.4.15-Tail-Trials');OUT.mkdir(parents=True,exist_ok=True)
BG=(8,13,24,255);W,H=300,300;BASE=255
try:F=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
except:F=ImageFont.load_default()
G=t.G

def settail(root,p):
 a=r.find(root,'body','waist','Body','tail');b=r.find(root,'body','waist','Body','tail','tail2');rx,ry,rz,tx,ty,tz,z=p;a.rx=rx;a.ry=ry;a.rz=rz;a.z=a.base[2]+z;b.rx=tx;b.ry=ty;b.rz=tz

def render(root,tex,tw,th,yaw,label):
 _,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=False);mnx,mxx=pts[:,0].min(),pts[:,0].max();mny,mxy=pts[:,1].min(),pts[:,1].max();sc=min((W-20)/max(mxx-mnx,1),(BASE-36)/max(mxy-G,1));xo=W/2-(mnx+mxx)/2*sc;yo=BASE+G*sc
 can=np.zeros((H,W,4),dtype=np.uint8);can[:]=np.array(BG);im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);d.line((10,BASE,W-10,BASE),fill=(110,145,200,255),width=2);can=np.array(im);z=np.full((H,W),np.inf);polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=True)
 for _,q,rgba in polys:
  pp=np.array([[xo+p[0]*sc,yo-p[1]*sc,p[2]] for p in q]);r._raster_triangle(can,z,pp[[0,1,2]],rgba);r._raster_triangle(can,z,pp[[0,2,3]],rgba)
 im=Image.fromarray(can,'RGBA');ImageDraw.Draw(im).text((8,8),label,font=F,fill=(240,245,255));return im
configs={
'SIT':(lambda root:t.pose_sit(root,3),[(.36,.08,0,.72,.18,0,.12),(.42,.30,.04,.78,.45,.08,.10),(.48,.42,.05,.90,.62,.10,.08),(.40,.52,.04,.82,.75,.12,.08)]),
'LOAF':(lambda root:t.pose_loaf(root,1),[(.42,.12,0,.92,.24,0,.04),(.46,.34,.05,.96,.52,.10,.04),(.52,.46,.06,1.02,.70,.12,.02),(.48,.58,.06,1.08,.82,.12,.02)]),
'SPRAWL':(lambda root:t.pose_sprawl(root,1),[(.20,0,0,.45,0,0,.20),(.24,.12,.02,.50,.22,.06,.18),(.28,.20,.02,.56,.34,.08,.16),(.22,-.15,-.02,.48,-.28,-.06,.18)])}
for name,(pose,ps) in configs.items():
 sheet=Image.new('RGBA',(2*W,4*H),BG)
 for i,p in enumerate(ps):
  for c,(yaw,vn) in enumerate([(-28,'3Q'),(-90,'SIDE')]):
   root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',42,0,0,0,0,cat_motion='sit');pose(root);settail(root,p);sheet.alpha_composite(render(root,tex,tw,th,yaw,f'{name} tail {i+1} · {vn}'),(c*W,i*H))
 out=OUT/f'{name}-tail-trials.png';sheet.save(out);print(out)
