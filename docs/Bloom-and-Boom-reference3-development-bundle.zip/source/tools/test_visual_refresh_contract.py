#!/usr/bin/env python3
"""Reference2 regression checks; static contracts, not a substitute for in-game QA."""
from pathlib import Path
import hashlib,json
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
fixture=json.loads((ROOT/'tools/fixtures/visual1-protected-assets.json').read_text())
for path,digest in fixture.items():
 assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest, f'Protected asset changed: {path}'
for name in ('cinderella','mariglow','verdalia','nacrella'):
 texture=ROOT/f'src/main/resources/assets/creeperella/textures/entity/{name}_creeper.png'
 im=Image.open(texture).convert('RGBA'); glow=Image.open(texture.with_name(texture.stem+'_e.png')).convert('RGBA')
 scale=1 if name=='cinderella' else 4
 assert im.size==glow.size==(128*scale,64*scale), name
 assert sum(p[3]>0 for p in im.getdata())==2182*scale*scale, f'{name}: UV coverage drift'
 if scale==4:
  baseline=Image.open(ROOT/f'reference-assets/froglight/polish23-body-source/{name}_creeper.png').convert('RGBA')
  assert im.getchannel('A').tobytes()==baseline.getchannel('A').resize(im.size,Image.Resampling.NEAREST).tobytes(), f'{name}: normalized UV alpha changed'
 assert all(p[:3]==(0,0,0) for p in glow.getdata() if p[3]==0), f'{name}: additive glow leaks RGB'
 assert all(a[3]>0 or g[3]==0 for a,g in zip(im.getdata(),glow.getdata())), f'{name}: glow outside mesh UV'
model=(ROOT/'src/main/java/dev/herbertofury/creeperella/client/CreeperellaModel.java').read_text()
start=model.index('private void animateCatSource');end=model.index('private static void animateCatLegIk',start)
expected=(ROOT/'tools/fixtures/visual1-cat-animation.sha256').read_text().strip()
assert hashlib.sha256(model[start:end].encode()).hexdigest()==expected, 'Cat animation changed during visual pass'
print(f'PASS: {len(fixture)} protected assets; Cat animation unchanged; four UV atlases and additive glow masks valid')
