#!/usr/bin/env python3
"""Deterministic Cherry Creeper vs Boomshroom visual QA.

Renders only from real project Java model data, textures, and runtime animation formulas.
No image generation is involved.
"""
from __future__ import annotations
import math, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from make_boomshroom_visual_qa import (
    parse_layer, compute_view as boom_compute_view, render_model as render_boom,
    BODY_JAVA, BODY_TEX, CAP_TEX,
)
from render_mobs_visual_qa import load_variant, compute_view as cherry_compute_view, render_frame as render_cherry

VERSION = '1.5.2'
MODEL_SIZE = (440, 520)
CELL_SIZE = (500, 620)
BG = (18, 21, 27)
PANEL = (29, 33, 41)


def font(size: int, bold: bool = True):
    path = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    try:
        return ImageFont.truetype(path, size)
    except OSError:
        return ImageFont.load_default()


def panel(subject: Image.Image, title: str, subtitle: str) -> Image.Image:
    im = Image.new('RGB', CELL_SIZE, BG)
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((10, 10, CELL_SIZE[0]-10, CELL_SIZE[1]-10), radius=16,
                        fill=PANEL, outline=(84, 92, 108), width=2)
    d.text((24, 22), title, font=font(23), fill=(246,248,250))
    d.text((25, 55), subtitle, font=font(12, False), fill=(173,183,199))
    d.text((25, 76), 'ACTUAL SOURCE RENDER · NO IMAGE GENERATION', font=font(10, False), fill=(139,205,149))
    x = (CELL_SIZE[0] - subject.width) // 2
    y = 94 + (CELL_SIZE[1] - 108 - subject.height) // 2
    im.paste(subject, (x, y), subject)
    return im


def pair(cherry_im: Image.Image, boom_im: Image.Image, label: str) -> Image.Image:
    left = panel(cherry_im, 'CHERRY CREEPER', label)
    right = panel(boom_im, 'BOOMSHROOM', label)
    out = Image.new('RGB', (CELL_SIZE[0]*2, CELL_SIZE[1]), BG)
    out.paste(left, (0,0)); out.paste(right, (CELL_SIZE[0],0))
    return out


def save_gif(frames, path: Path, fps: int = 6):
    frames[0].save(path, save_all=True, append_images=frames[1:], loop=0,
                   duration=int(round(1000/fps)), disposal=2, optimize=True)


def views_for(boom_root, boom_tex, cap_tex, cherry_root, cherry_tex, specs, yaw, pitch):
    bview = boom_compute_view(boom_root, boom_tex, cap_tex, specs, MODEL_SIZE, yaw, pitch)
    cspec = [(age, ls, amount, 0.0, 0.0) for age, ls, amount, _greet in specs]
    cview = cherry_compute_view(cherry_root, cherry_tex, 64, 64, 'cherry', cspec,
                                size=MODEL_SIZE, yaw=yaw, pitch=pitch)
    shared_scale = min(bview[1], cview[1])
    return (bview[0], shared_scale), (cview[0], shared_scale)


def render_pair_frame(boom_root, boom_tex, cap_tex, cherry_root, cherry_tex,
                      spec, bview, cview, label, yaw=0.0, pitch=0.0):
    age, ls, amount, greet = spec
    b = render_boom(boom_root, boom_tex, cap_tex, age, ls, amount, greet,
                    bview, MODEL_SIZE, yaw, pitch)
    c = render_cherry(cherry_root, cherry_tex, 64, 64, 'cherry', age, ls, amount,
                      cview, size=MODEL_SIZE, yaw=yaw, pitch=pitch)
    return pair(c, b, label)


def main():
    out = Path(sys.argv[1] if len(sys.argv) > 1 else '/mnt/data/Boomshroom-1.5.2-Visual-QA')
    out.mkdir(parents=True, exist_ok=True)

    boom_root, tw, th = parse_layer(BODY_JAVA, 'createCherryLayer')
    if (tw, th) != (64,64): raise RuntimeError((tw,th))
    boom_tex = Image.open(BODY_TEX).convert('RGBA')
    cap_tex = Image.open(CAP_TEX).convert('RGBA')
    cherry_root, cherry_tex, ctw, cth = load_variant('cherry')
    if (ctw,cth)!=(64,64): raise RuntimeError((ctw,cth))

    neutral_age = 7.0 * math.pi / 2.0
    neutral = [(neutral_age,0.0,0.0,0.0)]
    bv, cv = views_for(boom_root,boom_tex,cap_tex,cherry_root,cherry_tex,neutral,0,0)
    render_pair_frame(boom_root,boom_tex,cap_tex,cherry_root,cherry_tex,
                      neutral[0],bv,cv,'TRUE FRONT · YAW 0° · PITCH 0°',0,0).save(
                      out/'Cherry-vs-Boomshroom-True-Front.png', optimize=True)

    # Four-angle parity sheet; same scale within each Cherry/Boomshroom pair.
    angles=[('FRONT',0),('3/4',-28),('SIDE',-90),('BACK',-180)]
    rows=[]
    for name,yaw in angles:
        bv,cv=views_for(boom_root,boom_tex,cap_tex,cherry_root,cherry_tex,neutral,yaw,0)
        rows.append(render_pair_frame(boom_root,boom_tex,cap_tex,cherry_root,cherry_tex,
                                     neutral[0],bv,cv,f'{name} · SAME SOURCE RIG SCALE',yaw,0))
    sheet=Image.new('RGB',(CELL_SIZE[0]*2,CELL_SIZE[1]*4),BG)
    for i,r in enumerate(rows): sheet.paste(r,(0,i*CELL_SIZE[1]))
    sheet.save(out/'Cherry-vs-Boomshroom-Multi-Angle.png', optimize=True)

    fps=6
    # Idle/blink comparison.
    idle=[]
    for i in range(18):
        age=(i/fps)*20.0
        idle.append((age,0.0,0.0,0.0))
    bv,cv=views_for(boom_root,boom_tex,cap_tex,cherry_root,cherry_tex,idle,0,0)
    frames=[render_pair_frame(boom_root,boom_tex,cap_tex,cherry_root,cherry_tex,s,bv,cv,
                              'TRUE FRONT · IDLE + BLINK',0,0) for s in idle]
    save_gif(frames,out/'Cherry-vs-Boomshroom-Front-Idle.gif',fps)

    # Walk comparison.
    walk=[]
    for i in range(18):
        age=(i/fps)*20.0
        walk.append((age,age*0.38,0.34,0.0))
    bv,cv=views_for(boom_root,boom_tex,cap_tex,cherry_root,cherry_tex,walk,0,0)
    frames=[render_pair_frame(boom_root,boom_tex,cap_tex,cherry_root,cherry_tex,s,bv,cv,
                              'TRUE FRONT · SHARED CHERRY-FAMILY WALK',0,0) for s in walk]
    save_gif(frames,out/'Cherry-vs-Boomshroom-Front-Walk.gif',fps)

    # Boomshroom greeting, with Cherry kept in its normal idle so the body/face comparison stays visible.
    greeting=[]
    for i in range(15):
        age=(i/fps)*20.0
        greet=min(age,30.0)/30.0 if age<=30.0 else 0.0
        greeting.append((age,0.0,0.0,greet))
    bv,cv=views_for(boom_root,boom_tex,cap_tex,cherry_root,cherry_tex,greeting,0,0)
    frames=[render_pair_frame(boom_root,boom_tex,cap_tex,cherry_root,cherry_tex,s,bv,cv,
                              'CHERRY IDLE · BOOMSHROOM CAP-TIP GREETING',0,0) for s in greeting]
    save_gif(frames,out/'Cherry-vs-Boomshroom-Cap-Tip.gif',fps)

    (out/'README.md').write_text(
        f'# Cherry Creeper vs Boomshroom {VERSION} deterministic QA\n\n'
        'All previews are rendered from the actual Java model hierarchy, protected Cherry texture, '
        'Boomshroom body texture, exact Boomshroom cap layer, and runtime animation formulas. '
        'No image generation is used.\n\n'
        '- `Cherry-vs-Boomshroom-True-Front.png` — exact yaw 0° comparison\n'
        '- `Cherry-vs-Boomshroom-Multi-Angle.png` — front / 3-quarter / side / back\n'
        '- `Cherry-vs-Boomshroom-Front-Idle.gif` — synchronized idle/blink\n'
        '- `Cherry-vs-Boomshroom-Front-Walk.gif` — synchronized Cherry-family walk\n'
        '- `Cherry-vs-Boomshroom-Cap-Tip.gif` — Cherry idle beside Boomshroom greeting\n',
        encoding='utf-8')
    print(out)

if __name__ == '__main__':
    main()
