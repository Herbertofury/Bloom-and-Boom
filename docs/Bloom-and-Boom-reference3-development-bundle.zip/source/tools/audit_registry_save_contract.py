#!/usr/bin/env python3
"""Offline regression audit for Creeperella registry/save compatibility.

Checks that registered content has stable identifiers and that every item/block/entity
JSON reference stays inside the creeperella namespace. This is intentionally build-free.
"""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "src" / "main" / "resources"

failures = []

# Registry-sensitive data locations.
for rel in [
    "data/creeperella/recipes",
    "data/creeperella/loot_tables",
    "data/creeperella/tags",
    "assets/creeperella",
]:
    path = RES / rel
    if not path.exists():
        failures.append(f"missing expected content tree: {rel}")

ids = []
for path in RES.rglob("*.json"):
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        continue
    for match in re.findall(r"\"([a-z0-9_]+:[a-z0-9_/.-]+)\"", text):
        ids.append((path, match))
        if not match.startswith(("minecraft:", "creeperella:", "forge:")):
            failures.append(f"foreign namespace reference {match} in {path.relative_to(ROOT)}")

# Save compatibility guard: namespaced ids should not be empty or malformed.
for path, ident in ids:
    namespace, value = ident.split(":", 1)
    if not value or value.startswith("/"):
        failures.append(f"invalid namespaced id {ident} in {path.relative_to(ROOT)}")

if failures:
    print("FAIL")
    for failure in failures:
        print(f"- {failure}")
    sys.exit(1)

print(f"PASS: registry/save contract audit scanned {len(ids)} namespaced references")
