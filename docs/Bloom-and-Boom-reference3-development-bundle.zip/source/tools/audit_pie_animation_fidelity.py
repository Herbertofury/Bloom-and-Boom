#!/usr/bin/env python3
"""Deterministic parity gate for Pie's Female/Bunny/Bee CEM animation port."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIE = ROOT / "reference-assets" / "pie"
MODEL = ROOT / "src/main/java/dev/herbertofury/creeperella/client/CreeperellaModel.java"

EXPECTED_HASHES = {
    "creeper.jem": "b0decaf8772e67e16ab9d2f9e594665ad65935008e01e2a3e408fe6c8745340a",
    "creeper2.jem": "3cf7459c5886825c9ff8c65d6f3d387391170321126c433d48eb1c98c33dd903",
    "creeper3.jem": "539eafc3d7f30686adc8ffdf58d60a9ebf238722ed6baef2697ee83d7b69dd54",
    "creeper_charge.jem": "db2122bb5e39817e8a067397a54b370653695be8ba3e113dd41b9a3edd0fe833",
    "creeper_charge2.jem": "d667dc73c19915121e6ae0de62425ccc44d1927dd3abd501ba8741e9dbcabc99",
    "creeper_charge3.jem": "2549e19fbc31b307a582130662a5d2416b20cbc9d7c5971dbee5aaaf7b865021",
    "creeper.properties": "a2a6de913cd0be6b70ba2e4978230c1a93be7a5f223ba454784d461870263e30",
    "creeper_charge.properties": "a2a6de913cd0be6b70ba2e4978230c1a93be7a5f223ba454784d461870263e30",
}

EXPECTED_CHANNEL_COUNTS = {
    "creeper.jem": 53,
    "creeper2.jem": 61,
    "creeper3.jem": 64,
}

CORE_CHANNELS = {
    "body.tx", "body.ty", "body.tz", "body.rx", "body.ry", "body.rz",
    "breasts.ty", "breasts.rx", "breasts.ry",
    "head2.ty", "head2.rx", "head2.ry", "head2.rz",
    "hair_left.ty", "hair_left.rx", "hair_left.rz",
    "hair_right.ty", "hair_right.rx", "hair_right.rz",
    "l_eye_white.sy", "l_pupil.tx", "l_pupil.sy", "l_pupil.visible", "l_eyebrow.ty",
    "r_eye_white.sy", "r_pupil.tx", "r_pupil.sy", "r_pupil.visible", "r_eyebrow.ty",
}
for i in range(1, 5):
    CORE_CHANNELS |= {f"leg{i}.tx", f"leg{i}.ty", f"leg{i}.tz", f"leg{i}.rx", f"leg{i}.ry", f"leg{i}.rz"}

BUNNY_CHANNELS = {"tail.rx", "tail.ry", "left_ear.rx", "left_ear.rz", "right_ear.rx", "right_ear.rz", "right_ear2.rx", "right_ear2.rz"}
BEE_CHANNELS = {"tail.rx", "tail.ry", "left_ear.rx", "left_ear.rz", "right_ear.rx", "right_ear.rz", "left_wings.rx", "left_wings.ry", "left_wings.rz", "right_wings.ry", "right_wings.rz"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def animation_channels(path: Path) -> set[str]:
    data = json.loads(path.read_text(encoding="utf-8"))
    root = next(model for model in data["models"] if model.get("id") == "root")
    return {
        key
        for block in root.get("animations", [])
        for key in block
        if not key.startswith("var.")
    }


def method_hash(text: str, start: str, end: str) -> str:
    a = text.index(start)
    b = text.index(end, a)
    return hashlib.sha256(text[a:b].encode("utf-8")).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"FAIL: {message}")


def main() -> None:
    for name, expected in EXPECTED_HASHES.items():
        actual = sha256(PIE / name)
        require(actual == expected, f"source asset drift: {name} {actual} != {expected}")
    print(f"PASS: {len(EXPECTED_HASHES)}/{len(EXPECTED_HASHES)} Pie source hashes exact")

    base = animation_channels(PIE / "creeper.jem")
    bunny = animation_channels(PIE / "creeper2.jem")
    bee = animation_channels(PIE / "creeper3.jem")
    for name, channels in [("creeper.jem", base), ("creeper2.jem", bunny), ("creeper3.jem", bee)]:
        require(len(channels) == EXPECTED_CHANNEL_COUNTS[name], f"unexpected channel count in {name}: {len(channels)}")
    require(CORE_CHANNELS <= base, f"base CEM missing expected channels: {sorted(CORE_CHANNELS - base)}")
    require(BUNNY_CHANNELS <= bunny, f"Bunny CEM missing accessory channels: {sorted(BUNNY_CHANNELS - bunny)}")
    require(BEE_CHANNELS <= bee, f"Bee CEM missing accessory channels: {sorted(BEE_CHANNELS - bee)}")
    print("PASS: source animation channel sets = Female 53 / Bunny 61 / Bee 64")

    java = MODEL.read_text(encoding="utf-8")
    required_markers = [
        "animatePieSource(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch)",
        "final float bodyY = 5.0F",
        "vanillaBody.x = bodyX",
        "vanillaBody.y = bodyY",
        "vanillaBody.z = bodyZ",
        "vanillaBody.xRot = bodyXRot",
        "vanillaBody.yRot = bodyYRot",
        "vanillaBody.zRot = bodyZRot",
        "body.resetPose()",
        "vanillaHead.x = vanillaBody.x",
        "vanillaHead.y = vanillaBody.y",
        "vanillaHead.z = vanillaBody.z",
        "vanillaHead.xRot = vanillaBody.xRot",
        "vanillaHead.yRot = vanillaBody.yRot",
        "vanillaHead.zRot = vanillaBody.zRot",
        "head2.y += Mth.cos(b * 2.0F) / 5.0F * idle - Mth.cos(ls * 2.0F) / 2.0F * speed",
        "animatePieProxyLeg(child(this.root(), \"right_hind_leg\"), 1",
        "animatePieProxyLeg(child(this.root(), \"left_hind_leg\"), 2",
        "animatePieProxyLeg(child(this.root(), \"right_front_leg\"), 3",
        "animatePieProxyLeg(child(this.root(), \"left_front_leg\"), 4",
        "x = -2.5F + yaw / 2.0F",
        "x = 2.5F + yaw / 2.0F",
        "x = 2.5F + invYaw / 2.0F",
        "x = -2.5F + invYaw / 2.0F",
        "y = 18.0F +",
        "z = 4.0F + yaw",
        "z = 4.0F + invYaw",
        "z = -4.0F + invYaw",
        "z = -4.0F + yaw",
        "white.yScale = blink",
        "pupil.yScale = blink + Mth.clamp(-headPitch, -90.0F, 0.0F) / 180.0F",
        "pupil.visible = pupil.yScale >= 0.0F",
        "Mth.clamp(-netHeadYaw, 0.0F, 90.0F) / 180.0F",
        "Mth.clamp(-netHeadYaw, -90.0F, 0.0F) / 180.0F",
        "animatePieTailAndEars",
        "animatePieBeeWings",
        "stablePieRandom",
        "updatePieAggro",
        "easeInOutSine",
        "easeOutBack",
        "Mth.sin(ageInTicks / 20.0F) * 8.0F",
        "Mth.cos(ageInTicks / 30.0F) * 2.0F",
        "Mth.cos(ageInTicks / 20.0F) * 6.0F",
        "breasts.yRot += Mth.sin(ls) / pi * speed",
        "tail.yRot += Mth.sin(b) * 2.0F / pi * idle - Mth.sin(ls) * 2.0F / pi * speed",
    ]
    missing = [marker for marker in required_markers if marker not in java]
    require(not missing, f"native Pie animation mapping markers missing: {missing}")

    forbidden_markers = [
        "neutralizeProxyLeg",
        "animatePieLeg(child(outer",
        "body.x += bodyX",
        "body.y += bodyY",
        "body.z += bodyZ",
        "head2.x += bodyX",
        "head2.z += bodyZ",
        "Math.max(0.035F, blink)",
        "pupil.yScale > 0.04F",
        "ageInTicks * 1.15F",
        "float flap =",
    ]
    survived = [marker for marker in forbidden_markers if marker in java]
    require(not survived, f"superseded/non-source Pie animation logic survived: {survived}")
    print("PASS: CEM target hierarchy, proxy gait, exact blink/gaze, and accessory routing are source-faithful")
    # 1.4.3 intentionally advances Cat and Cherry/Blossom too. Their fidelity is owned by the
    # dedicated Bedrock and Cherry formula gates rather than a stale byte-identical 1.4.1 lock.
    require("private void animateCatSource" in java, "Cat animation path missing")
    require("private void animateCherryRemake" in java, "Cherry animation path missing")
    print("PASS: cross-family animation paths present; Cat/Cherry fidelity delegated to dedicated source-parity gates")

    # Charged CEMs intentionally omit only the ten eye/eyebrow channels because their charged
    # overlay models do not contain those visible face children. Every remaining source expression
    # is exactly the same, and the Java charged ModelPart is driven through the same setupAnim path.
    def source_channels(path: Path) -> dict[str, str]:
        data = json.loads(path.read_text(encoding="utf-8"))
        out = {}
        for source_model in data.get("models", []):
            for animation_block in source_model.get("animations", []) or []:
                for key, value in animation_block.items():
                    if "." in key and not key.startswith("var."):
                        out[key] = re.sub(r"\s+", "", str(value))
        return out

    face_only = {
        "l_eye_white.sy", "l_eyebrow.ty", "l_pupil.sy", "l_pupil.tx", "l_pupil.visible",
        "r_eye_white.sy", "r_eyebrow.ty", "r_pupil.sy", "r_pupil.tx", "r_pupil.visible",
    }
    for base_name, charge_name in [
        ("creeper.jem", "creeper_charge.jem"),
        ("creeper2.jem", "creeper_charge2.jem"),
        ("creeper3.jem", "creeper_charge3.jem"),
    ]:
        base_channels = source_channels(PIE / base_name)
        charge_channels = source_channels(PIE / charge_name)
        require(set(base_channels) - set(charge_channels) == face_only,
                f"unexpected charged missing-channel set for {charge_name}")
        require(not (set(charge_channels) - set(base_channels)),
                f"unexpected charged-only animation channel in {charge_name}")
        require(all(base_channels[key] == charge_channels[key] for key in charge_channels),
                f"charged animation expression drift in {charge_name}")
    print("PASS: Pie charged CEM programs equal base variants minus exactly 10 absent face-only channels")

    print("PASS: Pie animation fidelity gate")


if __name__ == "__main__":
    main()
