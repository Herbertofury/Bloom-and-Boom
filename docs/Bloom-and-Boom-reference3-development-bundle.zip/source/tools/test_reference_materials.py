"""Static reference2 asset contracts, independent of visual acceptance."""
from pathlib import Path
from PIL import Image
R=Path(__file__).resolve().parents[1];T=R/'src/main/resources/assets/creeperella/textures/entity'
for name in ('nacrella','verdalia','mariglow'):
 skin=Image.open(T/f'{name}_face_skin.png').convert('RGBA')
 assert skin.size==(512,512)
 assert len(set(skin.crop((2,2,66,66)).getdata()))>100,'face surface flattened'
 iris=Image.open(T/f'{name}_face_iris.png').convert('RGBA')
 assert len(set(iris.getdata()))>=2
 a=Image.open(T/f'{name}_accessories.png').convert('RGBA');g=Image.open(T/f'{name}_accessories_e.png').convert('RGBA')
 for y in range(a.height):
  for x in range(a.width):
   p,q=a.getpixel((x,y)),g.getpixel((x,y))
   assert q[3] or q[:3]==(0,0,0),'emissive leaks outside alpha'
   if x>=48*(a.width//64): assert max(p[k]+q[k] for k in range(3))<=255,'lantern loses tint through clipping'
print('PASS: reference face detail, colored eyes, and non-clipping emissive lanterns')

for name in ('nacrella','verdalia','mariglow'):
 charge=Image.open(T/f'{name}_charge.png').convert('RGBA')
 assert charge.size==(128,64)
 visible=sum(p[3]>0 for p in charge.getdata())
 assert 0<visible/(128*64)<=0.15,'charged shell obscures material'
 assert all(p[3] or p[:3]==(0,0,0) for p in charge.getdata())
layer=(R/'src/main/java/dev/herbertofury/creeperella/client/CreeperellaPowerLayer.java').read_text()
assert 'case CAT -> CAT_POWER;' in layer
assert 'case CHERRY, BLOSSOM, BOOMSHROOM -> VANILLA_POWER;' in layer
print('PASS: sparse Froglight charged masks and unchanged Cat/legacy charge routes')

for name in ('nacrella','verdalia','mariglow'):
 glass=Image.open(T/f'{name}_lantern_glass.png').convert('RGBA')
 assert glass.size==(512,512)
 assert max(glass.getchannel('A').getextrema())<255
 assert Image.open(T/f'{name}_face_iris.png').size==(1024,1024)
print('PASS: translucent lantern shells and high-density iris UV painting')
