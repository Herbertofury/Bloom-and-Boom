#!/usr/bin/env python3
"""Grouped deterministic Creeperella 1.4.8 Cat animation QA renderer."""
from __future__ import annotations
import argparse, math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageSequence
import numpy as np
import render_mobs_visual_qa as r

OUT=Path('/mnt/data/Creeperella-1.4.8-Cat-State-QA'); OUT.mkdir(parents=True,exist_ok=True)
BG=(18,21,27,255); SIZE=(380,450); FONT=ImageFont.load_default()


def cat_view(root,tex,tw,th,samples,yaw=-32,pitch=9,size=SIZE):
    mins=np.array([1e9,1e9]); maxs=np.array([-1e9,-1e9])
    for spec in samples:
        r.apply_anim(root,'cat',spec['age'],spec.get('limb',0),spec.get('amount',0),0,0,
                     cat_motion=spec.get('motion'),cat_idle=spec.get('idle','none'),
                     cat_idle_elapsed=spec.get('idle_elapsed',0),cat_left=spec.get('left',True))
        _,pts=r.build_polygons(root,tex,tw,th,yaw,pitch,subdivide=False)
        if len(pts):
            mins=np.minimum(mins,pts[:,:2].min(axis=0)); maxs=np.maximum(maxs,pts[:,:2].max(axis=0))
    center=(mins+maxs)/2; span=maxs-mins; w,h=size
    return center,min((w-42)/max(span[0],1),(h-52)/max(span[1],1))


def label(im,text):
    im=im.copy(); d=ImageDraw.Draw(im); bb=d.textbbox((0,0),text,font=FONT); tw=bb[2]-bb[0]
    d.rounded_rectangle((9,9,17+tw,28),4,fill=(0,0,0,165)); d.text((13,13),text,font=FONT,fill=(245,245,245,255)); return im


def savegif(path,frames,dur):
    frames[0].save(path,save_all=True,append_images=frames[1:],duration=dur,loop=0,disposal=2,optimize=False)


def motion_specs(motion,amount,n=24):
    cadence={'creep':0.56,'walk':1.0,'run':1.58}[motion]
    return [dict(age=40+i*0.35,limb=(math.tau*i/n)/(0.6662*cadence),amount=amount,motion=motion) for i in range(n)]


def idle_specs(idle,duration,n=28,left=True):
    return [dict(age=80+duration*i/(n-1),amount=0,motion='idle',idle=idle,idle_elapsed=duration*i/(n-1),left=left) for i in range(n)]


def render(root,tex,tw,th,specs,view,labeltext,yaw=-32,pitch=9):
    return [label(r.render_frame(root,tex,tw,th,'cat',q['age'],q.get('limb',0),q.get('amount',0),view,
             size=SIZE,yaw=yaw,pitch=pitch,bg=BG,cat_motion=q.get('motion'),cat_idle=q.get('idle','none'),
             cat_idle_elapsed=q.get('idle_elapsed',0),cat_left=q.get('left',True)),labeltext) for q in specs]


def loadgif(path):
    im=Image.open(path); frames=[]; durations=[]
    for f in ImageSequence.Iterator(im):
        frames.append(f.convert('RGBA').copy()); durations.append(int(f.info.get('duration',im.info.get('duration',70))))
    return frames,durations


def contact(frames,path):
    cols=4; thumb=(190,225); rows=math.ceil(len(frames)/cols)
    c=Image.new('RGBA',(cols*190,rows*225+32),BG); d=ImageDraw.Draw(c)
    d.text((10,10),'1.4.8 Cat - joint/clipping extremes',font=FONT,fill=(245,245,245,255))
    for i,im in enumerate(frames):
        c.alpha_composite(im.resize(thumb,Image.Resampling.NEAREST),((i%cols)*190,32+(i//cols)*225))
    c.convert('RGB').save(path,quality=95)


def main(group):
    root,tex,tw,th=r.load_variant('cat')
    universe=[]
    for mo,amt in [('creep',.30),('walk',.62),('run',.92)]: universe+=motion_specs(mo,amt,10)
    for idle,dur,left in [('paw_lift',58,True),('tail_wag',72,True),('curious_look',62,False),('knead',80,True)]: universe+=idle_specs(idle,dur,8,left)
    view=cat_view(root,tex,tw,th,universe)
    if group=='motion':
        for mo,amt,name,dur in [('creep',.30,'Creep-Stalk',90),('walk',.62,'Walk-Follow',72),('run',.92,'Run-Chase',55)]:
            savegif(OUT/f'Cat-Creeper-1.4.8-{name}.gif',render(root,tex,tw,th,motion_specs(mo,amt),view,name.replace('-',' / ')),dur)
    elif group=='idle-a':
        for idle,dur,name,left in [('paw_lift',58,'Paw-Lift-Hello',True),('tail_wag',72,'Tail-Wag',True)]:
            specs=idle_specs(idle,dur,max(2,int(dur//2)),left)
            frame_ms=100
            savegif(OUT/f'Cat-Creeper-1.4.8-Idle-{name}.gif',render(root,tex,tw,th,specs,view,name.replace('-',' ')),frame_ms)
    elif group=='idle-b':
        for idle,dur,name,left in [('curious_look',62,'Curious-Look',False),('knead',80,'Knead',True)]:
            specs=idle_specs(idle,dur,max(2,int(dur//2)),left)
            frame_ms=100
            savegif(OUT/f'Cat-Creeper-1.4.8-Idle-{name}.gif',render(root,tex,tw,th,specs,view,name.replace('-',' ')),frame_ms)
    elif group=='diag':
        diag=[]
        side_view=cat_view(root,tex,tw,th,universe,yaw=90,pitch=7)
        for mo,amt in [('creep',.30),('walk',.62),('run',.92)]:
            specs=motion_specs(mo,amt,8)
            diag += render(root,tex,tw,th,specs[::2],side_view,mo.title(),yaw=90,pitch=7)
        for idle,dur,left in [('paw_lift',58,True),('knead',80,True)]:
            specs=idle_specs(idle,dur,8,left)
            diag += render(root,tex,tw,th,[specs[2],specs[4]],side_view,idle.replace('_',' ').title(),yaw=90,pitch=7)
        contact(diag,OUT/'Cat-Creeper-1.4.8-Clipping-and-Joint-QA.png')
    elif group=='reels':
        creep,creep_d=loadgif(OUT/'Cat-Creeper-1.4.8-Creep-Stalk.gif'); walk,walk_d=loadgif(OUT/'Cat-Creeper-1.4.8-Walk-Follow.gif'); run,run_d=loadgif(OUT/'Cat-Creeper-1.4.8-Run-Chase.gif')
        reel=[]; reel_d=[]
        for seq,durs in ((creep,creep_d),(walk,walk_d),(run,run_d)):
            reel+=seq+[seq[-1]]*4; reel_d+=durs+[220]*4
        savegif(OUT/'Cat-Creeper-1.4.8-Creep-Walk-Run-State-Reel.gif',reel,reel_d)
        paw,paw_d=loadgif(OUT/'Cat-Creeper-1.4.8-Idle-Paw-Lift-Hello.gif'); wag,wag_d=loadgif(OUT/'Cat-Creeper-1.4.8-Idle-Tail-Wag.gif'); look,look_d=loadgif(OUT/'Cat-Creeper-1.4.8-Idle-Curious-Look.gif'); knead,knead_d=loadgif(OUT/'Cat-Creeper-1.4.8-Idle-Knead.gif')
        reel=[]; reel_d=[]
        for seq,durs in ((paw,paw_d),(wag,wag_d),(look,look_d),(knead,knead_d)):
            reel+=seq+[seq[-1]]*4; reel_d+=durs+[220]*4
        savegif(OUT/'Cat-Creeper-1.4.8-Cute-Idle-Reel.gif',reel,reel_d)
        (OUT/'README.md').write_text("""# Creeperella 1.4.8 Cat State QA

Deterministic renders from the actual Creeperella Java model, exact Cat texture, source-authored secondary curves, and the 1.4.8 state/IK formulas. **No image generation.**

- Creep/stalk: long planted stance, low foot clearance, crouched spine and restrained tail.
- Walk/follow: four-beat feline walk with planted-paw IK and body weight transfer.
- Run/chase: distinct faster bound with hind drive and fore catch-up.
- Personality: paw-lift hello, tail wag, curious look/ear twitch, and kneading.
- Animation motion is gated by actual `limbSwingAmount`; a RUN state while physically stuck does not create fake foot cycling.
- Server sync sends state/idle/start-tick only when state changes; curves and blending evaluate locally.
- Personality GIF timing matches the actual server clip durations: Paw Lift 58 ticks, Tail Wag 72, Curious Look 62, Knead 80.
""",encoding='utf-8')

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('group',choices=['motion','idle-a','idle-b','diag','reels']); a=ap.parse_args(); main(a.group)
