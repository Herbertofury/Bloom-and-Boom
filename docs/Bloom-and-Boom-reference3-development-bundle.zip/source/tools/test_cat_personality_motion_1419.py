#!/usr/bin/env python3
from pathlib import Path
import math

ROOT=Path(__file__).resolve().parents[1]
MODEL=(ROOT/'src/main/java/dev/herbertofury/creeperella/client/CreeperellaModel.java').read_text()

required=[
    'float phase = u * (float)Math.PI * 4.15F;',
    'tail.yRot += rootWave * 0.135F;',
    'tail2.yRot += tipWave * 0.305F + side * flick * 0.055F;',
    'float kneadPulse = Mth.sin(wave);',
    'float leftPress = smooth01(Math.max(0.0F, kneadPulse)) * envelope;',
    'float rightPress = smooth01(Math.max(0.0F, -kneadPulse)) * envelope;',
    'leftFoot.y += leftPress * 0.055F;',
    'rightFoot.y += rightPress * 0.055F;',
]
for token in required:
    if token not in MODEL: raise AssertionError('missing 1.4.19 personality token: '+token)
if 'tail2.zRot += side * Mth.sin(phase * 0.50F - 0.40F) * 0.018F * envelope;' in MODEL:
    raise AssertionError('tail roll must remain absent to preserve authored Cat axis semantics')

# Alternating knead contract: at every phase at least one paw is fully released/ground-supporting.
def smooth01(x):
    x=max(0.0,min(1.0,x)); return x*x*(3.0-2.0*x)
for i in range(1001):
    u=i/1000
    pulse=math.sin(u*math.pi*6.0)
    l=smooth01(max(0.0,pulse)); r=smooth01(max(0.0,-pulse))
    if min(l,r) > 1e-12:
        raise AssertionError(f'knead support overlap at u={u}: {l}, {r}')

# Tail contract: slower than old four-cycle metronome; distal amplitude exceeds root.
root_amp=.135
tip_amp=.305+.055
if not tip_amp > root_amp*2.0: raise AssertionError('tail tip follow-through is not sufficiently distal-weighted')
cycles=4.15/2.0
if not 1.8 < cycles < 2.3: raise AssertionError('tail swish cadence drifted out of relaxed range')

print('PASS: 1.4.19 tail wag uses slow asymmetric root + larger delayed distal follow-through')
print('PASS: no unsupported tail roll reintroduced')
print('PASS: knead pulses are strictly alternating so one forepaw remains support-neutral at every phase')
