#!/usr/bin/env python3
"""Build-free JSON and local asset-reference validation, not gameplay/save proof."""
import argparse
import json
from pathlib import Path


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'duplicate JSON key: {key}')
        result[key] = value
    return result


def audit(root):
    root = Path(root)
    errors, external = [], set()
    documents = {}
    files = sorted(root.rglob('*.json'))
    if not files:
        errors.append('No JSON resources found')
    for path in files:
        try:
            documents[path] = json.loads(path.read_text(encoding='utf-8'),
                                        object_pairs_hook=unique_object)
        except (ValueError, UnicodeError) as exc:
            errors.append(f'{path.relative_to(root)}: {exc}')

    def reference(source, value, kind):
        if not isinstance(value, str):
            errors.append(f'{source.relative_to(root)}: non-string {kind} reference')
            return
        if value.startswith('#'):
            return  # Model variables require inherited bindings; not filesystem paths.
        namespace, sep, location = value.partition(':')
        if not sep:
            namespace, location = 'minecraft', value
        import re
        if not re.fullmatch(r'[a-z0-9_.-]+', namespace) or not re.fullmatch(r'[a-z0-9_./-]+', location) or '..' in location.split('/') or location.startswith('/'):
            errors.append(f'{source.relative_to(root)}: invalid reference {value}')
            return
        base = root / 'assets' / namespace
        if not base.is_dir():
            external.add(namespace)
            return  # Dependency assets are checked by a real game resource reload.
        target = base / ('models' if kind == 'model' else 'textures') / (location + ('.json' if kind == 'model' else '.png'))
        if not target.is_file():
            errors.append(f'{source.relative_to(root)}: missing {kind} {value}')

    for path, doc in documents.items():
        parts = path.relative_to(root).parts
        if len(parts) < 4 or parts[0] != 'assets' or not isinstance(doc, dict):
            continue
        category = parts[2]
        if category == 'models':
            if 'parent' in doc:
                reference(path, doc['parent'], 'model')
            for value in doc.get('textures', {}).values():
                reference(path, value, 'texture')
            for override in doc.get('overrides', []):
                if 'model' in override:
                    reference(path, override['model'], 'model')
        elif category == 'blockstates':
            def walk(node):
                if isinstance(node, dict):
                    if 'model' in node:
                        reference(path, node['model'], 'model')
                    for value in node.values():
                        walk(value)
                elif isinstance(node, list):
                    for value in node:
                        walk(value)
            walk(doc)
        elif category == 'particles':
            for value in doc.get('textures', []):
                if isinstance(value, str):
                    ns, sep, loc = value.partition(':')
                    reference(path, f'{ns}:particle/{loc}' if sep else f'minecraft:particle/{value}', 'texture')
                else:
                    errors.append(f'{path.relative_to(root)}: non-string particle texture')
    return {'json_files': len(files), 'parsed_files': len(documents),
            'external_namespaces_not_resolved': sorted(external), 'errors': errors,
            'scope': 'JSON syntax/duplicate keys and explicit local model/texture paths only; no runtime or save compatibility proof'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1] / 'src/main/resources')
    report = audit(parser.parse_args().root)
    print(json.dumps(report, indent=2))
    raise SystemExit(bool(report['errors']))
