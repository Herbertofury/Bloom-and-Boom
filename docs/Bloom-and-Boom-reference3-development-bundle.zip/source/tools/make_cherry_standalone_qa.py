#!/usr/bin/env python3
from __future__ import annotations
import math, shutil, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageEnhance

ROOT=Path(__file__).resolve().parents[1]
OUT=Path('/mnt/data/Creeperella-1.4.5-Visual-QA')
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0,str(ROOT/'tools'))
import render_mobs_visual_qa as r
import render_3d_item_model as r3d

BG=(27,20,38,255); CARD=(43,32,57,255); BORDER=(122,88,145,255); TEXT=(250,238,250,255); MUTED=(204,181,210,255); ACC=(239,148,185,255)
try:
    FONT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',22)
    SMALL=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
    BIG=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',30)
except Exception:
    FONT=SMALL=BIG=ImageFont.load_default()

def checker(size, a=(65,52,75,255), b=(76,59,88,255), step=16):
    im=Image.new('RGBA',size,a); d=ImageDraw.Draw(im)
    for y in range(0,size[1],step):
        for x in range(0,size[0],step):
            if (x//step+y//step)%2: d.rectangle((x,y,x+step-1,y+step-1),fill=b)
    return im

def contain(im, box, pad=10):
    im=im.copy(); im.thumbnail((box[0]-2*pad,box[1]-2*pad),Image.Resampling.LANCZOS)
    bg=Image.new('RGBA',box,(0,0,0,0)); bg.alpha_composite(im,((box[0]-im.width)//2,(box[1]-im.height)//2)); return bg

def render_head(yaw=-28, pitch=10, size=(360,360)):
    root,tw,th=r.parse_layer(ROOT/'src/main/java/dev/herbertofury/creeperella/client/CherryRemakeModelLayers.java','createCherryHeadLayer')
    tex=Image.open(ROOT/'src/main/resources/assets/creeperella/textures/entity/cherry_creeper.png').convert('RGBA')
    specs=[(0,0,0,0,0)]
    view=r.compute_view(root,tex,tw,th,'head',specs,size=size,yaw=yaw,pitch=pitch)
    return r.render_frame(root,tex,tw,th,'head',0,0,0,view,size=size,yaw=yaw,pitch=pitch)

def render_cherry(age=24, walk=0.75, size=(360,420), yaw=-28):
    root,tex,tw,th=r.load_variant('cherry')
    specs=[(age,age*.45,walk,0,0)]
    view=r.compute_view(root,tex,tw,th,'cherry',specs,size=size,yaw=yaw,pitch=10)
    return r.render_frame(root,tex,tw,th,'cherry',age,age*.45,walk,view,size=size,yaw=yaw,pitch=10)

def render_tnt(scale=1.0, flash=False, size=(360,360)):
    # Render the actual runtime block model. The renderer includes a deterministic built-in
    # minecraft:block/cube_bottom_top template so this QA works without the client asset jar.
    cache=OUT/'_cherry_tnt_runtime_model.png'
    if not cache.exists():
        r3d.render(
            ROOT/'src/main/resources/assets/creeperella/models/block/cherry_tnt.json',
            cache, size=420, azim=-48, elev=24
        )
    im=Image.open(cache).convert('RGBA')
    if flash:
        overlay=Image.new('RGBA',im.size,(255,255,255,0)); a=im.getchannel('A')
        overlay.putalpha(a.point(lambda v:int(v*.45))); im=Image.alpha_composite(im,overlay)
    if abs(scale-1)>1e-3:
        nw=max(1,int(im.width*scale)); nh=max(1,int(im.height*scale)); z=im.resize((nw,nh),Image.Resampling.NEAREST)
        canvas=Image.new('RGBA',im.size,(0,0,0,0)); canvas.alpha_composite(z,((im.width-nw)//2,(im.height-nh)//2)); im=canvas
    return contain(im,size,0)

def sprite_panel(path, size, art=False):
    im=Image.open(path).convert('RGBA')
    if art:
        im=im.resize((min(size[0]-30,im.width*9),min(size[1]-30,im.height*9)),Image.Resampling.NEAREST)
    else:
        fac=min((size[0]-30)//im.width,(size[1]-30)//im.height)
        im=im.resize((im.width*max(1,fac),im.height*max(1,fac)),Image.Resampling.NEAREST)
    return contain(im,size,0)

def card(canvas, xy, wh, title, subtitle, art):
    x,y=xy; w,h=wh; d=ImageDraw.Draw(canvas)
    d.rounded_rectangle((x,y,x+w,y+h),18,fill=CARD,outline=BORDER,width=2)
    canvas.alpha_composite(contain(art,(w-20,h-92),0),(x+10,y+48))
    d.text((x+16,y+12),title,font=FONT,fill=TEXT)
    # Compact two-line metadata so long fidelity descriptions never clip the QA card.
    words=subtitle.split(); lines=[]; cur=''
    for word in words:
        test=(cur+' '+word).strip()
        if d.textlength(test,font=SMALL) > w-32 and cur:
            lines.append(cur); cur=word
        else: cur=test
    if cur: lines.append(cur)
    lines=lines[:2]
    for li,line in enumerate(lines): d.text((x+16,y+h-50+li*20),line,font=SMALL,fill=MUTED)

# Static sidecar grid.
W,H=1560,980
canvas=Image.new('RGBA',(W,H),BG); d=ImageDraw.Draw(canvas)
d.text((42,28),'Creeperella 1.4.5 — Cherry Creeper Standalone Source-Pack Port',font=BIG,fill=TEXT)
d.text((42,70),'Exact source art/geometry, namespaced as dedicated content; vanilla assets are untouched.',font=FONT,fill=MUTED)
cherry=render_cherry()
head=render_head()
gun=sprite_panel(ROOT/'src/main/resources/assets/creeperella/textures/item/cherry_gunpowder.png',(330,330))
tnt=render_tnt(size=(330,330))
painting=sprite_panel(ROOT/'src/main/resources/assets/creeperella/textures/painting/cherry_creebet.png',(330,330),art=True)
items=[
 ('Cherry Creeper','source mob + full animation rig','Mob',cherry),
 ('Cherry Gunpowder','exact source sprite • dedicated drop','Item',gun),
 ('Cherry TNT','vanilla TNT cube + exact source face art','Block + primed entity',tnt),
 ('Cherry Creeper Head','exact head_creeper.jem geometry','Standing / wall / item',head),
 ('Cherry Creebet Painting','exact 32×16 source painting art','Dedicated painting variant',painting),
]
for i,(title,sub,kind,art) in enumerate(items):
    x=42+(i%3)*500; y=120+(i//3)*410
    card(canvas,(x,y),(460,380),title,f'{kind} — {sub}',art)
# final policy card
d.rounded_rectangle((1042,530,1502,910),18,fill=CARD,outline=BORDER,width=2)
d.text((1062,550),'Standalone fidelity rule',font=FONT,fill=TEXT)
lines=['✓ no assets/minecraft override','✓ Cherry mob drops Cherry Gunpowder','✓ Cherry Gunpowder crafts Cherry TNT','✓ Cherry TNT primes as Cherry TNT','✓ charged Creeper → Cherry Head','✓ painting item places only Creebet','✓ EN/RU source names preserved','✓ source bytes remain mirrored in full']
for j,line in enumerate(lines): d.text((1065,595+j*36),line,font=SMALL,fill=ACC if j<7 else MUTED)
static=OUT/'Creeperella-1.4.5-Cherry-Standalone-Assets-QA.png'; canvas.save(static)

# Head multi-angle source-geometry check.
angles=[('Front',0),('3/4',-32),('Side',-90),('Back',180)]
angle_canvas=Image.new('RGBA',(1480,430),BG); da=ImageDraw.Draw(angle_canvas)
da.text((30,20),'Cherry Creeper Head — exact source CEM multi-angle QA',font=BIG,fill=TEXT)
for i,(lab,yaw) in enumerate(angles):
    art=render_head(yaw=yaw,size=(330,330)); x=30+i*360
    da.rounded_rectangle((x,70,x+330,400),16,fill=CARD,outline=BORDER,width=2); angle_canvas.alpha_composite(art,(x,70)); da.text((x+12,365),lab,font=FONT,fill=TEXT)
angle_canvas.save(OUT/'Cherry-Creeper-Head-Source-CEM-Multi-Angle-QA.png')

# Animated sidecar review: source Cherry walk, custom primed TNT swelling/flash, rotating exact head.
frames=[]
for i in range(24):
    fr=Image.new('RGBA',(1260,470),BG); dr=ImageDraw.Draw(fr)
    dr.text((30,18),'1.4.5 standalone motion QA — Cherry mob + primed TNT + source head',font=BIG,fill=TEXT)
    mob=render_cherry(age=18+i*1.8,walk=.82,size=(370,380),yaw=-28)
    fuse=23-i
    swell=1.0
    if fuse<10:
        q=max(0,min(1,1-(fuse+0.5)/10)); q=q*q*q*q; swell=1+q*.3
    tntf=render_tnt(scale=swell,flash=(fuse//3)%2==0,size=(340,340))
    headf=render_head(yaw=-75+i*(150/23),size=(340,340))
    for x,title,art in [(30,'Cherry Creeper walk',mob),(445,'Cherry TNT fuse',tntf),(845,'Cherry Head rotation',headf)]:
        dr.rounded_rectangle((x,70,x+370,440),16,fill=CARD,outline=BORDER,width=2)
        fr.alpha_composite(contain(art,(350,320),0),(x+10,95)); dr.text((x+14,405),title,font=FONT,fill=TEXT)
    frames.append(fr.convert('P',palette=Image.Palette.ADAPTIVE,colors=255))
gif=OUT/'Creeperella-1.4.5-Cherry-Standalone-Assets-Animation.gif'
frames[0].save(gif,save_all=True,append_images=frames[1:],duration=95,loop=0,optimize=False,disposal=2)

# Carry forward parity-locked all-mob review media, clearly noted in the README as unchanged rigs.
old=Path('/mnt/data/Creeperella-1.4.3-Visual-QA')
copy_names=['Cat-Creeper-Mob-and-Egg-Animation.gif','Female-Creeper-Mob-and-Egg-Animation.gif','Bunny-Creeper-Mob-and-Egg-Animation.gif','Bee-Creeper-Mob-and-Egg-Animation.gif','Cherry-Creeper-Mob-and-Egg-Animation.gif','Blossom-Creeper-Mob-and-Egg-Animation.gif','Creeperella-1.4.3-All-Mob-Animations.gif','Creeperella-1.4.3-All-Mobs-and-Eggs.png','Creeperella-1.4.3-All-Mobs-Multi-Angle-QA.png','Cat-Creeper-1.4.3-Improved-Motion-Contact-Sheet.png']
for n in copy_names:
    if (old/n).exists(): shutil.copy2(old/n,OUT/n)

# Combined approval grid: unchanged six-mob parity panel plus new standalone sidecar panel.
old_grid=Image.open(old/'Creeperella-1.4.3-All-Mobs-and-Eggs.png').convert('RGBA')
new_panel=Image.open(static).convert('RGBA')
scale=min(1500/old_grid.width,1.0); og=old_grid.resize((int(old_grid.width*scale),int(old_grid.height*scale)),Image.Resampling.LANCZOS)
scale2=min(1500/new_panel.width,1.0); np=new_panel.resize((int(new_panel.width*scale2),int(new_panel.height*scale2)),Image.Resampling.LANCZOS)
combo=Image.new('RGBA',(1560,og.height+np.height+130),BG); dc=ImageDraw.Draw(combo)
dc.text((30,20),'Creeperella 1.4.5 — All mobs + source-pack standalone content approval grid',font=BIG,fill=TEXT)
dc.text((30,62),'Mob rigs are parity-locked from 1.4.3; the 1.4.5 section keeps Cherry sidecars standalone and fixes TNT against vanilla geometry.',font=SMALL,fill=MUTED)
combo.alpha_composite(og,((1560-og.width)//2,100)); combo.alpha_composite(np,((1560-np.width)//2,110+og.height))
combo.save(OUT/'Creeperella-1.4.5-All-Mobs-and-Standalone-Assets.png')

(OUT/'README.md').write_text('''# Creeperella 1.4.5 deterministic Visual QA\n\nNo image-generation model was used. All new 1.4.5 visuals are deterministic renders/composites of the checked-in source-derived geometry and exact source textures.\n\n## New 1.4.5 review\n- `Creeperella-1.4.5-Cherry-Standalone-Assets-QA.png` — Cherry mob + Gunpowder + TNT + source CEM head + Creebet painting.\n- `Cherry-Creeper-Head-Source-CEM-Multi-Angle-QA.png` — exact `head_creeper.jem` multi-angle defect check.\n- `Creeperella-1.4.5-Cherry-Standalone-Assets-Animation.gif` — Cherry walk, Cherry primed-TNT swelling/flash, and exact head rotation.\n- `Creeperella-1.4.5-All-Mobs-and-Standalone-Assets.png` — full approval grid.\n\n## Carry-forward mob-rig evidence\nThe individual mob animation GIFs and six-mob 1.4.3 grids are included byte-for-byte because 1.4.5 does not alter those parity-locked rigs; it fixes Cherry TNT rendering/semantics while preserving the standalone sidecars. Cat remains the improved 1.4.3 animation shown in the included Cat GIF/contact sheet.\n''',encoding='utf-8')
print(static)
print(gif)
print(OUT/'Creeperella-1.4.5-All-Mobs-and-Standalone-Assets.png')
