#!/usr/bin/env python3
"""1.4.22 gate: Cherry is the sole active pink Cherry-Grove Creeper; Blossom is legacy-only."""
from pathlib import Path
import json, sys
R=Path(__file__).resolve().parents[1]
def t(rel): return (R/rel).read_text(encoding='utf-8')
def j(rel): return json.loads(t(rel))
def req(c,m):
    if not c: raise AssertionError(m)
    print('PASS '+m)

def main():
    ver=next((line.split('=',1)[1].strip() for line in t('gradle.properties').splitlines() if line.startswith('mod_version=')), '')
    req(ver == '1.6.0' or ver.startswith('1.6.0-dev'), 'release line is 1.6.0 (stable or visual-development suffix)')
    tag=j('src/main/resources/data/creeperella/tags/worldgen/biome/cherry_spawns.json')
    req('minecraft:cherry_grove' in tag['values'], 'Cherry spawn tag explicitly includes vanilla Cherry Grove')
    mod=j('src/main/resources/data/creeperella/forge/biome_modifier/cherry_creeper_spawns.json')
    sp=mod['spawners']
    req(sp['type']=='creeperella:cherry_creeper', 'Cherry Grove biome modifier spawns Cherry Creeper')
    req((sp['weight'],sp['minCount'],sp['maxCount'])==(18,1,2), 'Cherry inherits combined 12+6 Cherry/Blossom ecology weight with 1-2 group size')
    req(not (R/'src/main/resources/data/creeperella/forge/biome_modifier/blossom_creeper_spawns.json').exists(), 'Blossom natural-spawn biome modifier is removed')
    cfg=t('src/main/java/dev/herbertofury/creeperella/config/CreeperellaConfig.java')
    req('Deprecated compatibility key' in cfg and '.define("blossomCreeper", false)' in cfg, 'legacy Blossom config defaults off')
    bus=t('src/main/java/dev/herbertofury/creeperella/event/ModBusEvents.java')
    req('ModEntities.BLOSSOM_CREEPER.get()' in bus and '(type, level, reason, pos, random) -> false' in bus, 'legacy Blossom spawn placement hard-denies natural spawn')
    ents=t('src/main/java/dev/herbertofury/creeperella/registry/ModEntities.java')
    req('if (type == BLOSSOM_CREEPER.get()) return CreeperellaKind.CHERRY' in ents, 'legacy Blossom entity ID resolves to Cherry behavior')
    req('case BLOSSOM -> CHERRY_CREEPER.get()' in ents, 'legacy Blossom enum creation resolves to Cherry entity type')
    client=t('src/main/java/dev/herbertofury/creeperella/client/ClientEvents.java')
    req('ModEntities.BLOSSOM_CREEPER.get(), context -> new CreeperellaRenderer(context, CreeperellaKind.CHERRY)' in client, 'legacy Blossom entity renders with approved Cherry renderer')
    creative=t('src/main/java/dev/herbertofury/creeperella/Creeperella.java')
    for token in ('BLOSSOM_CREEPER_SPAWN_EGG','BLOSSOM_POWDER','BLOSSOM_TNT','BLOSSOM_CREEPER_HEAD','BLOSSOM_CREEBET_PAINTING'):
        req(('event.accept(ModItems.'+token) not in creative, f'{token} retired from normal creative tabs')
    common=t('src/main/java/dev/herbertofury/creeperella/event/CommonEvents.java')
    req('held.is(Items.PINK_PETALS)' in common and 'Your Cherry Creeper is in full bloom!' in common, 'Pink Petals preserve Bloom & Boom as an in-place Cherry interaction')
    req('return CreeperellaKind.BLOSSOM' not in common, 'no gameplay transformation creates a second Blossom mob')
    req('BLOSSOM_BURST_COOKIE.get()' in common and 'case CHERRY, BLOSSOM' in common, 'legacy Blossom treat remains useful for Cherry compatibility')
    req(not (R/'src/main/resources/data/creeperella/recipes/blossom_tnt.json').exists(), 'legacy Blossom TNT recipe no longer creates new duplicate content')
    req(not (R/'src/main/resources/data/creeperella/recipes/blossom_burst_cookie.json').exists(), 'legacy Blossom cookie recipe no longer creates new duplicate content')
    req('creeperella:blossom_powder' not in j('src/main/resources/data/forge/tags/items/gunpowder.json').get('values', []), 'legacy Blossom Powder removed from active Forge gunpowder tag')
    entity=t('src/main/java/dev/herbertofury/creeperella/entity/CreeperellaEntity.java')
    req('case CHERRY, BLOSSOM -> CHERRY_LOOT' in entity, 'legacy Blossom entities use Cherry loot')
    req('this.spawnAtLocation(ModItems.CHERRY_CREEPER_HEAD.get())' in entity, 'cherry-family charged skull drop is Cherry head')
    cherryfam=j('src/main/resources/data/creeperella/tags/entity_types/cherry_family.json')
    req(cherryfam['values']==['creeperella:cherry_creeper'], 'active cherry-family tag contains only Cherry Creeper')
    root=j('src/main/resources/assets/creeperella/models/item/blossom_creeper_spawn_egg.json')
    req(root['textures']['layer0']=='creeperella:item/cherry_creeper_spawn_egg', 'legacy Blossom spawn egg visually aliases to Cherry')
    qa=t('src/main/java/dev/herbertofury/creeperella/CreeperellaQaCommands.java')
    req('MMV_QA_CHERRY_ECOLOGY' in qa and 'MMV_QA_LEGACY_BLOSSOM_ALIAS' in qa, 'native/runtime ecology and legacy-alias QA hooks are wired')
    print('PASS Cherry/Blossom merge contract: one active pink mob, Cherry Grove ecology preserved, legacy worlds compatible')
    return 0
if __name__=='__main__':
    try: raise SystemExit(main())
    except Exception as e:
        print('FAIL '+str(e), file=sys.stderr); raise
