#!/usr/bin/env python3
from __future__ import annotations
import math, sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import render_mobs_visual_qa as r
OUT=Path('/mnt/data/Creeperella-1.4.14-Cat-Pose-Audit'); OUT.mkdir(parents=True,exist_ok=True)
BG=(8,13,24,255); W,H=300,300; BASE=255
try:
  FONT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',13)
  SMALL=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
except Exception:
  FONT=ImageFont.load_default(); SMALL=ImageFont.load_default()
MAP={'leftLeg':('leftlegsub2','leftfoot3'),'rightLeg':('rightlegsub2','rightfoot3'),'leftLegback':('leftlegsub','leftfoot2'),'rightLegback':('rightlegsub','rightfoot2')}
def P(root,*p): return r.find(root,*p)
def pose_leg_adv(root,n,rx,lrx,frx,ry=0,rz=0):
  ln,fn=MAP[n]; leg=P(root,'body','waist',n); low=P(root,'body','waist',n,ln); foot=P(root,'body','waist',n,ln,fn)
  leg.rx=rx;leg.ry=ry;leg.rz=rz;low.rx=lrx;foot.rx=frx

def pose_leg_rest(root,n,dx,dy,dz,rx,ry,rz,lrx,frx):
  ln,fn=MAP[n]; leg=P(root,'body','waist',n); low=P(root,'body','waist',n,ln); foot=P(root,'body','waist',n,ln,fn)
  leg.x+=dx;leg.y+=dy;leg.z+=dz; leg.rx=rx;leg.ry=ry;leg.rz=rz;low.rx=lrx;foot.rx=frx

def apply_sit(root,v=0):
  body=P(root,'body','waist','Body'); upper=P(root,'body','waist','Body','Upperbody'); head=P(root,'body','waist','Body','Upperbody','head')
  body.y+=.20; body.rx+=.05; upper.rx-=.05
  if v==1: head.rx+=.08
  elif v==2: head.rz+=.08
  elif v==3: head.ry+=.10
  for n in ('leftLeg','rightLeg'): pose_leg_adv(root,n,-.18,.56,-.30)
  for n in ('leftLegback','rightLegback'): pose_leg_adv(root,n,.22,1.16,-.74)
  tail=P(root,'body','waist','Body','tail');tail2=P(root,'body','waist','Body','tail','tail2');tail.z+=.12;tail.rx=.18;tail.ry=0;tail2.rx=.42;tail2.ry=0

def apply_loaf(root,v=0):
  body=P(root,'body','waist','Body'); upper=P(root,'body','waist','Body','Upperbody'); head=P(root,'body','waist','Body','Upperbody','head')
  body.y+=.95;body.rx+=.18;upper.y+=.35;upper.rx-=.10;head.y+=.12;head.rx+=(.14 if v==0 else -.04);head.rz+=(.04 if v==0 else -.04)
  pose_leg_adv(root,'leftLeg',-.46,1.10,-.54,0,.04);pose_leg_adv(root,'rightLeg',-.46,1.10,-.54,0,-.04)
  pose_leg_adv(root,'leftLegback',.82,1.38,-1.02,0,.04);pose_leg_adv(root,'rightLegback',.82,1.38,-1.02,0,-.04)
  side=1 if v%2==0 else -1;tail=P(root,'body','waist','Body','tail');tail2=P(root,'body','waist','Body','tail','tail2');tail.rx=.28;tail.ry=side*.20;tail2.rx=.58;tail2.ry=side*.16

def apply_sprawl(root,v=0):
  body=P(root,'body','waist','Body'); upper=P(root,'body','waist','Body','Upperbody'); head=P(root,'body','waist','Body','Upperbody','head');side=1 if v%2==0 else -1
  body.y+=1.15;body.rx+=.28;upper.y+=.25;upper.rx-=.08;head.rx+=.02;head.rz+=side*.06
  pose_leg_adv(root,'leftLeg',-.36,.78,-.20,-.18,.28);pose_leg_adv(root,'rightLeg',-.36,.78,-.20,.18,-.28)
  pose_leg_adv(root,'leftLegback',.28,1.02,-.34,-.20,.22);pose_leg_adv(root,'rightLegback',.28,1.02,-.34,.20,-.22)
  tail=P(root,'body','waist','Body','tail');tail2=P(root,'body','waist','Body','tail','tail2');tail.rx=.10;tail.ry=0;tail2.rx=.25;tail2.ry=0

ROLL=[.82,.86,.80,.84]; GROUND_Y=[-2.8239,-3.8517,-2.5893,-3.0833]; BODY_LEAN=[.05,.04,.06,.025]; UPPER_LEAN=[.025,.02,.03,.01];HEAD_LEAN=[.008,.006,.01,.002];BODY_PITCH=[.12,.10,.14,.08];UPPER_PITCH=[-.09,-.08,-.10,-.07];HEAD_PITCH=[.01,0,.015,-.005];UPPER_Y=[.29,.27,.31,.23];HEAD_Y=[-.08,-.02,.08,-.28];HEAD_RY=[.14,.16,.12,.22]
LEGS=[
 [('leftLeg',2.0,1.4,-1.6,-.10,-.20,.72,.50,-.10),('rightLeg',4.0,1.7,-.4,-.58,-.10,.54,1.35,-.35),('leftLegback',2.4,1.6,1.2,.55,.12,.82,1.40,-.45),('rightLegback',4.3,1.8,.4,.28,.06,.60,1.25,-.30)],
 [('leftLeg',2.8,1.3,-2.2,.05,-.24,.86,.38,-.05),('rightLeg',4.4,1.8,-.2,-.65,-.10,.52,1.42,-.38),('leftLegback',3.0,1.6,1.6,.62,.12,.96,1.46,-.48),('rightLegback',4.7,1.9,.5,.30,.06,.62,1.28,-.30)],
 [('leftLeg',1.8,1.4,-1.2,-.22,-.16,.70,.78,-.18),('rightLeg',3.8,1.8,-.2,-.62,-.08,.50,1.38,-.35),('leftLegback',2.8,1.7,1.8,.70,.12,1.02,1.50,-.52),('rightLegback',4.6,2.0,.7,.34,.05,.62,1.30,-.32)],
 [('leftLeg',2.4,1.2,-1.8,-.02,-.22,.78,.46,-.08),('rightLeg',4.2,1.6,-.5,-.52,-.12,.58,1.25,-.30),('leftLegback',2.5,1.5,1.3,.50,.14,.88,1.36,-.40),('rightLegback',4.4,1.8,.4,.25,.06,.60,1.20,-.28)]]
def apply_side(root,v=0):
  waist=P(root,'body','waist');body=P(root,'body','waist','Body');upper=P(root,'body','waist','Body','Upperbody');head=P(root,'body','waist','Body','Upperbody','head')
  roll=ROLL[v];waist.y+=GROUND_Y[v];waist.rz+=roll;body.y+=1.15;body.rx+=BODY_PITCH[v];body.rz+=-roll+BODY_LEAN[v];upper.y+=UPPER_Y[v];upper.rx+=UPPER_PITCH[v];upper.rz+=UPPER_LEAN[v]-BODY_LEAN[v];head.y+=HEAD_Y[v];head.rx+=HEAD_PITCH[v];head.ry+=HEAD_RY[v];head.rz+=HEAD_LEAN[v]-UPPER_LEAN[v]
  for row in LEGS[v]: pose_leg_rest(root,*row)
  tail=P(root,'body','waist','Body','tail');tail2=P(root,'body','waist','Body','tail','tail2');tail.rx=.28;tail.ry=-.08;tail2.rx=.58;tail2.ry=-.04

def standing_ground():
 root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',40,0,0,0,0,cat_motion='idle');_,pts=r.build_polygons(root,tex,tw,th,yaw=0,pitch=0,subdivide=False);return float(pts[:,1].min())
GROUND=standing_ground()
def render_ground(root,tex,tw,th,yaw,label):
  _,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=False);minx,maxx=pts[:,0].min(),pts[:,0].max();miny,maxy=pts[:,1].min(),pts[:,1].max();scale=min((W-20)/max(maxx-minx,1),(BASE-36)/max(maxy-GROUND,1));xoff=W/2-(minx+maxx)/2*scale;yoff=BASE+GROUND*scale
  canvas=np.zeros((H,W,4),dtype=np.uint8);canvas[:]=np.array(BG,dtype=np.uint8);im=Image.fromarray(canvas,'RGBA');d=ImageDraw.Draw(im);d.line((10,BASE,W-10,BASE),fill=(110,145,200,255),width=2);canvas=np.array(im);zbuf=np.full((H,W),np.inf)
  polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=True)
  for _,q,rgba in polys:
    pp=np.array([[xoff+p[0]*scale,yoff-p[1]*scale,p[2]] for p in q],dtype=float);r._raster_triangle(canvas,zbuf,pp[[0,1,2]],rgba);r._raster_triangle(canvas,zbuf,pp[[0,2,3]],rgba)
  im=Image.fromarray(canvas,'RGBA');d=ImageDraw.Draw(im);d.rounded_rectangle((7,6,7+len(label)*7,27),radius=6,fill=(15,22,38,220));d.text((11,10),label,font=SMALL,fill=(240,245,255));return im

def render_state(pose,v,yaw,label):
 root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',42,0,0,0,0,cat_motion='sit');pose(root,v);return render_ground(root,tex,tw,th,yaw,label)

# rest sheet: rows states/variants, 3q + side
rows=[]
for state,pose,count in [('SIT',apply_sit,4),('LOAF',apply_loaf,2),('SPRAWL',apply_sprawl,2),('HORSE REST',apply_side,4)]:
 for v in range(count): rows.append((state,pose,v))
sheet=Image.new('RGBA',(2*W,len(rows)*H),BG)
for i,(state,pose,v) in enumerate(rows):
 sheet.alpha_composite(render_state(pose,v,-28,f'{state} v{v+1} · 3Q'),(0,i*H));sheet.alpha_composite(render_state(pose,v,-90,f'{state} v{v+1} · SIDE'),(W,i*H))
sheet.save(OUT/'Creeperella-1.4.14-Rest-Pose-Audit.png')

# locomotion/idle sheet using renderer actual formula
items=[]
for motion,amount in [('creep',.30),('walk',.62),('run',.92)]:
 root,tex,tw,th=r.load_variant('cat');q=dict(age=42,limb=2.3,amount=amount);r.apply_anim(root,'cat',q['age'],q['limb'],q['amount'],0,0,cat_motion=motion);items.append((motion.upper(),root,tex,tw,th))
for idle,dur in [('paw_lift',58),('tail_wag',72),('curious_look',62),('knead',80)]:
 root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',80,0,0,0,0,cat_motion='idle',cat_idle=idle,cat_idle_elapsed=dur*.45,cat_left=True);items.append((idle.upper(),root,tex,tw,th))
sheet2=Image.new('RGBA',(2*W,len(items)*H),BG)
for i,(name,root,tex,tw,th) in enumerate(items):
 sheet2.alpha_composite(render_ground(root,tex,tw,th,-28,name+' · 3Q'),(0,i*H));sheet2.alpha_composite(render_ground(root,tex,tw,th,-90,name+' · SIDE'),(W,i*H))
sheet2.save(OUT/'Creeperella-1.4.14-Locomotion-Idle-Audit.png')
print(OUT/'Creeperella-1.4.14-Rest-Pose-Audit.png')
print(OUT/'Creeperella-1.4.14-Locomotion-Idle-Audit.png')
