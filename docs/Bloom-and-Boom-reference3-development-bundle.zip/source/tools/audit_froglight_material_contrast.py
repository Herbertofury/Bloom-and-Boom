#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
import sys

ROOT = Path(__file__).resolve().parents[1]
TEX = ROOT / 'src/main/resources/assets/creeperella/textures/entity'
VARIANTS = ('nacrella','verdalia','mariglow')

def lum(px):
    r,g,b = px[:3]
    return 0.2126*r + 0.7152*g + 0.0722*b

def opaque(path):
    im=Image.open(path).convert('RGBA')
    return [p for p in im.getdata() if p[3] > 0]

def band_lums(path,x0,x1):
    im=Image.open(path).convert('RGBA')
    vals=[]
    for y in range(im.height):
        for x in range(x0,x1):
            p=im.getpixel((x,y))
            if p[3]: vals.append(lum(p))
    return vals

errors=[]

# Nacrella must be sourced from the actual Minecraft Pearlescent Froglight top/side references,
# not regress to a hand-waved pastel-only ramp.
bodygen=(ROOT/'tools/generate_froglight_body_palettes.py').read_text()
for vanilla_name in ('pearlescent_froglight_side.png','pearlescent_froglight_top.png'):
    vp=ROOT/'.mvf-generated/vanilla'/vanilla_name
    if not vp.exists(): errors.append(f'nacrella: missing vanilla Froglight reference {vanilla_name}')
    if vanilla_name not in bodygen: errors.append(f'nacrella: generator no longer consumes {vanilla_name}')

for v in VARIANTS:
    body=opaque(TEX/f'{v}_creeper.png')
    pale=[lum(p) for p in body if lum(p) >= 105]
    if not pale:
        errors.append(f'{v}: no pale body pixels')
        continue
    mean=sum(pale)/len(pale)
    hi=sum(1 for x in pale if x>235)/len(pale)
    spread=max(pale)-min(pale)
    print(f'{v}: body mean={mean:.1f} >235={hi:.3f} spread={spread:.1f}')
    if mean > 220: errors.append(f'{v}: body mean too bright ({mean:.1f})')
    if hi > 0.05: errors.append(f'{v}: too many near-white body pixels ({hi:.3f})')
    if spread < 55: errors.append(f'{v}: body tonal spread too low ({spread:.1f})')

    acc=TEX/f'{v}_accessories.png'
    petals=band_lums(acc,0,32)
    leaves=band_lums(acc,32,48)
    pd=sum(petals)/len(petals); ld=sum(leaves)/len(leaves)
    print(f'{v}: accessory petal mean={pd:.1f} leaf mean={ld:.1f} separation={pd-ld:.1f}')
    if pd-ld < 35: errors.append(f'{v}: petal/leaf separation too weak ({pd-ld:.1f})')

    face=opaque(TEX/f'{v}_face_skin.png')
    fm=sum(lum(p) for p in face)/len(face)
    if fm > 225: errors.append(f'{v}: face mask too bright ({fm:.1f})')

    em=opaque(TEX/f'{v}_creeper_e.png')
    print(f'{v}: body emissive pixels={len(em)} face mean={fm:.1f}')
    if len(em) > 64: errors.append(f'{v}: body emissive coverage too large ({len(em)})')

if errors:
    print('FROGLIGHT_MATERIAL_CONTRAST_FAIL')
    for e in errors: print(' -',e)
    sys.exit(1)
print('FROGLIGHT_MATERIAL_CONTRAST_PASS')
