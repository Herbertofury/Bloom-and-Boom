#!/usr/bin/env python3
"""Deterministically derive Blossom standalone sidecar art from the approved in-project sources.

This keeps Blossom Powder/TNT/Creebet/head-particle reproducible without modifying the
source-authored Cherry entity/model/animation assets.
"""
from __future__ import annotations
import colorsys
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
TEX = ROOT / "src/main/resources/assets/creeperella/textures"


def recolor(src: Path, dst: Path, mode: str) -> None:
    im = Image.open(src).convert("RGBA")
    out = Image.new("RGBA", im.size)
    pixels = []
    for r, g, b, a in im.getdata():
        if a == 0:
            pixels.append((r, g, b, a))
            continue
        h, sat, val = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
        if sat > 0.18 and (h < 0.10 or h > 0.78):
            h2 = 0.92 if mode == "powder" else 0.91
            s2 = min(0.62 if mode == "powder" else 0.55, max(0.30, sat * 0.70))
            v2 = min(1.0, val * (1.18 if mode == "powder" else 1.12) + (0.06 if mode == "powder" else 0.08))
            rr, gg, bb = colorsys.hsv_to_rgb(h2, s2, v2)
            pixels.append((round(rr * 255), round(gg * 255), round(bb * 255), a))
        else:
            pixels.append((r, g, b, a))
    out.putdata(pixels)
    dst.parent.mkdir(parents=True, exist_ok=True)
    out.save(dst, optimize=False)


def main() -> None:
    recolor(TEX / "item/cherry_gunpowder.png", TEX / "item/blossom_powder.png", "powder")
    for face in ("side", "top", "bottom"):
        recolor(TEX / f"block/cherry_tnt_{face}.png", TEX / f"block/blossom_tnt_{face}.png", "tnt")
    recolor(TEX / "painting/cherry_creebet.png", TEX / "painting/blossom_creebet.png", "tnt")
    entity = Image.open(TEX / "entity/blossom_creeper.png").convert("RGBA")
    entity.crop((0, 0, 24, 16)).resize((16, 16), Image.Resampling.NEAREST).save(
        TEX / "block/blossom_creeper_head_particle.png", optimize=False
    )
    print("Generated deterministic Blossom sidecar textures")


if __name__ == "__main__":
    main()
