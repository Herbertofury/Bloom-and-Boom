#!/usr/bin/env python3
"""Deterministically preview vanilla/Forge JSON item models without image generation.

The renderer evaluates actual cuboid coordinates/rotations and now samples each face's
real Minecraft UV region, allowing pixel-textured model QA rather than material-average
color approximations.
"""
from __future__ import annotations

import argparse, json, math
from pathlib import Path
from typing import Dict, List, Tuple
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

FACE_VERTS = {
    "north": ((0,0,0),(1,0,0),(1,1,0),(0,1,0)),
    "south": ((1,0,1),(0,0,1),(0,1,1),(1,1,1)),
    "west": ((0,0,1),(0,0,0),(0,1,0),(0,1,1)),
    "east": ((1,0,0),(1,0,1),(1,1,1),(1,1,0)),
    "down": ((0,0,1),(1,0,1),(1,0,0),(0,0,0)),
    "up": ((0,1,0),(1,1,0),(1,1,1),(0,1,1)),
}


def rotate_point(p, rotation):
    if not rotation:
        return np.array(p, dtype=float)
    v=np.array(p,dtype=float)-np.array(rotation["origin"],dtype=float)
    a=math.radians(float(rotation["angle"]))
    c,s=math.cos(a),math.sin(a)
    axis=rotation["axis"]
    if axis=="x": R=np.array([[1,0,0],[0,c,-s],[0,s,c]])
    elif axis=="y": R=np.array([[c,0,s],[0,1,0],[-s,0,c]])
    else: R=np.array([[c,-s,0],[s,c,0],[0,0,1]])
    return R@v+np.array(rotation["origin"],dtype=float)


def assets_root(model_path: Path) -> Path:
    parts=model_path.parts
    idx=parts.index("assets")
    return Path(*parts[:idx+1])


def texture_path(model_path: Path, texloc: str) -> Path | None:
    if texloc.startswith("#"):
        return None
    if ":" in texloc:
        ns, rel=texloc.split(":",1)
    else:
        ns, rel="minecraft",texloc
    return assets_root(model_path)/ns/"textures"/(rel+".png")


def model_resource_path(model_path: Path, resource: str) -> Path | None:
    if ":" in resource:
        ns, rel = resource.split(":", 1)
    else:
        ns, rel = "minecraft", resource
    if ns == "minecraft":
        return None
    return assets_root(model_path) / ns / "models" / (rel + ".json")


def load_model(model_path: Path, seen=None) -> dict:
    if seen is None:
        seen=set()
    key=str(model_path.resolve())
    if key in seen:
        raise ValueError(f"model parent cycle: {model_path}")
    seen.add(key)
    child=json.loads(model_path.read_text())
    parent_ref=child.get("parent")
    if not parent_ref:
        return child
    pp=model_resource_path(model_path,parent_ref)
    if pp is None or not pp.exists():
        # Small built-in vanilla templates keep deterministic QA grounded in the real runtime
        # model even when the Minecraft client asset jar is not available in this environment.
        if parent_ref == "minecraft:block/cube_bottom_top":
            parent={
                "elements":[{
                    "from":[0,0,0],"to":[16,16,16],
                    "faces":{
                        "north":{"uv":[0,0,16,16],"texture":"#side"},
                        "east":{"uv":[0,0,16,16],"texture":"#side"},
                        "south":{"uv":[0,0,16,16],"texture":"#side"},
                        "west":{"uv":[0,0,16,16],"texture":"#side"},
                        "up":{"uv":[0,0,16,16],"texture":"#top"},
                        "down":{"uv":[0,0,16,16],"texture":"#bottom"}
                    }
                }]
            }
        elif parent_ref == "minecraft:block/cube_all":
            parent={
                "elements":[{
                    "from":[0,0,0],"to":[16,16,16],
                    "faces":{k:{"uv":[0,0,16,16],"texture":"#all"} for k in FACE_VERTS}
                }]
            }
        else:
            return child
    else:
        parent=load_model(pp,seen)
    merged=dict(parent)
    # Child scalar/list keys override parent; texture/display maps merge by key.
    for k,v in child.items():
        if k in ("textures","display") and isinstance(v,dict):
            mv=dict(parent.get(k,{})); mv.update(v); merged[k]=mv
        elif k != "parent":
            merged[k]=v
    merged["parent"]=parent_ref
    return merged


def sample_face(model_path: Path, texloc: str, uv) -> Tuple[float,float,float,float]:
    t=texture_path(model_path,texloc)
    if t is None or not t.exists():
        return (0.65,0.65,0.65,1.0)
    im=Image.open(t).convert("RGBA")
    arr=np.asarray(im,dtype=np.float32)/255.0
    if not uv or len(uv)!=4:
        crop=arr
    else:
        u1,v1,u2,v2=[float(v) for v in uv]
        # Minecraft JSON UV coordinates are in a logical 0..16 texture space.
        x1=int(math.floor(min(u1,u2)/16.0*im.width))
        x2=int(math.ceil(max(u1,u2)/16.0*im.width))
        y1=int(math.floor(min(v1,v2)/16.0*im.height))
        y2=int(math.ceil(max(v1,v2)/16.0*im.height))
        x1=max(0,min(im.width-1,x1)); x2=max(x1+1,min(im.width,x2))
        y1=max(0,min(im.height-1,y1)); y2=max(y1+1,min(im.height,y2))
        crop=arr[y1:y2,x1:x2]
    alpha=crop[...,3]
    mask=alpha>0.02
    if not mask.any(): return (0.8,0.8,0.8,0.0)
    weights=alpha[mask]
    rgb=(crop[...,:3][mask]*weights[:,None]).sum(axis=0)/weights.sum()
    return (float(rgb[0]),float(rgb[1]),float(rgb[2]),float(np.clip(weights.mean(),0.25,1.0)))


def resolve_texture(textures: dict, ref: str) -> str:
    seen=set()
    while ref.startswith("#"):
        key=ref[1:]
        if key in seen or key not in textures:
            break
        seen.add(key)
        ref=textures[key]
    return ref


def rotation_matrix_xyz(rx: float, ry: float, rz: float):
    ax,ay,az=[math.radians(v) for v in (rx,ry,rz)]
    cx,sx=math.cos(ax),math.sin(ax); cy,sy=math.cos(ay),math.sin(ay); cz,sz=math.cos(az),math.sin(az)
    Rx=np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]],dtype=float)
    Ry=np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]],dtype=float)
    Rz=np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]],dtype=float)
    return Rz@Ry@Rx


def apply_display_point(p, transform):
    if not transform:
        return np.array(p,dtype=float)
    q=np.array(p,dtype=float)
    center=np.array([8.0,8.0,8.0])
    scale=np.array(transform.get("scale",[1,1,1]),dtype=float)
    q=(q-center)*scale+center
    rot=transform.get("rotation",[0,0,0])
    q=rotation_matrix_xyz(*rot)@(q-center)+center
    trans=np.array(transform.get("translation",[0,0,0]),dtype=float)
    q=q+trans
    return q


def render(model_path: Path, out: Path, title: str|None=None, size=420, azim=-96, elev=8, display_name: str|None=None):
    data=load_model(model_path)
    textures=data.get("textures",{})
    display_transform=data.get("display",{}).get(display_name) if display_name else None

    fig=plt.figure(figsize=(size/100,size/100),dpi=100)
    ax=fig.add_subplot(111,projection="3d")
    fig.patch.set_alpha(0)
    ax.set_facecolor((0,0,0,0))

    allpts=[]; polygons=[]; facecolors=[]
    for el in data.get("elements",[]):
        frm=np.array(el["from"],dtype=float); to=np.array(el["to"],dtype=float)
        delta=to-frm; rot=el.get("rotation")
        for face_name,face in el.get("faces",{}).items():
            if face_name not in FACE_VERTS: continue
            verts=[]
            for u,v,w in FACE_VERTS[face_name]:
                p=frm+delta*np.array([u,v,w],dtype=float)
                p=rotate_point(p,rot)
                p=apply_display_point(p,display_transform)
                q=(p[0],p[2],p[1])  # model Y vertical
                verts.append(q); allpts.append(q)
            tex=resolve_texture(textures,face.get("texture","#egg"))
            uv=face.get("uv")
            # Subdivide textured faces by logical texel so a 10-pixel strip renders as
            # ten real pixel colors instead of one averaged rectangle.
            if uv and len(uv)==4:
                u1,v1,u2,v2=[float(v) for v in uv]
                nu=max(1,int(math.ceil(abs(u2-u1))))
                nv=max(1,int(math.ceil(abs(v2-v1))))
            else:
                u1=v1=0.0; u2=v2=16.0; nu=nv=1
            p00=np.array(verts[0],dtype=float); p10=np.array(verts[1],dtype=float)
            p11=np.array(verts[2],dtype=float); p01=np.array(verts[3],dtype=float)
            def interp(ss,tt):
                return ((1-ss)*(1-tt)*p00 + ss*(1-tt)*p10 + ss*tt*p11 + (1-ss)*tt*p01)
            for jj in range(nv):
                t0=jj/nv; t1=(jj+1)/nv
                vv0=v1+(v2-v1)*t0; vv1=v1+(v2-v1)*t1
                for ii in range(nu):
                    s0=ii/nu; s1=(ii+1)/nu
                    uu0=u1+(u2-u1)*s0; uu1=u1+(u2-u1)*s1
                    q=[tuple(interp(s0,t0)),tuple(interp(s1,t0)),tuple(interp(s1,t1)),tuple(interp(s0,t1))]
                    polygons.append(q)
                    facecolors.append(sample_face(model_path,tex,[uu0,vv0,uu1,vv1]))

    poly=Poly3DCollection(polygons,facecolors=facecolors,edgecolors=(0.04,0.04,0.04,0.10),linewidths=0.20)
    poly.set_zsort('average'); ax.add_collection3d(poly)

    pts=np.array(allpts)
    mins=pts.min(axis=0); maxs=pts.max(axis=0); center=(mins+maxs)/2
    span=max(maxs-mins)*1.10
    ax.set_xlim(center[0]-span/2,center[0]+span/2)
    ax.set_ylim(center[1]-span/2,center[1]+span/2)
    ax.set_zlim(center[2]-span/2,center[2]+span/2)
    ax.set_box_aspect((1,1,1)); ax.view_init(elev=elev,azim=azim); ax.set_axis_off()
    if title: ax.set_title(title,fontsize=13,pad=2)
    plt.subplots_adjust(left=0,right=1,bottom=0,top=0.93 if title else 1)
    out.parent.mkdir(parents=True,exist_ok=True)
    plt.savefig(out,transparent=True,dpi=100)
    plt.close(fig)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('model',type=Path); ap.add_argument('output',type=Path)
    ap.add_argument('--title'); ap.add_argument('--size',type=int,default=420)
    ap.add_argument('--azim',type=float,default=-96); ap.add_argument('--elev',type=float,default=8)
    ap.add_argument('--display',choices=['gui','ground','fixed','head','firstperson_righthand','firstperson_lefthand','thirdperson_righthand','thirdperson_lefthand'])
    a=ap.parse_args(); render(a.model,a.output,a.title,a.size,a.azim,a.elev,a.display)

if __name__=='__main__': main()
