#!/usr/bin/env python3
from __future__ import annotations
import math, sys, hashlib
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import render_mobs_visual_qa as r
OUT=Path('/mnt/data/Creeperella-1.4.17-Cat-Sit2-Ground-QA');OUT.mkdir(parents=True,exist_ok=True)
BG=(8,13,24,255);W,H=300,320;BASE=280;FRAMES=8
try:
    FONT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',13)
    SMALL=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',10)
except Exception:
    FONT=ImageFont.load_default();SMALL=ImageFont.load_default()
MAP={'leftLeg':('leftlegsub2','leftfoot3',False),'rightLeg':('rightlegsub2','rightfoot3',False),'leftLegback':('leftlegsub','leftfoot2',True),'rightLegback':('rightlegsub','rightfoot2',True)}
def P(root,*p): return r.find(root,*p)
def solve_ik(hind,ty,tz):
    udy,udz=5.25,1.75;ldy,ldz=(5.05,-.25) if hind else (3.0,0.0)
    l1=math.hypot(udy,udz);l2=math.hypot(ldy,ldz);a1=math.atan2(udz,udy);a2=math.atan2(ldz,ldy)
    d=max(abs(l1-l2)+.08,min(l1+l2-.08,math.hypot(ty,tz)))
    k=math.acos(max(-1,min(1,(d*d-l1*l1-l2*l2)/(2*l1*l2))))
    ta=math.atan2(tz,ty);ua=ta-math.atan2(l2*math.sin(k),l1+l2*math.cos(k))-a1;la=k+a1-a2
    return ua,la,-(ua+la)
def leg_ik(root,n,ty,tz,dx,dy,dz,yaw,roll):
    ln,fn,hind=MAP[n];leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn);ua,la,pa=solve_ik(hind,ty,tz)
    leg.x+=dx;leg.y+=dy;leg.z+=dz;leg.rx=ua;leg.ry=yaw;leg.rz=roll;lo.rx=la;fo.rx=pa

def sit2(root,v=0,hind_reach=8.72):
    side=1 if v%2==0 else -1;w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head')
    w.y+=.89;b.y+=1.40;b.rx+=.16;u.y+=.28;u.rx-=.08;h.rx+=.01;h.rz+=side*.035
    leg_ik(root,'leftLeg',6.90,-1.60,1.50,.35,0,.18,.42);leg_ik(root,'rightLeg',6.90,-1.60,-1.50,.35,0,-.18,-.42)
    leg_ik(root,'leftLegback',hind_reach,1.60,2.00,.50,0,.08,.42);leg_ik(root,'rightLegback',hind_reach,1.60,-2.00,.50,0,-.08,-.42)
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.z+=.16;t.rx=.24;t.ry=0;t2.rx=.50;t2.ry=side*.10

def standing_ground():
    root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',40,0,0,0,0,cat_motion='idle');_,pts=r.build_polygons(root,tex,tw,th,0,0,subdivide=False);return float(pts[:,1].min())
GROUND=standing_ground()
def render(root,tex,tw,th,yaw,label,pitch=5):
    _,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=pitch,subdivide=False);mnx,mxx=pts[:,0].min(),pts[:,0].max();mny,mxy=pts[:,1].min(),pts[:,1].max();sc=min((W-22)/max(mxx-mnx,1),(BASE-36)/max(mxy-GROUND,1));xo=W/2-(mnx+mxx)/2*sc;yo=BASE+GROUND*sc
    can=np.zeros((H,W,4),dtype=np.uint8);can[:]=np.array(BG,dtype=np.uint8);im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);d.rounded_rectangle((10,BASE-4,W-10,BASE+8),radius=6,fill=(12,22,40,230));d.line((10,BASE,W-10,BASE),fill=(115,145,195,255),width=2);can=np.array(im);z=np.full((H,W),np.inf)
    polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=pitch,subdivide=True)
    for _,q,rgba in polys:
        pp=np.array([[xo+p[0]*sc,yo-p[1]*sc,p[2]] for p in q],dtype=float);r._raster_triangle(can,z,pp[[0,1,2]],rgba);r._raster_triangle(can,z,pp[[0,2,3]],rgba)
    im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);bb=d.textbbox((0,0),label,font=SMALL);tx=(W-(bb[2]-bb[0]))//2;d.rounded_rectangle((tx-6,8,tx+(bb[2]-bb[0])+6,28),radius=6,fill=(15,22,38,225),outline=(105,125,165,255));d.text((tx,11),label,font=SMALL,fill=(241,244,255));return im

def pose_frame(reach,variant=0,age=42):
    root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',age,0,0,0,0,cat_motion='sit');sit2(root,variant,reach);return root,tex,tw,th

def save_gif(path,reach,label,yaw):
    fs=[]
    for i in range(FRAMES):
        root,tex,tw,th=pose_frame(reach,0,40+i*.75);fs.append(render(root,tex,tw,th,yaw,label))
    fs[0].save(path,save_all=True,append_images=fs[1:],duration=120,loop=0,disposal=2,optimize=False)

def wm(part):
    chain=[];p=part
    while p is not None: chain.append(p);p=p.parent
    M=np.eye(4)
    for q in reversed(chain):M=M@r.local_matrix(q)
    return M
def part_bottom(part):
    M=wm(part);ys=[]
    for c in part.cubes:
        for x in (c.x-c.deform,c.x+c.dx+c.deform):
            for y in (c.y-c.deform,c.y+c.dy+c.deform):
                for z in (c.z-c.deform,c.z+c.dz+c.deform):ys.append(float(-(M@np.array([x,y,z,1.0]))[1]))
    return min(ys)
def foot_delta(root,n):
    ln,fn,_=MAP[n];return part_bottom(P(root,'body','waist',n,ln,fn))-GROUND

# Hero before/after side and 3Q.
sheet=Image.new('RGBA',(2*W,2*H),BG)
for row,(yaw,vn) in enumerate([(-90,'SIDE'),(-28,'3Q')]):
    root,tex,tw,th=pose_frame(7.00);sheet.alpha_composite(render(root,tex,tw,th,yaw,f'BEFORE 1.4.16 · SIT 2 · {vn}'),(0,row*H))
    root,tex,tw,th=pose_frame(8.72);sheet.alpha_composite(render(root,tex,tw,th,yaw,f'AFTER 1.4.17 · SIT 2 · {vn}'),(W,row*H))
hero=OUT/'Creeperella-1.4.16-vs-1.4.17-Sit2-Hind-Ground.png';sheet.save(hero)

save_gif(OUT/'Cat-Creeper-1.4.17-SIT-2-SIDE.gif',8.72,'1.4.17 · SIT 2 · SIDE',-90)
save_gif(OUT/'Cat-Creeper-1.4.17-SIT-2-3Q.gif',8.72,'1.4.17 · SIT 2 · 3Q',-28)

lines=[f'standing_ground_y={GROUND:.6f}']
for label,reach in [('BEFORE_1.4.16',7.00),('AFTER_1.4.17',8.72)]:
    vals={n:[] for n in MAP}
    for v in (0,1):
        for i in range(FRAMES):
            root,tex,tw,th=pose_frame(reach,v,40+i*.75)
            for n in MAP:vals[n].append(foot_delta(root,n))
    lines.append(label)
    for n in MAP:lines.append(f'  {n}: ground_delta_min={min(vals[n]):.6f} max={max(vals[n]):.6f}')

# Four-angle after-only inspection to catch any secondary placement regression.
views=[(0,'FRONT'),(-28,'3Q'),(-90,'SIDE'),(180,'BACK')]
multi=Image.new('RGBA',(2*W,2*H),BG)
for i,(yaw,vn) in enumerate(views):
    root,tex,tw,th=pose_frame(8.72,0,42)
    multi.alpha_composite(render(root,tex,tw,th,yaw,f'1.4.17 · SIT 2 · {vn}'),((i%2)*W,(i//2)*H))
multi_path=OUT/'Cat-Creeper-1.4.17-SIT-2-Multiangle.png';multi.save(multi_path)

qa=OUT/'SIT2_GROUND_CONTACT_QA.txt';qa.write_text('\n'.join(lines)+'\n',encoding='utf-8')
(OUT/'README.md').write_text('''# Creeperella 1.4.17 Sit 2 hind-paw grounding QA\n\nDeterministic renders from the actual Cat Creeper model/texture and runtime-equivalent pose math. No generative image model was used.\n\nChange: only Sit 2 rear-leg IK reach changed from 7.00 to 8.72 so the hind paws settle to the Minecraft floor while keeping hip pivots, torso, forelegs, tail, and rest-state behavior intact.\n''',encoding='utf-8')
print(hero)
print(qa.read_text())
