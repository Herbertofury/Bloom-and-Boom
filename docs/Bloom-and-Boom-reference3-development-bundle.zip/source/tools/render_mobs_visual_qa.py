#!/usr/bin/env python3
from __future__ import annotations
import re, math, copy, json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import numpy as np
from PIL import Image, ImageDraw

SRC=Path(__file__).resolve().parents[1]

@dataclass
class Cube:
    u: float; v: float
    x: float; y: float; z: float
    dx: float; dy: float; dz: float
    deform: float=0.0
    mirror: bool=False

@dataclass
class Part:
    name: str
    x: float=0; y: float=0; z: float=0
    rx: float=0; ry: float=0; rz: float=0
    sx: float=1; sy: float=1; sz: float=1
    visible: bool=True
    cubes: List[Cube]=field(default_factory=list)
    children: List['Part']=field(default_factory=list)
    parent: Optional['Part']=None
    base: Tuple[float,float,float,float,float,float]=None
    def __post_init__(self):
        if self.base is None: self.base=(self.x,self.y,self.z,self.rx,self.ry,self.rz)
    def reset(self):
        self.x,self.y,self.z,self.rx,self.ry,self.rz=self.base
        self.sx=self.sy=self.sz=1.0
        self.visible=True
        for c in self.children: c.reset()
    def child(self,name):
        for c in self.children:
            if c.name==name: return c
        return None

FLOAT=r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?F?'

def fnum(s): return float(s.strip().rstrip('Ff'))

def extract_method(text: str, method: str) -> str:
    m=re.search(r'public\s+static\s+LayerDefinition\s+'+re.escape(method)+r'\s*\(\s*\)\s*\{',text)
    if not m: raise ValueError(f'method {method} not found')
    start=m.end(); depth=1; i=start
    while i < len(text) and depth:
        if text[i]=='{': depth+=1
        elif text[i]=='}': depth-=1
        i+=1
    return text[start:i-1]

def parse_builder_statement(stmt: str, builders: Dict[str,List[Cube]], default_var: str|None=None):
    # Determine builder variable from declaration or prefix.
    var=default_var
    m=re.search(r'CubeListBuilder\s+(\w+)\s*=\s*CubeListBuilder\.create\(\)',stmt)
    if m:
        var=m.group(1); builders.setdefault(var,[])
    else:
        m2=re.match(r'\s*(\w+)\.texOffs',stmt)
        if m2: var=m2.group(1)
    if not var: return
    # Stateful scan to respect mirror() calls in chained builders.
    pos=0; cur_u=cur_v=None; mirror=False
    token_re=re.compile(r'\.texOffs\(\s*('+FLOAT+r')\s*,\s*('+FLOAT+r')\s*\)|\.mirror\((true|false)?\)|\.addBox\((.*?)\)',re.S)
    for mt in token_re.finditer(stmt):
        if mt.group(1) is not None:
            cur_u=fnum(mt.group(1)); cur_v=fnum(mt.group(2)); mirror=False
        else:
            tok=mt.group(0)
            if tok.startswith('.mirror'):
                mirror = (mt.group(3) != 'false')
            elif tok.startswith('.addBox'):
                args=mt.group(4)
                nums=re.findall(FLOAT,args)
                # addBox x,y,z,dx,dy,dz then CubeDeformation d; nums may include only these 7
                if len(nums) >= 7 and cur_u is not None:
                    x,y,z,dx,dy,dz=[fnum(n) for n in nums[:6]]
                    deform=fnum(nums[6])
                    builders.setdefault(var,[]).append(Cube(cur_u,cur_v,x,y,z,dx,dy,dz,deform,mirror))

def parse_layer(java_path: Path, method: str):
    text=java_path.read_text()
    sec=extract_method(text,method)
    builders: Dict[str,List[Cube]]={}
    # statements separated by semicolon are safe for these generated files
    for raw in sec.split(';'):
        stmt=raw.strip()
        if not stmt: continue
        if 'CubeListBuilder' in stmt or '.texOffs' in stmt:
            parse_builder_statement(stmt+';',builders)
    root=Part('root')
    var_parts={'root':root}
    # parse part definitions line-oriented; generated statements are one logical line ending ;
    for raw in sec.split(';'):
        stmt=' '.join(raw.strip().split())
        if 'addOrReplaceChild' not in stmt: continue
        m=re.search(r'PartDefinition\s+(\w+)\s*=\s*(\w+)\.addOrReplaceChild\("([^"]+)"\s*,\s*(.*?)\s*,\s*PartPose\.(offsetAndRotation|offset)\((.*?)\)\)',stmt)
        if not m:
            # try statement without PartDefinition? unlikely
            continue
        var,parent_var,name,builder_expr,pose_kind,pose_args=m.groups()
        parent=var_parts.get(parent_var)
        if parent is None:
            raise ValueError(f'unknown parent {parent_var} for {name}')
        nums=[fnum(n) for n in re.findall(FLOAT,pose_args)]
        if pose_kind=='offset':
            x,y,z=nums[:3]; rx=ry=rz=0.0
        else:
            x,y,z,rx,ry,rz=nums[:6]
        p=Part(name,x,y,z,rx,ry,rz,parent=parent)
        bm=re.fullmatch(r'(\w+)',builder_expr.strip())
        if bm and bm.group(1) in builders:
            p.cubes=copy.deepcopy(builders[bm.group(1)])
        parent.children.append(p); var_parts[var]=p
    tm=re.search(r'LayerDefinition\.create\(mesh\s*,\s*(\d+)\s*,\s*(\d+)\s*\)',sec)
    tw,th=(int(tm.group(1)),int(tm.group(2))) if tm else (64,64)
    return root,tw,th

def mat_translate(x,y,z):
    M=np.eye(4); M[:3,3]=[x,y,z]; return M

def mat_scale(x,y,z):
    M=np.eye(4); M[0,0]=x;M[1,1]=y;M[2,2]=z;return M

def rot_x(a):
    c,s=math.cos(a),math.sin(a); return np.array([[1,0,0,0],[0,c,-s,0],[0,s,c,0],[0,0,0,1]],float)
def rot_y(a):
    c,s=math.cos(a),math.sin(a); return np.array([[c,0,s,0],[0,1,0,0],[-s,0,c,0],[0,0,0,1]],float)
def rot_z(a):
    c,s=math.cos(a),math.sin(a); return np.array([[c,-s,0,0],[s,c,0,0],[0,0,1,0],[0,0,0,1]],float)

def local_matrix(p:Part):
    # Minecraft applies translation then Z/Y/X rotation and scale.
    return mat_translate(p.x,p.y,p.z) @ rot_z(p.rz) @ rot_y(p.ry) @ rot_x(p.rx) @ mat_scale(p.sx,p.sy,p.sz)

def find(root:Part,*path):
    cur=root
    for n in path:
        cur=cur.child(n) if cur else None
        if cur is None: return None
    return cur

def vanilla_anim(root:Part, limbSwing, amount, headYaw=0.0, headPitch=0.0):
    deg=math.pi/180
    head=find(root,'head')
    if head:
        head.ry=headYaw*deg; head.rx=headPitch*deg
    rh=find(root,'right_hind_leg'); lh=find(root,'left_hind_leg'); rf=find(root,'right_front_leg'); lf=find(root,'left_front_leg')
    a=math.cos(limbSwing*0.6662)*1.4*amount
    b=math.cos(limbSwing*0.6662+math.pi)*1.4*amount
    if rh: rh.rx=a
    if lh: lh.rx=b
    if rf: rf.rx=b
    if lf: lf.rx=a

def pie_blink(age):
    signal=abs(math.sin(age/20)*8 + math.cos(age/30)*2 + math.cos(age/20)*6)
    b=max(0,min(1,signal)); return b*b

def ease_in_out_sine(value):
    value=max(0.0,min(1.0,value))
    return -(math.cos(math.pi*value)-1.0)/2.0

def ease_out_back(value):
    x=max(0.0,min(1.0,value))-1.0
    c1=1.70158; c3=c1+1.0
    return 1.0+c3*x*x*x+c1*x*x

def animate_pie_eye(eye:Part|None, whiteName, pupilName,browName,blink,headYaw,headPitch,left):
    if not eye:return
    white=eye.child(whiteName); pupil=eye.child(pupilName); brow=eye.child(browName)
    if white:white.sy=blink
    if pupil:
        pupil.x=pupil.base[0]+(max(0,min(90,-headYaw))/180 if left else max(-90,min(0,-headYaw))/180)
        pupil.sy=blink+max(-90,min(0,-headPitch))/180
        pupil.visible=pupil.sy>=0.0
    if brow:brow.y=brow.base[1]+1.0-blink

def stable_pie_random(kind):
    # Fixed representative entity IDs for reproducible showcase phase, equivalent to Java's
    # per-entity UUID-derived CEM random(id) adaptation.
    return {'female':0.1731,'bunny':0.4837,'bee':0.8129}.get(kind,0.5)

def apply_pie_source(root:Part,kind:str,age:float,limbSwing:float,amount:float,headYaw=0.0,headPitch=0.0,hurt=0.0,aggro=0.0):
    pi=math.pi; deg=pi/180.0
    speed=max(0.0,min(1.0,amount)); idle=1.0-max(0.0,min(1.0,speed*3.0))
    rnd=stable_pie_random(kind); seed=1.0+rnd*2.0
    b=seed+age/(10.0+5.0*rnd); ls=seed+limbSwing
    yaw=max(-70.0,min(70.0,headYaw))*deg
    invYaw=max(-70.0,min(70.0,-headYaw))*deg
    pitch=headPitch*deg; clampedPitch=max(-70.0,min(30.0,headPitch))*deg
    aggroSine=ease_in_out_sine(aggro); aggroBack=ease_out_back(aggro)

    vanillaBody=find(root,'body'); body=find(vanillaBody,'body') if vanillaBody else None
    vanillaHead=find(root,'head'); head2=find(vanillaHead,'head2') if vanillaHead else None
    if not(vanillaBody and body and vanillaHead and head2):return

    bodyX=-math.sin(b)*pi/5.0*idle
    bodyY=5.0-math.sin(b*2.0)/5.0*idle+math.sin(ls*2.0)/2.0*speed
    bodyZ=-pitch*pi/2.0-22.5*deg*pi*pi*speed-hurt*pi
    bodyXR=pitch/(pi*2.0)+22.5*deg*speed+hurt/pi
    bodyYR=yaw/2.0-math.cos(ls)/pi*(speed+0.25)
    bodyZR=-math.sin(b)/(pi*5.0)*idle
    vanillaBody.x=bodyX; vanillaBody.y=bodyY; vanillaBody.z=bodyZ
    vanillaBody.rx=bodyXR; vanillaBody.ry=bodyYR; vanillaBody.rz=bodyZR
    # custom body stays at generated bind pose

    breasts=body.child('breasts')
    if breasts:
        breasts.y=breasts.base[1]+math.cos(b*2.0)/3.0*idle+math.sin(ls*2.0)/2.0*speed
        breasts.rx=breasts.base[3]+math.sin(b*2.0)/(pi*3.0)*idle-math.cos(ls*2.0)/pi*speed-hurt/pi*2.0
        breasts.ry=breasts.base[4]+math.sin(ls)/pi*speed

    # generator-detached head2: copy animated body proxy, then add only head2 local dynamics.
    vanillaHead.x=vanillaBody.x; vanillaHead.y=vanillaBody.y; vanillaHead.z=vanillaBody.z
    vanillaHead.rx=vanillaBody.rx; vanillaHead.ry=vanillaBody.ry; vanillaHead.rz=vanillaBody.rz
    head2.y=head2.base[1]+math.cos(b*2.0)/5.0*idle-math.cos(ls*2.0)/2.0*speed
    head2.rx=head2.base[3]+clampedPitch-pitch/(pi*2.0)-22.5*deg*speed-hurt/pi*2.0
    head2.ry=head2.base[4]+yaw+invYaw/2.0+math.cos(ls)/pi*(speed+0.25)
    head2.rz=head2.base[5]+math.cos(b)/(pi*5.0)*idle+math.sin(ls)/(pi*2.0)*speed

    for n in ('hair_left','hair_right'):
        hair=head2.child(n)
        if hair:
            hair.y=hair.base[1]+aggroSine+math.cos(b*2.0)/5.0*idle+math.cos(ls*2.0)*speed
            hair.rx=hair.base[3]-hurt/pi
            hair.rz=hair.base[5]+math.sin(b)/(pi*5.0)*idle-math.cos(ls)/(pi*2.0)*speed

    blink=pie_blink(age)
    animate_pie_eye(head2.child('left_eye'),'l_eye_white','l_pupil','l_eyebrow',blink,headYaw,headPitch,True)
    animate_pie_eye(head2.child('right_eye'),'r_eye_white','r_pupil','r_eyebrow',blink,headYaw,headPitch,False)

    stride=speed+0.25; quarter=pi/2.0; third=pi/3.0
    idlePitch=math.sin(b*2.0)/(pi*8.0)*idle
    legs=[find(root,'right_hind_leg'),find(root,'left_hind_leg'),find(root,'right_front_leg'),find(root,'left_front_leg')]
    for idx,leg in enumerate(legs,1):
        if not leg:continue
        if idx==1:
            x=-2.5+yaw/2.0
            y=18.0+max(-3.0,min(0.0,math.cos(0.25+ls+math.cos(quarter+ls)/2.0)))*3.0*speed+hurt
            z=4.0+yaw-math.sin(b*2.0)*pi/16.0*idle+math.sin(ls-math.sin(third+ls)/3.0)*2.0*stride
            xr=invYaw/pi+idlePitch+(20.0*deg+math.sin(0.5+ls+math.cos(quarter+ls)/2.0)*2.0/pi)*stride-hurt/pi
            yr=10.0*deg; zr=-2.0*deg+yaw/(pi*2.0)
        elif idx==2:
            x=2.5+yaw/2.0
            y=18.0+max(-3.0,min(0.0,-math.cos(0.25+ls-math.cos(quarter+ls)/2.0)))*3.0*speed+hurt
            z=4.0+invYaw-math.sin(b*2.0)*pi/16.0*idle-math.sin(ls-math.sin(-third+ls)/3.0)*2.0*stride
            xr=yaw/pi+idlePitch+(20.0*deg-math.sin(0.5+ls+math.cos(-quarter+ls)/2.0)*2.0/pi)*stride-hurt/pi
            yr=-10.0*deg; zr=2.0*deg+yaw/(pi*2.0)
        elif idx==3:
            x=2.5+invYaw/2.0
            y=18.0+max(-3.0,min(0.0,math.cos(0.25+ls-math.cos(-quarter+ls)/2.0)))*3.0*speed+hurt
            z=-4.0+invYaw+math.sin(b*2.0)*pi/16.0*idle+math.sin(ls+math.sin(-third+ls)/3.0)*2.0*stride
            xr=yaw/pi-idlePitch+(20.0*deg+math.sin(0.5+ls-math.cos(-quarter+ls)/2.0)*2.0/pi)*stride+hurt/pi
            yr=-10.0*deg; zr=2.0*deg+invYaw/(pi*2.0)
        else:
            x=-2.5+invYaw/2.0
            y=18.0+max(-3.0,min(0.0,-math.cos(0.25+ls-math.cos(quarter+ls)/2.0)))*3.0*speed+hurt
            z=-4.0+yaw+math.sin(b*2.0)*pi/16.0*idle-math.sin(ls+math.sin(third+ls)/3.0)*2.0*stride
            xr=invYaw/pi-idlePitch+(20.0*deg-math.sin(0.5+ls-math.cos(quarter+ls)/2.0)*2.0/pi)*stride+hurt/pi
            yr=10.0*deg; zr=-2.0*deg+invYaw/(pi*2.0)
        leg.x=x; leg.y=y; leg.z=z; leg.rx=xr; leg.ry=yr; leg.rz=zr

    if kind in ('bunny','bee'):
        tail=body.child('tail')
        if tail:
            tail.rx=tail.base[3]+20.0*deg*aggroSine
            tail.ry=tail.base[4]+math.sin(b)*2.0/pi*idle-math.sin(ls)*2.0/pi*speed
        left=head2.child('left_ear'); right=head2.child('right_ear')
        sourceEarBase=10.0*deg if kind=='bee' else 0.0
        if left:
            left.rx=left.base[3]+pitch/3.0+hurt/pi*3.0
            left.rz=left.base[5]+sourceEarBase+20.0*deg*aggroBack+math.cos(b)/(pi*2.0)*idle-math.cos(ls)*2.0/pi*speed
        if right:
            right.rx=right.base[3]+pitch/3.0+hurt/pi*3.0
            right.rz=right.base[5]-sourceEarBase-20.0*deg*aggroBack+math.cos(b)/(pi*2.0)*idle-math.cos(ls)*2.0/pi*speed
            if kind=='bunny':
                r2=right.child('right_ear2')
                if r2:
                    pf=max(-1.0,min(1.25,headPitch/90.0*2.0+1.0))
                    r2.rx=r2.base[3]+pitch/3.0+math.cos(b*2.0)/pi*(idle*pf)-math.sin(ls)*2.0/pi*(speed*pf)+hurt/pi*3.0
                    r2.rz=r2.base[5]+math.cos(b)/pi*idle-math.sin(ls)*2.0/pi*speed
    if kind=='bee':
        l=body.child('left_wings'); r=body.child('right_wings')
        if l:l.ry=l.base[4]+math.sin(b*2.0)/pi*idle+math.sin(ls*2.0)*2.0/pi*speed+math.cos(ls)/pi*speed
        if r:r.ry=r.base[4]-math.sin(b*2.0)/pi*idle-math.sin(ls*2.0)*2.0/pi*speed+math.cos(ls)/pi*speed

CAT_ANIM_DOC=json.loads((SRC/'reference-assets/cat/creeper.animation.json').read_text())
CAT_ANIM=CAT_ANIM_DOC['animations']['animation.creeper.legs']
CAT_ANIM_LENGTH=float(CAT_ANIM['animation_length'])

def cat_channel(bone, channel, component):
    raw=CAT_ANIM['bones'][bone][channel]
    out=[]; mode='linear'
    for k,v in raw.items():
        t=float(k)
        if isinstance(v,dict):
            if v.get('lerp_mode')=='catmullrom': mode='catmull'
            v=v.get('post',v.get('pre'))
        out.append((t,float(v[component])))
    return out,mode

CAT_CHANNELS={
    'body_y':cat_channel('Body','position',1),
    'upper_z':cat_channel('Upperbody','rotation',2),
    'upper_x':cat_channel('Upperbody','position',0),
    'upper_y':cat_channel('Upperbody','position',1),
    'breast_x':cat_channel('Breast','rotation',0),
    'head_z':cat_channel('head','rotation',2),
    'ear_l_z':cat_channel('earL','rotation',2),
    'ear_r_z':cat_channel('earL2','rotation',2),
    'tail_x':cat_channel('tail','rotation',0),
    'tail2_x':cat_channel('tail2','rotation',0),
    'blink':cat_channel('white','position',2),
}

def cat_sample(name,t):
    keys,mode=CAT_CHANNELS[name]
    t=t%CAT_ANIM_LENGTH
    if t>=keys[-1][0]: return keys[-1][1]
    i=0
    while i+1<len(keys) and t>=keys[i+1][0]: i+=1
    if i+1>=len(keys): return keys[-1][1]
    t0,v1=keys[i]; t1,v2=keys[i+1]
    u=0 if t1<=t0 else max(0,min(1,(t-t0)/(t1-t0)))
    if mode!='catmull': return v1+(v2-v1)*u
    last_unique=max(0,len(keys)-2)
    p0=keys[last_unique][1] if i==0 else keys[i-1][1]
    p1=v1; p2=v2
    p3=keys[i+2][1] if i+2<len(keys) else keys[1][1]
    u2=u*u; u3=u2*u
    return 0.5*((2*p1)+(-p0+p2)*u+(2*p0-5*p1+4*p2-p3)*u2+(-p0+3*p1-3*p2+p3)*u3)

def apply_anim(root:Part,kind:str,age:float,limbSwing:float,amount:float,headYaw=0.0,headPitch=0.0,
               cat_motion=None,cat_idle='none',cat_idle_elapsed=0.0,cat_left=True):
    root.reset(); vanilla_anim(root,limbSwing,amount,headYaw,headPitch)
    deg=math.pi/180
    if kind in ('female','bunny','bee'):
        apply_pie_source(root,kind,age,limbSwing,amount,headYaw,headPitch)
    elif kind=='cat':
        waist=find(root,'body','waist'); body=find(waist,'Body') if waist else None; upper=find(body,'Upperbody') if body else None; head=find(upper,'head') if upper else None
        if not (waist and body and upper and head): return
        seconds=age/20.0
        movement=max(0.0,min(1.0,amount))
        def smooth01(x):
            x=max(0.0,min(1.0,x)); return x*x*(3.0-2.0*x)
        def smooth_step(a,b,x):
            return 1.0 if b<=a and x>=b else (0.0 if b<=a else smooth01((x-a)/(b-a)))
        def lerp_angle(a,b,t):
            tau=math.tau; d=(b-a)%tau
            if d>math.pi:d-=tau
            return a+d*max(0.0,min(1.0,t))

        motion=(cat_motion or ('idle' if movement<0.03 else 'walk')).lower()
        creep=1.0 if motion=='creep' else 0.0
        walk=1.0 if motion=='walk' else 0.0
        run=1.0 if motion=='run' else 0.0
        swell=1.0 if motion=='swell' else 0.0
        sit=1.0 if motion=='sit' else 0.0
        move_sum=max(1e-4,creep+walk+run)
        creep_n,walk_n,run_n=creep/move_sum,walk/move_sum,run/move_sum
        movement_gate=smooth_step(0.015,0.20,movement)
        gait=max(0.0,min(1.0,(creep+walk+run)*movement_gate))
        cadence=0.56*creep_n+walk_n+1.58*run_n if (creep+walk+run)>1e-4 else 1.0
        phase=limbSwing*0.6662*cadence
        stride=math.sin(phase); double_stride=math.sin(phase*2.0)
        stride_energy=0.58*creep_n+walk_n+1.36*run_n
        lift_energy=0.52*creep_n+walk_n+1.22*run_n
        stance=0.76*creep_n+0.68*walk_n+0.50*run_n
        spine_flex=double_stride*(0.012*creep_n+0.030*walk_n+0.046*run_n)*gait
        pelvis_roll=stride*(0.010*creep_n+0.018*walk_n+0.030*run_n)*gait
        shoulder_roll=-stride*(0.014*creep_n+0.026*walk_n+0.036*run_n)*gait
        weight_shift=math.sin(phase+0.65)*(0.050*creep_n+0.085*walk_n+0.115*run_n)*gait
        step_bob=(0.5-0.5*math.cos(phase*2.0))*(0.040*creep_n+0.100*walk_n+0.155*run_n)*gait
        creep_crouch=creep*movement_gate; run_stretch=run*movement_gate

        body.y=body.base[1]-cat_sample('body_y',seconds)+step_bob+creep_crouch*0.24-run_stretch*0.05+swell*0.18+sit*0.85
        body.x=body.base[0]+weight_shift
        body.rx=body.base[3]-(0.010*creep_n+0.018*walk_n+0.026*run_n)*gait-spine_flex*0.55+swell*0.035+sit*0.080
        body.rz=body.base[5]+pelvis_roll
        upper.x=upper.base[0]+cat_sample('upper_x',seconds)-weight_shift*0.72
        upper.y=upper.base[1]-cat_sample('upper_y',seconds)+creep_crouch*0.18+sit*0.35
        upper.rx=upper.base[3]+spine_flex+swell*0.065-sit*0.035
        upper.rz=upper.base[5]+cat_sample('upper_z',seconds)*deg+shoulder_roll
        head.ry=head.base[4]+headYaw*deg
        head.rx=head.base[3]+headPitch*deg-spine_flex*0.82-swell*0.045
        head.y=head.base[1]+step_bob*0.22+creep_crouch*0.08+sit*0.25
        head.rz=head.base[5]+cat_sample('head_z',seconds)*deg-shoulder_roll*0.62
        breast=upper.child('Breast')
        if breast: breast.rx=breast.base[3]+cat_sample('breast_x',seconds)*deg+double_stride*(0.008*creep_n+0.018*walk_n+0.026*run_n)*gait
        tail=body.child('tail'); tail2=tail.child('tail2') if tail else None
        if tail:
            tail.rx=tail.base[3]+cat_sample('tail_x',seconds)*deg+math.sin(phase-0.45)*(0.028*creep_n+0.050*walk_n+0.070*run_n)*gait+swell*0.10
            tail.ry=tail.base[4]+math.sin(phase-0.70)*(0.035*creep_n+0.055*walk_n+0.080*run_n)*gait
            if tail2:
                tail2.rx=tail2.base[3]+cat_sample('tail2_x',seconds)*deg+math.sin(phase-1.08)*(0.070*creep_n+0.115*walk_n+0.155*run_n)*gait+swell*0.06
                tail2.ry=tail2.base[4]+math.sin(phase-1.30)*(0.060*creep_n+0.095*walk_n+0.130*run_n)*gait
            if sit>1e-4:
                tail.z=tail.base[2]+0.20
                tail.rx=tail.rx+(0.35-tail.rx)*sit
                tail.ry=tail.ry+(0.0-tail.ry)*sit
                tail.rz=tail.rz+(0.0-tail.rz)*sit
                if tail2:
                    tail2.rx=tail2.rx+(0.75-tail2.rx)*sit
                    tail2.ry=tail2.ry+(0.0-tail2.ry)*sit
                    tail2.rz=tail2.rz+(0.0-tail2.rz)*sit
        ears=head.child('Ears'); ear_l=ears.child('earL') if ears else None; ear_r=ears.child('earL2') if ears else None
        if ear_l: ear_l.rz=ear_l.base[5]+cat_sample('ear_l_z',seconds)*deg+double_stride*0.012*gait+swell*0.11
        if ear_r: ear_r.rz=ear_r.base[5]+cat_sample('ear_r_z',seconds)*deg-double_stride*0.012*gait-swell*0.11

        def cat_leg_ik(leg_name,lower_name,foot_name,leg_phase,hind):
            leg=waist.child(leg_name)
            if not leg:return
            lower=leg.child(lower_name); foot=lower.child(foot_name) if lower else None
            if not (lower and foot):return
            leg.x,leg.y,leg.z,leg.rx,leg.ry,leg.rz=leg.base
            lower.x,lower.y,lower.z,lower.rx,lower.ry,lower.rz=lower.base
            foot.x,foot.y,foot.z,foot.rx,foot.ry,foot.rz=foot.base
            if gait<=1e-4:return
            q=(leg_phase%math.tau)/math.tau
            stride_len=(2.45 if hind else 2.15)*movement*stride_energy
            ground=9.68 if hind else 7.72
            lift=(1.52 if hind else 1.30)*(0.45+0.55*movement)*lift_energy
            if q<stance:
                z=smooth01(q/stance); tz=-stride_len*0.5+stride_len*z; ty=ground+math.sin(z*math.pi)*0.040*gait
            else:
                z=smooth01((q-stance)/(1.0-stance)); arc=math.sin(z*math.pi); tz=stride_len*0.5-stride_len*z; ty=ground-lift*max(0.0,arc)**1.15
            udy,udz=5.25,1.75; ldy,ldz=(5.05,-0.25) if hind else (3.0,0.0)
            l1=math.hypot(udy,udz); l2=math.hypot(ldy,ldz); a1=math.atan2(udz,udy); a2=math.atan2(ldz,ldy)
            dist=max(abs(l1-l2)+0.08,min(l1+l2-0.08,math.hypot(ty,tz)))
            c=max(-1.0,min(1.0,(dist*dist-l1*l1-l2*l2)/(2*l1*l2)))
            knee=math.acos(c); target=math.atan2(tz,ty)
            ua=target-math.atan2(l2*math.sin(knee),l1+l2*math.cos(knee))-a1
            la=knee+a1-a2
            ua=max(-1.02 if hind else -0.96,min(0.24 if hind else 0.26,ua))
            la=max(0.38 if hind else 0.36,min(1.42 if hind else 1.36,la))
            paw=max(-0.92,min(0.46,-(ua+la)))
            leg.rx=ua; lower.rx=la; foot.rx=paw

        lh=phase+lerp_angle(0.0,0.00,run_n)
        lf=phase+lerp_angle(math.pi*0.5,math.pi*0.96,run_n)
        rh=phase+lerp_angle(math.pi,math.pi*0.28,run_n)
        rf=phase+lerp_angle(math.pi*1.5,math.pi*1.24,run_n)
        cat_leg_ik('leftLeg','leftlegsub2','leftfoot3',lf,False)
        cat_leg_ik('rightLeg','rightlegsub2','rightfoot3',rf,False)
        cat_leg_ik('leftLegback','leftlegsub','leftfoot2',lh,True)
        cat_leg_ik('rightLegback','rightlegsub','rightfoot2',rh,True)

        def pose_leg(leg_name,lower_name,foot_name,a,ut,lt,pt):
            leg=waist.child(leg_name); lower=leg.child(lower_name) if leg else None; foot=lower.child(foot_name) if lower else None
            if not (leg and lower and foot):return
            leg.rx=leg.rx+(ut-leg.rx)*a; lower.rx=lower.rx+(lt-lower.rx)*a; foot.rx=foot.rx+(pt-foot.rx)*a

        if sit>1e-4:
            pose_leg('leftLeg','leftlegsub2','leftfoot3',sit,-0.12,0.54,-0.28)
            pose_leg('rightLeg','rightlegsub2','rightfoot3',sit,-0.12,0.54,-0.28)
            pose_leg('leftLegback','leftlegsub','leftfoot2',sit,0.16,1.15,-0.72)
            pose_leg('rightLegback','rightlegsub','rightfoot2',sit,0.16,1.15,-0.72)

        idle_gate=max(0.0,min(1.0,1.0-creep-walk-run-swell-sit))
        idle=cat_idle.lower() if cat_idle else 'none'
        durations={'paw_lift':58.0,'tail_wag':72.0,'curious_look':62.0,'knead':80.0}
        if idle in durations and idle_gate>1e-4:
            u=max(0.0,min(1.0,cat_idle_elapsed/durations[idle]))
            envelope=smooth_step(0.0,0.16,u)*(1.0-smooth_step(0.82,1.0,u))*idle_gate
            side=1.0 if cat_left else -1.0
            if idle=='paw_lift':
                lift=max(0.0,math.sin(u*math.pi))**1.20*envelope
                if cat_left:
                    pose_leg('leftLeg','leftlegsub2','leftfoot3',lift,-0.58,0.96,-0.34); leg=waist.child('leftLeg')
                else:
                    pose_leg('rightLeg','rightlegsub2','rightfoot3',lift,-0.58,0.96,-0.34); leg=waist.child('rightLeg')
                if leg:leg.ry+=side*0.055*lift
                body.x-=side*0.10*lift; head.rz+=side*0.15*lift; head.ry+=side*0.07*lift
                if tail:tail.ry+=math.sin(u*math.pi*6.0)*0.10*envelope
                if tail2:tail2.ry+=math.sin(u*math.pi*6.0-0.65)*0.18*envelope
            elif idle=='tail_wag':
                phase=u*math.pi*4.15
                root_wave=(math.sin(phase)*0.82+math.sin(phase*0.47+0.85)*0.18)*envelope
                tip_wave=(math.sin(phase-0.72)*0.76+math.sin(phase*0.51+0.15)*0.24)*envelope
                fs=max(0.0,math.sin(phase*0.53+1.20)); flick=fs*fs*fs*envelope
                if tail:
                    tail.ry+=root_wave*0.135
                    tail.rx+=math.sin(phase*0.50+0.35)*0.010*envelope
                if tail2:
                    tail2.ry+=tip_wave*0.305+side*flick*0.055
                    tail2.rx+=math.sin(phase-1.05)*0.025*envelope
                    tail2.rz+=side*math.sin(phase*0.50-0.40)*0.018*envelope
                body.rz+=root_wave*0.008
                ear_twitch=math.sin(phase*0.50+1.55)*0.012*envelope
                if ear_l:ear_l.rz+=ear_twitch
                if ear_r:ear_r.rz-=ear_twitch
            elif idle=='curious_look':
                look=math.sin(u*math.pi)*envelope
                head.ry+=side*0.30*look; head.rz+=side*0.17*look; head.rx-=0.055*look
                twitch=math.sin(u*math.pi*7.0)*envelope
                if ear_l:ear_l.rz+=(0.06 if cat_left else 0.025)*twitch
                if ear_r:ear_r.rz-=(0.025 if cat_left else 0.06)*twitch
                if tail2:tail2.ry+=math.sin(u*math.pi*3.0-0.4)*0.11*envelope
            elif idle=='knead':
                wave=u*math.pi*6.0
                lp=smooth01(0.5+0.5*math.sin(wave-math.pi*0.5))*envelope
                rp=smooth01(0.5+0.5*math.sin(wave+math.pi*0.5))*envelope
                alt=lp-rp; settle=(lp+rp)*0.5
                ll=lp*0.72; rr=rp*0.72
                pose_leg('leftLeg','leftlegsub2','leftfoot3',ll,-0.30,0.74,-0.30)
                pose_leg('rightLeg','rightlegsub2','rightfoot3',rr,-0.30,0.74,-0.30)
                body.x+=alt*0.045; body.y+=settle*0.028
                head.rz-=alt*0.016; head.rx+=settle*0.014
                if tail:tail.ry+=math.sin(wave*0.34+0.35)*0.050*envelope
                if tail2:
                    tail2.ry+=math.sin(wave*0.34-0.45)*0.105*envelope
                    tail2.rx+=math.sin(wave*0.17+0.80)*0.012*envelope

        ba=max(0,min(1,cat_sample('blink',seconds)))
        for n in ('eye1','eye2'):
            e=head.child(n)
            if e:e.sy=max(0.06,1-ba*0.94)
    elif kind in ('cherry','blossom'):
        vanillaBody=find(root,'body')
        cemBody=vanillaBody.child('body') if vanillaBody else None
        rotation=cemBody.child('body_cherry_rotation') if cemBody else None
        cb=rotation.child('body_cherry') if rotation else None
        legs=rotation.child('cherrycreeper_legs') if rotation else None
        if not(vanillaBody and rotation and cb and legs): return
        idleSin=math.sin(age/7); idleCos=math.cos(age/7); limbSpeed=max(0,min(1,amount))*10
        # Normal showcase frames represent the source animation in its steady non-hurt state.
        # The dedicated formula-parity test separately exercises hurt_time and var.hurt transitions.
        hurtTime=0.0; hurtBlend=1.0
        walkRx=(-math.sin(limbSwing)/6.0)*limbSpeed/2.0*hurtBlend
        walk=min(0,(-math.sin(limbSwing+math.pi/2)+0.3)*limbSpeed/1.5)*hurtBlend
        minusWalk=min(0,(math.sin(limbSwing+math.pi/2)+0.3)*limbSpeed/1.5)*hurtBlend
        # Source body.ty=18 targets the original Creeper body proxy, not custom id=body.
        vanillaBody.y=18.0
        rotation.rz=-idleCos*2*deg
        legs.ry=headYaw/6*deg
        vals=[
            ('cherrycreeper_leg1',walkRx-hurtTime*4*deg,8*deg-idleCos*2*deg+hurtTime*3.5*deg,8*deg+idleSin*deg,walk),
            ('cherrycreeper_leg2',-walkRx-hurtTime*4*deg,-8*deg+idleCos*2*deg-hurtTime*3.5*deg,-8*deg-idleSin*deg,minusWalk),
            ('cherrycreeper_leg3',-walkRx-hurtTime*4*deg,-8*deg+idleSin*2*deg+hurtTime*3.5*deg,8*deg-idleCos*deg,minusWalk),
            ('cherrycreeper_leg4',walkRx-hurtTime*4*deg,-8*deg-idleSin*2*deg-hurtTime*3.5*deg,-8*deg+idleCos*deg,walk),
        ]
        for n,xr,yr,zr,yo in vals:
            p=legs.child(n)
            if p: p.rx=xr;p.ry=yr;p.rz=zr;p.y=-6+yo
        cb.x=idleSin*0.3
        cb.y=(-5.95)*(1-hurtBlend)+(-5.95-math.sin(limbSwing)*limbSpeed/7+limbSpeed*0.18)*hurtBlend
        cb.rx=idleCos*3.5*deg+headPitch/4*deg
        cb.ry=headYaw/4*deg-idleCos*2*deg+math.sin(limbSwing)*hurtTime*3*deg
        cb.rz=idleSin*2*deg+math.sin(limbSwing)*hurtTime*2*deg
        chest=cb.child('boobs')
        if chest:
            chest.rx=-5.5-idleSin*3*deg+math.sin(limbSwing+math.pi/4)*limbSpeed/58
            chest.ry=math.cos(limbSwing)*hurtTime*4*deg
            chest.rz=idleCos*6*deg+math.sin(limbSwing)*hurtTime*4*deg
            q=chest.child('bone3')
            if q:q.rx=-35*deg+math.cos(limbSwing/0.5)*hurtTime*6*deg-idleCos*16*deg
        q=cb.child('bone9')
        if q:q.rx=-140*deg-math.sin(limbSwing/0.5)*hurtTime*6*deg+idleCos*16*deg
        q=cb.child('bone15')
        if q:
            q.ry=-120*deg-math.sin(limbSwing/0.5)*hurtTime*6*deg-idleCos*6*deg
            q.rz=-220*deg-math.sin(limbSwing/0.5)*hurtTime*6*deg-idleSin*16*deg
        h=cb.child('head_cherry')
        if h:
            h.x=idleSin*16*deg; h.y=-12
            h.rx=idleSin*4*deg-headPitch/4*deg
            h.ry=headYaw/2.5*deg+math.cos(limbSwing)*hurtTime*2.5*deg
            h.rz=-idleCos*10*deg+headYaw/4*deg
            q=h.child('bone11')
            if q:
                q.rx=-idleCos*6*deg-math.sin(limbSwing)*hurtTime*2*deg
                q.rz=-idleSin*6*deg-math.cos(limbSwing)*hurtTime*3*deg
                q2=q.child('bone12')
                if q2:
                    q2.rx=177*deg-math.cos(limbSwing/0.5)*hurtTime*6*deg
                    q2.rz=190*deg+math.sin(limbSwing/0.5)*hurtTime*8*deg-idleSin*16*deg
            q=h.child('bone13')
            if q:
                q.rx=-idleCos*6*deg-math.sin(limbSwing)*hurtTime*3*deg
                q.rz=-idleSin*6*deg-math.cos(limbSwing)*hurtTime*4*deg
                q2=q.child('bone14')
                if q2:
                    q2.ry=290*deg+math.cos(limbSwing/0.5)*hurtTime*8*deg
                    q2.rz=-190*deg+math.sin(limbSwing/0.5)*hurtTime*6*deg-idleSin*16*deg
            face=h.child('head_cherry_face')
            if face:
                frame=int(math.floor(age/2.5))%21
                q=face.child('head_cherry_face_fr1');
                if q:q.visible=0<=frame<=17
                q=face.child('head_cherry_face_fr2');
                if q:q.visible=frame==18
                q=face.child('head_cherry_face_fr3');
                if q:q.visible=19<=frame<=20

# Standard Minecraft CubeListBuilder UV layout in texture-pixel units.
def face_data(c:Cube):
    x0=c.x-c.deform; x1=c.x+c.dx+c.deform
    y0=c.y-c.deform; y1=c.y+c.dy+c.deform
    z0=c.z-c.deform; z1=c.z+c.dz+c.deform
    u,v=c.u,c.v; dx,dy,dz=c.dx,c.dy,c.dz
    faces={
      'north': ([(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0)], (u+dz,v+dz,u+dz+dx,v+dz+dy)),
      'south': ([(x1,y0,z1),(x0,y0,z1),(x0,y1,z1),(x1,y1,z1)], (u+dz+dx+dz,v+dz,u+dz+dx+dz+dx,v+dz+dy)),
      'west': ([(x0,y0,z1),(x0,y0,z0),(x0,y1,z0),(x0,y1,z1)], (u+dz+dx,v+dz,u+dz+dx+dz,v+dz+dy)),
      'east': ([(x1,y0,z0),(x1,y0,z1),(x1,y1,z1),(x1,y1,z0)], (u,v+dz,u+dz,v+dz+dy)),
      'up': ([(x0,y0,z0),(x1,y0,z0),(x1,y0,z1),(x0,y0,z1)], (u+dz,v,u+dz+dx,v+dz)),
      'down': ([(x0,y1,z1),(x1,y1,z1),(x1,y1,z0),(x0,y1,z0)], (u+dz+dx,v,u+dz+dx+dx,v+dz)),
    }
    if c.mirror:
        # generated mirror() principally mirrors texture horizontally
        faces={k:(verts,(uv[2],uv[1],uv[0],uv[3])) for k,(verts,uv) in faces.items()}
    return faces

def cam_matrix(yaw_deg=-28,pitch_deg=10):
    y=math.radians(yaw_deg); p=math.radians(pitch_deg)
    cy,sy=math.cos(y),math.sin(y); cp,sp=math.cos(p),math.sin(p)
    Ry=np.array([[cy,0,sy], [0,1,0], [-sy,0,cy]],float)
    Rx=np.array([[1,0,0],[0,cp,-sp],[0,sp,cp]],float)
    return Rx@Ry

def texture_pixel(tex:Image.Image,u,v,tw,th):
    # layer UVs are in pixels of the declared texture size; actual source image matches it.
    x=max(0,min(tex.width-1,int(math.floor(u*tex.width/tw))))
    y=max(0,min(tex.height-1,int(math.floor(v*tex.height/th))))
    return tex.getpixel((x,y))

def build_polygons(root:Part,tex:Image.Image,tw:int,th:int,yaw=-28,pitch=10,subdivide=True):
    C=cam_matrix(yaw,pitch); polys=[]; allpts=[]
    light=np.array([-0.35,0.75,-0.55],float); light/=np.linalg.norm(light)
    def walk(p:Part,parentM):
        if not p.visible:return
        M=parentM@local_matrix(p)
        for cube in p.cubes:
            for fname,(verts,uv) in face_data(cube).items():
                arr=[]
                for vv in verts:
                    q=M@np.array([vv[0],vv[1],vv[2],1.0]); w=np.array([q[0],-q[1],q[2]]) # y-up
                    arr.append(w)
                arr=np.array(arr)
                # cull degenerate geometry only if area almost zero
                n=np.cross(arr[1]-arr[0],arr[2]-arr[0]); nl=np.linalg.norm(n)
                if nl<1e-7: continue
                n/=nl
                brightness=0.68+0.32*max(0,float(np.dot(n,light)))
                cam=np.array([C@w for w in arr]); allpts.extend(cam.tolist())
                u1,v1,u2,v2=uv
                # subdivide based on actual UV pixel span but cap to prevent excessive work
                nu=max(1,min(12,int(math.ceil(abs(u2-u1))))) if subdivide else 1
                nv=max(1,min(12,int(math.ceil(abs(v2-v1))))) if subdivide else 1
                # Bilinear interpolation corners. Texture orientation follows UV direction.
                p00,p10,p11,p01=cam
                for jj in range(nv):
                    t0=jj/nv;t1=(jj+1)/nv
                    vv0=v1+(v2-v1)*t0; vv1=v1+(v2-v1)*t1
                    for ii in range(nu):
                        s0=ii/nu;s1=(ii+1)/nu
                        uu0=u1+(u2-u1)*s0;uu1=u1+(u2-u1)*s1
                        # sample center in model texture pixel coordinates
                        rgba=texture_pixel(tex,(uu0+uu1)/2,(vv0+vv1)/2,tw,th)
                        if rgba[3] < 25: continue
                        rgb=tuple(max(0,min(255,int(c*brightness))) for c in rgba[:3])+(rgba[3],)
                        def interp(s,t): return (1-s)*(1-t)*p00+s*(1-t)*p10+s*t*p11+(1-s)*t*p01
                        qq=np.array([interp(s0,t0),interp(s1,t0),interp(s1,t1),interp(s0,t1)])
                        depth=float(qq[:,2].mean())
                        polys.append((depth,qq,rgb))
        for ch in p.children: walk(ch,M)
    walk(root,np.eye(4))
    return polys,np.array(allpts) if allpts else np.zeros((0,3))

def compute_view(root,tex,tw,th,kind,framespecs,size=(380,440),yaw=-28,pitch=10):
    mins=np.array([1e9,1e9]); maxs=np.array([-1e9,-1e9])
    for age,ls,amt,hy,hp in framespecs:
        apply_anim(root,kind,age,ls,amt,hy,hp)
        _,pts=build_polygons(root,tex,tw,th,yaw,pitch,subdivide=False)
        if len(pts):
            mins=np.minimum(mins,pts[:,:2].min(axis=0)); maxs=np.maximum(maxs,pts[:,:2].max(axis=0))
    center=(mins+maxs)/2; span=maxs-mins
    w,h=size; scale=min((w-30)/max(span[0],1),(h-30)/max(span[1],1))
    return center,scale

def _raster_triangle(canvas,zbuf,pts,rgba):
    # Orthographic triangle rasterizer with interpolated camera-space depth.
    # The camera convention in this renderer uses smaller Z as nearer.
    h,w,_=canvas.shape
    x0,y0,z0=pts[0]; x1,y1,z1=pts[1]; x2,y2,z2=pts[2]
    minx=max(0,int(math.floor(min(x0,x1,x2)))); maxx=min(w-1,int(math.ceil(max(x0,x1,x2))))
    miny=max(0,int(math.floor(min(y0,y1,y2)))); maxy=min(h-1,int(math.ceil(max(y0,y1,y2))))
    if minx>maxx or miny>maxy:return
    den=(y1-y2)*(x0-x2)+(x2-x1)*(y0-y2)
    if abs(den)<1e-9:return
    xs=np.arange(minx,maxx+1,dtype=float)+0.5
    ys=np.arange(miny,maxy+1,dtype=float)+0.5
    X,Y=np.meshgrid(xs,ys)
    a=((y1-y2)*(X-x2)+(x2-x1)*(Y-y2))/den
    b=((y2-y0)*(X-x2)+(x0-x2)*(Y-y2))/den
    c=1.0-a-b
    inside=(a>=-1e-7)&(b>=-1e-7)&(c>=-1e-7)
    if not inside.any():return
    Z=a*z0+b*z1+c*z2
    zz=zbuf[miny:maxy+1,minx:maxx+1]
    take=inside&(Z<zz)
    if not take.any():return
    zz[take]=Z[take]
    sub=canvas[miny:maxy+1,minx:maxx+1]
    src=np.array(rgba,dtype=np.uint8)
    if src[3]>=250:
        sub[take]=src
    else:
        # Alpha blend only where the textured fragment wins depth.
        alpha=float(src[3])/255.0
        dst=sub[take].astype(float)
        out=np.empty_like(dst)
        out[:,:3]=src[:3]*alpha+dst[:,:3]*(1-alpha)
        out[:,3]=np.maximum(src[3],dst[:,3])
        sub[take]=np.clip(out,0,255).astype(np.uint8)

def render_frame(root,tex,tw,th,kind,age,limbSwing,amount,view,size=(380,440),yaw=-28,pitch=10,bg=(0,0,0,0),
                 cat_motion=None,cat_idle='none',cat_idle_elapsed=0.0,cat_left=True):
    apply_anim(root,kind,age,limbSwing,amount,0,0,cat_motion=cat_motion,cat_idle=cat_idle,
               cat_idle_elapsed=cat_idle_elapsed,cat_left=cat_left)
    polys,_=build_polygons(root,tex,tw,th,yaw,pitch,subdivide=True)
    center,scale=view; w,h=size
    canvas=np.zeros((h,w,4),dtype=np.uint8)
    canvas[:]=np.array(bg,dtype=np.uint8)
    zbuf=np.full((h,w),np.inf,dtype=float)
    for _depth,q,rgba in polys:
        pts=np.array([[w/2+(p[0]-center[0])*scale,
                       h/2-(p[1]-center[1])*scale,
                       p[2]] for p in q],dtype=float)
        _raster_triangle(canvas,zbuf,pts[[0,1,2]],rgba)
        _raster_triangle(canvas,zbuf,pts[[0,2,3]],rgba)
    return Image.fromarray(canvas,'RGBA')

VARIANTS={
 'female': ('CreeperellaModelLayers.java','createFemaleLayer','female_creeper.png'),
 'bunny': ('CreeperellaModelLayers.java','createBunnyLayer','bunny_creeper.png'),
 'bee': ('CreeperellaModelLayers.java','createBeeLayer','bee_creeper.png'),
 'cherry': ('CherryRemakeModelLayers.java','createCherryLayer','cherry_creeper.png'),
 'blossom': ('CherryRemakeModelLayers.java','createCherryLayer','blossom_creeper.png'),
 'cat': ('CatCreeperModelLayers.java','createCatLayer','cat_creeper.png'),
}

def load_variant(kind):
    f,method,texname=VARIANTS[kind]
    root,tw,th=parse_layer(SRC/'src/main/java/dev/herbertofury/creeperella/client'/f,method)
    tex=Image.open(SRC/'src/main/resources/assets/creeperella/textures/entity'/texname).convert('RGBA')
    return root,tex,tw,th

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('kind',choices=VARIANTS);ap.add_argument('out');ap.add_argument('--age',type=float,default=20);ap.add_argument('--walk',type=float,default=0.0)
    a=ap.parse_args();root,tex,tw,th=load_variant(a.kind)
    specs=[(a.age,a.age*0.45,a.walk,0,0)]
    view=compute_view(root,tex,tw,th,a.kind,specs)
    im=render_frame(root,tex,tw,th,a.kind,a.age,a.age*0.45,a.walk,view)
    im.save(a.out)
