#!/usr/bin/env python3
"""Generate CatCreeperSourceAnimation.java from FemaleCreeper.mcpack animation JSON.

Only channels that address bones present in the shipped geometry are emitted. The pack's legacy
white/eyebrow/blink channels target bones absent from creeper.geo.json; the authored `white` Z pulse
is retained as the timing source for the Java eye-group compatibility blink.
"""
from __future__ import annotations
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ANIM = ROOT / 'reference-assets/cat/creeper.animation.json'
OUT = ROOT / 'src/main/java/dev/herbertofury/creeperella/client/CatCreeperSourceAnimation.java'
ANIM_NAME = 'animation.creeper.legs'


def ff(v: float) -> str:
    if abs(v) < 5e-8: v = 0.0
    s=f'{v:.6f}'.rstrip('0').rstrip('.')
    if '.' not in s: s += '.0'
    return s+'F'


def value_component(v, idx:int) -> float:
    if isinstance(v, dict):
        v = v.get('post', v.get('pre'))
    return float(v[idx])


def channel(data, bone:str, kind:str, idx:int):
    raw=data['bones'][bone][kind]
    if isinstance(raw, list):
        raise ValueError(f'{bone}.{kind} is expression/static list; expected keyframes')
    times=[]; vals=[]; mode='linear'
    for k,v in raw.items():
        times.append(float(k)); vals.append(value_component(v,idx))
        if isinstance(v,dict) and v.get('lerp_mode')=='catmullrom': mode='catmull'
    return times,vals,mode


def arr(name, vals):
    return f'    private static final float[] {name} = new float[]{{' + ', '.join(ff(v) for v in vals) + '};'


def main():
    doc=json.loads(ANIM.read_text(encoding='utf-8'))
    a=doc['animations'][ANIM_NAME]
    length=float(a['animation_length'])
    specs=[
        ('BODY_Y','Body','position',1),
        ('UPPER_Z','Upperbody','rotation',2),
        ('UPPER_X','Upperbody','position',0),
        ('UPPER_Y','Upperbody','position',1),
        ('BREAST_X','Breast','rotation',0),
        ('HEAD_Z','head','rotation',2),
        ('EAR_L_Z','earL','rotation',2),
        ('EAR_R_Z','earL2','rotation',2),
        ('TAIL_X','tail','rotation',0),
        ('TAIL2_X','tail2','rotation',0),
        ('BLINK_PULSE','white','position',2),
    ]
    channels={}
    for n,b,k,i in specs:
        channels[n]=channel(a,b,k,i)

    lines=[
        'package dev.herbertofury.creeperella.client;', '',
        'import net.minecraft.util.Mth;', '',
        '/**',
        ' * Generated directly from reference-assets/cat/creeper.animation.json in FemaleCreeper.mcpack.',
        ' * Bedrock-to-Java axis conversion is applied only at the public accessor boundary.',
        ' * Do not hand-edit; run tools/generate_cat_bedrock_animation.py.',
        ' */',
        'public final class CatCreeperSourceAnimation {',
        '    private CatCreeperSourceAnimation() {}',
        f'    public static final float LENGTH_SECONDS = {ff(length)};',
        '    private static final float DEG = (float)Math.PI / 180.0F;', '',
    ]
    for n,(t,v,m) in channels.items():
        lines.append(arr(n+'_T',t)); lines.append(arr(n+'_V',v));
    lines += ['',
        '    public static float loop(float seconds) {',
        '        float t = seconds % LENGTH_SECONDS;',
        '        return t < 0.0F ? t + LENGTH_SECONDS : t;',
        '    }', '',
        '    // Java ModelPart Y is down. This is the same Y conversion performed by',
        '    // KeyframeAnimations.posVec when Blockbench exports a modded-entity animation.',
        '    public static float bodyYOffset(float seconds) { return -linear(loop(seconds), BODY_Y_T, BODY_Y_V); }',
        '    public static float upperXOffset(float seconds) { return catmull(loop(seconds), UPPER_X_T, UPPER_X_V); }',
        '    public static float upperYOffset(float seconds) { return -catmull(loop(seconds), UPPER_Y_T, UPPER_Y_V); }',
        '    // Blockbench Bedrock import negates X/Y rotations and the Java animation exporter',
        '    // negates X/Y again. Net Bedrock -> Java authored rotation values keep their signs.',
        '    public static float upperZRot(float seconds) { return catmull(loop(seconds), UPPER_Z_T, UPPER_Z_V) * DEG; }',
        '    public static float breastXRot(float seconds) { return linear(loop(seconds), BREAST_X_T, BREAST_X_V) * DEG; }',
        '    public static float headZRot(float seconds) { return catmull(loop(seconds), HEAD_Z_T, HEAD_Z_V) * DEG; }',
        '    public static float earLZRot(float seconds) { return linear(loop(seconds), EAR_L_Z_T, EAR_L_Z_V) * DEG; }',
        '    public static float earRZRot(float seconds) { return linear(loop(seconds), EAR_R_Z_T, EAR_R_Z_V) * DEG; }',
        '    public static float tailXRot(float seconds) { return linear(loop(seconds), TAIL_X_T, TAIL_X_V) * DEG; }',
        '    public static float tail2XRot(float seconds) { return linear(loop(seconds), TAIL2_X_T, TAIL2_X_V) * DEG; }',
        '    public static float blinkPulse(float seconds) { return Mth.clamp(linear(loop(seconds), BLINK_PULSE_T, BLINK_PULSE_V), 0.0F, 1.0F); }', '',
        '    private static float linear(float t, float[] times, float[] values) {',
        '        int i = segment(t, times);',
        '        if (i >= times.length - 1) return values[values.length - 1];',
        '        float span = times[i + 1] - times[i];',
        '        if (span <= 0.000001F) return values[i];',
        '        return Mth.lerp(Mth.clamp((t - times[i]) / span, 0.0F, 1.0F), values[i], values[i + 1]);',
        '    }', '',
        '    private static float catmull(float t, float[] times, float[] values) {',
        '        int i = segment(t, times);',
        '        if (i >= times.length - 1) return values[values.length - 1];',
        '        float span = times[i + 1] - times[i];',
        '        float u = span <= 0.000001F ? 0.0F : Mth.clamp((t - times[i]) / span, 0.0F, 1.0F);',
        '        int lastUnique = values.length - 2; // final key duplicates loop start at animation length',
        '        int p0i = (i == 0) ? lastUnique : i - 1;',
        '        int p1i = i;',
        '        int p2i = i + 1;',
        '        int p3i = (i + 2 < values.length) ? i + 2 : 1;',
        '        return catmullValue(u, values[p0i], values[p1i], values[p2i], values[p3i]);',
        '    }', '',
        '    private static float catmullValue(float t, float p0, float p1, float p2, float p3) {',
        '        float t2 = t * t;',
        '        float t3 = t2 * t;',
        '        return 0.5F * ((2.0F * p1) + (-p0 + p2) * t',
        '                + (2.0F * p0 - 5.0F * p1 + 4.0F * p2 - p3) * t2',
        '                + (-p0 + 3.0F * p1 - 3.0F * p2 + p3) * t3);',
        '    }', '',
        '    private static int segment(float t, float[] times) {',
        '        for (int i = 0; i < times.length - 1; i++) {',
        '            if (t < times[i + 1]) return i;',
        '        }',
        '        return times.length - 1;',
        '    }',
        '}', ''
    ]
    OUT.write_text('\n'.join(lines),encoding='utf-8')
    print('Generated',OUT)

if __name__=='__main__': main()
