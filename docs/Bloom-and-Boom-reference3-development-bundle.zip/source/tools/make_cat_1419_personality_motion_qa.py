#!/usr/bin/env python3
from __future__ import annotations
import math, sys, shutil
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import render_mobs_visual_qa as r

OUT=Path('/mnt/data/Creeperella-1.4.19-Cat-Personality-Motion-QA');OUT.mkdir(parents=True,exist_ok=True)
BEFORE=OUT/'BEFORE-1.4.18';AFTER=OUT/'AFTER-1.4.19';BEFORE.mkdir(exist_ok=True);AFTER.mkdir(exist_ok=True)
BG=(8,13,24,255);W,H=280,300;BASE=258;SCALE=8.5;FRAMES=8
try:
    FONT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',14)
    SMALL=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
except Exception:
    FONT=ImageFont.load_default();SMALL=ImageFont.load_default()
MAP={'leftLeg':('leftlegsub2','leftfoot3',False),'rightLeg':('rightlegsub2','rightfoot3',False),'leftLegback':('leftlegsub','leftfoot2',True),'rightLegback':('rightlegsub','rightfoot2',True)}
def P(root,*p): return r.find(root,*p)

def solve_ik(hind,ty,tz):
    udy,udz=5.25,1.75; ldy,ldz=(5.05,-.25) if hind else (3.0,0.0)
    l1=math.hypot(udy,udz);l2=math.hypot(ldy,ldz);a1=math.atan2(udz,udy);a2=math.atan2(ldz,ldy)
    d=max(abs(l1-l2)+.08,min(l1+l2-.08,math.hypot(ty,tz)))
    k=math.acos(max(-1,min(1,(d*d-l1*l1-l2*l2)/(2*l1*l2))))
    ta=math.atan2(tz,ty);ua=ta-math.atan2(l2*math.sin(k),l1+l2*math.cos(k))-a1;la=k+a1-a2
    return ua,la,-(ua+la)
def leg_ik(root,n,ty,tz,dx,dy,dz,yaw,roll):
    ln,fn,hind=MAP[n];leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn);ua,la,pa=solve_ik(hind,ty,tz)
    leg.x+=dx;leg.y+=dy;leg.z+=dz;leg.rx=ua;leg.ry=yaw;leg.rz=roll;lo.rx=la;fo.rx=pa
def leg_adv(root,n,upper,lower,paw,yaw=0,roll=0,yoff=0):
    ln,fn,_=MAP[n];leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn);leg.y+=yoff;leg.rx=upper;leg.ry=yaw;leg.rz=roll;lo.rx=lower;fo.rx=paw
def rest_leg(root,row):
    n,dx,dy,dz,rx,ry,rz,lrx,frx=row;ln,fn,_=MAP[n];leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn);leg.x+=dx;leg.y+=dy;leg.z+=dz;leg.rx=rx;leg.ry=ry;leg.rz=rz;lo.rx=lrx;fo.rx=frx

def sit(root,v=0,new=True):
    style=v%4;w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head')
    w.y+=.61;b.y+=.82;b.rx+=.09;u.y+=.16;u.rx-=.07;h.rx-=.01
    if style==1:h.rx+=.06
    elif style==2:h.rz+=.055
    elif style==3:h.ry+=.085
    leg_ik(root,'leftLeg',7.50,-.05,.12,.25,0,0,.03);leg_ik(root,'rightLeg',7.50,-.05,-.12,.25,0,0,-.03)
    hr=8.83 if new else 6.70
    leg_ik(root,'leftLegback',hr,1.05,.62,.55,-.55,0,.22);leg_ik(root,'rightLegback',hr,1.05,-.62,.55,-.55,0,-.22)
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');side=1 if v%2==0 else -1;t.z+=.08;t.rx=.40;t.ry=0;t2.rx=.82;t2.ry=side*.20

def loaf(root,v=0,new=True):
    style=v%2;w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head')
    w.y+=.70;w.rx+=.25;b.y+=1.75;b.rx+=.45;u.y+=.65;u.rx-=.47;h.y+=.15;h.rx-=.23;h.rz+=(.025 if style==0 else -.025)
    fr=5.45 if new else 5.20;hr=8.15 if new else 5.55
    leg_ik(root,'leftLeg',fr,1.55,.22,.65,.60,0,.08);leg_ik(root,'rightLeg',fr,1.55,-.22,.65,.60,0,-.08);leg_ik(root,'leftLegback',hr,-.45,.40,.80,-.40,0,.10);leg_ik(root,'rightLegback',hr,-.45,-.40,.80,-.40,0,-.10)
    side=1 if style==0 else -1;t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.z+=.02;t.rx=.52;t.ry=(side*.12 if new else .12);t2.rx=1.02;t2.ry=(side*.28 if new else .28)

ROLL=[.82,.86,.80,.84];GY=[-2.8239,-3.8517,-2.5893,-3.0833];BL=[.05,.04,.06,.025];UL=[.025,.02,.03,.01];HL=[.008,.006,.01,.002];BP=[.12,.10,.14,.08];UP=[-.09,-.08,-.10,-.07];HP=[.01,0,.015,-.005];UY=[.29,.27,.31,.23];HY=[-.08,-.02,.08,-.28];HRY=[.14,.16,.12,.22]
LEGS=[[('leftLeg',2.0,1.4,-1.6,-.10,-.20,.72,.50,-.10),('rightLeg',4.0,1.7,-.4,-.58,-.10,.54,1.35,-.35),('leftLegback',2.4,1.6,1.2,.55,.12,.82,1.40,-.45),('rightLegback',4.3,1.8,.4,.28,.06,.60,1.25,-.30)],[('leftLeg',2.8,1.3,-2.2,.05,-.24,.86,.38,-.05),('rightLeg',4.4,1.8,-.2,-.65,-.10,.52,1.42,-.38),('leftLegback',3.0,1.6,1.6,.62,.12,.96,1.46,-.48),('rightLegback',4.7,1.9,.5,.30,.06,.62,1.28,-.30)],[('leftLeg',1.8,1.4,-1.2,-.22,-.16,.70,.78,-.18),('rightLeg',3.8,1.8,-.2,-.62,-.08,.50,1.38,-.35),('leftLegback',2.8,1.7,1.8,.70,.12,1.02,1.50,-.52),('rightLegback',4.6,2.0,.7,.34,.05,.62,1.30,-.32)],[('leftLeg',2.4,1.2,-1.8,-.02,-.22,.78,.46,-.08),('rightLeg',4.2,1.6,-.5,-.52,-.12,.58,1.25,-.30),('leftLegback',2.5,1.5,1.3,.50,.14,.88,1.36,-.40),('rightLegback',4.4,1.8,.4,.25,.06,.60,1.20,-.28)]]
def side_lie(root,v=0,new=True):
    w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head');roll=ROLL[v]
    w.y+=GY[v];w.rz+=roll;b.y+=1.15;b.rx+=BP[v];b.rz+=-roll+BL[v];u.y+=UY[v];u.rx+=UP[v];u.rz+=UL[v]-BL[v];h.y+=HY[v];h.rx+=HP[v];h.ry+=HRY[v];h.rz+=HL[v]-UL[v]
    for row in LEGS[v]:rest_leg(root,row)
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.rx=.28;t.ry=-.08;t2.rx=.58;t2.ry=-.04

def sit2(root,v=0,new=True):
    side=1 if v%2==0 else -1;w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head');w.y+=.89;b.y+=1.40;b.rx+=.16;u.y+=.28;u.rx-=.08;h.rx+=.01;h.rz+=side*.035
    leg_ik(root,'leftLeg',6.90,-1.60,1.50,.35,0,.18,.42);leg_ik(root,'rightLeg',6.90,-1.60,-1.50,.35,0,-.18,-.42);leg_ik(root,'leftLegback',8.72,1.60,2.00,.50,0,.08,.42);leg_ik(root,'rightLegback',8.72,1.60,-2.00,.50,0,-.08,-.42)
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.z+=.16;t.rx=.24;t.ry=0;t2.rx=.50;t2.ry=side*.10

def sprawl(root,v=0,new=True):
    side=1 if v%2==0 else -1;w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head');w.y+=6.28;b.y+=.30;b.rx+=1.48;u.y+=.05;u.rx-=1.18;h.rx-=.28;h.rz+=side*.020
    front_paw=.30 if new else -.02;hy=1.35 if new else 0.0
    leg_adv(root,'leftLeg',-1.46,.02,front_paw,0,.03,0);leg_adv(root,'rightLeg',-1.46,.02,front_paw,0,-.03,0);leg_adv(root,'leftLegback',1.34,.02,-.02,0,.015,hy);leg_adv(root,'rightLegback',1.34,.02,-.02,0,-.015,hy)
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.z+=.10;t.rx=-.50;t.ry=0;t2.rx=-.15;t2.ry=0

def tail_life(root,pose,variant,age,entity_id=8):
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');seed=(entity_id&31)*.37+variant*.61;slow=math.sin(age*.085+seed);drift=math.sin(age*.137+seed*1.63+.80);wave=slow*.72+drift*.28;pitch=math.sin(age*.103+seed+1.15)
    amps={'SIT':(.040,.105,.010),'LOAF':(.016,.050,.005),'SIDE_LIE':(.012,.040,.004),'SIT_2':(.032,.085,.008),'SPRAWL':(.012,.045,.005)};ra,ta,pa=amps[pose];t.ry+=wave*ra;t2.ry+=wave*ta;t2.rx+=pitch*pa

def standing_ground(age=40):
    root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',age,0,0,0,0,cat_motion='idle');_,pts=r.build_polygons(root,tex,tw,th,0,0,subdivide=False);return float(pts[:,1].min())
GROUND=standing_ground()
def wm(part):
    chain=[];p=part
    while p is not None:chain.append(p);p=p.parent
    M=np.eye(4)
    for q in reversed(chain):M=M@r.local_matrix(q)
    return M
def part_bottom(part):
    M=wm(part);ys=[]
    for c in part.cubes:
        for x in (c.x-c.deform,c.x+c.dx+c.deform):
            for y in (c.y-c.deform,c.y+c.dy+c.deform):
                for z in (c.z-c.deform,c.z+c.dz+c.deform):ys.append(float(-(M@np.array([x,y,z,1.0]))[1]))
    return min(ys) if ys else 999.0
def foot_delta(root,n):
    ln,fn,_=MAP[n];return part_bottom(P(root,'body','waist',n,ln,fn))-GROUND
def tail_delta(root):
    return min(part_bottom(P(root,'body','waist','Body','tail')),part_bottom(P(root,'body','waist','Body','tail','tail2')))-GROUND

def make_pose(name,fn,v,age=42,new=True,tail=True,entity_id=8):
    root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',age,0,0,0,0,cat_motion='sit');fn(root,v,new)
    if new and tail:tail_life(root,name,v,age,entity_id)
    return root,tex,tw,th

def render(root,tex,tw,th,yaw,label,pitch=5,detail=False):
    _,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=pitch,subdivide=detail);mnx,mxx=pts[:,0].min(),pts[:,0].max();cx=(mnx+mxx)/2;xo=W/2-cx*SCALE;yo=BASE+GROUND*SCALE
    can=np.zeros((H,W,4),dtype=np.uint8);can[:]=np.array(BG,dtype=np.uint8);im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);d.rounded_rectangle((10,BASE-4,W-10,BASE+8),radius=6,fill=(12,22,40,230));d.line((10,BASE,W-10,BASE),fill=(115,145,195,255),width=2);can=np.array(im);z=np.full((H,W),np.inf)
    polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=pitch,subdivide=detail)
    for _,q,rgba in polys:
        pp=np.array([[xo+p[0]*SCALE,yo-p[1]*SCALE,p[2]] for p in q],dtype=float);r._raster_triangle(can,z,pp[[0,1,2]],rgba);r._raster_triangle(can,z,pp[[0,2,3]],rgba)
    im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);bb=d.textbbox((0,0),label,font=SMALL);tx=(W-(bb[2]-bb[0]))//2;d.rounded_rectangle((tx-6,8,tx+(bb[2]-bb[0])+6,29),radius=6,fill=(15,22,38,225),outline=(105,125,165,255));d.text((tx,11),label,font=SMALL,fill=(241,244,255));return im


POSES=[('SIT',sit,4),('SIT_2',sit2,2),('LOAF',loaf,2),('SIDE_LIE',side_lie,4),('SPRAWL',sprawl,2)]

def smooth01(x):
    x=max(0.0,min(1.0,x)); return x*x*(3.0-2.0*x)
def smooth_step(a,b,x):
    return smooth01((x-a)/(b-a)) if b>a else (1.0 if x>=b else 0.0)
def personality_env(elapsed,duration):
    u=max(0.0,min(1.0,elapsed/duration)); return u,smooth_step(0,.16,u)*(1-smooth_step(.82,1,u))

def old_tail_wag(root,elapsed,left=True):
    u,e=personality_env(elapsed,72.0); wag=math.sin(u*math.pi*8.0)*e
    b=P(root,'body','waist','Body');t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');h=P(root,'body','waist','Body','Upperbody','head');ears=h.child('Ears');el=ears.child('earL');er=ears.child('earL2')
    t.ry+=wag*.24;t2.ry+=math.sin(u*math.pi*8-.72)*.38*e;b.rz+=wag*.018
    el.rz+=math.sin(u*math.pi*4)*.028*e;er.rz-=math.sin(u*math.pi*4)*.028*e

def new_tail_wag(root,elapsed,left=True):
    u,e=personality_env(elapsed,72.0);side=1 if left else -1;phase=u*math.pi*4.15
    rw=(math.sin(phase)*.82+math.sin(phase*.47+.85)*.18)*e
    tw=(math.sin(phase-.72)*.76+math.sin(phase*.51+.15)*.24)*e
    fs=max(0.0,math.sin(phase*.53+1.20));flick=fs**3*e
    b=P(root,'body','waist','Body');t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');h=P(root,'body','waist','Body','Upperbody','head');ears=h.child('Ears');el=ears.child('earL');er=ears.child('earL2')
    t.ry+=rw*.135;t.rx+=math.sin(phase*.50+.35)*.010*e
    t2.ry+=tw*.305+side*flick*.055;t2.rx+=math.sin(phase-1.05)*.025*e
    b.rz+=rw*.008;et=math.sin(phase*.50+1.55)*.012*e;el.rz+=et;er.rz-=et

def old_loaf_knead(root,elapsed):
    u,e=personality_env(elapsed,80.0);wave=u*math.pi*6;ll=max(0,math.sin(wave))*e;rr=max(0,math.sin(wave+math.pi))*e
    # exact 1.4.18 loaf personality override
    def blend_leg(n,ln,fn,a):
        leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn)
        leg.rx+=( -.52-leg.rx)*(a*.42);lo.rx+=(2.05-lo.rx)*(a*.42);fo.rx+=(-1.52-fo.rx)*(a*.42)
    blend_leg('leftLeg','leftlegsub2','leftfoot3',ll);blend_leg('rightLeg','rightlegsub2','rightfoot3',rr)
    b=P(root,'body','waist','Body');h=P(root,'body','waist','Body','Upperbody','head');t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2')
    b.y+=(ll+rr)*.018;h.rx+=(ll+rr)*.010;t.ry+=math.sin(wave*.5)*.08*e;t2.ry+=math.sin(wave*.5-.55)*.14*e

def new_loaf_knead(root,elapsed):
    u,e=personality_env(elapsed,80.0);wave=u*math.pi*6
    pulse=math.sin(wave);lp=smooth01(max(0.0,pulse))*e;rp=smooth01(max(0.0,-pulse))*e;alt=lp-rp;settle=(lp+rp)*.5
    for n,ln,fn,pr in [('leftLeg','leftlegsub2','leftfoot3',lp),('rightLeg','rightlegsub2','rightfoot3',rp)]:
        leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn);leg.rx+=pr*.035;lo.rx+=pr*.070;fo.rx-=pr*.095;fo.y+=pr*.055
    b=P(root,'body','waist','Body');h=P(root,'body','waist','Body','Upperbody','head');t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2')
    b.x+=alt*.030;b.y+=settle*.016;h.rz-=alt*.012;h.rx+=settle*.008;t.ry+=math.sin(wave*.34+.35)*.050*e;t2.ry+=math.sin(wave*.34-.45)*.105*e;t2.rx+=math.sin(wave*.17+.80)*.012*e

def base_pose(name,fn,v,age):
    root,tex,tw,th=make_pose(name,fn,v,age,True,True,8); return root,tex,tw,th

def save_true_duration_compare(name,fn,variant,kind):
    duration=72 if kind=='tail' else 80; frames=[]
    # one frame per 4 game ticks => 5 fps, exact wall-clock duration
    for tick in range(0,duration,4):
        age=40+tick
        lroot,tex,tw,th=base_pose(name,fn,variant,age); rroot,_,_,_=base_pose(name,fn,variant,age)
        if kind=='tail': old_tail_wag(lroot,tick);new_tail_wag(rroot,tick)
        else: old_loaf_knead(lroot,tick);new_loaf_knead(rroot,tick)
        left=render(lroot,tex,tw,th,-28,f'1.4.18 · {name} · {kind.upper()} · BEFORE')
        right=render(rroot,tex,tw,th,-28,f'1.4.19 · {name} · {kind.upper()} · AFTER')
        c=Image.new('RGBA',(W*2,H),BG);c.alpha_composite(left,(0,0));c.alpha_composite(right,(W,0));frames.append(c)
    out=OUT/f'Cat-Creeper-1.4.18-vs-1.4.19-{name}-{kind}-True-Duration.gif';frames[0].save(out,save_all=True,append_images=frames[1:],duration=200,loop=0,disposal=2,optimize=False);return out

def save_tail_pose(name,fn,v):
    frames=[]
    for tick in range(0,72,4):
        age=40+tick;root,tex,tw,th=base_pose(name,fn,v,age);new_tail_wag(root,tick);frames.append(render(root,tex,tw,th,-28,f'1.4.19 · {name} · TAIL WAG · {tick/20:.1f}s'))
    out=AFTER/f'Cat-Creeper-1.4.19-{name}-Tail-Wag-True-Duration.gif';frames[0].save(out,save_all=True,append_images=frames[1:],duration=200,loop=0,disposal=2,optimize=False);return out

cmp_tail=save_true_duration_compare('SIT',sit,0,'tail')
cmp_knead=save_true_duration_compare('LOAF',loaf,0,'knead')
for name,fn,count in POSES: save_tail_pose(name,fn,0)

# Multi-phase diagnostic for knead paw contact and tail envelope.
frames=[]; contact=[]
for tick in range(0,80,4):
    age=40+tick;root,tex,tw,th=base_pose('LOAF',loaf,0,age);new_loaf_knead(root,tick)
    frames.append(render(root,tex,tw,th,-28,f'1.4.19 · LOAF KNEAD · {tick/20:.1f}s'))
    contact.append((tick,foot_delta(root,'leftLeg'),foot_delta(root,'rightLeg'),tail_delta(root)))
kout=AFTER/'Cat-Creeper-1.4.19-LOAF-Knead-True-Duration.gif';frames[0].save(kout,save_all=True,append_images=frames[1:],duration=200,loop=0,disposal=2,optimize=False)

sheet=Image.new('RGBA',(4*W,2*H),BG)
for col,tick in enumerate((12,28,44,60)):
    root,tex,tw,th=base_pose('SIT',sit,0,40+tick);new_tail_wag(root,tick);sheet.alpha_composite(render(root,tex,tw,th,180,f'TAIL WAG · {tick/20:.1f}s · BACK',detail=True),(col*W,0))
    root,tex,tw,th=base_pose('LOAF',loaf,0,40+tick);new_loaf_knead(root,tick);sheet.alpha_composite(render(root,tex,tw,th,-28,f'KNEAD · {tick/20:.1f}s · 3Q',detail=True),(col*W,H))
sheet_path=OUT/'Creeperella-1.4.19-Tail-Wag-Knead-Keyframes.png';sheet.save(sheet_path)

report=OUT/'PERSONALITY_MOTION_QA.txt'
report.write_text('\n'.join([
    'Creeperella 1.4.19 personality motion QA',
    'TAIL_WAG duration=72 ticks / 3.6s, rendered every 4 ticks at 200ms/frame (true duration)',
    'KNEAD duration=80 ticks / 4.0s, rendered every 4 ticks at 200ms/frame (true duration)',
    f'LOAF knead left paw ground delta min={min(x[1] for x in contact):.6f} max={max(x[1] for x in contact):.6f}',
    f'LOAF knead right paw ground delta min={min(x[2] for x in contact):.6f} max={max(x[2] for x in contact):.6f}',
    f'LOAF knead nearest support paw delta max={max(min(x[1], x[2]) for x in contact):.6f}',
    f'LOAF knead nearest support paw delta min={min(min(x[1], x[2]) for x in contact):.6f}',
    f'LOAF knead tail ground delta min={min(x[3] for x in contact):.6f}',
    f'LOAF knead support gate={"PASS" if max(min(x[1], x[2]) for x in contact) <= 0.115 else "FAIL"} (at least one forepaw remains within 0.115 of fixed ground each sampled frame)',
    'QA acceptance: actual rest pose + ambient tail life + personality layer; fixed world-space standing ground; no generated imagery.'
])+'\n',encoding='utf-8')
(OUT/'README.md').write_text('''# Creeperella 1.4.19 Cat personality motion QA\n\nDeterministic QA from the actual Cat Creeper source model/texture and runtime-equivalent 1.4.19 personality curves. No image generation.\n\nThe old 1.4.18 tail-wag/knead reels were temporally misleading because they compressed long clips into only a handful of frames. This package renders one frame every four game ticks at 200 ms/frame, so 72-tick Tail Wag lasts 3.6 s and 80-tick Knead lasts 4.0 s. Tail Wag is checked on every rest family. LOAF kneading is layered on top of the grounded loaf and numerically checked against the fixed standing-paw ground plane.\n''',encoding='utf-8')
print(cmp_tail);print(cmp_knead);print(kout);print(sheet_path);print(report.read_text())
