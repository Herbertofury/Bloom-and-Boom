#!/usr/bin/env python3
"""Regression gate for the real-client Cat rest transform accumulator fixed after native Forge QA."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL = (ROOT / 'src/main/java/dev/herbertofury/creeperella/client/CreeperellaModel.java').read_text()

animate_start = MODEL.index('private void animateCatSource')
pose_start = MODEL.index('private static void animateCatLegIk', animate_start)
section = MODEL[animate_start:pose_start]
reset = section.index('waist.resetPose();')
first_waist_mutation_candidates = [
    section.find('applyCatSitPose('),
    section.find('applyCatSit2Pose('),
    section.find('applyCatLoafPose('),
    section.find('applyCatSideLiePose('),
    section.find('applyCatSprawlPose('),
]
assert all(i >= 0 for i in first_waist_mutation_candidates), 'rest pose dispatch missing'
assert reset < min(first_waist_mutation_candidates), 'waist bind pose must reset before rest transforms'
assert section.count('waist.resetPose();') == 1, 'Cat frame should have one deterministic waist reset'

# CreeperModel.setupAnim only drives the vanilla head/legs; the custom Cat waist is therefore a
# persistent mutable parent and every function below mutates it. This guard exists specifically so
# future refactors cannot reintroduce native per-frame drift while offline geometry tests still pass.
for fn in ('applyCatSitPose', 'applyCatLoafPose', 'applyCatSideLiePose', 'applyCatSit2Pose', 'applyCatSprawlPose'):
    start = MODEL.index(f'private static void {fn}')
    end = MODEL.find('\n    private static ', start + 1)
    body = MODEL[start:end if end != -1 else None]
    assert 'waist.' in body, f'{fn} unexpectedly no longer mutates waist; revisit this regression gate'

print('PASS: native Cat custom waist resets to its authored bind pose before every rest-frame transform')
print('PASS: all five rest families remain covered by the accumulator regression gate')
