#!/usr/bin/env python3
"""Froglight-only sparse additive charge masks. Keeps other families' exact assets."""
from pathlib import Path
from PIL import Image
T=Path(__file__).resolve().parents[1]/'src/main/resources/assets/creeperella/textures/entity'
for name,color in [('nacrella',(125,85,155)),('verdalia',(90,145,75)),('mariglow',(155,120,45))]:
 im=Image.new('RGBA',(128,64))
 for y in range(64):
  bend=(0,1,2,1,0,-1,-2,-1)[(y//4)%8]
  for x in range(128):
   phase=(x+y//2+bend)%32
   if phase in (0,1):im.putpixel((x,y),(*color,190))
   elif phase in (2,31):im.putpixel((x,y),(*(v//3 for v in color),90))
 im.save(T/f'{name}_charge.png')
