from pathlib import Path
r=Path(__file__).resolve().parents[1]/"src/main/java/dev/herbertofury/creeperella/client"
m=(r/"CreeperellaModel.java").read_text();a=(r/"NacrellaAccessoryLayer.java").read_text()
assert "referenceEyeOpenness(left)" in a and "referenceEyeGaze(left)" in a
assert "white.yScale" in m and "pupil.getInitialPose().x" in m
blink=a[a.index("private void animateReferenceBlink"):a.index("private static void animateTassel")]
assert "positiveModulo" not in blink and "entityId" not in blink
assert "pupil.x += gaze" in blink
print("PASS: reference-sized Froglight eyes consume existing Pie blink/gaze instead of a second animation clock")

assert 'TASSEL_COUNT = 12' in a and 'ring_blossom_' in a
assert 'texOffs(3,3)' in a, 'iris must sample its colored interior'
assert 'mouth_zone_mask' not in a, 'obsolete chin plate returned'
renderer=(r/"CreeperellaRenderer.java").read_text()
assert 'case MARIGLOW, VERDALIA, NACRELLA -> 15' in renderer
assert 'default -> super.getBlockLightLevel(entity, position)' in renderer
print("PASS: full-head crown and twelve chains exist; colored iris sampling and Froglight-only self-light are retained")

assert 'RenderType.entityTranslucent(this.lanternGlass)' in a
assert 'entity,false);' in a, 'curved petals must not be redundantly drawn in glow pass'

mesh=(r/"FroglightPetalMesh.java").read_text()
for name in ("roof_back_l","roof_back_r","roof_front"):
 assert name in a and name in mesh, f"Missing native-observed roof-gap correction: {name}"
print("PASS: additional roof blossoms are defined and submitted by the curved-petal renderer")
