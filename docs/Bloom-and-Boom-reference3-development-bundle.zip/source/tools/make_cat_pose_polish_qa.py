#!/usr/bin/env python3
from __future__ import annotations
import math, sys, shutil
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import render_mobs_visual_qa as r

OUT=Path('/mnt/data/Creeperella-1.4.15-Cat-Pose-Polish-QA'); OUT.mkdir(parents=True,exist_ok=True)
BEFORE=OUT/'BEFORE-1.4.14'; AFTER=OUT/'AFTER-1.4.15'; BEFORE.mkdir(exist_ok=True); AFTER.mkdir(exist_ok=True)
BG=(8,13,24,255); W,H=330,330; BASE=286; FRAMES=12
try:
    FONT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',14)
    SMALL=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
except Exception:
    FONT=ImageFont.load_default(); SMALL=ImageFont.load_default()
MAP={'leftLeg':('leftlegsub2','leftfoot3',False),'rightLeg':('rightlegsub2','rightfoot3',False),'leftLegback':('leftlegsub','leftfoot2',True),'rightLegback':('rightlegsub','rightfoot2',True)}
def P(root,*p): return r.find(root,*p)

def solve_ik(hind,ty,tz):
    udy,udz=5.25,1.75; ldy,ldz=(5.05,-.25) if hind else (3.0,0.0)
    l1=math.hypot(udy,udz); l2=math.hypot(ldy,ldz); a1=math.atan2(udz,udy); a2=math.atan2(ldz,ldy)
    d=math.hypot(ty,tz); d=max(abs(l1-l2)+.08,min(l1+l2-.08,d)); ck=max(-1,min(1,(d*d-l1*l1-l2*l2)/(2*l1*l2))); knee=math.acos(ck)
    ta=math.atan2(tz,ty); ua=ta-math.atan2(l2*math.sin(knee),l1+l2*math.cos(knee))-a1; la=knee+a1-a2; pa=-(ua+la)
    return ua,la,pa

def leg_adv(root,n,upper,lower,paw,yaw=0,roll=0):
    ln,fn,_=MAP[n]; leg=P(root,'body','waist',n); lo=P(root,'body','waist',n,ln); fo=P(root,'body','waist',n,ln,fn)
    leg.rx=upper;leg.ry=yaw;leg.rz=roll;lo.rx=lower;fo.rx=paw

def leg_ik(root,n,ty,tz,dx,dy,dz,yaw,roll):
    ln,fn,hind=MAP[n]; leg=P(root,'body','waist',n); lo=P(root,'body','waist',n,ln); fo=P(root,'body','waist',n,ln,fn); ua,la,pa=solve_ik(hind,ty,tz)
    leg.x+=dx;leg.y+=dy;leg.z+=dz;leg.rx=ua;leg.ry=yaw;leg.rz=roll;lo.rx=la;fo.rx=pa

def rest_leg(root,row):
    n,dx,dy,dz,rx,ry,rz,lrx,frx=row; ln,fn,_=MAP[n]; leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn)
    leg.x+=dx;leg.y+=dy;leg.z+=dz;leg.rx=rx;leg.ry=ry;leg.rz=rz;lo.rx=lrx;fo.rx=frx

def old_sit(root,v=0):
    b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head');b.y+=.20;b.rx+=.05;u.rx-=.05
    if v==1:h.rx+=.08
    elif v==2:h.rz+=.08
    elif v==3:h.ry+=.10
    for n in ('leftLeg','rightLeg'):leg_adv(root,n,-.18,.56,-.30)
    for n in ('leftLegback','rightLegback'):leg_adv(root,n,.22,1.16,-.74)
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.z+=.12;t.rx=.18;t.ry=0;t2.rx=.42;t2.ry=0

def old_loaf(root,v=0):
    b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head');b.y+=.95;b.rx+=.18;u.y+=.35;u.rx-=.10;h.y+=.12;h.rx+=(.14 if v==0 else -.04);h.rz+=(.04 if v==0 else -.04)
    leg_adv(root,'leftLeg',-.46,1.10,-.54,0,.04);leg_adv(root,'rightLeg',-.46,1.10,-.54,0,-.04);leg_adv(root,'leftLegback',.82,1.38,-1.02,0,.04);leg_adv(root,'rightLegback',.82,1.38,-1.02,0,-.04)
    side=1 if v%2==0 else -1;t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.rx=.28;t.ry=side*.20;t2.rx=.58;t2.ry=side*.16

def old_sprawl(root,v=0):
    side=1 if v%2==0 else -1;b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head');b.y+=1.15;b.rx+=.28;u.y+=.25;u.rx-=.08;h.rx+=.02;h.rz+=side*.06
    leg_adv(root,'leftLeg',-.36,.78,-.20,-.18,.28);leg_adv(root,'rightLeg',-.36,.78,-.20,.18,-.28);leg_adv(root,'leftLegback',.28,1.02,-.34,-.20,.22);leg_adv(root,'rightLegback',.28,1.02,-.34,.20,-.22)
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.rx=.10;t.ry=0;t2.rx=.25;t2.ry=0

def new_sit(root,v=0):
    w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head');style=v%4
    w.y+=.61;b.y+=.82;b.rx+=.09;u.y+=.16;u.rx-=.07;h.rx-=.01
    if style==1:h.rx+=.06
    elif style==2:h.rz+=.055
    elif style==3:h.ry+=.085
    leg_ik(root,'leftLeg',7.50,-.05,.12,.25,0,0,.03);leg_ik(root,'rightLeg',7.50,-.05,-.12,.25,0,0,-.03);leg_ik(root,'leftLegback',6.70,1.05,.62,.55,-.55,0,.22);leg_ik(root,'rightLegback',6.70,1.05,-.62,.55,-.55,0,-.22)
    side=1;t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.z+=.08;t.rx=.40;t.ry=0;t.rz=0;t2.rx=.82;t2.ry=side*.20;t2.rz=0

def new_loaf(root,v=0):
    style=v%2;w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head')
    w.y+=.70;w.rx+=.25;b.y+=1.75;b.rx+=.45;u.y+=.65;u.rx-=.47;h.y+=.15;h.rx-=.23;h.rz+=(.025 if style==0 else -.025)
    leg_ik(root,'leftLeg',5.20,1.55,.22,.65,.60,0,.08);leg_ik(root,'rightLeg',5.20,1.55,-.22,.65,.60,0,-.08);leg_ik(root,'leftLegback',5.55,-.45,.40,.80,-.40,0,.10);leg_ik(root,'rightLegback',5.55,-.45,-.40,.80,-.40,0,-.10)
    side=1 if style==0 else -1;t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.z+=.02;t.rx=.52;t.ry=.12;t.rz=0;t2.rx=1.02;t2.ry=.28;t2.rz=0

def new_sprawl(root,v=0):
    side=1 if v%2==0 else -1;w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head');w.y+=.89;b.y+=1.40;b.rx+=.16;u.y+=.28;u.rx-=.08;h.rx+=.01;h.rz+=side*.035
    leg_ik(root,'leftLeg',6.90,-1.60,1.50,.35,0,.18,.42);leg_ik(root,'rightLeg',6.90,-1.60,-1.50,.35,0,-.18,-.42);leg_ik(root,'leftLegback',7.00,1.60,2.00,.50,0,.08,.42);leg_ik(root,'rightLegback',7.00,1.60,-2.00,.50,0,-.08,-.42)
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.z+=.16;t.rx=.24;t.ry=0;t.rz=0;t2.rx=.50;t2.ry=side*.10;t2.rz=0

# Approved 1.4.14 horse rest is intentionally reused unchanged.
ROLL=[.82,.86,.80,.84]; GY=[-2.8239,-3.8517,-2.5893,-3.0833]; BL=[.05,.04,.06,.025];UL=[.025,.02,.03,.01];HL=[.008,.006,.01,.002];BP=[.12,.10,.14,.08];UP=[-.09,-.08,-.10,-.07];HP=[.01,0,.015,-.005];UY=[.29,.27,.31,.23];HY=[-.08,-.02,.08,-.28];HRY=[.14,.16,.12,.22]
LEGS=[[('leftLeg',2.0,1.4,-1.6,-.10,-.20,.72,.50,-.10),('rightLeg',4.0,1.7,-.4,-.58,-.10,.54,1.35,-.35),('leftLegback',2.4,1.6,1.2,.55,.12,.82,1.40,-.45),('rightLegback',4.3,1.8,.4,.28,.06,.60,1.25,-.30)],[('leftLeg',2.8,1.3,-2.2,.05,-.24,.86,.38,-.05),('rightLeg',4.4,1.8,-.2,-.65,-.10,.52,1.42,-.38),('leftLegback',3.0,1.6,1.6,.62,.12,.96,1.46,-.48),('rightLegback',4.7,1.9,.5,.30,.06,.62,1.28,-.30)],[('leftLeg',1.8,1.4,-1.2,-.22,-.16,.70,.78,-.18),('rightLeg',3.8,1.8,-.2,-.62,-.08,.50,1.38,-.35),('leftLegback',2.8,1.7,1.8,.70,.12,1.02,1.50,-.52),('rightLegback',4.6,2.0,.7,.34,.05,.62,1.30,-.32)],[('leftLeg',2.4,1.2,-1.8,-.02,-.22,.78,.46,-.08),('rightLeg',4.2,1.6,-.5,-.52,-.12,.58,1.25,-.30),('leftLegback',2.5,1.5,1.3,.50,.14,.88,1.36,-.40),('rightLegback',4.4,1.8,.4,.25,.06,.60,1.20,-.28)]]
def horse(root,v=0):
    w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head');roll=ROLL[v];w.y+=GY[v];w.rz+=roll;b.y+=1.15;b.rx+=BP[v];b.rz+=-roll+BL[v];u.y+=UY[v];u.rx+=UP[v];u.rz+=UL[v]-BL[v];h.y+=HY[v];h.rx+=HP[v];h.ry+=HRY[v];h.rz+=HL[v]-UL[v]
    for row in LEGS[v]:rest_leg(root,row)
    t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.rx=.28;t.ry=-.08;t2.rx=.58;t2.ry=-.04

def standing_ground(age=40.0):
    root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',age,0,0,0,0,cat_motion='idle');_,pts=r.build_polygons(root,tex,tw,th,0,0,subdivide=False);return float(pts[:,1].min())
GROUND=standing_ground()

def render(root,tex,tw,th,yaw,label):
    _,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=False);mnx,mxx=pts[:,0].min(),pts[:,0].max();mny,mxy=pts[:,1].min(),pts[:,1].max();sc=min((W-24)/max(mxx-mnx,1),(BASE-38)/max(mxy-GROUND,1));xo=W/2-(mnx+mxx)/2*sc;yo=BASE+GROUND*sc
    can=np.zeros((H,W,4),dtype=np.uint8);can[:]=np.array(BG,dtype=np.uint8);im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);d.rounded_rectangle((12,BASE-4,W-12,BASE+8),radius=6,fill=(12,22,40,230));d.line((12,BASE,W-12,BASE),fill=(115,145,195,255),width=2);can=np.array(im);z=np.full((H,W),np.inf)
    polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=True)
    for _,q,rgba in polys:
        pp=np.array([[xo+p[0]*sc,yo-p[1]*sc,p[2]] for p in q],dtype=float);r._raster_triangle(can,z,pp[[0,1,2]],rgba);r._raster_triangle(can,z,pp[[0,2,3]],rgba)
    im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);bb=d.textbbox((0,0),label,font=SMALL);tx=(W-(bb[2]-bb[0]))//2;d.rounded_rectangle((tx-6,8,tx+(bb[2]-bb[0])+6,29),radius=6,fill=(15,22,38,225),outline=(105,125,165,255));d.text((tx,11),label,font=SMALL,fill=(241,244,255));return im

def make_pose(pose,v,age=42.0):
    root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',age,0,0,0,0,cat_motion='sit');pose(root,v);return root,tex,tw,th

def save_gif(path,pose,v,label):
    frames=[]
    for i in range(FRAMES):
        age=40+i*.75;root,tex,tw,th=make_pose(pose,v,age);frames.append(render(root,tex,tw,th,-28,label))
    frames[0].save(path,save_all=True,append_images=frames[1:],duration=110,loop=0,disposal=2,optimize=False)

# Before/after hero comparison.
comparisons=[('SIT',old_sit,new_sit,0),('LOAF',old_loaf,new_loaf,0),('SPRAWL',old_sprawl,new_sprawl,0),('HORSE REST · unchanged',horse,horse,3)]
sheet=Image.new('RGBA',(2*W,len(comparisons)*H),BG)
for i,(name,before,after,v) in enumerate(comparisons):
    root,tex,tw,th=make_pose(before,v);sheet.alpha_composite(render(root,tex,tw,th,-28,f'BEFORE 1.4.14 · {name}'),(0,i*H))
    root,tex,tw,th=make_pose(after,v);sheet.alpha_composite(render(root,tex,tw,th,-28,f'AFTER 1.4.15 · {name}'),(W,i*H))
comparison_path=OUT/'Creeperella-1.4.14-vs-1.4.15-Pose-Comparison.png';sheet.save(comparison_path)

# Full after rest gallery.
rows=[]
for name,pose,count in [('SIT',new_sit,4),('LOAF',new_loaf,2),('SPRAWL',new_sprawl,2),('HORSE REST',horse,4)]:
    for v in range(count): rows.append((name,pose,v))
all_sheet=Image.new('RGBA',(2*W,len(rows)*H),BG)
for i,(name,pose,v) in enumerate(rows):
    for c,(yaw,vn) in enumerate([(-28,'3Q'),(-90,'SIDE')]):
        root,tex,tw,th=make_pose(pose,v);all_sheet.alpha_composite(render(root,tex,tw,th,yaw,f'{name} v{v+1} · {vn}'),(c*W,i*H))
after_path=AFTER/'Creeperella-1.4.15-Rest-Pose-Audit.png';all_sheet.save(after_path)

# Preserve baseline audit images inside the bundle.
for src in [Path('/mnt/data/Creeperella-1.4.14-Cat-Pose-Audit/Creeperella-1.4.14-Rest-Pose-Audit.png'),Path('/mnt/data/Creeperella-1.4.14-Cat-Pose-Audit/Creeperella-1.4.14-Locomotion-Idle-Audit.png')]:
    if src.exists(): shutil.copy2(src,BEFORE/src.name)

# Representative before + after GIFs for direct rollback review.
for name,pose,v in [('SIT',old_sit,0),('LOAF',old_loaf,0),('SPRAWL',old_sprawl,0),('HORSE-REST',horse,3)]:
    save_gif(BEFORE/f'Cat-Creeper-1.4.14-{name}.gif',pose,v,'BEFORE 1.4.14 · '+name.replace('-',' '))
for name,pose,v in [('SIT',new_sit,0),('LOAF',new_loaf,0),('SPRAWL',new_sprawl,0),('HORSE-REST-UNCHANGED',horse,3)]:
    save_gif(AFTER/f'Cat-Creeper-1.4.15-{name}.gif',pose,v,'AFTER 1.4.15 · '+name.replace('-',' '))

# Ground / pose numeric checks.
lines=[f'standing_ground_y={GROUND:.6f}']
for name,pose,count in [('SIT',new_sit,4),('LOAF',new_loaf,2),('SPRAWL',new_sprawl,2),('HORSE_REST',horse,4)]:
    vals=[]
    for v in range(count):
        root,tex,tw,th=make_pose(pose,v);_,pts=r.build_polygons(root,tex,tw,th,0,0,subdivide=False);vals.append(float(pts[:,1].min()-GROUND))
    lines.append(f'{name}: bottom_delta_min={min(vals):.6f} max={max(vals):.6f}')
(AFTER/'GROUND_QA.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')

(OUT/'POSE_AUDIT.md').write_text('''# Creeperella 1.4.15 Cat pose audit\n\nDeterministic QA only; no generative image model was used.\n\n## Changed after reviewing 1.4.14\n- **SIT** — old hand-rotated legs produced a chair-like silhouette and one long-looking forward limb from the side. 1.4.15 uses static two-link IK with front paws under the chest and rear legs folded into the haunches.\n- **LOAF** — old pose read as another sit rather than a compact loaf. 1.4.15 lowers/folds the body, tucks all four paws more deeply, and curls the tail closer to the body.\n- **SPRAWL** — old pose did not clearly separate all four limbs. 1.4.15 targets each paw outward using IK so the spread-all-fours silhouette is readable.\n- **Rest idle safety** — PAW_LIFT is no longer eligible in SIDE_LIE/SPRAWL, and LOAF kneading now uses a tiny tucked-paw pressure motion instead of reopening the legs.\n\n## Intentionally unchanged\n- **CREEP / WALK / RUN** — previous locomotion IK and clipping regression suite already passed; visual audit found no reason to disturb it.\n- **Standing PAW_LIFT / TAIL_WAG / CURIOUS_LOOK / KNEAD** — kept unless a rest-pose compatibility rule overrides them.\n- **1.4.14 upright HORSE REST / SIDE_LIE family** — user-approved pose is regression-locked and copied forward unchanged.\n\n## Rollback\nThe complete 1.4.14 source ZIP, original model/entity source files, and baseline QA images are stored under `pose-history/1.4.14-before/` in the 1.4.15 source tree. The canonical 1.4.14 source also remains a separate Drive object, so reverting does not depend on this archive.\n''',encoding='utf-8')
(OUT/'ROLLBACK.md').write_text('''# Rollback / before-after map

- Full 1.4.14 source snapshot is bundled inside the 1.4.15 source tree at `pose-history/1.4.14-before/`.
- The preserved original Cat model/entity source files live beside that ZIP.
- `BEFORE-1.4.14/` contains deterministic baseline audits and representative GIFs.
- `AFTER-1.4.15/` contains the polished rest poses.
- The approved 1.4.14 horse-rest/SIDE_LIE runtime method is regression-locked byte-for-byte and was not changed in 1.4.15.
- The canonical 1.4.14 Drive source remains a separate object, so rollback does not depend on the 1.4.15 archive.
''',encoding='utf-8')
print(comparison_path);print(after_path);print((AFTER/'GROUND_QA.txt').read_text())
