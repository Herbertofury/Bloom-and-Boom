#!/usr/bin/env python3
"""Deterministic QA compositor: approved reference vs real native Minecraft capture/video.
No image generation; only crops/scales/composites supplied project evidence."""
from pathlib import Path
from PIL import Image, ImageOps, ImageDraw
import argparse, subprocess, tempfile

def crop_native(im, crop=None):
    if crop is None: return im
    x0,y0,x1,y1=crop
    if not (0 <= x0 < x1 <= im.width and 0 <= y0 < y1 <= im.height):
        raise ValueError("Native crop must fit the actual screenshot")
    return im.crop(crop)

def pane(ref, native, label, crop=None):
    r=ImageOps.contain(ref,(420,520),Image.Resampling.LANCZOS)
    n=ImageOps.contain(crop_native(native,crop),(420,520),Image.Resampling.NEAREST)
    out=Image.new('RGB',(880,575),(18,18,22)); d=ImageDraw.Draw(out)
    out.paste(r,((420-r.width)//2+10,40)); out.paste(n,(450+(420-n.width)//2,40+(520-n.height)//2))
    d.text((18,10),'APPROVED REFERENCE',fill=(245,245,250)); d.text((458,10),label,fill=(245,245,250))
    return out

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--reference',required=True); ap.add_argument('--native',required=True)
    ap.add_argument('--out',required=True); ap.add_argument('--label',default='NATIVE FORGE'); ap.add_argument('--video'); ap.add_argument('--crop',nargs=4,type=int,metavar=('LEFT','TOP','RIGHT','BOTTOM'))
    a=ap.parse_args(); ref=Image.open(a.reference).convert('RGB'); nat=Image.open(a.native).convert('RGB')
    pane(ref,nat,a.label,a.crop).save(a.out)
    if a.video:
        outgif=str(Path(a.out).with_suffix('.gif'))
        with tempfile.TemporaryDirectory() as td:
            subprocess.run(['ffmpeg','-y','-loglevel','error','-i',a.video,'-vf','fps=8',f'{td}/f_%03d.png'],check=True)
            frames=[pane(ref,Image.open(p).convert('RGB'),a.label+' MOTION',a.crop) for p in sorted(Path(td).glob('f_*.png'))]
            frames[0].save(outgif,save_all=True,append_images=frames[1:],duration=125,loop=0,optimize=True)
        print(outgif)
    print(a.out)
if __name__=='__main__': main()
