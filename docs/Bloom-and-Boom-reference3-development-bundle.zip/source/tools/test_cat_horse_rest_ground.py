#!/usr/bin/env python3
from __future__ import annotations
import sys, numpy as np
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import render_mobs_visual_qa as r

JAVA=(HERE.parent/'src/main/java/dev/herbertofury/creeperella/client/CreeperellaModel.java').read_text()
required=[
    'applyCatSideLiePose','poseCatRestLeg','-2.8239F','-3.8517F','-2.5893F','-3.0833F',
    '0.82F','0.86F','0.80F','0.84F','bodyLean','upperLean','headLean','bodyPitch','upperPitch','headPitch',
    '(-roll + bodyLean)','(upperLean - bodyLean)','(headLean - upperLean)'
]
for token in required:
    assert token in JAVA, f'missing runtime token {token}'

src=(HERE/'make_cat_horse_rest_qa.py').read_text().split('outputs=[]')[0]
ns={'__file__':str(HERE/'make_cat_horse_rest_qa.py')}; exec(src,ns)
apply_pose=ns['apply_horse_rest']; P=ns['P']; standing_ground=ns['standing_ground']

def world_matrix(part):
    mats=[]; cur=part
    while cur is not None:
        mats.append(r.local_matrix(cur)); cur=cur.parent
    out=np.eye(4)
    for m in reversed(mats): out=out@m
    return out

def up_vec(part):
    v=world_matrix(part)[:3,:3]@np.array([0.,1.,0.])
    return v/np.linalg.norm(v)

for v in range(4):
    ground_deltas=[]
    for i in range(120):
        age=20.0+i*0.31
        root,tex,tw,th=r.load_variant('cat')
        r.apply_anim(root,'cat',age,0,0,0,0,cat_motion='sit')
        apply_pose(root,v)
        _,pts=r.build_polygons(root,tex,tw,th,yaw=0,pitch=0,subdivide=False)
        ground_deltas.append(float(pts[:,1].min()-standing_ground(age)))
    assert min(ground_deltas) >= 0.0, (v,min(ground_deltas))
    assert max(ground_deltas) <= 0.25, (v,max(ground_deltas))

    root,tex,tw,th=r.load_variant('cat')
    r.apply_anim(root,'cat',40,0,0,0,0,cat_motion='sit'); apply_pose(root,v)
    body=P(root,'body','waist','Body'); upper=P(root,'body','waist','Body','Upperbody'); head=P(root,'body','waist','Body','Upperbody','head')
    body_y=up_vec(body); upper_y=up_vec(upper); head_y=up_vec(head)

    # 1.4.14: the visible chest/head must be essentially upright. Tiny x/lateral lean is allowed;
    # forward bend on upper/head is kept under a few degrees for a comfortable Creeper silhouette.
    assert abs(float(body_y[0])) <= 0.07, (v,body_y)
    assert abs(float(upper_y[0])) <= 0.04, (v,upper_y)
    assert abs(float(head_y[0])) <= 0.02, (v,head_y)
    assert float(upper_y[1]) >= 0.995, (v,upper_y)
    assert float(head_y[1]) >= 0.995, (v,head_y)

    # The lower body is still the horse-rest family: every leg is shifted onto the same rest side.
    for leg_name in ('leftLeg','rightLeg','leftLegback','rightLegback'):
        leg=P(root,'body','waist',leg_name)
        assert leg.x-leg.base[0] >= 1.75, (v,leg_name,leg.x-leg.base[0])

print('PASS: four grounded upright horse-rest variants; tiny lean, near-vertical chest/head, legs swept to one side')
