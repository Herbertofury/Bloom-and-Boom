#!/usr/bin/env python3
"""Generate Boomshroom body art from the protected Cherry Creeper UV/layout.

This is deterministic pixel-art authoring, not image generation.
Design contract:
- Preserve Cherry Creeper's proven 64x64 UV layout and facial animation frames.
- Re-author the body as a low-chroma ivory/white mushroom stalk.
- Keep readable dark Creeperella facial features with zero red facial markings.
- Translate Creeper Overhaul's authorized Mushroom Creeper ground-stain language onto the Cherry UVs:
  irregular neutral mushroom-gray staining rises from the feet into the lower stalk.
- Keep the stain low-chroma and root-like, never burgundy/purple body spots.
- Do not touch the separate exact Creeper Overhaul cap assets.
"""
from __future__ import annotations
import hashlib
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ENT = ROOT / "src/main/resources/assets/creeperella/textures/entity"
SRC = ENT / "cherry_creeper.png"
OUT = ENT / "boomshroom_creeper.png"
EMISSIVE = ENT / "boomshroom_creeper_e.png"
CO_REF = ROOT / "reference-assets/creeper-overhaul/mushroom_creeper.png"

# Protected Cherry donor hash from the 1.5.0 quality contract.
CHERRY_SHA = "f616daad6e1aa1f9b9b81041cd8823aa17faa4eeb8d4e00801a1547328cf1bdb"
CO_SHA = "ababadc6df55ab4e42803ac19fce39d4ceaf7dfc255c0fbc0e9c45abb2d6da4a"

# Face animation overlays in CherryRemakeModelLayers.java: texOffs(26,37/45/53), 8x8 each.
FACE_RECTS = [(26, 37, 34, 45), (26, 45, 34, 53), (26, 53, 34, 61)]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def in_rect(x: int, y: int, rect) -> bool:
    x0, y0, x1, y1 = rect
    return x0 <= x < x1 and y0 <= y < y1


def is_face(x: int, y: int) -> bool:
    return any(in_rect(x, y, r) for r in FACE_RECTS)


def luma(r: int, g: int, b: int) -> float:
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def classify(r: int, g: int, b: int) -> str:
    mx, mn = max(r, g, b), min(r, g, b)
    lum = luma(r, g, b)
    # Cherry foliage greens are the only strong yellow-green family in the donor.
    if g > r * 0.92 and g > b * 1.45 and r < 185 and g >= 100:
        return "green"
    # The darkest wine pixels are deliberate face/toe linework in the donor.
    if lum < 102 and r > b * 0.90:
        return "dark"
    if mx - mn < 18 and lum > 230:
        return "white"
    return "pink"


def clamp(v: float, lo: int, hi: int) -> int:
    return max(lo, min(hi, int(round(v))))


def stalk_pixel(r: int, g: int, b: int, x: int, y: int) -> tuple[int, int, int, int]:
    fam = classify(r, g, b)
    lum = luma(r, g, b)
    # Very small deterministic material variation. It follows the existing authored pixel
    # distribution instead of spraying random noise across the atlas.
    micro = ((x * 5 + y * 3) % 7) - 3

    if fam == "dark":
        # CO-style purple/gray root shadow: neutral enough to read as shadow, not body markings.
        t = clamp(50 + (lum / 102.0) * 45 + micro, 48, 96)
        return (clamp(t + 2, 0, 255), clamp(t - 2, 0, 255), clamp(t + 5, 0, 255), 255)

    if fam == "green":
        # Former foliage becomes cool mycelial shadow embedded in the white stalk material.
        # Keeping a lower contrast band preserves Cherry's texture richness without green/red spots.
        t = clamp(184 + (lum / 190.0) * 38 + micro, 186, 224)
        return (clamp(t + 2, 0, 255), clamp(t + 1, 0, 255), clamp(t + 4, 0, 255), 255)

    # Pink/white Cherry flesh becomes warm ivory with enough range to retain pixel-art depth.
    t = clamp(158 + lum * 0.37 + micro, 196, 247)
    return (clamp(t + 4, 0, 255), clamp(t + 2, 0, 255), clamp(t - 3, 0, 255), 255)


def face_pixel(r: int, g: int, b: int, x: int, y: int) -> tuple[int, int, int, int]:
    fam = classify(r, g, b)
    lum = luma(r, g, b)
    if fam == "dark":
        # Strong neutral charcoal Creeperella linework.
        if lum < 62:
            return (34, 33, 35, 255)
        return (57, 55, 59, 255)
    if fam == "green":
        # Cherry's green accent pixels become neutral facial shadow, never mooshroom red.
        # This keeps the authored eye/mouth topology while removing the 1.5.1 red marks entirely.
        t = 74 if lum < 145 else 92
        return (t + 1, t, t + 2, 255)
    # Face flesh uses the same ivory family but is slightly brighter for clean readability.
    t = clamp(170 + lum * 0.35, 205, 249)
    return (clamp(t + 4, 0, 255), clamp(t + 2, 0, 255), clamp(t - 4, 0, 255), 255)


def source_row_gray(im: Image.Image, u: int, v: int, width: int) -> int:
    """Low-chroma luminance sampled from the authorized Creeper Overhaul atlas row."""
    vals = []
    for x in range(u, u + width):
        r, g, b, a = im.getpixel((x, v))
        if a:
            vals.append(luma(r, g, b))
    if not vals:
        raise RuntimeError(f"empty Creeper Overhaul source row: {(u, v, width)}")
    return clamp(sum(vals) / len(vals), 0, 255)


def blend_rgb(base: tuple[int, int, int, int], target: tuple[int, int, int], amount: float):
    r, g, b, a = base
    amount = max(0.0, min(1.0, amount))
    return (
        clamp(r * (1.0 - amount) + target[0] * amount, 0, 255),
        clamp(g * (1.0 - amount) + target[1] * amount, 0, 255),
        clamp(b * (1.0 - amount) + target[2] * amount, 0, 255),
        a,
    )


def ground_stain_pixel(px: tuple[int, int, int, int], x: int, y: int, co: Image.Image):
    """Translate CO's pulled-from-the-ground fade onto Cherry-family body/leg UVs.

    Java Cherry UVs:
      legs = texOffs(0,16), side rows y20..25 (top -> ground)
      body = texOffs(16,16), side rows y20..31 (top -> lower stalk)
    CO's Mushroom Creeper uses a progressively darker warm/mauve-gray foot/root fade.
    We sample its row luminance directly, then neutralize the hue to mushroom gray.
    """
    r, g, b, a = px
    if not a:
        return px

    # Shared leg atlas: all four Cherry legs use texOffs(0,16).
    if 0 <= x < 16 and 20 <= y <= 25:
        row = y - 20
        # CO leg1 side rows are v+d = 4..8; row 5 holds the deepest source tone.
        co_row = 4 + min(4, round(row * 4 / 5))
        src_l = source_row_gray(co, 42, co_row, 18)
        # Neutralize the source's mauve/taupe hue but retain its actual luminance progression.
        target_l = clamp(src_l + 8, 112, 166)
        target = (target_l + 1, target_l, target_l + 3)
        # Uneven CO-like climb: solidest at ground, broken fingers higher up.
        base_strength = (0.06, 0.12, 0.24, 0.43, 0.68, 0.86)[row]
        breakup = ((x * 11 + y * 7) % 13) / 12.0
        strength = base_strength * (0.72 + 0.38 * breakup)
        # Preserve authored dark toe/root pixels, but stain the surrounding white flesh upward.
        if max(r, g, b) < 120:
            strength = max(strength, 0.72 + 0.05 * row)
        return blend_rgb(px, target, min(0.92, strength))

    # Main stalk/body sides: preserve the white stalk and let only irregular root fingers
    # wick upward from the leg joint. This mirrors CO's "pulled out of the ground" read
    # without turning Boomshroom's whole torso into a gray band.
    if 16 <= x < 40 and 20 <= y <= 31:
        row = y - 20
        # Standard Java box-UV side layout for the 8x12x4 Cherry body:
        # right 16..19, front 20..27, left 28..31, back 32..39.
        if x < 20:
            local = x - 16; heights = (2, 4, 3, 2)
        elif x < 28:
            local = x - 20; heights = (2, 4, 3, 5, 3, 4, 2, 3)
        elif x < 32:
            local = x - 28; heights = (3, 2, 4, 2)
        else:
            local = x - 32; heights = (2, 3, 4, 2, 5, 3, 2, 4)
        height = heights[local]
        depth_from_bottom = 31 - y
        if depth_from_bottom >= height:
            return px

        # CO body side is 11 rows at (28,34); sample its darker lower-stalk rows directly.
        co_row = 34 + min(10, depth_from_bottom)
        src_l = source_row_gray(co, 28, co_row, 24)
        target_l = clamp(src_l + 35, 112, 178)
        target = (target_l + 1, target_l, target_l + 3)
        # Strongest at the ground/joint; each upward pixel gets markedly subtler.
        strength_by_depth = (0.50, 0.36, 0.25, 0.16, 0.10)
        strength = strength_by_depth[min(depth_from_bottom, len(strength_by_depth)-1)]
        # Small source-like breakup prevents a ruler-straight edge while keeping a coherent streak.
        breakup = 0.84 + 0.22 * (((x * 7 + y * 11) % 7) / 6.0)
        return blend_rgb(px, target, min(0.58, strength * breakup))

    return px


def main() -> None:
    if sha(SRC) != CHERRY_SHA:
        raise SystemExit(f"Refusing to generate from modified Cherry donor: {sha(SRC)}")
    if sha(CO_REF) != CO_SHA:
        raise SystemExit(f"Refusing to generate from modified Creeper Overhaul reference: {sha(CO_REF)}")
    src = Image.open(SRC).convert("RGBA")
    co = Image.open(CO_REF).convert("RGBA")
    if src.size != (64, 64):
        raise SystemExit(f"Unexpected Cherry atlas size: {src.size}")

    out = Image.new("RGBA", src.size, (0, 0, 0, 0))
    for y in range(64):
        for x in range(64):
            r, g, b, a = src.getpixel((x, y))
            if not a:
                continue
            px = face_pixel(r, g, b, x, y) if is_face(x, y) else stalk_pixel(r, g, b, x, y)
            if not is_face(x, y):
                px = ground_stain_pixel(px, x, y, co)
            out.putpixel((x, y), px[:-1] + (a,))
    out.save(OUT, optimize=True)

    # The 1.5.2 face is deliberately non-emissive. The authorized cap retains its separate
    # exact glow layer, so Boomshroom still has a fungal luminous accent without red facial marks.
    Image.new("RGBA", (64, 64), (0, 0, 0, 0)).save(EMISSIVE, optimize=True)

    print("Boomshroom body:", OUT)
    print("SHA256:", sha(OUT))
    print("Emissive SHA256:", sha(EMISSIVE))


if __name__ == "__main__":
    main()
