from pathlib import Path
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
TEX=ROOT/'src/main/resources/assets/creeperella/textures/entity'
VANILLA=ROOT/'.mvf-generated/vanilla'

def darken(c, f=0.88, bias=(-6,-8,-2)):
    return tuple(max(0,min(255,round(c[i]*f+bias[i]))) for i in range(3))

def tile_from_image(im, dark=False):
    out=Image.new('RGBA',(16,16),(0,0,0,0))
    for y in range(16):
        for x in range(16):
            p=im.getpixel((x%im.width,y%im.height))
            rgb=p[:3]
            if dark: rgb=darken(rgb)
            out.putpixel((x,y),(*rgb,255))
    return out

def tile_from_body(name):
    src=Image.open(TEX/f'{name}_creeper.png').convert('RGBA')
    out=Image.new('RGBA',(16,16),(0,0,0,0))
    # Sample the clean body band and repeat it. Avoid black face pixels.
    for y in range(16):
        for x in range(16):
            sx=32+(x%16)
            sy=4+(y%16)
            p=src.getpixel((sx,sy))
            if p[3]==0 or sum(p[:3])<140:
                p=(180,180,180,255)
            out.putpixel((x,y),p)
    return out

def blit_tile(dst,box,tile):
    x0,y0,x1,y1=box
    for y in range(y0,y1):
        for x in range(x0,x1):
            dst.putpixel((x,y),tile.getpixel(((x-x0)%16,(y-y0)%16)))

def shell_for(name):
    if name=='nacrella':
        side=tile_from_image(Image.open(VANILLA/'pearlescent_froglight_side.png').convert('RGBA'), True)
        top=tile_from_image(Image.open(VANILLA/'pearlescent_froglight_top.png').convert('RGBA'), True)
    else:
        side=tile_from_body(name); top=side
    atlas=Image.new('RGBA',(64,64),(0,0,0,0))
    # Broadly fill all occupied UV zones with the side material first.
    blit_tile(atlas,(0,0,64,64),side)
    # Standard cube top/bottom zones: head, torso upper/lower, four leg blocks.
    for box in [
        (8,0,24,8),          # 8^3 head top/bottom
        (4,16,14,20),        # upper torso top/bottom
        (28,16,38,20),       # lower torso top/bottom
        (4,32,12,36),(20,32,28,36),(36,32,44,36),(52,32,60,36)
    ]: blit_tile(atlas,box,top)
    atlas.save(TEX/f'{name}_shell.png',optimize=True)

for n in ('nacrella','verdalia','mariglow'): shell_for(n)
print('generated dedicated Froglight shell textures')
