#!/usr/bin/env python3
"""Build deterministic Creeperella 1.4.8 visual QA from actual project source.

No generative imagery is used. Frames are rasterized from generated Java ModelPart layers, exact
source textures, and the same source-derived runtime formulas audited by the project.
"""
from __future__ import annotations
import argparse, hashlib, shutil, subprocess, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE))
from render_mobs_visual_qa import load_variant, compute_view, render_frame

VERSION='1.4.8'
BASELINE_VERSION='1.4.7'
VARIANTS=['female','bunny','bee','cherry','blossom','cat']
PIE_VARIANTS=['female','bunny','bee']
CHANGED_VARIANTS=['cat']
NAMES={
 'female':'Female Creeper','bunny':'Bunny Creeper','bee':'Bee Creeper',
 'cherry':'Cherry Creeper','blossom':'Blossom Creeper','cat':'Cat Creeper',
}
PHASE={'female':0,'bunny':430,'bee':860,'cherry':1290,'blossom':1720,'cat':2150}

def font(size:int,bold:bool=True):
    p='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    try:return ImageFont.truetype(p,size)
    except OSError:return ImageFont.load_default()

def grid_bg(size):
    w,h=size; im=Image.new('RGBA',size,(22,25,31,255)); d=ImageDraw.Draw(im,'RGBA')
    for x in range(0,w,32):d.line((x,0,x,h),fill=(255,255,255,8),width=1)
    for y in range(0,h,32):d.line((0,y,w,y),fill=(255,255,255,8),width=1)
    return im

def fit_rgba(im,maxsize):
    bb=im.getbbox()
    if bb:im=im.crop(bb)
    im.thumbnail(maxsize,Image.Resampling.LANCZOS); return im

def egg_state(kind,tsec):
    t=int(tsec*1000+PHASE[kind])%3200
    if 2460<=t<2580:return 'blink'
    if 820<=t<1140:return 'sway_right'
    if 500<=t<820:return 'sway_left'
    return 'idle'

def subtitle(kind):
    if kind in PIE_VARIANTS:return 'full supplied Pie CEM motion'
    if kind in ('cherry','blossom'):return 'full Remake 3.0 CEM motion + exact blink/hurt channels'
    return 'Bedrock identity + state-driven feline creep/walk/run / planted paws / personality idles'

def compose_card(kind,entity,eggs_dir:Path,tsec=0.0,static=False):
    w,h=640,440; bg=grid_bg((w,h)); d=ImageDraw.Draw(bg,'RGBA')
    d.rounded_rectangle((14,12,w-14,h-12),radius=18,fill=(31,35,43,238),outline=(255,255,255,28),width=2)
    d.text((30,25),NAMES[kind],font=font(29),fill=(245,247,250,255))
    d.text((31,62),subtitle(kind),font=font(12,False),fill=(173,182,198,255))
    d.line((396,90,396,h-28),fill=(255,255,255,24),width=1)
    ent=fit_rgba(entity.copy(),(350,335)); bg.alpha_composite(ent,(30+(340-ent.width)//2,88+(330-ent.height)//2))
    d.text((35,h-46),'ENTITY',font=font(13),fill=(145,207,149,255))
    state='idle' if static else egg_state(kind,tsec); ep=eggs_dir/f'{kind}_{state}.png'
    if ep.exists():
        egg3=fit_rgba(Image.open(ep).convert('RGBA'),(205,205)); bg.alpha_composite(egg3,(410+(205-egg3.width)//2,105+(205-egg3.height)//2))
    d.text((424,95),'3D EGG',font=font(12),fill=(222,179,255,255))
    egg2=Image.open(ROOT/'src/main/resources/assets/creeperella/textures/item'/f'{kind}_creeper_spawn_egg.png').convert('RGBA')
    scale=max(1,min(7,96//max(egg2.size))); egg2=egg2.resize((egg2.width*scale,egg2.height*scale),Image.Resampling.NEAREST)
    bg.alpha_composite(egg2,(462+(100-egg2.width)//2,315+(82-egg2.height)//2))
    d.text((424,315),'EXACT 2D EGG',font=font(12),fill=(245,210,127,255))
    if not static:d.text((424,h-46),f'EGG: {state.replace("_"," ").upper()}',font=font(11,False),fill=(154,164,180,255))
    return bg.convert('RGB')

def specs_for(kind,fps=8):
    duration=5.25 if kind in ('cherry','blossom') else 4.0
    n=int(round(duration*fps)); specs=[]
    for i in range(n):
        t=i/fps; age=t*20.0; amount=0.46 if kind not in ('cherry','blossom') else 0.34
        specs.append((age,age*0.38,amount,0,0))
    return duration,specs

def mp4_from_frames(frame_pattern:Path,out:Path,fps:int):
    if not shutil.which('ffmpeg'):return
    subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate',str(fps),'-i',str(frame_pattern),'-c:v','libx264','-pix_fmt','yuv420p','-crf','18',str(out)],check=True)

def generate_variant(kind,out:Path,eggs_dir:Path,fps=8):
    root,tex,tw,th=load_variant(kind); _,specs=specs_for(kind,fps)
    view=compute_view(root,tex,tw,th,kind,specs,size=(380,410),yaw=-28,pitch=10)
    fdir=out/'frames'/kind; fdir.mkdir(parents=True,exist_ok=True); cards=[]
    for i,(age,ls,amt,hy,hp) in enumerate(specs):
        ent=render_frame(root,tex,tw,th,kind,age,ls,amt,view,size=(380,410),yaw=-28,pitch=10)
        card=compose_card(kind,ent,eggs_dir,i/fps,False); card.save(fdir/f'{i:03d}.png',optimize=True); cards.append(card)
    stem=NAMES[kind].replace(' ','-')+'-Mob-and-Egg-Animation'
    cards[0].save(out/f'{stem}.gif',save_all=True,append_images=cards[1:],duration=int(1000/fps),loop=0,optimize=True,disposal=2)
    mp4_from_frames(fdir/'%03d.png',out/f'{stem}.mp4',fps)
    age=20.0; view=compute_view(root,tex,tw,th,kind,[(age,0,0,0,0)],size=(380,410),yaw=-28,pitch=10)
    ent=render_frame(root,tex,tw,th,kind,age,0,0,view,size=(380,410),yaw=-28,pitch=10)
    compose_card(kind,ent,eggs_dir,0,True).save(out/f'{NAMES[kind].replace(" ","-")}-Mob-and-Egg.png',optimize=True)

def make_gallery(out:Path):
    title_h=100; cardw,cardh=640,440
    sheet=Image.new('RGB',(cardw*3,title_h+cardh*2),(13,16,21));d=ImageDraw.Draw(sheet)
    d.text((34,24),f'Creeperella: Bloom & Boom {VERSION}',font=font(34),fill=(248,249,252))
    d.text((36,64),'Actual source models/textures + deterministic runtime formulas — NO image generation',font=font(15,False),fill=(165,174,190))
    for i,k in enumerate(VARIANTS):sheet.paste(Image.open(out/f'{NAMES[k].replace(" ","-")}-Mob-and-Egg.png').convert('RGB'),((i%3)*cardw,title_h+(i//3)*cardh))
    sheet.save(out/f'Creeperella-{VERSION}-All-Mobs-and-Eggs.png',quality=95)

def make_lineup(out:Path,fps=8):
    counts={k:len(list((out/'frames'/k).glob('*.png'))) for k in VARIANTS};maxn=max(counts.values());cell=(360,248)
    ddir=out/'frames'/'all';ddir.mkdir(parents=True,exist_ok=True);frames=[]
    for i in range(maxn):
        canvas=Image.new('RGB',(cell[0]*3,cell[1]*2),(12,14,19))
        for j,k in enumerate(VARIANTS):
            card=Image.open(out/'frames'/k/f'{i%counts[k]:03d}.png').convert('RGB').resize(cell,Image.Resampling.LANCZOS)
            canvas.paste(card,((j%3)*cell[0],(j//3)*cell[1]))
        canvas.save(ddir/f'{i:03d}.png',optimize=True);frames.append(canvas)
    frames[0].save(out/f'Creeperella-{VERSION}-All-Mob-Animations.gif',save_all=True,append_images=frames[1:],duration=int(1000/fps),loop=0,optimize=True,disposal=2)
    mp4_from_frames(ddir/'%03d.png',out/f'Creeperella-{VERSION}-All-Mob-Animations.mp4',fps)

def make_all_multiangle(out:Path):
    angles=[('FRONT',0),('3/4',-28),('SIDE',-90),('BACK',-180)];cw,ch=300,330;title_h=96
    sheet=Image.new('RGB',(cw*4,title_h+ch*6),(12,14,19));d=ImageDraw.Draw(sheet)
    d.text((24,18),f'{VERSION} — all six mobs, four-angle model/motion QA',font=font(28),fill=(248,249,252))
    d.text((26,56),'Same representative walking checkpoint on actual converted geometry and exact textures',font=font(13,False),fill=(165,174,190))
    for row,kind in enumerate(VARIANTS):
        root,tex,tw,th=load_variant(kind);age=28.0;ls=age*.38;amt=.34 if kind in ('cherry','blossom') else .46
        for col,(label,yaw) in enumerate(angles):
            view=compute_view(root,tex,tw,th,kind,[(age,ls,amt,0,0)],size=(270,275),yaw=yaw,pitch=8)
            ent=render_frame(root,tex,tw,th,kind,age,ls,amt,view,size=(270,275),yaw=yaw,pitch=8,bg=(0,0,0,0));card=grid_bg((cw,ch));cd=ImageDraw.Draw(card,'RGBA')
            cd.text((12,10),f'{NAMES[kind]} · {label}',font=font(14),fill=(240,243,248,255));ent=fit_rgba(ent,(270,275));card.alpha_composite(ent,((cw-ent.width)//2,40+(275-ent.height)//2))
            sheet.paste(card.convert('RGB'),(col*cw,title_h+row*ch))
    sheet.save(out/f'Creeperella-{VERSION}-All-Mobs-Multi-Angle-QA.png',quality=95)

def make_cat_contact_sheet(out:Path,fps=8):
    files=sorted((out/'frames'/'cat').glob('*.png')); idxs=[0,4,8,12,16,20,24,28];cell=(480,330);title_h=82
    sheet=Image.new('RGB',(cell[0]*4,title_h+cell[1]*2),(11,13,18));d=ImageDraw.Draw(sheet)
    d.text((24,17),f'Cat Creeper {VERSION} — articulated feline walk / spine / leg / tail-tip review',font=font(28),fill=(248,249,252))
    d.text((26,53),'Eight real renderer checkpoints; real rig + feline IK gait; clipping/joint-limit review',font=font(13,False),fill=(165,174,190))
    for j,i in enumerate(idxs):
        p=files[i%len(files)];im=Image.open(p).convert('RGB').resize(cell,Image.Resampling.LANCZOS);sheet.paste(im,((j%4)*cell[0],title_h+(j//4)*cell[1]))
    sheet.save(out/f'Cat-Creeper-{VERSION}-Improved-Motion-Contact-Sheet.png',quality=95)

def make_changed_before_after(out:Path,baseline:Path,fps=8):
    if not baseline.exists():return
    new={k:len(list((out/'frames'/k).glob('*.png'))) for k in CHANGED_VARIANTS};old={k:len(list((baseline/'frames'/k).glob('*.png'))) for k in CHANGED_VARIANTS}
    if not all(old.values()):return
    n=max(max(new.values()),max(old.values()));cell=(430,296);ddir=out/'frames'/'changed_comparison';ddir.mkdir(parents=True,exist_ok=True);frames=[]
    for i in range(n):
        c=Image.new('RGB',(cell[0]*3,62+cell[1]*2),(11,13,18));d=ImageDraw.Draw(c)
        d.text((18,12),f'{BASELINE_VERSION} BEFORE',font=font(18),fill=(205,210,220));d.text((18,34+cell[1]),f'{VERSION} NOW — source-completeness corrections',font=font(18),fill=(245,247,250))
        for col,k in enumerate(CHANGED_VARIANTS):
            a=Image.open(baseline/'frames'/k/f'{i%old[k]:03d}.png').convert('RGB').resize(cell,Image.Resampling.LANCZOS);b=Image.open(out/'frames'/k/f'{i%new[k]:03d}.png').convert('RGB').resize(cell,Image.Resampling.LANCZOS)
            c.paste(a,(col*cell[0],62));c.paste(b,(col*cell[0],62+cell[1]))
        c.save(ddir/f'{i:03d}.png',optimize=True);frames.append(c)
    stem=f'Creeperella-{BASELINE_VERSION}-vs-{VERSION}-Cat-Cherry-Blossom-Animation-Comparison'
    frames[0].save(out/f'{stem}.gif',save_all=True,append_images=frames[1:],duration=int(1000/fps),loop=0,optimize=True,disposal=2)
    mp4_from_frames(ddir/'%03d.png',out/f'{stem}.mp4',fps)

def write_readme(out:Path):
    (out/'README.md').write_text(f'''# Creeperella {VERSION} Visual QA Showcase

Everything here is generated deterministically from the actual Creeperella project source. **No image-generation model is used.**

## Review first

- `Cat-Creeper-Mob-and-Egg-Animation.gif` — the 1.4.8 Cat walk-state render over the clipping-safe IK rig; focused creep/run/idles live in the Cat State QA package.
- `Cat-Creeper-{VERSION}-Improved-Motion-Contact-Sheet.png` — eight Cat walk checkpoints for gait/bend review.
- `Creeperella-{VERSION}-All-Mob-Animations.gif` — animated 3×2 grid confirming the other five mobs remain visually intact.
- `Creeperella-{VERSION}-All-Mobs-and-Eggs.png` — static all-six grid.
- `Creeperella-{VERSION}-All-Mobs-Multi-Angle-QA.png` — front / 3⁄4 / side / back for every mob.

## 1.4.8 Cat motion/state change

The exact FemaleCreeper geometry, texture, blink timing and authored idle/secondary curves remain the baseline. 1.4.8 retains the clipping-safe 1.4.7 two-link IK and adds server-authoritative IDLE/CREEP/WALK/RUN/SWELL/SIT/REFORM states plus interruptible personality idles. This broad all-mob showcase renders Cat in its normal walk state; the dedicated 1.4.8 Cat State QA package covers creep, run, paw-lift, tail-wag, curious-look, knead, and clipping extremes. Real movement remains the locomotion gate, and exact zero movement returns to the authored bind/idle leg pose.

These are deterministic source renders, not live Minecraft screenshots.
''' ,encoding='utf-8')

def write_sha(out:Path):
    rows=[]
    for p in sorted(out.rglob('*')):
        if p.is_file() and p.name!='SHA256SUMS.txt':rows.append(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(out).as_posix()}')
    (out/'SHA256SUMS.txt').write_text('\n'.join(rows)+'\n')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('output',type=Path);ap.add_argument('--eggs',type=Path,required=True);ap.add_argument('--baseline',type=Path);ap.add_argument('--fps',type=int,default=8);a=ap.parse_args()
    out=a.output;out.mkdir(parents=True,exist_ok=True);(out/'frames').mkdir(exist_ok=True)
    for k in VARIANTS:print('generating',k,flush=True);generate_variant(k,out,a.eggs,a.fps)
    make_gallery(out);make_lineup(out,a.fps);make_all_multiangle(out);make_cat_contact_sheet(out,a.fps)
    if a.baseline:make_changed_before_after(out,a.baseline,a.fps)
    write_readme(out)
    for f in ['render_mobs_visual_qa.py','make_visual_qa_showcase.py','audit_pie_animation_fidelity.py','test_pie_animation_formula_parity.py','test_cherry_animation_formula_parity.py','audit_source_pack_completeness.py','audit_model_generation_determinism.py','audit_cat_bedrock_port.py']:
        shutil.copy2(HERE/f,out/f)
    shutil.copy2(ROOT/'SOURCE_PACK_PARITY.md',out/'SOURCE_PACK_PARITY.md')
    shutil.copy2(ROOT/'FINAL_VERIFICATION.md',out/'FINAL_VERIFICATION.md')
    write_sha(out)
if __name__=='__main__':main()
