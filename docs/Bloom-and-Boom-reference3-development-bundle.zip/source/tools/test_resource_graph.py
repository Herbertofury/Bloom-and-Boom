import json
import tempfile
import unittest
from pathlib import Path
from audit_resource_graph import audit


class ResourceGraphTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def put(self, path, content):
        target = self.root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)

    def test_malformed_and_duplicate_json_fail(self):
        for content in ['{"x":', '{"x":1,"x":2}']:
            with self.subTest(content=content):
                self.put('assets/example/models/item/a.json', content)
                self.assertTrue(audit(self.root)['errors'])

    def test_missing_local_texture_fails(self):
        self.put('assets/example/models/item/a.json', '{"textures":{"layer0":"example:item/missing"}}')
        self.assertIn('missing texture', audit(self.root)['errors'][0])

    def test_dependency_namespace_is_reported_not_rejected(self):
        self.put('assets/example/models/item/a.json', '{"parent":"another_mod:item/base"}')
        report = audit(self.root)
        self.assertEqual([], report['errors'])
        self.assertEqual(['another_mod'], report['external_namespaces_not_resolved'])

    def test_existing_parent_and_variable_pass(self):
        self.put('assets/example/models/item/base.json', '{}')
        self.put('assets/example/models/item/a.json', '{"parent":"example:item/base","textures":{"particle":"#layer0"}}')
        self.assertEqual([], audit(self.root)['errors'])

    def test_blockstate_missing_model_fails(self):
        self.put('assets/example/blockstates/a.json', '{"multipart":[{"apply":{"model":"example:block/missing"}}]}')
        self.assertIn('missing model', audit(self.root)['errors'][0])

    def test_traversal_fails(self):
        self.put('assets/example/models/item/a.json', '{"parent":"example:../outside"}')
        self.assertIn('invalid reference', audit(self.root)['errors'][0])

    def test_empty_tree_fails(self):
        self.assertTrue(audit(self.root)['errors'])


if __name__ == '__main__':
    unittest.main()
