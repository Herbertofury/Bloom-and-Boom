#!/usr/bin/env python3
"""Numerically compare Creeperella 1.4.3 Cherry/Blossom native formulas with Remake 3.0 CEM.

The source side evaluates the animation strings directly from the uploaded CEM. The independent port
side transcribes the Java formulas. This catches omitted channels, sign/phase mistakes, wrong blink
speed, hurt response regressions, and the easy-to-miss original-body `body.ty = 18` target.
"""
from __future__ import annotations
import json, math, re
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'reference-assets/cherry/creeper.jem'
EPS=2e-6

def clamp(v,a,b): return max(a,min(b,v))
def torad(v): return math.radians(v)
def todeg(v): return math.degrees(v)
def lerp(t,a,b): return a+(b-a)*t
def iff(c,a,b): return a if c else b

def expr_py(s:str)->str:
    return re.sub(r'\bif\s*\(', 'iff(', s).replace('&&',' and ').replace('||',' or ')

def source_channels(st):
    d=json.loads(SRC.read_text())
    model=next(m for m in d['models'] if m.get('id')=='body')
    var=SimpleNamespace(hurt=st['hurt_prev'])
    env={
      'sin':math.sin,'cos':math.cos,'min':min,'max':max,'abs':abs,'floor':math.floor,
      'clamp':clamp,'torad':torad,'todeg':todeg,'lerp':lerp,'iff':iff,'pi':math.pi,
      'var':var,'time':st['time'],'frame_time':st['frame_time'],'is_hurt':st['is_hurt'],
      'limb_swing':st['limb_swing'],'limb_speed':st['limb_speed'],'head_yaw':st['head_yaw'],
      'head_pitch':st['head_pitch'],'hurt_time':st['hurt_time'],
    }
    out={}
    for block in model['animations']:
      for key,raw in block.items():
        v=eval(expr_py(raw),{'__builtins__':{}},env)
        if key.startswith('var.'):
          setattr(var,key.split('.',1)[1],v)
        else:
          out[key]=v
          target,attr=key.split('.',1)
          obj=env.setdefault(target,SimpleNamespace()); setattr(obj,attr,v)
    return out, var.hurt

def port(st):
    deg=math.pi/180
    t=st['time']; ls=st['limb_swing']; speed=st['limb_speed']*10; ht=st['hurt_time']
    # Exact source state update, including its degree-domain sine wrapper.
    hurt=todeg(math.sin(torad(clamp(st['hurt_prev'] + (-0.2 if st['is_hurt'] else 0.2)*st['frame_time']*20,0,1))))
    face=math.floor(t/2.5)%21
    walk=lerp(hurt,0,min(0,(-math.sin(ls+math.pi/2)+0.3)*speed/1.5))
    minuswalk=lerp(hurt,0,min(0,(math.sin(ls+math.pi/2)+0.3)*speed/1.5))
    walkrx=lerp(hurt,0,(-math.sin(ls)/6)*speed/2)
    si=math.sin(t/7); co=math.cos(t/7)
    o={
      'head_cherry_face_fr1.visible': face>=0 and face<=17,
      'head_cherry_face_fr2.visible': face==18,
      'head_cherry_face_fr3.visible': face>=19 and face<=20,
      'body_cherry_rotation.rz': -co*torad(2),
      'cherrycreeper_legs.ry': torad(st['head_yaw']/6),
      'cherrycreeper_leg1.rx': walkrx-ht*torad(4),
      'cherrycreeper_leg1.ry': torad(8)-co*torad(2)+ht*torad(3.5),
      'cherrycreeper_leg1.rz': torad(8)+si*torad(1),
      'cherrycreeper_leg2.rx': -walkrx-ht*torad(4),
      'cherrycreeper_leg2.ry': -torad(8)+co*torad(2)-ht*torad(3.5),
      'cherrycreeper_leg2.rz': -torad(8)-si*torad(1),
      'cherrycreeper_leg3.rx': -walkrx-ht*torad(4),
      'cherrycreeper_leg3.ry': -torad(8)+si*torad(2)+ht*torad(3.5),
      'cherrycreeper_leg3.rz': torad(8)-co*torad(1),
      'cherrycreeper_leg4.rx': walkrx-ht*torad(4),
      'cherrycreeper_leg4.ry': -torad(8)-si*torad(2)-ht*torad(3.5),
      'cherrycreeper_leg4.rz': -torad(8)+co*torad(1),
      'cherrycreeper_leg1.ty': -6+walk,
      'cherrycreeper_leg2.ty': -6+minuswalk,
      'cherrycreeper_leg3.ty': -6+minuswalk,
      'cherrycreeper_leg4.ty': -6+walk,
      'boobs.rx': -5.5-si*torad(3)+math.sin(ls+math.pi/4)*speed/58,
      'boobs.ry': math.cos(ls)*ht*torad(4),
      'boobs.rz': co*torad(6)+math.sin(ls)*ht*torad(4),
      'bone3.rx': -torad(35)+math.cos(ls/0.5)*ht*torad(6)-co*torad(16),
      'bone15.ry': -torad(120)-math.sin(ls/0.5)*ht*torad(6)-co*torad(6),
      'bone15.rz': -torad(220)-math.sin(ls/0.5)*ht*torad(6)-si*torad(16),
      'bone14.ry': torad(290)+math.cos(ls/0.5)*ht*torad(8),
      'bone14.rz': -torad(190)+math.sin(ls/0.5)*ht*torad(6)-si*torad(16),
      'bone12.rz': torad(190)+math.sin(ls/0.5)*ht*torad(8)-si*torad(16),
      'bone12.rx': torad(177)-math.cos(ls/0.5)*ht*torad(6),
      'bone9.rx': -torad(140)-math.sin(ls/0.5)*ht*torad(6)+co*torad(16),
      'body_cherry.ry': torad(st['head_yaw']/4)-co*torad(2)+math.sin(ls)*ht*torad(3),
      'body_cherry.rz': si*torad(2)+math.sin(ls)*ht*torad(2),
      'body_cherry.rx': co*torad(3.5)+torad(st['head_pitch']/4),
      'body_cherry.tx': si*0.3,
      'body_cherry.ty': lerp(hurt,-5.95,-5.95-math.sin(ls)*speed/7+speed*0.18),
      'head_cherry.tx': si*torad(16),
      'head_cherry.rx': si*torad(4)-torad(st['head_pitch']/4),
      'head_cherry.ry': torad(st['head_yaw']/2.5)+math.cos(ls)*ht*torad(2.5),
      'head_cherry.rz': -co*torad(10)+torad(st['head_yaw']/4),
      'bone11.rx': -co*torad(6)-math.sin(ls)*ht*torad(2),
      'bone11.rz': -si*torad(6)-math.cos(ls)*ht*torad(3),
      'bone13.rx': -co*torad(6)-math.sin(ls)*ht*torad(3),
      'bone13.rz': -si*torad(6)-math.cos(ls)*ht*torad(4),
      'body.ty': lerp(hurt,18,18),
      'head_cherry.ty': lerp(hurt,-12,-12),
    }
    return o,hurt

SAMPLES=[
 dict(time=0.0,frame_time=1/60,is_hurt=False,hurt_prev=0.0,limb_swing=0.0,limb_speed=0.0,head_yaw=0,head_pitch=0,hurt_time=0),
 dict(time=17.5,frame_time=1/60,is_hurt=False,hurt_prev=0.63,limb_swing=3.1,limb_speed=.22,head_yaw=35,head_pitch=-18,hurt_time=0),
 dict(time=45.1,frame_time=1/144,is_hurt=True,hurt_prev=.91,limb_swing=7.25,limb_speed=.64,head_yaw=-52,head_pitch=26,hurt_time=7),
 dict(time=52.4,frame_time=1/30,is_hurt=True,hurt_prev=.35,limb_swing=10.8,limb_speed=1.0,head_yaw=72,head_pitch=-48,hurt_time=3),
 dict(time=100.0,frame_time=1/75,is_hurt=False,hurt_prev=.02,limb_swing=14.2,limb_speed=.45,head_yaw=-17,head_pitch=11,hurt_time=0),
]

def main():
    total=0
    channel_count=None
    for i,s in enumerate(SAMPLES):
      src,h1=source_channels(s); got,h2=port(s)
      channel_count=len(src) if channel_count is None else channel_count
      missing=sorted(set(src)-set(got)); extra=sorted(set(got)-set(src))
      if missing or extra: raise SystemExit(f'FAIL sample {i}: missing={missing}, extra={extra}')
      if not math.isclose(h1,h2,abs_tol=EPS,rel_tol=0): raise SystemExit(f'FAIL sample {i}: var.hurt {h1} != {h2}')
      for k,v in src.items():
        a=got[k]
        if isinstance(v,bool):
          if a is not v: raise SystemExit(f'FAIL sample {i} {k}: {a!r}!={v!r}')
        elif not math.isclose(float(a),float(v),abs_tol=EPS,rel_tol=0):
          raise SystemExit(f'FAIL sample {i} {k}: port={a:.12g} source={v:.12g}')
        total+=1
    java=(ROOT/'src/main/java/dev/herbertofury/creeperella/client/CreeperellaModel.java').read_text()
    required=['vanillaBody.y = 18.0F','ageInTicks / 2.5F','bone12.xRot = 177.0F','bone14.yRot = 290.0F','hurtTime * 3.5F * deg','new CherryHurtState(0.0F, ageInTicks)']
    bad=[x for x in required if x not in java]
    if bad: raise SystemExit('FAIL Java port markers missing: '+repr(bad))
    print(f'PASS: Cherry Remake source exposes {channel_count} runtime output channels')
    print(f'PASS: {total} sampled Cherry/Blossom channel evaluations match supplied CEM formulas')
    print('PASS: original body proxy Y=18, exact 2.5-tick face timing, full leaf/hair/chest/hurt channels present')

if __name__=='__main__': main()
