#!/usr/bin/env python3
"""Derive vanilla-TNT face textures from Cherry Remake's exact authored 64x64 TNT atlas.

The source resource pack uses a Blockbench one-cube model solely to address 16x16 face tiles
inside a 64x64 atlas. Creeperella preserves the exact atlas as provenance, but the runtime block
uses Minecraft's vanilla cube_bottom_top geometry with deterministic 16x16 face textures.
"""
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'reference-assets/source-packs/cherry/assets/minecraft/textures/block/tnt/tnt.png'
OUT = ROOT / 'src/main/resources/assets/creeperella/textures/block'
OUT.mkdir(parents=True, exist_ok=True)

im = Image.open(SRC).convert('RGBA')
if im.size != (64, 64):
    raise SystemExit(f'expected 64x64 Cherry TNT atlas, got {im.size}')

# Convert the exact source model UV declarations into final 16x16 face pixels.
# UV coordinates are model-space 0..16 across the 64x64 source atlas.
def face(uv, rotation=0):
    x1, y1, x2, y2 = uv
    sx = im.width / 16
    sy = im.height / 16
    left, right = sorted((int(round(x1 * sx)), int(round(x2 * sx))))
    top, bottom = sorted((int(round(y1 * sy)), int(round(y2 * sy))))
    out = im.crop((left, top, right, bottom))
    if x2 < x1:
        out = out.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    if y2 < y1:
        out = out.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
    if rotation:
        out = out.rotate(-rotation, expand=False, resample=Image.Resampling.NEAREST)
    if out.size != (16, 16):
        raise SystemExit(f'face produced {out.size}, expected 16x16')
    return out

side = face((4, 4, 8, 8), 0)      # all four source side tiles are pixel-identical
upper = face((8, 4, 4, 0), 90)
lower = face((8, 0, 12, 4), 270)

side.save(OUT / 'cherry_tnt_side.png')
upper.save(OUT / 'cherry_tnt_top.png')
lower.save(OUT / 'cherry_tnt_bottom.png')
print('generated vanilla-compatible Cherry TNT side/top/bottom faces from exact source atlas')
