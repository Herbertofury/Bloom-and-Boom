import copy
import json
from pathlib import Path

from generate_layers import WORK, emit_part, generate_method
from generate_cherry_remake_layers import puff

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'src/main/java/dev/herbertofury/creeperella/client/BlossomRemakeModelLayers.java'
JEM = WORK / 'cherry/creeper.jem'
HEAD_JEM = WORK / 'cherry/head_creeper.jem'

HEADER = '''package dev.herbertofury.creeperella.client;

import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Blossom Creeper layer: Cherry Remake source geometry plus namespaced sakura silhouette accents.
 * Base Cherry geometry stays source-faithful and untouched; only Blossom receives these additions.
 */
public final class BlossomRemakeModelLayers {
    private BlossomRemakeModelLayers() {}

'''


def find_id(part, wanted):
    if part.get('id') == wanted:
        return part
    for sub in part.get('submodels', []) or []:
        hit = find_id(sub, wanted)
        if hit is not None:
            return hit
    return None


def plane(name, translate, rotate, axis='z', size=4.0, mirror=False):
    half = size / 2.0
    if axis == 'x':
        coords = [0.0, -half, -half, 0.0, size, size]
    elif axis == 'y':
        coords = [-half, 0.0, -half, size, 0.0, size]
    else:
        coords = [-half, -half, 0.0, size, size, 0.0]
    out = {
        'id': name,
        'invertAxis': 'xy',
        'translate': translate,
        'rotate': rotate,
        'boxes': [{'coordinates': coords, 'textureOffset': [46, 21]}],
    }
    if mirror:
        out['mirrorTexture'] = 'u'
    return out


def add_mob_accents(data):
    body = head = None
    for model in data.get('models', []):
        body = body or find_id(model, 'body_cherry')
        head = head or find_id(model, 'head_cherry')
    if body is None or head is None:
        raise ValueError('Cherry source hierarchy changed; Blossom accents need review')
    head.setdefault('submodels', []).extend([
        plane('blossom_crown_center', [0.0, 8.2, -0.35], [0.0, 0.0, 45.0], 'z', 4.2),
        plane('blossom_crown_left', [4.15, 6.9, 0.7], [12.0, -34.0, 28.0], 'x', 4.0),
        plane('blossom_crown_right', [-4.15, 6.8, 0.7], [12.0, 34.0, -28.0], 'x', 4.0, True),
        plane('blossom_back_bloom', [0.0, 5.1, 4.05], [-20.0, 0.0, 20.0], 'z', 4.4),
    ])
    body.setdefault('submodels', []).extend([
        plane('blossom_shoulder_left', [4.15, 9.4, -0.8], [18.0, -42.0, 28.0], 'x', 4.1),
        plane('blossom_shoulder_right', [-4.15, 9.4, -0.8], [18.0, 42.0, -28.0], 'x', 4.1, True),
        plane('blossom_hip_bloom', [0.0, 2.35, 2.15], [8.0, 0.0, 45.0], 'z', 4.3),
    ])
    return data


def add_head_accents(data):
    models = [copy.deepcopy(m) for m in data.get('models', []) if m.get('part') == 'head']
    if len(models) != 1:
        raise ValueError('Expected one source head')
    head = models[0]
    head.setdefault('submodels', []).extend([
        plane('blossom_crown_center', [0.0, 8.2, -0.35], [0.0, 0.0, 45.0], 'z', 4.2),
        plane('blossom_crown_left', [4.15, 6.9, 0.7], [12.0, -34.0, 28.0], 'x', 4.0),
        plane('blossom_crown_right', [-4.15, 6.8, 0.7], [12.0, 34.0, -28.0], 'x', 4.0, True),
        plane('blossom_back_bloom', [0.0, 5.1, 4.05], [-20.0, 0.0, 20.0], 'z', 4.4),
    ])
    return head


def generate_head_method(name, data):
    tex_size = data.get('textureSize', [64, 64])
    model = add_head_accents(data)
    lines = [
        f'    public static LayerDefinition {name}() {{',
        '        MeshDefinition mesh = new MeshDefinition();',
        '        PartDefinition root = mesh.getRoot();',
    ]
    emit_part(lines, 'root', model, 'blossom_head', tex_size, force_thin_planes=True)
    lines.append(f'        return LayerDefinition.create(mesh, {int(tex_size[0])}, {int(tex_size[1])});')
    lines.append('    }')
    return '\n'.join(lines)


if __name__ == '__main__':
    base = add_mob_accents(json.loads(JEM.read_text(encoding='utf-8')))
    charge = copy.deepcopy(base)
    for part in charge.get('models', []):
        puff(part)
    head = json.loads(HEAD_JEM.read_text(encoding='utf-8'))
    methods = [
        generate_method('createBlossomLayer', base, force_thin_planes=True),
        generate_method('createBlossomChargeLayer', charge, force_thin_planes=True),
        generate_head_method('createBlossomHeadLayer', head),
    ]
    OUT.write_text(HEADER + '\n\n'.join(methods) + '\n}\n', encoding='utf-8')
    print(OUT)
    print('bytes', OUT.stat().st_size)
