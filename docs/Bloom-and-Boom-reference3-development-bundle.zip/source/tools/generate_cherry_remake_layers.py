import copy
import json
from pathlib import Path

from generate_layers import WORK, emit_part, generate_method

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'src/main/java/dev/herbertofury/creeperella/client/CherryRemakeModelLayers.java'
JEM = WORK / 'cherry/creeper.jem'
HEAD_JEM = WORK / 'cherry/head_creeper.jem'

HEADER = '''package dev.herbertofury.creeperella.client;\n\nimport net.minecraft.client.model.geom.PartPose;\nimport net.minecraft.client.model.geom.builders.CubeDeformation;\nimport net.minecraft.client.model.geom.builders.CubeListBuilder;\nimport net.minecraft.client.model.geom.builders.LayerDefinition;\nimport net.minecraft.client.model.geom.builders.MeshDefinition;\nimport net.minecraft.client.model.geom.builders.PartDefinition;\n\n/**\n * Native model layers converted from Cherry Creeper remake 3.0 by Poolb / Kotisimo.\n * The mob and standalone Cherry Creeper Head are generated directly from the supplied CEM geometry.\n */\npublic final class CherryRemakeModelLayers {\n    private CherryRemakeModelLayers() {}\n\n'''

def puff(part):
    for box in part.get('boxes', []) or []:
        box['sizeAdd'] = float(box.get('sizeAdd', 0.0)) + 0.5
    for sub in part.get('submodels', []) or []:
        puff(sub)


def generate_head_method(name: str, data: dict) -> str:
    tex_size = data.get('textureSize', [64, 64])
    models = [copy.deepcopy(m) for m in data.get('models', []) if m.get('part') == 'head']
    if len(models) != 1:
        raise ValueError(f'Expected exactly one head model in {HEAD_JEM}, got {len(models)}')
    lines = [
        f'    public static LayerDefinition {name}() {{',
        '        MeshDefinition mesh = new MeshDefinition();',
        '        PartDefinition root = mesh.getRoot();',
    ]
    emit_part(lines, 'root', models[0], 'cherry_head', tex_size, force_thin_planes=True)
    lines.append(f'        return LayerDefinition.create(mesh, {int(tex_size[0])}, {int(tex_size[1])});')
    lines.append('    }')
    return '\n'.join(lines)


if __name__ == '__main__':
    base = json.loads(JEM.read_text(encoding='utf-8'))
    charge = copy.deepcopy(base)
    for part in charge.get('models', []):
        puff(part)
    head = json.loads(HEAD_JEM.read_text(encoding='utf-8'))

    methods = [
        generate_method('createCherryLayer', base, force_thin_planes=True),
        generate_method('createCherryChargeLayer', charge, force_thin_planes=True),
        generate_head_method('createCherryHeadLayer', head),
    ]
    OUT.write_text(HEADER + '\n\n'.join(methods) + '\n}\n', encoding='utf-8')
    print(OUT)
    print('bytes', OUT.stat().st_size)
