#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re, sys
from pathlib import Path
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'src/main/resources/assets/creeperella'
JAVA=ROOT/'src/main/java/dev/herbertofury/creeperella'
REF=ROOT/'reference-assets/shroomboom'
BASELINE=Path('/mnt/data/nacrella-baseline')
EXPECTED_STABLE={
 'textures/entity/boomshroom_creeper.png':'37b72d8e1a11569bc79b743c5c77f90dc539ba9dd251f898de62a580bd5b9dd0',
 'textures/entity/boomshroom_cap.png':'ababadc6df55ab4e42803ac19fce39d4ceaf7dfc255c0fbc0e9c45abb2d6da4a',
 'textures/entity/boomshroom_cap_glow.png':'688aee5d8ac0e0f6a8c5d0e5fe6aba9586f19d843a0138d3605dda6c6047305f',
 'textures/entity/cherry_creeper.png':'f616daad6e1aa1f9b9b81041cd8823aa17faa4eeb8d4e00801a1547328cf1bdb',
 'textures/entity/nacrella_creeper.png':'f3c8a72ba144d4fb0ed91f5990944cb0d6473f8450f4c6eb1fe52bc03811c7ae',
 'textures/entity/cinderella_creeper.png':'e95697d29896eb70346cbb6b435ee2f32ed27161fc6c2e1503e86226bfa5fab8',
}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fail(errors,msg): errors.append(msg)

def main():
    errors=[]
    for rel,h in EXPECTED_STABLE.items():
        p=RES/rel
        if not p.is_file(): fail(errors,f'missing protected stable asset {rel}')
        elif sha(p)!=h: fail(errors,f'protected stable asset changed {rel}: {sha(p)}')
    body=RES/'textures/entity/shroomboom_creeper.png'; detail=RES/'textures/entity/shroomboom_details.png'; egg=RES/'textures/item/shroomboom_creeper_spawn_egg.png'
    for p,size in [(body,(128,64)),(detail,(256,128)),(egg,(16,16))]:
        if not p.is_file(): fail(errors,f'missing {p.relative_to(ROOT)}'); continue
        im=Image.open(p).convert('RGBA')
        if im.size!=size: fail(errors,f'{p.name} size {im.size} != {size}')
        opaque=[px for px in im.getdata() if px[3]>8]
        if len(opaque)<20: fail(errors,f'{p.name} is suspiciously empty')
        if len(set(opaque))<8: fail(errors,f'{p.name} palette/detail too flat ({len(set(opaque))} colors)')
    if (REF/'Shroomboom.png').is_file() and Path('/mnt/data/Shroomboom.png').is_file() and sha(REF/'Shroomboom.png')!=sha('/mnt/data/Shroomboom.png'):
        fail(errors,'stored Shroomboom reference differs from the user attachment')
    rec=json.loads((ROOT/'tools/shroomboom_detail_recipe.json').read_text())
    names={p['name'] for p in rec['parts']}; cubes=sum(len(p.get('cubes',[])) for p in rec['parts'])
    required={'cap_root','gill_plate','gill_hub','cap_spots','cap_side_spots','face_details','face_bangs','lashes_left','lashes_right','eyelid_left','eyelid_right',
              'hair_left_root','hair_left_mid','hair_left_tip','hair_right_root','hair_right_mid','hair_right_tip',
              'hair_front_left_root','hair_front_left_mid','hair_front_left_tip','hair_front_right_root','hair_front_right_mid','hair_front_right_tip',
              'hair_back_left_root','hair_back_left_mid','hair_back_left_tip','hair_back_right_root','hair_back_right_mid','hair_back_right_tip',
              'body_details','chest_details','leg1_details','leg2_details','leg3_details','leg4_details'} | {f'gill_rib_{i}' for i in range(24)}
    missing=sorted(required-names)
    if missing: fail(errors,f'missing required recipe parts: {missing}')
    if len(rec['parts'])<73 or cubes<343: fail(errors,f'detail mesh unexpectedly reduced: parts={len(rec["parts"])} cubes={cubes}')
    part_map={p['name']:p for p in rec['parts']}
    motif_floors={'cap_root':13,'gill_skirt':6,'gill_hub':1,'cap_spots':18,'cap_side_spots':10,'face_details':12,'face_bangs':6,'lashes_left':9,'lashes_right':9,'body_details':26,'chest_details':14,'leg1_details':18,'leg2_details':18,'leg3_details':18,'leg4_details':18}
    for name,floor in motif_floors.items():
        actual=len(part_map.get(name,{}).get('cubes',[]))
        if actual<floor: fail(errors,f'{name} detail floor regressed: {actual} < {floor}')
    mini_caps=[n for n in names if n.startswith('mini_cap_')]
    if len(mini_caps)<9: fail(errors,f'cap mushroom count regressed: {len(mini_caps)} < 9')
    hair_stems=['hair_left','hair_right','hair_front_left','hair_front_right','hair_back_left','hair_back_right']
    for stem in hair_stems:
        for suffix in ('root','mid','tip'):
            name=f'{stem}_{suffix}'
            if name not in names: fail(errors,f'missing 3-segment physics hair part {name}')
            elif len(part_map[name].get('cubes',[])) < 4: fail(errors,f'{name} moss-strand density regressed: {len(part_map[name].get("cubes",[]))} < 4')
    recipe_audit=REF/'voxel-recipe-audit.json'
    if not recipe_audit.is_file(): fail(errors,'missing Texture Intelligence voxel recipe audit')
    else:
        audit=json.loads(recipe_audit.read_text())
        if not audit.get('passed') or audit.get('uv',{}).get('out_of_bounds_count')!=0:
            fail(errors,f'voxel recipe audit failed: {audit.get("uv",{}).get("out_of_bounds_count")} UV overflow(s)')
    layer=(JAVA/'client/ShroomboomDetailLayer.java').read_text()
    for token in ['applyPieBreastAnchor','applyPieLegAnchor','SpringChain','turnImpulse','Math.pow(damping, dt)','eyelid_left','hair_front_left','hair_back_right','frontLeft.step','backRight.step','MMV']:
        if token=='MMV': continue
        if token not in layer: fail(errors,f'ShroomboomDetailLayer missing required implementation token {token}')
    model=(JAVA/'client/CreeperellaModel.java').read_text()
    for token in ['CreeperellaKind.SHROOMBOOM','applyPieHeadAnchor','applyPieBodyAnchor','applyPieBreastAnchor','applyPieLegAnchor']:
        if token not in model: fail(errors,f'CreeperellaModel missing {token}')
    bus=(JAVA/'event/ModBusEvents.java').read_text()
    pattern=r'event\.register\(ModEntities\.SHROOMBOOM_CREEPER\.get\(\).*?\(type, level, reason, pos, random\) -> false'
    if not re.search(pattern,bus,re.S): fail(errors,'Shroomboom natural spawning is not hard-disabled during visual development')
    qa=(JAVA/'CreeperellaQaCommands.java').read_text()
    for token in ['Commands.literal("shroomboom")','Commands.literal("shroomboom_motion")','Commands.literal("charged_shroomboom")','MMV_QA_SHROOMBOOM','MMV_QA_CHARGED_SHROOMBOOM']:
        if token not in qa: fail(errors,f'QA harness missing {token}')
    if errors:
        print('FAIL')
        for e in errors: print(' -',e)
        return 1
    print(f'PASS: stable Boomshroom/Cherry/Nacrella/Cinderella assets protected; Shroomboom reference exact; details parts={len(rec["parts"])} cubes={cubes}; 3D lashes+blink lids+six 3-segment four-strand spring hair chains+exposed radial gills+dark rooted feet+Pie chest/leg anchors present; recipe UV-safe; natural spawn hard-disabled')
    return 0
if __name__=='__main__': sys.exit(main())
