#!/usr/bin/env python3
"""Paint high-resolution UV-specific reference faces and non-clipping lantern colors.
Deterministic vanilla-derived pixel materials, no generated reference replacements.
"""
from pathlib import Path
from PIL import Image,ImageStat
R=Path(__file__).resolve().parents[1];T=R/'src/main/resources/assets/creeperella/textures/entity';V=R/'.mvf-generated/vanilla'
for name,material,tint,bulb in [('nacrella','pearlescent',(216,200,235),(158,105,205)),('verdalia','verdant',(203,224,188),(105,175,85)),('mariglow','ochre',(239,220,172),(205,140,55))]:
 vanilla=Image.open(V/f'{material}_froglight_side.png').convert('RGB');mean=ImageStat.Stat(vanilla).mean
 # The face plate occupies the first eight logical texels of a 64-wide layer atlas.
 # Eight physical pixels per logical texel provide a 64-pixel painted face.
 face=Image.new('RGBA',(512,512),(*tint,255))
 for y in range(80):
  for x in range(80):
   nx=min(1,max(0,(x-2)/64));ny=min(1,max(0,(y-2)/64))
   sample=vanilla.getpixel((min(15,int(nx*16)),min(15,int(ny*16))))
   center=1-abs(nx*2-1)
   shade=0.79+0.18*center
   stripe=((x//4)*17%11-5)*0.008
   cell=((x//4)*7+(y//4)*13)%9-4
   rgb=tuple(max(0,min(255,round((tint[k]*0.7+sample[k]*0.3)*(shade+stripe)+cell*2))) for k in range(3))
   face.putpixel((x,y),(*rgb,255))
 face.save(T/f'{name}_face_skin.png')
 acc=Image.open(T/f'{name}_accessories.png').convert('RGBA');glow=Image.open(T/f'{name}_accessories_e.png').convert('RGBA')
 for y in range(64):
  for x in range(48,64):
   d=5 if (x+y)%3 else -4
   acc.putpixel((x,y),(*(c+d for c in bulb),255))
   glow.putpixel((x,y),(*(min(255-c-5,round(c*0.26)) for c in bulb),255))
 acc.save(T/f'{name}_accessories.png');glow.save(T/f'{name}_accessories_e.png')
 print(name,'face surface and tinted lanterns written')
