#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'src/main/java/dev/herbertofury/creeperella'
RES = ROOT / 'src/main/resources'
ASSET = RES / 'assets/creeperella'
DATA = RES / 'data/creeperella'
REF = ROOT / 'reference-assets/creeper-overhaul'

CAP_SHA = 'ababadc6df55ab4e42803ac19fce39d4ceaf7dfc255c0fbc0e9c45abb2d6da4a'
GLOW_SHA = '688aee5d8ac0e0f6a8c5d0e5fe6aba9586f19d843a0138d3605dda6c6047305f'
CHERRY_SHA = 'f616daad6e1aa1f9b9b81041cd8823aa17faa4eeb8d4e00801a1547328cf1bdb'

def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(p: Path) -> str:
    return p.read_text(encoding='utf-8')

def j(p: Path):
    return json.loads(read(p))

def main() -> int:
    errors=[]
    def req(ok, msg):
        if not ok: errors.append(msg)

    kind = read(JAVA/'entity/CreeperellaKind.java')
    ents = read(JAVA/'registry/ModEntities.java')
    items = read(JAVA/'registry/ModItems.java')
    cfg = read(JAVA/'config/CreeperellaConfig.java')
    common = read(JAVA/'event/CommonEvents.java')
    themed_fx = read(JAVA/'effect/ThemedExplosionEffects.java')
    bus = read(JAVA/'event/ModBusEvents.java')
    client = read(JAVA/'client/ClientEvents.java')
    model = read(JAVA/'client/CreeperellaModel.java')
    renderer = read(JAVA/'client/CreeperellaRenderer.java')
    caplayer = read(JAVA/'client/BoomshroomCapLayer.java')
    particle = read(JAVA/'client/BoomshroomSporeParticle.java')
    particles = read(JAVA/'registry/ModParticles.java')
    qa = read(JAVA/'CreeperellaQaCommands.java')

    req('BOOMSHROOM("boomshroom_creeper")' in kind, 'Boomshroom kind missing')
    req('BOOMSHROOM_CREEPER' in ents and 'case BOOMSHROOM' in ents, 'Boomshroom entity registration/mapping incomplete')
    req('BOOMSHROOM_CREEPER_SPAWN_EGG' in items, 'Boomshroom spawn egg missing')
    req('SPAWN_BOOMSHROOM' in cfg, 'Boomshroom config gate missing')
    req('canSpawnBoomshroom' in bus and 'Biomes.MUSHROOM_FIELDS' in bus, 'Mushroom Fields spawn rule missing')
    req('held.is(Items.RED_MUSHROOM)' in common and 'CreeperellaKind.BOOMSHROOM' in common, 'red-mushroom transformation missing')
    req(('case BOOMSHROOM -> held.is(Items.BROWN_MUSHROOM)' in common or 'case BOOMSHROOM, SHROOMBOOM -> held.is(Items.BROWN_MUSHROOM)' in common), 'brown-mushroom taming treat missing')
    req('ThemedExplosionEffects.emit' in common and 'ModParticles.BOOMSHROOM_SPORE' in themed_fx and 'BOOMSHROOM_RING_SPORES' in themed_fx, 'themed Boomshroom explosion routing/profile missing')
    req('triggerBoomshroomGreeting' in common and 'getBoomshroomGreetingProgress' in model, 'greeting state/model hook missing')
    req('BoomshroomCapLayer' in renderer and 'BOOMSHROOM_CAP' in client, 'separate cap render layer missing')
    req('applyBoomshroomCapAnchor' in model, 'animated Cherry-head cap anchor missing')
    req('RegisterParticleProvidersEvent' in client and 'BoomshroomSporeParticle.Provider' in client, 'particle provider registration missing')
    req('TextureSheetParticle' in particle and 'PARTICLE_SHEET_TRANSLUCENT' in particle, 'custom spore particle implementation missing')
    req('DeferredRegister<ParticleType<?>>' in particles, 'native particle registry missing')
    req('MMV_QA_BOOMSHROOM' in qa and 'MMV_QA_BOOMSHROOM_ECOLOGY' in qa and 'MMV_QA_BOOMSHROOM_EXPLOSION' in qa and 'MMV_QA_CHARGED_BOOMSHROOM' in qa and 'MMV_QA_BOOMSHROOM_EXPLOSION_FX' in themed_fx, 'Boomshroom runtime QA hooks missing')

    body = ASSET/'textures/entity/boomshroom_creeper.png'
    emissive = ASSET/'textures/entity/boomshroom_creeper_e.png'
    cap = ASSET/'textures/entity/boomshroom_cap.png'
    glow = ASSET/'textures/entity/boomshroom_cap_glow.png'
    cherry = ASSET/'textures/entity/cherry_creeper.png'
    for p, size in ((body,(64,64)),(emissive,(64,64)),(cap,(128,128)),(glow,(128,128))):
        req(p.exists(), f'missing texture {p.name}')
        if p.exists(): req(Image.open(p).size==size, f'{p.name} expected {size}, got {Image.open(p).size}')
    if body.exists() and cherry.exists():
        req(sha(body) != sha(cherry), 'Boomshroom body is still byte-identical Cherry reskin')
        req(sha(cherry) == CHERRY_SHA, 'protected Cherry texture changed unexpectedly')

        # 1.5.2 visual contract: white/ivory mushroom stalk with low-chroma authored shading,
        # a CO-derived neutral root/soil fade rising from the feet, and zero red facial markings.
        im = Image.open(body).convert('RGBA')
        face_rects = ((26,37,34,45),(26,45,34,53),(26,53,34,61))
        def face_xy(x,y):
            return any(x0 <= x < x1 and y0 <= y < y1 for x0,y0,x1,y1 in face_rects)
        stalk=[]
        for y in range(64):
            for x in range(64):
                r,g,b,a = im.getpixel((x,y))
                if a and not face_xy(x,y):
                    stalk.append((r,g,b))
        if stalk:
            avg = sum((r+g+b)/3.0 for r,g,b in stalk) / len(stalk)
            max_chroma = max(max(r,g,b)-min(r,g,b) for r,g,b in stalk)
            req(avg >= 210.0, f'Boomshroom stalk is too dark for the white-stalk contract: avg={avg:.2f}')
            req(max_chroma <= 12, f'Boomshroom stalk contains saturated body markings: max_chroma={max_chroma}')

        face=[]
        for y in range(64):
            for x in range(64):
                r,g,b,a = im.getpixel((x,y))
                if a and face_xy(x,y): face.append((r,g,b,x,y))
        if face:
            max_face_chroma=max(max(r,g,b)-min(r,g,b) for r,g,b,_,_ in face)
            max_red_excess=max(r-max(g,b) for r,g,b,_,_ in face)
            req(max_face_chroma <= 10, f'Boomshroom face contains saturated markings: max_chroma={max_face_chroma}')
            req(max_red_excess <= 4, f'Boomshroom face still contains red-biased pixels: red_excess={max_red_excess}')

        # CO-inspired ground pull must be a real gradient, not black socks or a flat gray torso.
        def row_mean(x0,x1,y):
            vals=[]
            for x in range(x0,x1):
                r,g,b,a=im.getpixel((x,y))
                if a: vals.append((r+g+b)/3.0)
            return sum(vals)/len(vals) if vals else 255.0
        leg_top=row_mean(0,16,20); leg_mid=row_mean(0,16,23); leg_ground=row_mean(0,16,25)
        req(leg_top >= 210.0 and leg_mid < leg_top - 15.0 and leg_ground < leg_mid - 35.0,
            f'Boomshroom foot-up root fade missing/too flat: top={leg_top:.1f} mid={leg_mid:.1f} ground={leg_ground:.1f}')
        body_upper=row_mean(16,40,26); body_root=row_mean(16,40,31)
        req(body_upper >= 210.0 and body_root <= body_upper - 35.0,
            f'Boomshroom lower-stalk root fingers missing: upper={body_upper:.1f} root={body_root:.1f}')

        eim = Image.open(emissive).convert('RGBA')
        emissive_pixels=sum(1 for y in range(64) for x in range(64) if eim.getpixel((x,y))[3])
        req(emissive_pixels == 0, f'Boomshroom body/face emissive must be fully transparent in 1.5.2, got {emissive_pixels} pixels')
    if cap.exists(): req(sha(cap)==CAP_SHA, 'authorized Creeper Overhaul cap base is not exact')
    if glow.exists(): req(sha(glow)==GLOW_SHA, 'authorized Creeper Overhaul cap glow is not exact')
    req((REF/'PROVENANCE.md').exists() and (REF/'mushroom.geo.json').exists() and (REF/'mushroom.animation.json').exists(), 'Creeper Overhaul provenance/reference source incomplete')

    pjson=ASSET/'particles/boomshroom_spore.json'
    req(pjson.exists(), 'spore particle sprite-set JSON missing')
    if pjson.exists(): req(len(j(pjson).get('textures',[]))==4, 'spore sprite set must contain 4 authored frames')
    for i in range(4):
        p=ASSET/f'textures/particle/boomshroom_spore_{i}.png'
        req(p.exists(), f'missing spore frame {i}')
        if p.exists(): req(Image.open(p).size==(8,8), f'spore frame {i} must be 8x8')

    tag=j(DATA/'tags/worldgen/biome/boomshroom_spawns.json')
    req(tag.get('values')==['minecraft:mushroom_fields'], 'Boomshroom biome tag must be Mushroom Fields only')
    modifier=j(DATA/'forge/biome_modifier/boomshroom_creeper_spawns.json')
    raw_sp=modifier.get('spawners',{})
    sp=raw_sp[0] if isinstance(raw_sp, list) and raw_sp else raw_sp
    req(sp.get('type')=='creeperella:boomshroom_creeper', 'biome modifier points at wrong entity')
    req(sp.get('weight')==10 and sp.get('minCount')==1 and sp.get('maxCount')==2, 'Boomshroom spawn weight/group must be 10 / 1-2')

    fam=j(DATA/'tags/entity_types/creeper_family.json').get('values',[])
    female=j(DATA/'tags/entity_types/female_family.json').get('values',[])
    req('creeperella:boomshroom_creeper' in fam, 'Boomshroom missing creeper_family tag')
    req('creeperella:boomshroom_creeper' in female, 'Boomshroom missing female_family tag')

    for state in ('idle','sway_left','sway_right','blink'):
        req((ASSET/f'models/item/3d/boomshroom_creeper_spawn_egg_{state}.json').exists(), f'missing Boomshroom 3D egg state {state}')

    if errors:
        print('FAIL: Boomshroom quality contract')
        for e in errors: print(' -', e)
        return 1
    print('PASS: Boomshroom has independent body art, exact authorized cap preservation, native 4-frame spores, Mushroom Fields ecology, Cherry-quality rig/greeting hooks, themed explosions, and 3D egg integration')
    return 0

if __name__ == '__main__':
    sys.exit(main())
