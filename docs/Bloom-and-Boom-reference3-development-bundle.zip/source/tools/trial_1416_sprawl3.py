#!/usr/bin/env python3
import sys,math
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
sys.path.insert(0,'/mnt/data/creeperella1416_work/tools')
import render_mobs_visual_qa as r
OUT=Path('/mnt/data/Creeperella-1.4.16-Trials');BG=(8,13,24,255);W=330;H=330;BASE=282
try:F=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
except:F=ImageFont.load_default()
def P(root,*p):return r.find(root,*p)
MAP={'leftLeg':('leftlegsub2','leftfoot3'),'rightLeg':('rightlegsub2','rightfoot3'),'leftLegback':('leftlegsub','leftfoot2'),'rightLegback':('rightlegsub','rightfoot2')}
def leg(root,n,dx,dy,dz,rx,ry,rz,lrx,frx):
 ln,fn=MAP[n];a=P(root,'body','waist',n);b=P(root,'body','waist',n,ln);c=P(root,'body','waist',n,ln,fn);a.x+=dx;a.y+=dy;a.z+=dz;a.rx=rx;a.ry=ry;a.rz=rz;b.rx=lrx;c.rx=frx
def ground():
 root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',40,0,0,0,0,cat_motion='idle');_,pts=r.build_polygons(root,tex,tw,th,0,0,subdivide=False);return float(pts[:,1].min())
G=ground()
def render(root,tex,tw,th,yaw,label):
 _,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=False);mnx,mxx=pts[:,0].min(),pts[:,0].max();mny,mxy=pts[:,1].min(),pts[:,1].max();sc=min((W-20)/max(mxx-mnx,1),(BASE-36)/max(mxy-G,1));xo=W/2-(mnx+mxx)/2*sc;yo=BASE+G*sc;can=np.zeros((H,W,4),dtype=np.uint8);can[:]=np.array(BG);im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);d.line((10,BASE,W-10,BASE),fill=(110,145,200,255),width=2);can=np.array(im);z=np.full((H,W),np.inf);polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=True)
 for _,q,rgba in polys:
  pp=np.array([[xo+p[0]*sc,yo-p[1]*sc,p[2]] for p in q]);r._raster_triangle(can,z,pp[[0,1,2]],rgba);r._raster_triangle(can,z,pp[[0,2,3]],rgba)
 im=Image.fromarray(can,'RGBA');ImageDraw.Draw(im).text((8,8),label,font=F,fill=(240,245,255));return im

def pose(root,k):
 w=P(root,'body','waist');b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head')
 vals=[
  (3.4,1.28,-1.02,-.20,-1.32,1.18,.08),
  (3.7,1.40,-1.12,-.24,-1.40,1.27,.05),
  (6.28,1.48,-1.18,-.28,-1.46,1.34,.03),
  (3.2,1.18,-.92,-.16,-1.25,1.10,.10),
 ][k]
 wy,bx,ux,hx,frx,hrx,roll=vals;w.y+=wy;b.y+=.30;b.rx+=bx;u.y+=.05;u.rx+=ux;h.rx+=hx
 # nearly straight chains, front forward, rear backward
 leg(root,'leftLeg', .20,.05,0,frx,0,roll,.02,-.02);leg(root,'rightLeg',-.20,.05,0,frx,0,-roll,.02,-.02)
 leg(root,'leftLegback', .28,.05,0,hrx,0,roll*.5,.02,-.02);leg(root,'rightLegback',-.28,.05,0,hrx,0,-roll*.5,.02,-.02)
 t=P(root,'body','waist','Body','tail');t2=P(root,'body','waist','Body','tail','tail2');t.rx=-.50;t.ry=0;t2.rx=-.15;t2.ry=0

sheet=Image.new('RGBA',(2*W,4*H),BG)
for k in range(4):
 for c,(yaw,vn) in enumerate([(-28,'3Q'),(-90,'SIDE')]):
  root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',42,0,0,0,0,cat_motion='sit');pose(root,k);sheet.alpha_composite(render(root,tex,tw,th,yaw,f'SPRAWL3 {k+1} · {vn}'),(c*W,k*H))
out=OUT/'SPRAWL3-sploot-trials.png';sheet.save(out);print(out)
