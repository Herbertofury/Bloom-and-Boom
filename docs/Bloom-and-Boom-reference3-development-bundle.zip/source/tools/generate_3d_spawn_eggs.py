#!/usr/bin/env python3
"""Generate Creeperella's optional animated 3D *egg-head* spawn eggs.

No image generation is used. The visible front/side color field is built directly from
Creeperella's exact 16x16 pack-authored 2D spawn-egg sprites. Each opaque source pixel
becomes part of a shallow convex voxel shell, so the 3D version reads as the same icon
turned into a rounded Minecraft egg/head rather than a separate character statue.

The user's Rethoughted Spawn Eggs pack remains a geometry/reference input only; no model
or texture bytes from that pack are copied into Creeperella.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Dict, List, Tuple
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
MODEL_DIR = ROOT / "src/main/resources/assets/creeperella/models/item/3d"
BASE_MODEL_DIR = ROOT / "src/main/resources/assets/creeperella/models/item"
ITEM_TEXTURE_DIR = ROOT / "src/main/resources/assets/creeperella/textures/item"
LEGACY_MATERIAL_DIR = ITEM_TEXTURE_DIR / "3d"

VARIANT_ITEM_IDS = {
    "female": "female_creeper_spawn_egg",
    "bunny": "bunny_creeper_spawn_egg",
    "bee": "bee_creeper_spawn_egg",
    "cherry": "cherry_creeper_spawn_egg",
    "blossom": "blossom_creeper_spawn_egg",
    "boomshroom": "boomshroom_creeper_spawn_egg",
    "cinderella": "cinderella_creeper_spawn_egg",
    "nacrella": "nacrella_creeper_spawn_egg",
    "shroomboom": "shroomboom_creeper_spawn_egg",
    "cat": "cat_creeper_spawn_egg",
}

# Small per-state display motion. The egg itself stays the exact same textured head;
# only presentation moves a little, avoiding the previous oversized limb/accessory sway.
BASE_DISPLAY = {
    "thirdperson_righthand": {"rotation": [8, 150, 0], "translation": [0, 3.2, 0.8], "scale": [0.74, 0.74, 0.74]},
    "thirdperson_lefthand": {"rotation": [8, -150, 0], "translation": [0, 3.2, 0.8], "scale": [0.74, 0.74, 0.74]},
    "firstperson_righthand": {"rotation": [4, 158, 0], "translation": [0, 4.0, 0.3], "scale": [0.82, 0.82, 0.82]},
    "firstperson_lefthand": {"rotation": [4, -158, 0], "translation": [0, 4.0, 0.3], "scale": [0.82, 0.82, 0.82]},
    "ground": {"rotation": [0, 22, 0], "translation": [0, 2.1, 0], "scale": [0.52, 0.52, 0.52]},
    "gui": {"rotation": [18, 145, 0], "translation": [0, -0.25, 0], "scale": [0.92, 0.92, 0.92]},
    "head": {"rotation": [0, 180, 0], "translation": [0, 12.0, 0], "scale": [0.92, 0.92, 0.92]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, 0.0, 0], "scale": [0.88, 0.88, 0.88]},
}


def display_for_state(state: str) -> dict:
    out = json.loads(json.dumps(BASE_DISPLAY))
    # The whole egg does a tiny, toy-like lean/bob. This is deliberately subtle.
    gui = out["gui"]
    fixed = out["fixed"]
    ground = out["ground"]
    if state == "sway_left":
        gui["rotation"][1] -= 4
        gui["rotation"][2] = -2
        fixed["rotation"][1] -= 4
        ground["rotation"][2] = -2
    elif state == "sway_right":
        gui["rotation"][1] += 4
        gui["rotation"][2] = 2
        fixed["rotation"][1] += 4
        ground["rotation"][2] = 2
    elif state == "blink":
        # Kept as the fourth animation phase for compatibility with the existing
        # item-property cycle. It is now a soft hop/squish rather than redrawing the face.
        gui["translation"][1] += 0.28
        gui["scale"] = [0.94, 0.90, 0.94]
        ground["translation"][1] += 0.20
    return out


def uv_pixel(x: int, y: int) -> List[float]:
    return [float(x), float(y), float(x + 1), float(y + 1)]


def faces_for_run(x0: int, x1: int, y: int) -> Dict[str, dict]:
    """Exact 2D texture strip on front/back, stable edge colors on the curved sides."""
    strip = [float(x0), float(y), float(x1), float(y + 1)]
    west = uv_pixel(x0, y)
    east = uv_pixel(x1 - 1, y)
    return {
        "north": {"uv": strip, "texture": "#egg"},
        "south": {"uv": [float(x1), float(y), float(x0), float(y + 1)], "texture": "#egg"},
        "west": {"uv": west, "texture": "#egg"},
        "east": {"uv": east, "texture": "#egg"},
        "up": {"uv": strip, "texture": "#egg"},
        "down": {"uv": strip, "texture": "#egg"},
    }


def visible_bbox(im: Image.Image) -> Tuple[int, int, int, int]:
    px = im.load()
    pts = [(x, y) for y in range(16) for x in range(16) if px[x, y][3] > 0]
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def depth_for_pixel(x: int, y: int, bbox: Tuple[int, int, int, int]) -> float:
    minx, miny, maxx, maxy = bbox
    cx = (minx + maxx + 1) / 2.0
    cy = (miny + maxy + 1) / 2.0
    rx = max(1.0, (maxx - minx + 1) / 2.0)
    ry = max(1.0, (maxy - miny + 1) / 2.0)
    nx = ((x + 0.5) - cx) / (rx * 1.02)
    ny = ((y + 0.5) - cy) / (ry * 1.04)
    # Convex ellipsoid depth. Slightly fuller toward the lower half gives a true
    # egg silhouette in three-quarter view rather than a sphere or rectangular head.
    radial = max(0.0, 1.0 - nx * nx - ny * ny)
    fullness = 0.94 + 0.12 * max(-1.0, min(1.0, ny))
    return 0.72 + 2.72 * math.sqrt(radial) * fullness


def sprite_shell(item_id: str) -> List[dict]:
    path = ITEM_TEXTURE_DIR / f"{item_id}.png"
    im = Image.open(path).convert("RGBA")
    if im.size != (16, 16):
        raise ValueError(f"{path} must remain 16x16; got {im.size}")
    bbox = visible_bbox(im)
    px = im.load()
    elements: List[dict] = []
    # Quantize curvature and merge horizontal runs. This keeps the exact front texture
    # while cutting baked-quad cost dramatically versus one cuboid per source pixel.
    for y in range(16):
        x = 0
        while x < 16:
            if px[x, y][3] == 0:
                x += 1
                continue
            depth = round(depth_for_pixel(x, y, bbox) * 2.0) / 2.0
            x0 = x
            x += 1
            while x < 16 and px[x, y][3] > 0:
                next_depth = round(depth_for_pixel(x, y, bbox) * 2.0) / 2.0
                if abs(next_depth - depth) > 1e-6:
                    break
                x += 1
            x1 = x
            y0 = 15.0 - y
            y1 = 16.0 - y
            elements.append({
                "from": [float(x0), y0, 8.0 - depth],
                "to": [float(x1), y1, 8.0 + depth],
                "faces": faces_for_run(x0, x1, y),
            })
    return elements


def sampled_uv(im: Image.Image, selector: str) -> List[float]:
    colors = []
    for y in range(16):
        for x in range(16):
            r, g, b, a = im.getpixel((x, y))
            if a == 0:
                continue
            lum = 0.2126 * r + 0.7152 * g + 0.0722 * b
            sat = max(r, g, b) - min(r, g, b)
            colors.append((x, y, r, g, b, lum, sat))
    if selector == "dark":
        x, y, *_ = min(colors, key=lambda c: c[5])
    elif selector == "light":
        x, y, *_ = max(colors, key=lambda c: c[5])
    elif selector == "accent":
        x, y, *_ = max(colors, key=lambda c: (c[6], c[5]))
    else:
        # Median-ish body color by luminance.
        colors.sort(key=lambda c: c[5])
        x, y, *_ = colors[len(colors) // 2]
    return uv_pixel(x, y)


def solid_element(frm, to, uv: List[float], rotation=None, shade=True) -> dict:
    faces = {face: {"uv": uv, "texture": "#egg"} for face in ("north", "east", "south", "west", "up", "down")}
    out = {"from": list(frm), "to": list(to), "faces": faces}
    if rotation:
        out["rotation"] = rotation
    if not shade:
        out["shade"] = False
    return out


def entity_green_uv(kind: str) -> Tuple[str, List[float]]:
    """Bake the best source green into an item-atlas-safe derived leaf swatch.

    Entity textures are intentionally not part of Minecraft's block/item atlas. Referring to
    ``#entity`` from an item model therefore produces a missing-texture warning (and can turn the
    tiny Cherry/Blossom leaf relief into the checkerboard sprite) in the real Forge client. Keep
    the exact source-derived color, but persist it as a tiny dedicated item texture that the atlas
    is guaranteed to stitch. No generative imagery is involved; every pixel is copied from the
    authorized source texture.
    """
    path = ROOT / f"src/main/resources/assets/creeperella/textures/entity/{kind}_creeper.png"
    im = Image.open(path).convert("RGBA")
    best = None
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = im.getpixel((x, y))
            if a == 0:
                continue
            score = (g - max(r, b)) + g * 0.10
            if best is None or score > best[0]:
                best = (score, x, y)
    if best is None:
        return "#egg", [0.0, 0.0, 1.0, 1.0]
    _, x, y = best
    rgba = im.getpixel((x, y))
    item_id = VARIANT_ITEM_IDS[kind]
    leaf_path = ITEM_TEXTURE_DIR / f"{item_id}_leaf.png"
    Image.new("RGBA", (16, 16), rgba).save(leaf_path, optimize=False)
    return "#leaf", [0.0, 0.0, 16.0, 16.0]


def solid_element_tex(frm, to, uv: List[float], texture: str = "#egg", rotation=None, shade=True) -> dict:
    faces = {face: {"uv": uv, "texture": texture} for face in ("north", "east", "south", "west", "up", "down")}
    out = {"from": list(frm), "to": list(to), "faces": faces}
    if rotation:
        out["rotation"] = rotation
    if not shade:
        out["shade"] = False
    return out


def variant_relief(kind: str, state: str, item_id: str) -> List[dict]:
    """Small integrated silhouette details. The body remains the exact sprite extrusion."""
    im = Image.open(ITEM_TEXTURE_DIR / f"{item_id}.png").convert("RGBA")
    dark = sampled_uv(im, "dark")
    light = sampled_uv(im, "light")
    accent = sampled_uv(im, "accent")
    mid = sampled_uv(im, "mid")
    shift = 0.0
    hop = 0.0
    out: List[dict] = []

    if kind == "female":
        # Two compact hair/ponytail lobes that hug the egg instead of becoming a body.
        out += [
            solid_element((1.0 + shift, 6.0 + hop, 6.45), (2.25 + shift, 10.0 + hop, 9.55), dark),
            solid_element((13.75 + shift, 6.0 + hop, 6.45), (15.0 + shift, 10.0 + hop, 9.55), dark),
            solid_element((1.45 + shift, 4.9 + hop, 6.8), (2.7 + shift, 7.1 + hop, 9.2), mid),
            solid_element((13.3 + shift, 4.9 + hop, 6.8), (14.55 + shift, 7.1 + hop, 9.2), mid),
        ]
    elif kind == "bunny":
        # The source sprite already contains the ears; these only give them rear thickness/puff.
        out += [
            solid_element((2.0 + shift, 14.0 + hop, 6.75), (4.0 + shift, 16.9 + hop, 9.25), dark),
            solid_element((12.0 + shift, 14.0 + hop, 6.75), (14.0 + shift, 16.9 + hop, 9.25), dark),
        ]
    elif kind == "bee":
        # Small translucent-looking wing plates and antenna nubs; colors come from the 2D icon.
        out += [
            solid_element((0.45 + shift, 6.8 + hop, 7.25), (2.0 + shift, 10.4 + hop, 8.15), light, shade=False),
            solid_element((14.0 + shift, 6.8 + hop, 7.25), (15.55 + shift, 10.4 + hop, 8.15), light, shade=False),
            solid_element((5.2 + shift, 14.1 + hop, 7.0), (6.0 + shift, 16.4 + hop, 8.0), accent),
            solid_element((10.0 + shift, 14.1 + hop, 7.0), (10.8 + shift, 16.4 + hop, 8.0), accent),
        ]
    elif kind == "cherry":
        # Tight high-side ponytail, kept close to the egg silhouette, plus one real
        # Remake-3.0-family green leaf color sampled from the authorized mob texture.
        leaf_tex, leaf_uv = entity_green_uv("cherry")
        out += [
            solid_element((12.7 + shift, 9.0 + hop, 6.4), (14.3 + shift, 12.5 + hop, 9.6), accent),
            solid_element((13.25 + shift, 7.0 + hop, 6.7), (14.8 + shift, 9.8 + hop, 9.3), mid),
            solid_element_tex((7.85 + shift, 13.55 + hop, 7.2), (8.55 + shift, 15.9 + hop, 8.0), leaf_uv, leaf_tex),
            solid_element_tex((8.25 + shift, 14.85 + hop, 7.15), (10.2 + shift, 15.65 + hop, 8.05), leaf_uv, leaf_tex),
        ]
    elif kind == "boomshroom":
        # A compact red mushroom-cap relief. The front silhouette still comes from the exact
        # Boomshroom 2D sprite; these blocks only make the cap read in three-quarter inventory views.
        out += [
            solid_element((2.0 + shift, 13.4 + hop, 6.25), (14.0 + shift, 15.2 + hop, 9.75), accent),
            solid_element((3.2 + shift, 15.0 + hop, 6.55), (12.8 + shift, 16.2 + hop, 9.45), accent),
            solid_element((5.0 + shift, 15.1 + hop, 5.95), (6.5 + shift, 16.25 + hop, 10.05), light),
            solid_element((9.4 + shift, 14.1 + hop, 5.95), (10.9 + shift, 15.25 + hop, 10.05), light),
        ]
    elif kind == "shroomboom":
        # Development Shroomboom: broader stepped cap + cream gill lip + moss-side depth.
        out += [
            solid_element((1.2 + shift, 12.9 + hop, 5.9), (14.8 + shift, 14.8 + hop, 10.1), accent),
            solid_element((2.4 + shift, 14.5 + hop, 6.2), (13.6 + shift, 16.0 + hop, 9.8), accent),
            solid_element((3.6 + shift, 12.45 + hop, 6.3), (12.4 + shift, 13.1 + hop, 9.7), light),
            solid_element((0.7 + shift, 6.8 + hop, 7.0), (2.0 + shift, 11.8 + hop, 9.0), mid),
            solid_element((14.0 + shift, 6.8 + hop, 7.0), (15.3 + shift, 11.8 + hop, 9.0), mid),
        ]
    elif kind == "cat":
        # Cat ears are integral to the source silhouette; these tiny blocks add depth only.
        out += [
            solid_element((2.4 + shift, 13.4 + hop, 6.65), (5.0 + shift, 16.8 + hop, 9.35), mid),
            solid_element((10.7 + shift, 13.4 + hop, 6.65), (13.4 + shift, 16.8 + hop, 9.35), mid),
        ]
    elif kind == "blossom":
        # Blossom shares the supplied Cherry-family 2D sprite, so the exact pink head
        # stays intact while compact sakura puffs + a real green leaf distinguish her.
        leaf_tex, leaf_uv = entity_green_uv("blossom")
        out += [
            solid_element((1.6 + shift, 7.0 + hop, 6.65), (3.1 + shift, 10.1 + hop, 9.35), light),
            solid_element((12.9 + shift, 7.0 + hop, 6.65), (14.4 + shift, 10.1 + hop, 9.35), light),
            solid_element((7.25 + shift, 13.55 + hop, 6.85), (8.75 + shift, 14.95 + hop, 9.15), light),
            solid_element((6.45 + shift, 14.15 + hop, 7.0), (7.65 + shift, 15.35 + hop, 9.0), accent),
            solid_element((8.35 + shift, 14.15 + hop, 7.0), (9.55 + shift, 15.35 + hop, 9.0), accent),
            solid_element_tex((9.0 + shift, 13.75 + hop, 7.15), (10.8 + shift, 14.55 + hop, 8.05), leaf_uv, leaf_tex),
        ]
    return out


def write_variant(kind: str) -> None:
    item_id = VARIANT_ITEM_IDS[kind]
    idle_model = {
        "credit": "Creeperella egg-head 3D model generated from the exact pack-authored 2D spawn-egg sprite; Rethoughted Spawn Eggs is reference-only",
        "ambientocclusion": True,
        "gui_light": "front",
        "textures": {
            "egg": f"creeperella:item/{item_id}",
            **({"leaf": f"creeperella:item/{item_id}_leaf"} if kind in ("cherry", "blossom") else {}),
            "particle": f"creeperella:item/{item_id}",
        },
        "elements": sprite_shell(item_id) + variant_relief(kind, "idle", item_id),
        "display": display_for_state("idle"),
    }
    (MODEL_DIR / f"{item_id}_idle.json").write_text(json.dumps(idle_model, separators=(",", ":")) + "\n", encoding="utf-8")

    # Animation states inherit the exact same egg-head geometry and only alter item
    # presentation. That keeps source/bake complexity lower and prevents accessories
    # from looking detached or rubbery.
    for state in ("sway_left", "sway_right", "blink"):
        child = {
            "credit": "Creeperella egg-head animation state; inherits exact 2D-textured geometry from idle",
            "parent": f"creeperella:item/3d/{item_id}_idle",
            "display": display_for_state(state),
        }
        (MODEL_DIR / f"{item_id}_{state}.json").write_text(json.dumps(child, separators=(",", ":")) + "\n", encoding="utf-8")

    # Blossom is compatibility-only since 1.4.22. Keep its archived generated geometry for
    # provenance/audits, but its actual item must visually alias the canonical Cherry egg.
    visible_item_id = "cherry_creeper_spawn_egg" if kind == "blossom" else item_id
    base = {
        "parent": "minecraft:item/generated",
        "textures": {"layer0": f"creeperella:item/{visible_item_id}"},
        "overrides": [
            {"predicate": {"creeperella:spawn_egg_3d": 1.0}, "model": f"creeperella:item/3d/{visible_item_id}_idle"},
            {"predicate": {"creeperella:spawn_egg_3d": 1.0, "creeperella:spawn_egg_anim": 0.34}, "model": f"creeperella:item/3d/{visible_item_id}_sway_left"},
            {"predicate": {"creeperella:spawn_egg_3d": 1.0, "creeperella:spawn_egg_anim": 0.67}, "model": f"creeperella:item/3d/{visible_item_id}_sway_right"},
            {"predicate": {"creeperella:spawn_egg_3d": 1.0, "creeperella:spawn_egg_anim": 1.0}, "model": f"creeperella:item/3d/{visible_item_id}_blink"},
        ],
    }
    (BASE_MODEL_DIR / f"{item_id}.json").write_text(json.dumps(base, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    # 1.3.0's generic five-material tiles are intentionally retired. The new models
    # sample the exact supplied 2D spawn-egg PNG directly.
    if LEGACY_MATERIAL_DIR.exists():
        for p in LEGACY_MATERIAL_DIR.glob("*.png"):
            p.unlink()
        try:
            LEGACY_MATERIAL_DIR.rmdir()
        except OSError:
            pass
    for kind in VARIANT_ITEM_IDS:
        write_variant(kind)
    print(f"Generated {len(VARIANT_ITEM_IDS)*4} egg-head 3D models directly from exact/source-derived 2D spawn-egg sprites")


if __name__ == "__main__":
    main()
