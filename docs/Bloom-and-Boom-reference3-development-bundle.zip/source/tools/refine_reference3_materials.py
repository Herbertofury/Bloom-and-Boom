#!/usr/bin/env python3
"""Deterministic UV painting for curved petals, jewel eyes and lantern glass. No image generation."""
from pathlib import Path
from PIL import Image
import math
T=Path(__file__).resolve().parents[1]/'src/main/resources/assets/creeperella/textures/entity'
for name,shadow,light,iris,core in [
 ('nacrella',(111,64,164),(242,218,255),(155,90,218),(200,175,215)),
 ('verdalia',(63,118,55),(233,255,204),(81,178,76),(185,210,170)),
 ('mariglow',(151,96,24),(255,237,168),(232,157,45),(215,195,150))]:
 acc=Image.open(T/f'{name}_accessories.png').convert('RGBA').resize((512,512),Image.Resampling.NEAREST)
 em=Image.open(T/f'{name}_accessories_e.png').convert('RGBA').resize((512,512),Image.Resampling.NEAREST)
 for layer,u in enumerate((4,20)):
  for y in range(4*8,11*8):
   for x in range(u*8,(u+7)*8):
    t=max(0,min(1,(y-32)/48));side=max(-1,min(1,(x-u*8)/24-1))
    blend=0.36+0.49*t+0.13*(1-abs(side))+(0.07 if layer else 0)
    vein=0.07*math.cos(side*math.pi*5)*math.sin(t*math.pi)
    blend=max(0,min(1,blend+vein))
    rgb=tuple(round(shadow[k]*(1-blend)+light[k]*blend) for k in range(3))
    acc.putpixel((x,y),(*rgb,255))
 for y in range(512):
  for x in range(48*8,512):
   acc.putpixel((x,y),(*core,255));em.putpixel((x,y),(*(min(255-c,45) for c in core),255))
 acc.save(T/f'{name}_accessories.png');em.save(T/f'{name}_accessories_e.png')
 # Front iris rectangle in the 64-logical-pixel layer atlas, now sampled at 16x density.
 eye=Image.new('RGBA',(1024,1024),(*(round(c*0.2) for c in iris),255))
 for y in range(49,81):
  for x in range(49,78):
   px=max(0,min(1,(x-50.88)/23.04));py=max(0,min(1,(y-50.88)/26.56))
   brightness=0.26+0.93*py
   rings=0.06*math.sin(math.atan2(py-0.48,px-0.5)*13)
   center=1-abs(px*2-1)
   rgb=tuple(max(0,min(255,round(c*(brightness+rings)+center*py*24))) for c in iris)
   eye.putpixel((x,y),(*rgb,255))
 eye.save(T/f'{name}_face_iris.png')
 glass=Image.new('RGBA',(512,512))
 for y in range(512):
  for x in range(512):
   edge=x%7==0 or y%7==0
   rgb=tuple(min(255,round(c*(1.0 if edge else 0.9))) for c in light)
   glass.putpixel((x,y),(*rgb,105 if edge else 48))
 glass.save(T/f'{name}_lantern_glass.png')
 print(name,'painted petal volume, iris gradient and translucent glass')
