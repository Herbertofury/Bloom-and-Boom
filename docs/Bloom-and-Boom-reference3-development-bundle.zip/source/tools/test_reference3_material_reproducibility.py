"""Check the luminance bake without rewriting shipped assets."""
from pathlib import Path
import subprocess
import sys
import tempfile

R=Path(__file__).resolve().parents[1]
T=R/'src/main/resources/assets/creeperella/textures/entity'
with tempfile.TemporaryDirectory() as folder:
    out=Path(folder)
    subprocess.run([sys.executable,str(R/'tools/refine_reference3_luminance.py'),'--output-dir',str(out)],check=True)
    files=list(out.glob('*.png'))
    assert len(files)==12
    for p in files:
        assert p.read_bytes()==(T/p.name).read_bytes(),f'Non-reproducible material: {p.name}'
print('PASS: 12 final textures reproduce byte-for-byte from hash-pinned inputs')
