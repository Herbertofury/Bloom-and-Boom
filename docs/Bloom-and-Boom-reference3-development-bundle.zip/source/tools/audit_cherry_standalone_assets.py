#!/usr/bin/env python3
"""Verify Cherry Creeper Remake sidecars are standalone Creeperella content, not vanilla overrides."""
from __future__ import annotations
import hashlib, json
from PIL import Image, ImageChops
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'reference-assets/source-packs/cherry'
R=ROOT/'src/main/resources'
J=ROOT/'src/main/java/dev/herbertofury/creeperella'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fail(msg): raise SystemExit('FAIL: '+msg)
def need(path, text):
    s=(ROOT/path).read_text(encoding='utf-8')
    if text not in s: fail(f'{path} missing {text!r}')
    return s

# Source-authored visible bytes become namespaced assets byte-for-byte.
exact={
 'assets/minecraft/textures/block/tnt/tnt.png':'assets/creeperella/textures/block/cherry_tnt/tnt.png',
 'assets/minecraft/textures/item/gunpowder.png':'assets/creeperella/textures/item/cherry_gunpowder.png',
 'assets/minecraft/textures/painting/creebet.png':'assets/creeperella/textures/painting/cherry_creebet.png',
 'assets/minecraft/optifine/cem/creeper_cherry.png':'assets/creeperella/textures/entity/cherry_creeper.png',
}
for a,b in exact.items():
    if sha(SRC/a)!=sha(R/b): fail(f'exact standalone asset drift: {a} -> {b}')
print(f'PASS: {len(exact)}/{len(exact)} Cherry standalone visible assets are exact source bytes')

# No active minecraft namespace resource override is allowed.
if (R/'assets/minecraft').exists(): fail('assets/minecraft exists in runtime resources')
print('PASS: vanilla asset namespace untouched; Cherry content is standalone')

# TNT visual semantics: preserve the authored 64x64 atlas exactly, but use vanilla TNT cube geometry at runtime.
# The source Blockbench JSON is a one-cube UV adapter for six 16x16 tiles inside that atlas, not unique TNT shape.
src_model=json.loads((SRC/'assets/minecraft/models/block/tnt.json').read_text())
if len(src_model.get('elements',[])) != 1 or src_model['elements'][0].get('from') != [0,0,0] or src_model['elements'][0].get('to') != [16,16,16]:
    fail('source Cherry TNT is no longer a vanilla-size one-cube adapter; review semantic port')
out=json.loads((R/'assets/creeperella/models/block/cherry_tnt.json').read_text())
if out.get('parent') != 'minecraft:block/cube_bottom_top':
    fail('Cherry TNT runtime must use vanilla cube_bottom_top geometry')
expected_tex={
    'side':'creeperella:block/cherry_tnt_side',
    'top':'creeperella:block/cherry_tnt_top',
    'bottom':'creeperella:block/cherry_tnt_bottom',
    'particle':'creeperella:block/cherry_tnt_side',
}
if out.get('textures') != expected_tex:
    fail('Cherry TNT vanilla geometry texture map drift')

atlas=Image.open(SRC/'assets/minecraft/textures/block/tnt/tnt.png').convert('RGBA')
def source_face(uv, rotation=0):
    x1,y1,x2,y2=uv; sx=atlas.width/16; sy=atlas.height/16
    l,r=sorted((int(round(x1*sx)),int(round(x2*sx)))); t,b=sorted((int(round(y1*sy)),int(round(y2*sy))))
    im=atlas.crop((l,t,r,b))
    if x2<x1: im=im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    if y2<y1: im=im.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
    if rotation: im=im.rotate(-rotation,expand=False,resample=Image.Resampling.NEAREST)
    return im
faces={
    'cherry_tnt_side.png':source_face((4,4,8,8),0),
    'cherry_tnt_top.png':source_face((8,4,4,0),90),
    'cherry_tnt_bottom.png':source_face((8,0,12,4),270),
}
for name,exp in faces.items():
    got=Image.open(R/'assets/creeperella/textures/block'/name).convert('RGBA')
    if ImageChops.difference(exp,got).getbbox() is not None:
        fail('Cherry TNT derived vanilla face differs from exact source UV result: '+name)
print('PASS: Cherry TNT uses vanilla cube geometry with exact source-atlas side/top/bottom pixels')

# Full vanilla-style TNT behavior must remain on the standalone block/entity/renderer path.
tnt=need('src/main/java/dev/herbertofury/creeperella/block/CherryTntBlock.java','class CherryTntBlock')
for token in ['hasNeighborSignal','playerWillDestroy','wasExploded','FLINT_AND_STEEL','FIRE_CHARGE','onProjectileHit','dropFromExplosion','onCaughtFire','CherryPrimedTntEntity']:
    if token not in tnt: fail('Cherry TNT missing behavior path: '+token)
primed=need('src/main/java/dev/herbertofury/creeperella/entity/CherryPrimedTntEntity.java','extends PrimedTnt')
renderer=need('src/main/java/dev/herbertofury/creeperella/client/CherryPrimedTntRenderer.java','ModBlocks.CHERRY_TNT.get().defaultBlockState()')
print('PASS: Cherry TNT ignition, chain-reaction, primed entity, fuse and Cherry-model renderer paths present')

# Cherry gunpowder is the Cherry Creeper drop and is used by Cherry TNT + Cherry companion treat.
loot=json.loads((R/'data/creeperella/loot_tables/entities/cherry_creeper.json').read_text())
raw=json.dumps(loot,sort_keys=True)
if 'creeperella:cherry_gunpowder' not in raw: fail('Cherry mob does not drop Cherry Gunpowder')
if 'minecraft:creeper_drop_music_discs' not in raw or '#minecraft:skeletons' not in raw: fail('Cherry loot lost vanilla music-disc semantics')
recipe=json.loads((R/'data/creeperella/recipes/cherry_tnt.json').read_text())
if recipe['key']['G'].get('item')!='creeperella:cherry_gunpowder': fail('Cherry TNT recipe does not use Cherry Gunpowder')
bonbon=json.loads((R/'data/creeperella/recipes/cherry_bomb_bonbon.json').read_text())
if 'creeperella:cherry_gunpowder' not in json.dumps(bonbon): fail('Cherry Bomb Bonbon does not use Cherry Gunpowder')
tag=json.loads((R/'data/forge/tags/items/gunpowder.json').read_text())
if 'creeperella:cherry_gunpowder' not in tag.get('values',[]): fail('Cherry Gunpowder missing Forge gunpowder tag')
print('PASS: Cherry Gunpowder is standalone, mob-linked, recipe-linked and Forge-tagged')

# Source CEM Creeper Head becomes a dedicated standing/wall head and item, with exact Cherry texture.
head_src=SRC/'assets/minecraft/optifine/cem/head_creeper.jem'
if sha(head_src)!='1d41e777eff7deaa839d77f3ce88d95890068191710b35273a719459cf28001a': fail('source Cherry head hash drift')
layer=need('src/main/java/dev/herbertofury/creeperella/client/CherryRemakeModelLayers.java','createCherryHeadLayer')
for token in ['"head"','"head_cherry_face"','"bone11"','"bone12"','"bone13"','"bone14"','"bone10"']:
    if token not in layer: fail('generated Cherry head missing source part '+token)
need('src/main/java/dev/herbertofury/creeperella/registry/ModBlocks.java','CHERRY_CREEPER_WALL_HEAD')
need('src/main/java/dev/herbertofury/creeperella/registry/ModBlockEntities.java','CHERRY_CREEPER_HEAD')
need('src/main/java/dev/herbertofury/creeperella/client/ClientEvents.java','registerBlockEntityRenderer(ModBlockEntities.CHERRY_CREEPER_HEAD.get()')
need('src/main/java/dev/herbertofury/creeperella/entity/CreeperellaEntity.java','chargedCreeper.canDropMobsSkull()')
need('src/main/java/dev/herbertofury/creeperella/entity/CreeperellaEntity.java','ModItems.CHERRY_CREEPER_HEAD.get()')
item_model=json.loads((R/'assets/creeperella/models/item/cherry_creeper_head.json').read_text())
if item_model.get('parent')!='minecraft:item/template_skull': fail('Cherry head item is missing vanilla skull item transforms')
block_model=json.loads((R/'assets/creeperella/models/block/cherry_creeper_head.json').read_text())
particle=block_model.get('textures',{}).get('particle')
if particle!='creeperella:block/cherry_creeper_head_particle': fail('Cherry head particle must use an atlas-safe dedicated block texture')
particle_path=R/'assets/creeperella/textures/block/cherry_creeper_head_particle.png'
if not particle_path.exists() or Image.open(particle_path).size!=(16,16): fail('Cherry head atlas-safe particle texture missing or wrong size')
print('PASS: source Cherry head CEM is a standalone standing/wall/item head with charged-Creeper skull-drop semantics')
print('PASS: Cherry head block particle uses a dedicated block-atlas-safe source-derived texture')

# Dedicated painting variant/item: exact art and exact 32x16 authored dimensions.
need('src/main/java/dev/herbertofury/creeperella/registry/ModPaintings.java','new PaintingVariant(32, 16)')
paint_item=need('src/main/java/dev/herbertofury/creeperella/item/CherryPaintingItem.java','CHERRY_CREEBET_KEY')
for token in ['new Painting(','painting.survives()','playPlacementSound','ENTITY_PLACE']:
    if token not in paint_item: fail('Cherry painting item missing dedicated placement behavior: '+token)
print('PASS: Cherry Creebet is a dedicated 32x16 painting variant/item using exact source artwork')

# Source-authored English/Russian identities are namespaced exactly for mob, spawn egg and head.
sen=json.loads((SRC/'assets/minecraft/lang/en_us.json').read_text(encoding='utf-8'))
sru=json.loads((SRC/'assets/minecraft/lang/ru_ru.json').read_text(encoding='utf-8'))
men=json.loads((R/'assets/creeperella/lang/en_us.json').read_text(encoding='utf-8'))
mru=json.loads((R/'assets/creeperella/lang/ru_ru.json').read_text(encoding='utf-8'))
keys=[('entity.minecraft.creeper','entity.creeperella.cherry_creeper'),('item.minecraft.creeper_spawn_egg','item.creeperella.cherry_creeper_spawn_egg'),('block.minecraft.creeper_head','block.creeperella.cherry_creeper_head')]
for sk,mk in keys:
    if men.get(mk)!=sen.get(sk): fail('English source identity mismatch '+mk)
    if mru.get(mk)!=sru.get(sk): fail('Russian source identity mismatch '+mk)
print('PASS: source-authored Cherry mob/spawn-egg/head names preserved exactly in English and Russian')

# Registration/data existence gate.
items=need('src/main/java/dev/herbertofury/creeperella/registry/ModItems.java','CHERRY_CREEBET_PAINTING')
for token in ['CHERRY_GUNPOWDER','CHERRY_TNT','CHERRY_CREEPER_HEAD','CHERRY_CREEBET_PAINTING']:
    if token not in items: fail('missing item registration '+token)
entities=need('src/main/java/dev/herbertofury/creeperella/registry/ModEntities.java','CHERRY_PRIMED_TNT')
for rel in ['assets/creeperella/blockstates/cherry_tnt.json','assets/creeperella/blockstates/cherry_creeper_head.json','assets/creeperella/blockstates/cherry_creeper_wall_head.json','data/creeperella/loot_tables/blocks/cherry_tnt.json','data/creeperella/loot_tables/blocks/cherry_creeper_head.json','data/creeperella/loot_tables/blocks/cherry_creeper_wall_head.json']:
    if not (R/rel).exists(): fail('missing runtime resource '+rel)
print('PASS: all Cherry sidecar standalone registrations and block/data resources present')

# All runtime JSONs parse.
files=list(R.rglob('*.json'))
for p in files: json.loads(p.read_text(encoding='utf-8'))
print(f'PASS: parsed {len(files)} runtime JSON resources')
print('PASS: Cherry source sidecars are fully standalone; no authored gameplay/visual sidecar is reference-only')
