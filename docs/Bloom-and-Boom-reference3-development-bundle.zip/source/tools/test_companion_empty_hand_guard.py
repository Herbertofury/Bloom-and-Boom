#!/usr/bin/env python3
"""Source guard for the native-QA double-toggle regression; not a gameplay substitute."""
from pathlib import Path
import re
s=(Path(__file__).resolve().parents[1]/'src/main/java/dev/herbertofury/creeperella/event/CommonEvents.java').read_text()
condition=re.search(r'if \(([^\n]*held\.isEmpty\(\)[^\n]*)\) \{',s)
assert condition, 'empty-hand companion interaction missing'
assert 'event.getHand() == InteractionHand.MAIN_HAND' in condition.group(1), 'empty offhand can duplicate main-hand commands'
assert 'companion.isOwnedBy(player)' in condition.group(1), 'owner requirement removed'
assert 'companion.toggleSitting(player)' in s and 'companion.cycleCatRestPose()' in s
assert 'player.getItemInHand(event.getHand())' in s, 'item interactions lost hand-specific lookup'
print('PASS: source guard limits empty-hand command/rest toggles to owned main-hand interactions; item hand lookup preserved.')
e=(Path(__file__).resolve().parents[1]/'src/main/java/dev/herbertofury/creeperella/entity/CreeperellaEntity.java').read_text()
assert 'EntityDataAccessor<Optional<UUID>> DATA_COMPANION_OWNER' in e
assert 'this.entityData.define(DATA_COMPANION_OWNER, Optional.empty())' in e
assert e.count('syncCompanionOwner();') == 2, 'owner mirror must initialize on taming and legacy NBT load'
assert 'this.entityData.get(DATA_COMPANION_OWNER).filter(player.getUUID()::equals).isPresent()' in e
assert 'return companionTamed && ownerUuid != null && ownerUuid.equals(player.getUUID());' in e
assert 'tag.putBoolean(TAG_TAMED, this.companionTamed)' in e and 'tag.putUUID(TAG_OWNER, this.ownerUuid)' in e
print('PASS: client owner mirror initialized after tame/load; server authority and legacy save fields preserved.')
