#!/usr/bin/env python3
import sys, math
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
sys.path.insert(0,'/mnt/data/creeperella1415_work/tools')
import render_mobs_visual_qa as r
OUT=Path('/mnt/data/Creeperella-1.4.15-IK-Trials');OUT.mkdir(parents=True,exist_ok=True)
BG=(8,13,24,255);W,H=300,300;BASE=255
try: F=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11)
except:F=ImageFont.load_default()
MAP={'leftLeg':('leftlegsub2','leftfoot3',False),'rightLeg':('rightlegsub2','rightfoot3',False),'leftLegback':('leftlegsub','leftfoot2',True),'rightLegback':('rightlegsub','rightfoot2',True)}
def P(root,*p):return r.find(root,*p)
def solve(hind,ty,tz):
 udy,udz=5.25,1.75;ldy,ldz=(5.05,-.25) if hind else (3.0,0.0)
 l1=math.hypot(udy,udz);l2=math.hypot(ldy,ldz);a1=math.atan2(udz,udy);a2=math.atan2(ldz,ldy)
 d=math.hypot(ty,tz);d=max(abs(l1-l2)+.08,min(l1+l2-.08,d));cosk=max(-1,min(1,(d*d-l1*l1-l2*l2)/(2*l1*l2)));k=math.acos(cosk);ta=math.atan2(tz,ty);ua=ta-math.atan2(l2*math.sin(k),l1+l2*math.cos(k))-a1;la=k+a1-a2;pa=-(ua+la);return ua,la,pa
def ik(root,n,ty,tz,dx=0,dy=0,dz=0,ry=0,rz=0):
 ln,fn,hind=MAP[n];leg=P(root,'body','waist',n);lo=P(root,'body','waist',n,ln);fo=P(root,'body','waist',n,ln,fn);ua,la,pa=solve(hind,ty,tz);leg.x+=dx;leg.y+=dy;leg.z+=dz;leg.rx=ua;leg.ry=ry;leg.rz=rz;lo.rx=la;fo.rx=pa
def tail(root,rx,ry,tx,ty,z=.0):
 a=P(root,'body','waist','Body','tail');b=P(root,'body','waist','Body','tail','tail2');a.rx=rx;a.ry=ry;a.z+=z;b.rx=tx;b.ry=ty

def pose_sit(root,k):
 b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head')
 vals=[(.75,.10,.15,-.08,7.55,-.15,6.85,.95,.55,.18),(.90,.08,.18,-.07,7.45,.05,6.60,1.20,.70,.22),(1.00,.06,.20,-.06,7.35,.15,6.45,1.35,.80,.24),(.82,.09,.16,-.07,7.50,-.05,6.70,1.05,.62,.20)][k]
 by,bp,uy,up,fy,fz,hy,hz,hx,lean=vals;b.y+=by;b.rx+=bp;u.y+=uy;u.rx+=up;h.rx-=.01
 ik(root,'leftLeg',fy,fz,dx=.12,dy=.25,rz=.03);ik(root,'rightLeg',fy,fz,dx=-.12,dy=.25,rz=-.03)
 ik(root,'leftLegback',hy,hz,dx=hx,dy=.55,dz=-.55,rz=.22);ik(root,'rightLegback',hy,hz,dx=-hx,dy=.55,dz=-.55,rz=-.22)
 tail(root,.36,.08,.72,.18,.12)

def pose_loaf(root,k):
 b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head')
 vals=[(1.55,.38,.60,-.38,5.55,1.30,5.90,-.30,.30),(1.75,.45,.65,-.45,5.20,1.55,5.55,-.45,.40),(1.95,.52,.70,-.52,4.95,1.70,5.30,-.55,.48),(1.65,.42,.62,-.42,5.35,1.42,5.70,-.38,.34)][k]
 by,bp,uy,up,fy,fz,hy,hz,x=vals;b.y+=by;b.rx+=bp;u.y+=uy;u.rx+=up;h.y+=.15;h.rx+=.02
 ik(root,'leftLeg',fy,fz,dx=.22,dy=.65,dz=.60,rz=.08);ik(root,'rightLeg',fy,fz,dx=-.22,dy=.65,dz=.60,rz=-.08)
 ik(root,'leftLegback',hy,hz,dx=x,dy=.80,dz=-.40,rz=.10);ik(root,'rightLegback',hy,hz,dx=-x,dy=.80,dz=-.40,rz=-.10)
 tail(root,.42,.12,.92,.24,.04)

def pose_sprawl(root,k):
 b=P(root,'body','waist','Body');u=P(root,'body','waist','Body','Upperbody');h=P(root,'body','waist','Body','Upperbody','head')
 vals=[(1.25,.20,.25,-.10,7.0,-1.3,7.2,1.3,1.25,1.75,.36),(1.40,.16,.28,-.08,6.9,-1.6,7.0,1.6,1.50,2.00,.42),(1.55,.13,.30,-.07,6.8,-1.9,6.8,1.9,1.75,2.25,.48),(1.35,.18,.26,-.09,6.95,-1.45,7.1,1.45,1.40,1.90,.40)][k]
 by,bp,uy,up,fy,fz,hy,hz,fx,hx,roll=vals;b.y+=by;b.rx+=bp;u.y+=uy;u.rx+=up;h.rx+=.01
 ik(root,'leftLeg',fy,fz,dx=fx,dy=.35,rz=roll);ik(root,'rightLeg',fy,fz,dx=-fx,dy=.35,rz=-roll)
 ik(root,'leftLegback',hy,hz,dx=hx,dy=.50,rz=roll);ik(root,'rightLegback',hy,hz,dx=-hx,dy=.50,rz=-roll)
 tail(root,.20,0,.45,0,.20)

def ground():
 root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',40,0,0,0,0,cat_motion='idle');_,pts=r.build_polygons(root,tex,tw,th,0,0,subdivide=False);return float(pts[:,1].min())
G=ground()
def render(root,tex,tw,th,yaw,label):
 _,pts=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=False);mnx,mxx=pts[:,0].min(),pts[:,0].max();mny,mxy=pts[:,1].min(),pts[:,1].max();sc=min((W-20)/max(mxx-mnx,1),(BASE-36)/max(mxy-G,1));xo=W/2-(mnx+mxx)/2*sc;yo=BASE+G*sc
 can=np.zeros((H,W,4),dtype=np.uint8);can[:]=np.array(BG);im=Image.fromarray(can,'RGBA');d=ImageDraw.Draw(im);d.line((10,BASE,W-10,BASE),fill=(110,145,200,255),width=2);can=np.array(im);z=np.full((H,W),np.inf);polys,_=r.build_polygons(root,tex,tw,th,yaw=yaw,pitch=5,subdivide=True)
 for _,q,rgba in polys:
  pp=np.array([[xo+p[0]*sc,yo-p[1]*sc,p[2]] for p in q]);r._raster_triangle(can,z,pp[[0,1,2]],rgba);r._raster_triangle(can,z,pp[[0,2,3]],rgba)
 im=Image.fromarray(can,'RGBA');ImageDraw.Draw(im).text((8,8),label,font=F,fill=(240,245,255));return im
for name,pose in [('SIT',pose_sit),('LOAF',pose_loaf),('SPRAWL',pose_sprawl)]:
 sheet=Image.new('RGBA',(2*W,4*H),BG)
 for k in range(4):
  for c,(yaw,vn) in enumerate([(-28,'3Q'),(-90,'SIDE')]):
   root,tex,tw,th=r.load_variant('cat');r.apply_anim(root,'cat',42,0,0,0,0,cat_motion='sit');pose(root,k);sheet.alpha_composite(render(root,tex,tw,th,yaw,f'{name} IK {k+1} · {vn}'),(c*W,k*H))
 sheet.save(OUT/f'{name}-IK-trials.png');print(OUT/f'{name}-IK-trials.png')
