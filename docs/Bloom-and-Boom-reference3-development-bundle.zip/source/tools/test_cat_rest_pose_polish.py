#!/usr/bin/env python3
from __future__ import annotations
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
MODEL=ROOT/'src/main/java/dev/herbertofury/creeperella/client/CreeperellaModel.java'
ENTITY=ROOT/'src/main/java/dev/herbertofury/creeperella/entity/CreeperellaEntity.java'
ENUM=ROOT/'src/main/java/dev/herbertofury/creeperella/entity/CatCreeperRestPose.java'
BEFORE=ROOT/'pose-history/1.4.17-before/CreeperellaModel.java'
QA=ROOT/'tools/fixtures/rest_ground_and_tail_1.4.18.txt'

def extract_method(text,signature):
    start=text.find(signature)
    if start<0: raise AssertionError('method missing: '+signature)
    brace=text.find('{',start);depth=0
    for i in range(brace,len(text)):
        if text[i]=='{':depth+=1
        elif text[i]=='}':
            depth-=1
            if depth==0:return text[start:i+1]
    raise AssertionError('unclosed method: '+signature)

def block(report,pose):
    m=re.search(rf'^{re.escape(pose)}\n(?P<b>(?:  .*\n)+)',report,re.M)
    if not m: raise AssertionError(f'{pose} QA block missing')
    return m.group('b')
def val(block,key):
    m=re.search(rf'^  {re.escape(key)}=([-0-9.]+)(?: max=([-0-9.]+))?',block,re.M)
    if not m: raise AssertionError(f'QA value missing: {key}')
    lo=float(m.group(1));hi=float(m.group(2)) if m.group(2) is not None else lo
    return lo,hi

def main():
    model=MODEL.read_text();before=BEFORE.read_text();entity=ENTITY.read_text();enum=ENUM.read_text()
    # Approved side-rest and locomotion are regression-locked.
    if extract_method(model,'private static void applyCatSideLiePose') != extract_method(before,'private static void applyCatSideLiePose'):
        raise AssertionError('approved 1.4.17 SIDE_LIE body/leg method changed')
    if extract_method(model,'private static void applyCatSit2Pose') != extract_method(before,'private static void applyCatSit2Pose'):
        raise AssertionError('approved grounded 1.4.17 SIT_2 method changed')
    if extract_method(model,'private static void animateCatLegIk') != extract_method(before,'private static void animateCatLegIk'):
        raise AssertionError('locomotion gait IK changed during rest grounding pass')

    sit=extract_method(model,'private static void applyCatSitPose')
    if sit.count('8.83F') != 2: raise AssertionError('SIT must use calibrated 8.83 hind-paw IK reach on both sides')
    loaf=extract_method(model,'private static void applyCatLoafPose')
    if loaf.count('5.45F') != 2 or loaf.count('8.15F') != 2:
        raise AssertionError('LOAF must use calibrated 5.45 front / 8.15 hind IK reaches')
    sprawl=extract_method(model,'private static void applyCatSprawlPose')
    for token in ('0.30F','1.35F * amount','-1.46F','1.34F'):
        if token not in sprawl: raise AssertionError('SPRAWL grounding token missing: '+token)
    if '0.56F * amount' in sprawl: raise AssertionError('SPRAWL front roots must not be translated into the floor')

    tail=extract_method(model,'private static void animateCatRestTailLife')
    for token in ('visual.restSit * 0.040F','visual.loaf * 0.016F','visual.sideLie * 0.012F','visual.sit2 * 0.032F','visual.sprawl * 0.012F','tipWave * tipYawAmp'):
        if token not in tail: raise AssertionError('pose-aware lively-tail token missing: '+token)
    if 'animateCatRestTailLife(entity, tail, tail2, ageInTicks, visual, restVariant);' not in model:
        raise AssertionError('lively rest tail is not called from setupAnim')
    rest_tail=extract_method(model,'private static void applyCatRestTailPose')
    if 'side * 0.12F' not in rest_tail or 'side * 0.28F' not in rest_tail:
        raise AssertionError('LOAF tail must mirror with the pose variant')

    for token in ('SPRAWL(4, 2, "Sprawl")','SIT_2(5, 2, "Sit 2")'):
        if token not in enum: raise AssertionError('rest-pose ID contract missing: '+token)
    selector=extract_method(entity,'private CatCreeperIdleAnimation selectCatSeatedIdle')
    if 'case SPRAWL, SIT_2 ->' not in selector: raise AssertionError('SPRAWL/SIT_2 idle safety branch missing')

    if not QA.exists(): raise AssertionError('hermetic 1.4.18 rest grounding/tail QA fixture missing')
    report=QA.read_text()
    # Every pose family must be grounded as a whole and keep tail safely above the floor over the sampled envelope.
    for pose in ('SIT','SIT_2','LOAF','SIDE_LIE','SPRAWL'):
        b=block(report,pose)
        lo,hi=val(b,'mesh_ground_delta_min')
        if lo < -0.01 or hi > 0.16: raise AssertionError(f'{pose} whole-pose grounding invalid: {lo:.4f}..{hi:.4f}')
        tlo,thi=val(b,'tail_ground_delta_min')
        if tlo < 1.0: raise AssertionError(f'{pose} tail approaches/penetrates floor: {tlo:.4f}')
    # Support-paw families: every paw should share the floor. Side-lie intentionally rests on the lateral body/leg silhouette instead.
    for pose in ('SIT','SIT_2','LOAF','SPRAWL'):
        b=block(report,pose)
        for leg in ('leftLeg','rightLeg','leftLegback','rightLegback'):
            lo,hi=val(b,leg+'_paw_ground_delta_min')
            if lo < -0.01 or hi > 0.16: raise AssertionError(f'{pose} {leg} is not grounded: {lo:.4f}..{hi:.4f}')

    print('PASS: SIDE_LIE, SIT_2, and locomotion IK regression-locked to 1.4.17')
    print('PASS: SIT and LOAF use calibrated two-link IK for all four grounded paws')
    print('PASS: SPRAWL grounds forepaws by terminal-paw rotation and hind paws by safe root translation')
    print('PASS: all rest families keep whole mesh above the fixed standing-paw ground plane')
    print('PASS: all rest families have pose-aware lively tail motion with >1.0 model-unit floor clearance')
if __name__=='__main__':main()
