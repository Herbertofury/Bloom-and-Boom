# 1.5.2 — Boomshroom root-stain + clean-face texture pass

- Removed the remaining red facial accent from all three Boomshroom animated face frames; the face is now entirely ivory + neutral charcoal/gray, and the Boomshroom body/face emissive atlas is intentionally fully transparent.
- Re-inspected the supplied Creeper Overhaul Mushroom Creeper texture directly from both authorized JARs and translated its ground-contact material language onto Boomshroom's Cherry-family UVs.
- Added an irregular low-chroma mushroom-gray root/soil fade that climbs from the feet into the lower stalk instead of ending in hard dark "socks"; the white/ivory stalk remains dominant.
- The root fade samples Creeper Overhaul's exact authorized Mushroom Creeper row luminance at generation time, then neutralizes the original mauve/taupe hue toward gray so Boomshroom keeps her own body identity.
- Added regression gates for zero red face pixels, zero body/face emissive pixels, protected Cherry/cap hashes, white-stalk brightness/chroma, and measurable foot→lower-stalk gradient.
- Cap base/glow geometry and texture bytes remain unchanged from 1.5.1.

# 1.5.0 — Boomshroom

- Added **Boomshroom** as the active Mushroom Fields Creeperella (`creeperella:boomshroom_creeper`), natural weight **10**, group **1-2**.
- Kept Cherry Creeper's proven feminine model/animation language as the production baseline, then authored an independent cream/ivory fungal body texture instead of shipping a recolor.
- Added the user-authorized Creeper Overhaul Mushroom Creeper cap as an isolated exact-source **128×128** base/glow layer with its original cap cube silhouette/UVs preserved; provenance and source hashes are archived under `reference-assets/creeper-overhaul/`.
- Added a synchronized **cap-tip greeting** with anticipation, lift, tilt, overshoot, settle, and a small matching head bow; transforming, bonding, healing, or greeting an owned Boomshroom can trigger it.
- Added native Forge custom particles with four animated Boomshroom spore sprites and a persistent drifting/rising particle implementation.
- Added centralized `ThemedExplosionEffects` routing for reusable biome/variant explosion identities. Boomshroom now emits **248 spores + 64 mycelium particles**, including a **32-spore directional ring**; Cherry's petal profile also uses the same extension point.
- Added Red Mushroom transformations from vanilla Creepers and other Creeperellas into Boomshroom; **Brown Mushroom** is her deterministic taming/healing treat.
- Added a dedicated Boomshroom 3D spawn egg while preserving legacy Blossom's intentional Cherry egg alias.
- Added Boomshroom QA commands, quality/provenance audits, Mushroom Fields ecology assertions, real-fuse FX markers, and six-active-family parity checks.
- Real Forge 47.4.23 dedicated-server and native-client QA pass base, greeting, charged, real fuse/explosion, family, and cleanup phases with no Boomshroom/Creeperella model/texture/atlas/linkage/render errors.
- Blossom remains compatibility-only from 1.4.22: do not restore it to natural spawning, active family discovery, or transformations without an explicit product decision.

# 1.4.22 — Cherry/Blossom Merge

- Cherry Creeper is now the sole active pink Cherry Grove variant.
- Merged the former Blossom natural-spawn weight into Cherry: weight 18, group 1-2, biome tag `minecraft:cherry_grove`.
- Retired Blossom from natural spawning, transformations, creative tabs, active family tags, new recipes, and the active Forge gunpowder tag.
- Preserved old `creeperella:blossom_creeper` registry IDs for save compatibility; legacy entities resolve/render/loot as Cherry.
- Pink Petals now trigger the Bloom & Boom celebration/advancement on Cherry in place instead of creating a duplicate mob.
- Cherry inherits Blossom's richer heart/cherry-leaf ambient flavor and accepts legacy Blossom Burst Cookies as an alternate treat.
- Added deterministic `cherry_ecology` and `legacy_blossom_alias` runtime QA gates plus a Cherry-Grove flat server profile.

# Creeperella: Bloom & Boom — Changelog

## 1.4.21 — Blossom parity + full-family native QA

- Promotes Blossom Creeper from a Cherry recolor into a distinct sakura silhouette while preserving Cherry Remake source geometry/animation formulas.
- Adds seven Blossom-only crown/shoulder/hip petal accents with subtle secondary motion and a matching standalone Blossom head layer.
- Adds Blossom Powder, Blossom TNT + primed entity/render path, Blossom Creeper Head, Blossom Creebet painting, recipes, loot, skull drops, creative-tab entries, and localization.
- Adds deterministic `/creeperella qa family` and `/creeperella qa cherry_family` comparison gates for real-client release QA.
- Keeps all existing Cherry source-authored assets and formulas untouched.


## 1.4.20 — native Forge Cat rest-render + atlas QA fix

- Fixed a real-client-only Cat rest rendering failure discovered by the new Forge/Xvfb native QA gate: the custom Cat `waist` parent was not reset by vanilla `CreeperModel.setupAnim`, so seated/rest offsets accumulated every rendered frame until the complete rig moved out of view. `animateCatSource` now restores the authored waist bind pose before applying each frame.
- Added `test_cat_native_rest_reset.py` so all five waist-mutating rest families are permanently guarded against per-frame transform accumulation.
- Kept the approved 1.4.19 rest geometry, IK targets, tail life, and personality curves unchanged; the fix restores deterministic application of those transforms rather than redesigning the poses.
- Removed real-client model-atlas warnings: Cherry/Blossom egg leaf accents now use deterministic source-derived item-atlas swatches instead of entity textures, and the Cherry Creeper Head uses a dedicated source-derived block-atlas particle texture.
- Hardened the QA world to Normal difficulty with natural mob spawning disabled so operator-spawned Cat Creepers (a MONSTER category) survive deterministic captures without adding random hostile mobs.
- Native release gate: actual Minecraft 1.20.1 / Forge 47.4.23 client rendering under Xvfb/Mesa must show the Cat pose grid and full personality sequence before publication.

## 1.4.18
- Grounded the remaining Cat rest-pose support points against the fixed standing-paw floor reference instead of relying on visual alignment.
- Standard `SIT`: rear-paw two-link IK reach calibrated to `8.83`, bringing both hind paws to the same floor as the front paws while keeping the compact sit silhouette.
- `LOAF`: front/hind IK reaches calibrated to `5.45` / `8.15`; all four tucked paws now sit at ~0.10 model-unit floor clearance without opening the loaf.
- `SPRAWL`: straight foreleg chains stay out of the floor; only the terminal forepaws rotate down (`0.30`) while hind roots lower `1.35` so all four stretched paws make contact.
- `SIT_2` and the user-approved upright horse-style `SIDE_LIE` body/leg methods are unchanged from 1.4.17.
- Added low-amplitude always-on cat tail life for every rest family: slower root drift, delayed larger tip follow-through, pose-specific amplitudes, and preserved personality `TAIL_WAG` layering.
- LOAF tail curl now mirrors correctly with its pose variant instead of always curling to the same side.
- Added deterministic before/after, multi-angle, lively-tail GIFs, four-phase tail strip, fixed-ground numeric contact report, and rollback snapshot. No image generation used.

## 1.4.17
- Fixed Cat Creeper **Sit 2** floating hind paws by extending only the rear-leg IK reach; hip placement, torso, forelegs, tail, and Sit 2 silhouette are otherwise unchanged.
- Added deterministic before/after ground-contact QA and preserved the complete 1.4.16 source for rollback.

# Creeperella: Bloom & Boom — Changelog

## 1.4.16 — goofy full sploot + Sit 2 + side-lie tail visibility

- Preserved the complete 1.4.15 `SPRAWL` pose as a new owner-command rest state named **Sit 2**; existing rest-pose IDs 0-4 are unchanged and `SIT_2` is appended as ID 5 for save compatibility.
- Rebuilt **SPRAWL** as the requested goofy full sploot: front leg chains extend almost straight forward and rear chains almost straight backward, near-parallel to the fixed Minecraft ground plane.
- Kept the approved 1.4.15 `SIDE_LIE` / horse-rest body pose and tail transforms unchanged. The apparent missing tail was a 3Q camera occlusion, so the QA package now includes side, rear-3Q, back and deterministic turntable views where the tail is clearly visible.
- Preserved the full 1.4.15 source/model/entity snapshot under `pose-history/1.4.15-before/` for one-step rollback.
- Added fixed-ground/tail presence gates for `SIT_2`, new `SPRAWL`, and `SIDE_LIE`.
- No generative image model was used.

## 1.4.15 — Cat rest-pose polish + rollback archive

- Audited the Cat Creeper's complete rest/locomotion/personality pose family after the 1.4.14 horse-rest correction.
- Rebuilt **SIT** with static two-link rest IK so front paws stay under the chest and the long rear chains fold into the haunches instead of reading like a chair/forward spear.
- Rebuilt **LOAF** into a materially more compact body fold with all four paws tucked under the chest/hips while the head remains comfortably alert.
- Rebuilt **SPRAWL** with four explicit outward paw targets, making the spread-all-fours silhouette readable from both 3/4 and side views.
- Kept the user-approved **1.4.14 upright horse-rest / SIDE_LIE method byte-for-byte unchanged** and added a regression assertion for it.
- Kept the locomotion IK solver and visual state blender byte-for-byte unchanged from 1.4.14 after audit found no reason to disturb CREEP/WALK/RUN.
- Rest-idle safety: SIDE_LIE/SPRAWL can no longer select PAW_LIFT, and LOAF kneading uses tiny tucked-paw pressure motion instead of reopening the loaf.
- Removed explicit Cat rest-tail roll overrides so the source-authored no-roll invariant is preserved.
- Added fixed-ground QA for SIT/LOAF/SPRAWL/HORSE_REST; maximum sampled floor error is 0.101815 model units.
- Added deterministic before/after PNG/GIF review package and bundled the complete 1.4.14 rollback source/model/entity snapshot under `pose-history/1.4.14-before/`.
- No generative image model was used for any Creeperella 1.4.15 QA.

## 1.4.14 - upright alert horse-rest refinement

- Straightened Cat Creeper `SIDE_LIE` chest/upper torso/head into a much more Creeper-like upright resting silhouette while preserving the grounded horse-rest lower body and four side-folded legs.
- Reduced visible lateral lean to a tiny intentional bend: body target lean 0.025-0.060 rad, upper 0.010-0.030 rad, head 0.002-0.010 rad depending on variant.
- Reduced forward bend sharply: upper torso/head now remain within only a few degrees of vertical in deterministic world-space checks.
- Preserved the fixed standing-paw Minecraft ground plane and ~0.10 model-unit clearance for all four rest variants.
- Added `Creeperella-1.4.14-Cat-Upright-Horse-Rest-QA` deterministic 3Q/side GIFs and all-variant QA sheet; no image generation.
- Hardened `tools/test_cat_horse_rest_ground.py` to reject lateral torso/head lean regressions and excessive upper/head bend.


## 1.4.13 — Alert horse-rest refinement

- Raised/counter-rolled the Cat Creeper chest and upper torso during `SIDE_LIE` while preserving the horse-style hips/legs resting to one side.
- Kept the head world-upright and made the four variants progressively more watchful instead of sleepy/flopped.
- Preserved the fixed Minecraft standing-paw ground plane and all side-rest leg placements.
- Updated deterministic QA renders and added stronger chest/neck/head orientation assertions.

## 1.4.12 — Grounded horse-rest correction
- Rebuilt Cat Creeper `SIDE_LIE` as a real horse-style chest-down rest instead of a rolled-over/fallen pose.
- Head/neck counter-rotate upright while the torso rests nearly horizontal to the Minecraft floor.
- All four articulated legs are moved and folded to the same side; variants include calm, extended-foreleg, sleepy, and alert rests.
- Recalibrated runtime Y offsets against the normal standing Cat Creeper paw-bottom plane, with ~0.10 model-unit deterministic clearance.
- Replaced the misleading preview floor semantics with a fixed standing-ground reference.
- Kept SIT / LOAF / SPRAWL runtime states, Cat locomotion, personality idles, source asset parity, and prior tail fixes intact.
- Added deterministic `make_cat_horse_rest_qa.py` and numeric `test_cat_horse_rest_ground.py` gates.

# Changelog

## 1.4.9 — seated Cat tail direction fix

- Removed the incorrect seated left/right tail-routing approach that used large yaw and made the tail protrude sideways from the rump.
- Re-solved SIT in the Cat rig's actual local axes: root yaw/roll are zero at full sit, the root segment travels rearward/down, and tail2 eases toward a rear trail.
- Tail-wag variants now use only bounded lateral motion after the rearward base solve instead of rotating the whole tail sideways.
- Added a permanent seated-tail gate to `test_cat_aaa_gait.py`: zero lateral spear at static SIT, >12 model-unit rear travel, >4 model-unit floor clearance, plus the existing torso-tunneling check.
- Added `tools/make_cat_seated_tail_qa.py` with deterministic SIT / tail-wag / loaf / side-lie front, 3/4, side and back QA.

## 1.4.8 — Cat state controller + cute idles

- Added synced Cat motion states: IDLE, CREEP, WALK, RUN, SWELL, SIT, REFORM.
- Wild unnoticed player target -> CREEP (0.62); noticed/hurt/ambush -> RUN (1.45); 60-tick notice memory; 4.25-block ambush threshold; path refresh bounded to 8 ticks.
- Tamed follow uses WALK (1.00), RUN above 10 blocks, RUN exit inside 8 blocks, and RUN for commanded targets.
- Added Paw Lift, Tail Wag, Curious Look, and tamed-only Knead idles with true-still gating, 80–220 tick cooldowns, weighted choice, repeat avoidance and hard gameplay interruption.
- Positive taming/healing/bond interactions trigger Paw Lift.
- Client blends motion states, integrates gait phase from actual limb swing delta, and preserves real movement as the leg-cycle gate.
- Expanded clipping QA to 17,328 locomotion samples plus SIT/SWELL/all idles both handedness; all green.
- Preserved all 45/45 source files, Cherry standalone/TNT, Pie 712, Cherry 235, Cat 39/39 + 14/14 geometry, and 24/24 egg parity.

## 1.4.7 — feline IK gait + clipping hard gate

- Replaced Cat Creeper's oversized vanilla-style upper-leg swing with a **four-beat feline walk** that blends toward diagonal trot timing at high movement intensity.
- Added exact-rig **two-link IK** for every front and hind leg using the generated geometry's real joint lengths/pivot directions.
- Added stance-phase planted-paw travel, swing-phase paw lift/advance, level-paw counter-rotation, and separate fore/hind reach/lift tuning.
- Added anatomical joint hard limits so elbows/hocks cannot invert or fold into the torso even when another mod supplies extreme `limbSwingAmount`.
- Added subtle feline weight shift, pelvis/shoulder counter-roll, spine flex, head stabilization, and bounded two-segment tail balance yaw/tip lag.
- Added `test_cat_aaa_gait.py`: 7,220+ sampled leg poses across five movement intensities with torso-core penetration, centerline, continuity, tail-tunneling and idle-collapse assertions.
- Added multi-angle deterministic GIF QA specifically to make clipping and bad bends obvious. No image generation is used.


## 1.4.6 — articulated Cat Creeper motion

- Preserved the exact supplied Bedrock Cat animation as the baseline while making the moving gait visibly less rigid.
- Added movement-only pelvis/shoulder counter-sway and bounded spine counter-flex so the torso bends through a stride rather than traveling as one stiff block.
- Added head stabilization/dip that counteracts torso motion without overriding player look input or the authored head Z channel.
- Kept the exact Bedrock upper-leg equation and added bounded lower-leg + paw tuck/plant articulation on the existing authored child bones.
- Reworked the two-part tail follow-through on the source-authored X axis: the tip has larger travel and a delayed phase, producing a natural bend through the end of the tail instead of a rigid extension.
- Kept Cat tail Y/Z rotations forbidden; no invented yaw/roll channels were added.
- Added `tools/test_cat_secondary_motion.py` to regression-lock idle-source purity, source upper-leg parity, diagonal gait symmetry, bounded joint/spine/head/tail amplitudes, and elastic tail-tip follow-through.
- Updated the Cat port audit and deterministic renderer to mirror the runtime formulas exactly.
- Full source/model/data regression gates remain green: 45/45 source mirror, 39/39 Cat base cubes, 14/14 Cat charged cubes, Pie 712 animation samples, Cherry 235 samples, 24/24 3D egg states, and 84/84 runtime JSON resources.

## 1.4.5 — vanilla-anchored Cherry TNT fix

- Fixed the broken Cherry TNT presentation by using Minecraft's **vanilla TNT cube geometry** (`minecraft:block/cube_bottom_top`) as the runtime model instead of carrying the source pack's format-specific Blockbench UV adapter literally.
- Preserved the exact authored 64×64 Cherry TNT atlas byte-for-byte as provenance and added deterministic extraction of the exact source side/top/bottom face pixels.
- Added `tools/generate_cherry_tnt_vanilla_faces.py`; generated runtime hashes: side `5a63ce2708e5c9d84d39888f2c01ad0502bcdc378675b7fc2dc717ee7323e15f`, top `20a00b1ae4f0644947354f7edc78eb9c9bebf3fd3488928f05d048440aa74317`, bottom `3ba2cdf937b2c1b49d26d1cdf82f9e8f64e7c4171f186212f2a70739df16f015`.
- Kept the dedicated Cherry TNT block/item/primed entity and vanilla-style redstone, fire, projectile, chain-reaction, fuse, swelling/flash, and explosion semantics unchanged.
- Upgraded deterministic JSON-model QA to resolve standard vanilla `cube_bottom_top`/`cube_all` parent templates even when the client asset jar is unavailable.
- Added a permanent semantic-fidelity rule: preserve author intent and visible result, but do not blindly preserve a source-format adapter when the target runtime has a safer native vanilla primitive.
- No mob model/animation code changed; Female/Bunny/Bee, Cherry/Blossom, and Cat parity gates remain regression-locked.

## 1.4.4 — standalone source-pack sidecars

- Ported Cherry Creeper Remake 3.0's non-mob authored content as dedicated `creeperella:` features instead of leaving it reference-only or globally replacing vanilla.
- Added exact-source **Cherry Gunpowder** as the Cherry Creeper's normal gunpowder drop; retained skeleton music-disc drop semantics; added Forge gunpowder tagging and Cherry recipe integration.
- Added **Cherry TNT** using the exact authored TNT texture and source Blockbench geometry/UVs with namespace-only adaptation. It has dedicated block/item/primed entity/rendering and supports redstone, flint-and-steel, fire charges, flaming projectiles, fire catching and TNT chain reactions without falling back to vanilla TNT visuals.
- Added **Cherry Creeper Head** generated directly from `head_creeper.jem`, with standalone floor/wall blocks, block entity, exact Cherry texture, custom inventory rendering and charged-Creeper skull-drop behavior.
- Added the exact **Creebet** 32×16 painting art as a dedicated painting variant/item.
- Preserved source English/Russian mob, spawn-egg and head names under safe Creeperella keys.
- Added `audit_cherry_standalone_assets.py`; source-pack completeness now proves the sidecars are active standalone content and that no runtime `assets/minecraft` override exists.
- Runtime JSON count is now 84/84 parsed. Existing six mob rigs remain parity-locked; no Cat/Pie/Cherry animation regression was introduced.

## 1.4.3 - full source-pack parity + Cat/Cherry motion corrections

- Added complete exact-byte mirrors of all three supplied source packs: 45/45 files hash-locked.
- Added a permanent source-completeness gate covering assets, source semantics, safe namespace mappings, localization, particles/sounds inventory and mirror-only vanilla replacements.
- Confirmed the supplied packs contain zero particle assets and zero sound assets; no source particle/sound files were missing from Creeperella.
- Added safe source Russian localization for Cherry Creeper and its spawn egg without overriding global `minecraft:*` keys.
- Added deterministic regeneration parity for all Pie base/charged model layers, Cherry/Blossom layers and Cat base/charged layers.
- Pie charged CEM animation programs are now explicitly audited: each equals its base counterpart minus exactly the ten face-only channels absent from the supplied charged geometry.
- Improved Cat movement while preserving the corrected Bedrock animation as the baseline: bounded step compression, torso/head counter-sway, breast secondary motion, tail/tail2 response and ear response on source-authored axes only. No invented Cat tail yaw/roll.
- Added exact Cat legacy-animation target accounting: 28 source animation targets, including 16 legacy names absent from the shipped geometry; source blink pulse is deliberately routed to the actual `eye1`/`eye2` groups.
- Corrected Cherry/Blossom source fidelity: original body proxy `ty=18`, complete source chest/leaf/hair/hurt channels and exact `/2.5` face timing.
- Added a numerical Cherry parity gate: 47 source runtime channels / 235 sampled evaluations.
- Retained Pie numerical parity: 712 sampled evaluations.
- Expanded deterministic Visual QA with per-mob GIF+MP4, animated six-mob grid, static six-mob approval grid, four-angle all-mob grid, Cat improved-motion contact sheet, and 1.4.2-vs-1.4.3 comparison.
- No image-generation model is used for project QA.

## 1.4.2 - Pie-family animation fidelity

- Restored the full supplied Pie CEM animation program for Female, Bunny, and Bee instead of the 1.4.1 blink-plus-generic-accessory approximation.
- Added coordinated source-style torso translation/lean, breathing sway, head counter-motion, hair inertia, chest secondary motion, gaze/pupil tracking, and hurt recoil.
- Replaced vanilla Creeper leg animation for the Pie family with the source CEM proxy-part program: absolute leg pivots, four-leg phase relationships, per-leg lift/stride, stance yaw/roll, idle weight shift, and head-turn influence.
- Restored Bunny source tail and articulated ear channels, including the second right-ear segment and aggression-response easing.
- Restored Bee source tail/antenna-ear channels and bilateral source wing motion; removed the invented generic high-frequency flap.
- Preserved Pie's original blink expression unchanged.
- Added deterministic per-entity source phase seeding so idle/walk motion does not look robotically synchronized across a crowd.
- Added `tools/audit_pie_animation_fidelity.py` to lock exact Pie source hashes, 53/61/64 source channel sets, CEM target hierarchy semantics, exact blink/gaze behavior, and non-regression hashes for the corrected Cat and Cherry/Blossom animation methods.
- Added `tools/test_pie_animation_formula_parity.py`: 712 sampled channel evaluations are compared numerically against expressions read directly from the supplied Female/Bunny/Bee JEM files.
- Cat 1.4.1 source-derived animation and Cherry/Blossom Remake 3.0 animation methods remain byte-identical to their 1.4.1 baseline.

## 1.4.1 - Cat Creeper Bedrock-parity correction

- Fixed the Cat Creeper tail/protrusion regression caused by incorrect hand-port rotation sign conversion in 1.4.0.
- Re-derived the Bedrock -> Java transform from Blockbench's actual Bedrock importer and Minecraft Java entity exporter: after the codec transforms are composed, authored Bedrock bone/animation rotation signs are retained; model-space Y positions are inverted for Java.
- Re-generated the entire Cat base model directly from the supplied `creeper.geo.json`, preserving pivots, hierarchy, UVs, deformation/inflate values, zero-depth planes, and inherited `mirror` flags.
- Replaced the approximated Cat charge layer with the exact supplied `creeper_charged.geo.json` topology and exact supplied armor texture.
- Re-generated Cat animation sampling from the exact supplied `creeper.animation.json`; removed invented tail yaw motion and restored the authored tail X channels, ear channels, body/head Catmull-Rom motion, breast motion, and leg override directions.
- Preserved the supplied three blink pulses by mapping the pack's legacy blink timing channels onto its actually shipped `eye1` / `eye2` geometry.
- Added `tools/audit_cat_bedrock_port.py`, an independent source-hash + geometry/animation semantic gate that fails if the Cat port drifts from the supplied pack.
- Added complete Cat source references (client entity, render controllers, manifest, base/charged geometry, animation, textures, and credit) to the source package for deterministic future re-verification.

## 1.3.1 - 3D egg-head rework

- Rebuilt all five optional 3D spawn eggs around the exact pack-authored 16x16 egg sprites instead of the 1.3.0 generic material-tile character statues.
- The exact 2D PNGs remain byte-for-byte untouched and are referenced directly as the 3D egg-head surface textures.
- Replaced the tall body/face-plate look with convex, rounded egg/head depth generated from each source sprite silhouette.
- Kept compact mob-specific head details: Female side ponytail lobes, Bunny ears, Bee antennae/wings, Cherry high ponytail + Remake 3.0 leaf, Blossom sakura puffs/crown + leaf.
- Retired all 25 generic 1.3.0 3D material-tile PNGs from the active mod.
- Reworked animation into subtle whole-egg sway and bob/squish phases so textured faces and accessories stay visually coherent.
- Optimized generated model source by merging horizontal curvature runs and inheriting animation-state geometry from the idle model.
- Upgraded deterministic item-model QA to resolve parent models and sample actual per-face UV texels instead of material-average colors.
- 3D mode remains client-only; 2D fallback, spawn behavior, entities, recipes, companion gameplay, and server logic are unchanged.

## 1.3.0 - Animated 3D character eggs

- Added an optional client-side 3D presentation for all five Creeperella spawn eggs.
- Preserved the exact Pie/Cherry 1.2.3 2D sprites as the immediate fallback; disabling 3D mode restores those exact pixels.
- Added distinct character geometry for Female, Bunny, Bee, Cherry, and Blossom rather than generic recolored egg meshes.
- Added subtle per-variant sway and blink states, with ponytails/ears/wings/foliage moving through staggered animation phases.
- Added `creeperella-client.toml` options: `use3DSpawnEggs`, `animate3DSpawnEggs`, and `spawnEggAnimationSpeed`.
- 3D/animation settings are visual-only and do not alter spawning, registries, entities, companion gameplay, recipes, or server behavior.
- Used the user-supplied Rethoughted Spawn Eggs pack only as design/geometry reference; no reference-pack model JSON or texture bytes are bundled.

## 1.2.3 - Pack-accurate spawn eggs

- Replaced the five generic/tinted Forge spawn-egg item models with real custom item sprites sourced from the user-supplied resource packs.
- Female uses `(Pie's) Female Creeper 1.2/assets/minecraft/textures/item/creeper_spawn_egg.png` byte-for-byte.
- Bunny uses Pie's `textures/item/bunny.png` byte-for-byte.
- Bee uses Pie's `textures/item/bee.png` byte-for-byte.
- Cherry uses `Cherry Creeper 1.0.2/assets/minecraft/textures/item/creeper_spawn_egg.png` byte-for-byte.
- Blossom shares the exact provided Cherry-family pink egg sprite because none of the supplied packs contains a separate Blossom egg texture.
- Preserved Cherry Creeper Remake 3.0 mob geometry, animation, textures, emissive layer, all companion gameplay, entities, registry IDs, recipes, configs, and spawn behavior.
- Resource-only release: no Java source changes from 1.2.2.

## 1.2.2 - Cherry Creeper Remake 3.0

- Replaced the retired Cherry/Blossom geometry with the supplied Cherry Creeper Remake 3.0 topology.
- Added native Cherry-family movement/blink animation and supplied emissive treatment.
- Kept the retired visual set only as an external legacy backup rather than bundling it in the active mod.

## 1.2.1 - Visual QA hotfix

- Fixed Blossom Creeper shipping with pixel-identical Cherry texture data; Blossom gained a distinct pale sakura/lilac palette while preserving the authorized Cherry-derived art lineage.
- Added deterministic model-QA render verification for Female, Bunny, Bee, Cherry, and Blossom variants.
- No gameplay Java changes from the server-verified 1.2.0 companion build.

## 1.2.0 - Demolition Buddies

- Added persistent tameable companion state to all five Creeperella variants.
- Added five real edible, variant-themed explosive treats: Rosy Fuse Cake, Bunny Boom Bite, Honey Pop, Cherry Bomb Bonbon, and Blossom Burst Cookie.
- Taming is deterministic (3 matching treats by default) rather than random.
- Added owner-only Follow / Stay controls and long-distance catch-up recall.
- Added the Fuse Whistle with exact-companion binding, aimed mob targeting, direct mob interaction commands, recall, and sneak-use immediate detonation.
- Added reusable commanded explosions: the companion does not die, phases out, and reforms beside her owner after 3 seconds by default.
- Added balanced normal/charged cooldowns (30s / 45s defaults) and separate explosion power controls.
- Block damage from follower explosions is disabled by default.
- Owner, allied players, sibling Creeperellas, and the owner's tameable pets are protected from follower blast damage by default.
- Added a hard safety override preventing any tamed Creeperella from entering the vanilla self-destructive swell/ignite path.
- Added wall-respecting long-range whistle targeting and protected-target rejection.
- Added persistent owner, state, bond, cooldown, reform, and command-target NBT.
- Added `#creeperella:taming_treats` and the **Best Friends with Booms** advancement.
- Added Food & Drinks / Tools & Utilities creative-tab discoverability for all new items.
- Preserved every 1.1 transformation, renderer, spawn rule, model, tag, and vanilla-Creeper non-replacement guarantee.

## 1.1.0 - Premium Bloom & Boom pass

- Renamed the second cherry-family form to **Blossom Creeper** and gave it the distinct alternate blossom texture instead of relying on a renderer tint.
- Added configurable **Makeover Grace** (default 120 ticks / 6 seconds).
- Added vanilla-style transformation advancements and public datapack tags.
- Protected Deep Dark and Mushroom Fields from accidental natural spawns.
- Improved Blossom particles and transformation presentation.
- Kept all mobs real standalone registry entities; vanilla Creepers are never replaced.

## 1.0.0 - Forge 1.20.1 foundation

- Added five independent Creeperella entities: Female, Bunny, Bee, Cherry, and Blossom.
- Converted supplied CEM models to native Minecraft model layers.
- Added charged rendering, spawn eggs, natural spawning, config toggles, ambient particles, and vanilla-Creeper loot behavior.
- Added vanilla-item transformations and preserved Pie `bunny` / `bee` name-tag behavior.

## 1.4.0 - Cat Creeper / Source Animation Fidelity

- Added the **Cat Creeper** as a sixth standalone Creeperella variant, adapted from the supplied `FemaleCreeper.mcpack` rather than replacing vanilla Creepers.
- Ported the supplied Bedrock cat geometry and textures into a native Forge model/render path, including the charged overlay.
- Preserved the cat source pack's authored body/head sway, bob, breast/tail motion, ear motion, walking cadence, swelling behavior, and three blink beats per animation loop. Legacy blink helper bones referenced by the Bedrock animation but absent from its shipped geometry are mapped onto the visible authored eye groups so the blink is not lost in the Forge port.
- Restored Pie's source blink expression for the Female/Bunny/Bee family and retained Cherry/Blossom source-style CEM face/idle animation behavior.
- Added Cat Creeper natural spawning, spawn egg, Catnip Crunch taming treat, advancement, tags, particles, and String-as-yarn transformation from vanilla or another Creeperella.
- Expanded optional 3D spawn-egg generation/audit from 5 to 6 variants while locking the original five 2D fallback sprites byte-for-byte to the 1.3.1 baseline.

## 1.4.19 - Cat personality animation restoration
- Reworked Cat Creeper `TAIL_WAG` from a fast four-cycle metronomic sine into a slower asymmetric feline swish with delayed/larger distal follow-through, subtle pitch/curl, and occasional deterministic tip flick.
- Reworked LOAF `KNEAD` so the already-grounded tucked paws flex/compress in place instead of blending toward a second leg pose that made the motion stiff and risked reopening the loaf.
- Refined standing/SIT kneading with smoother alternating pressure, smaller lift, paw flex, shoulder weight transfer, and gentle head/tail secondary motion.
- QA rule: personality clips must be rendered at true clip duration and layered over the actual rest pose; sparse 8-frame compressed reels are not approval evidence for motion quality.
- 1.4.18 remains the rollback baseline.
