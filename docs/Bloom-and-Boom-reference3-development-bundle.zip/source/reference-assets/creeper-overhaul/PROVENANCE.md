# Creeper Overhaul -> Boomshroom authorized reference

The project owner supplied `creeperoverhaul-3.0.2-forge.jar` and `CreeperOverhaul-neoforge-1.21.1-4.0.6.jar` and stated they have full permission to use Creeper Overhaul assets for Bloom & Boom.

Boomshroom intentionally uses:
- the Mushroom Creeper cap cube dimensions / UV layout as the cap silhouette reference;
- the supplied Mushroom Creeper cap texture and glow texture as exact runtime cap atlases;
- the 4.0.6 mushroom idle/walk animation JSON as motion-language reference for cap secondary motion.

Bloom & Boom's body remains its own Cherry-family rig/texture derivative, and the cap is isolated as a render layer so later accessory variants can evolve without flattening the design into a reskin.
