# Shroomboom reference contract

- User-supplied visual reference: `Shroomboom.png`. It is provenance/reference art only; no image generation is used.
- Stable Boomshroom remains unchanged. Shroomboom is a separate visual-development variant.
- Base animation/silhouette authority: Pie/Female Creeperella hierarchy, including chest/breast animation.
- Target visual motifs from the reference: oversized stepped red/white cap, visible cream gills, dimensional expressive eyes, real 3D eyelashes, moss/vine hair, shelf fungi, mini mushrooms, bark/soil/moss growth from legs into torso.
- Hair uses six articulated root/mid/tip chains (left/right side, front, and back) with runtime spring/inertia motion plus irregular per-segment moss fringes.
- Natural spawning stays disabled until visual approval.
