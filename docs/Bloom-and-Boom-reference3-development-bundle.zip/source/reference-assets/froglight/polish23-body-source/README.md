# Froglight body source checkpoint

These three body atlases are byte-identical to the verified dev6 / dev7-polish23 Froglight base textures.
POLISH24+ body-palette tooling reads these immutable copies so repeated generation cannot compound color transforms.
They preserve the proven Pie UV layout and all dark facial/source details; only the pale Froglight material palette is remapped.
