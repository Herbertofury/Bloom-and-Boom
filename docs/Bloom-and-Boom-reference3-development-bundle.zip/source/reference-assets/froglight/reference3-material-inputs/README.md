# Reference3 material inputs

Frozen, hand-authored/vanilla-derived working textures from the first reference3 pass. Used by tools/refine_reference3_luminance.py for idempotent material refinement. Original Minecraft material attribution remains in ASSET_LICENSES.md. These are working textures, not approved concept artwork. No image generation was used.
