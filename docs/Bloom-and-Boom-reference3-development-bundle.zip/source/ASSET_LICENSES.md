# Asset provenance and permissions

Creeperella's original Java/Gradle/data code is licensed under the repository's `LICENSE` file. Bundled art/model assets retain their own provenance and authorization records.

## Pie's Female Creeper 1.2

Source input supplied by the user as `(Pie's) Female Creeper 1.2.zip`.

- Embedded CEM credit: `author-P1nus-Or-Mrflowy10`.
- The supplied pack contains the standard, `bunny`, and `bee` model/texture variants plus charged geometry/texture.
- Public project metadata identifies the resource pack as Creative Commons 4.0; retain attribution when redistributing.
- Creeperella converts the supplied CEM geometry to native Minecraft model layers instead of requiring OptiFine/EMF at runtime.
- 1.2.3 also carries the supplied 16x16 item sprites byte-for-byte for the matching spawn eggs:
  - Female: `assets/minecraft/textures/item/creeper_spawn_egg.png` — SHA-256 `475a5fcfa6138dc00f58f77bbe99813043fbcdee97eda632655f535166251187`
  - Bunny: `assets/minecraft/textures/item/bunny.png` — SHA-256 `81c8c6db0ff013a4ad459ab7856486068e2977922f423ea769f27d779972e23e`
  - Bee: `assets/minecraft/textures/item/bee.png` — SHA-256 `64fe7c8a410a4317f584765afcb98f4397f367a0f0bec6dbeaf0865adf84163d`

## Cherry Creeper 1.0.2

Source input supplied by the user as `Cherry Creeper 1.0.2.zip`.

- Embedded CEM credit: `Made with Blockbench`.
- Legacy 1.0.2 global-replacement assets are not used as vanilla overrides. In 1.4.4 the current Remake 3.0 Cherry sidecars are instead ported as dedicated namespaced Cherry-family content, documented below.
- The **pink Cherry spawn-egg sprite is intentionally included** in 1.2.3 because the user explicitly requested the actual supplied egg art rather than a generated/tinted Forge egg.
- Cherry egg source: `assets/minecraft/textures/item/creeper_spawn_egg.png` — SHA-256 `391c89f344f5b286539e696cbff107e0247afbd9e6adabfb1d2a60e26f2ba60f`.
- Blossom currently shares this exact provided Cherry-family egg sprite; no supplied pack includes a distinct Blossom spawn-egg PNG.
- The user states that the Cherry work reused Pie's work and that the relevant author directly confirmed permission/full rights for this Creeperella use. Preserve this record with the project.

## Cherry Creeper Remake 3.0

Source input supplied by the user as `Cherry_Creeper_remake(3.0).zip`.

- Embedded CEM credit: `made by Poolb, Kotisimo`.
- Supplies the active Cherry/Blossom 3.0 mob geometry/topology, Cherry texture, face-frame layout, emissive pixels, standalone Cherry head CEM, Cherry TNT model/texture, Cherry gunpowder sprite, Creebet painting art, and English/Russian identity strings.
- Starting in 1.4.4, those author-intended sidecar assets are **not discarded and do not replace vanilla globally**: they are ported as dedicated `creeperella:` content for the Cherry family. The exact TNT/gunpowder/painting source pixels are preserved. In 1.4.5, Cherry TNT uses vanilla TNT cube geometry while deterministic face extraction preserves the source atlas visual result; the original Blockbench model remains untouched in the provenance mirror. `head_creeper.jem` generates the standalone Cherry Creeper Head.
- Cherry Creepers drop Cherry Gunpowder; Cherry Gunpowder crafts Cherry TNT and participates in Cherry recipes; Cherry TNT retains normal TNT ignition/chain behavior but primes as the Cherry-textured entity; charged-Creeper skull-drop semantics yield the Cherry Creeper Head; the dedicated painting item places only the authored Creebet painting.
- The Remake 3.0 pack does **not** contain a spawn-egg texture; the preserved pink egg comes from Cherry Creeper 1.0.2.

## FemaleCreeper.mcpack — Cat Creeper source

Source input supplied by the user as `FemaleCreeper.mcpack`. Despite the filename, the authored geometry is the cat-eared/tail Creeper used by Creeperella as the standalone **Cat Creeper** variant.

- Embedded credit: `Original Pack Creator - ThePrismaticPinky`.
- Embedded source link: `https://www.planetminecraft.com/texture-pack/pinky-s-dynamoss-creepers/`.
- Bedrock port credit in the supplied pack: `AQua`.
- Creeperella retains the supplied 128x64 entity texture and charged texture and converts the supplied Bedrock geometry to a native Forge/Minecraft model layer.
- 1.4.1 keeps a deterministic reference copy of the supplied base geometry, charged geometry, animation, client-entity declaration, render controllers, manifest, textures, and embedded credit in `reference-assets/cat/` so the Java port can be audited against the actual source rather than memory or screenshots.
- Exact source hashes used by the 1.4.1 audit include base geometry `738081fcdb99d5200ce01f9c58283cd693cc78868decdeac6e7249ff1e6bda10`, charged geometry `cc2095ce5d9d11a8efb2dfb433f74f126e3398bfe6efcbabb7b9c2de1b394168`, animation `aaaa5b007956a264e099b76b71b4e1808c194e4be7a74af8a1c34f68a04f63a7`, base texture `220e9c4000e3d2a1b752af36e041f0266661d0f91bc1a77875df66784a5f693a`, and charged texture `dfcd53cb643b5d305bc31d9380f2156c546d28bc3fe2e57cff47eaa55f6fea4b`.
- The supplied `animation.creeper.legs` timing is explicitly preserved in the Forge port: body/head sway, tail motion, ear motion, source walking cadence, and the three authored blink windows in the 8.0417-second loop. The Bedrock animation references legacy blink bones that are absent from the shipped geometry, so Creeperella applies those exact blink timings directly to the two authored eye groups instead of silently dropping the blink.
- The Cat spawn-egg sprite is a deterministic, source-palette derivative authored for Creeperella; it does not replace or alter the exact five pre-1.4.0 Pie/Cherry egg sprites.

## Rethoughted Spawn Eggs — reference only

Source reference supplied by the user as `Rethoughted Spawn Eggs.zip` (pack metadata identifies Rethoughted Spawn Eggs v1.4 by CatFromNet).

- Used as a **visual/geometry reference** for the idea of tiny mob-shaped 3D spawn eggs.
- Creeperella 1.3.1 authors its own five Creeperella-specific egg-head item models and animation states. The 3D surfaces reference the already-authorized exact Pie/Cherry 2D egg sprites documented above; the generic 1.3.0 material tiles were retired.
- No model JSON, item definitions, or texture bytes from the reference pack are redistributed in the Creeperella JAR or source release.
- The exact Pie/Cherry 2D egg sprites documented above remain Creeperella's fallback art **and** are now the direct surface textures for the optional 3D egg-heads.

## Distribution note

These notes document provenance; they do not attempt to relicense third-party art beyond the rights/permissions that apply to those assets. Keep this file with any source or binary release containing the supplied art.


## visual1 four-variant material refresh — 7 October 2026

The Cinderella, Mariglow, Verdalia and Nacrella body texture atlases in visual1 use newly AI-generated pixel-art material samples integrated into the established 128x64 UV layout. Original alpha coverage and authored mouth/animated-eye UV contracts remain preserved. Their matching emissive masks were derived from the new accents and corrected for the additive shader. These are new development assets, not unchanged source-pack textures or native gameplay screenshots.

Shared family geometry retains its original Pie lineage and credits above. Froglight crown/accessory assets retain their original provenance. Cat art, geometry assets and animation were not redesigned. Original source and author attributions remain applicable; this refresh does not relicense third-party material.


## reference2 material correction — 7 October 2026

The visual1 generated body atlases are superseded in the working reference2 candidate. Mariglow, Verdalia and Nacrella now derive their body and face materials from checksum-verified vanilla Minecraft 1.20.1 Ochre/Verdant/Pearlescent Froglight textures, baked into the preserved Pie UV/alpha contract. The original Cinderella atlas is restored. Existing third-party geometry and asset attributions remain unchanged. The reference catalog pins the approved concept files; reference fidelity is still subject to native acceptance.

### reference2 material and charge refinements

The reference2 face and body finish uses deterministic UV-aware pixel work from the locally verified vanilla Froglight material inputs already credited above. Accessory colors and three new sparse charged masks are hand-authored deterministic project assets. No new AI-generated concept or replacement image was used for this pass. The supplied Cat charge texture and other families' charge routes are unchanged. The old visual1 generated samples are historical, not approved reconstruction targets.

## reference3 geometry and material refinements — 7 October 2026

Reference3 adds cached petal normals, denser roof flowers, twelve articulated chains, hand-painted iris gradients, translucent lantern-shell materials and brighter UV-aware body centers. The body/face inputs retain the checksum-verified vanilla Froglight provenance above; input snapshots and hashes for the idempotent finishing pass are stored under reference-assets/froglight/reference3-material-inputs. Flower, foliage and glass pixels are deterministic project-authored materials. No image generation was used. This pass does not modify Cat assets, the underlying Pie rig, or their original author credits.
