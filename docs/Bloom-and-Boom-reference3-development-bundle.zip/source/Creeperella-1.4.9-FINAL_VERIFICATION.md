# Creeperella 1.4.9 final verification

- Version: 1.4.9 (Forge 1.20.1 target).
- Seated tail solve: root yaw/roll = 0 at full SIT; root X target 0.35 rad; tail2 X target 0.75 rad; no arbitrary lateral root offset.
- Numerical seated-tail gate: PASS; max static lateral displacement 0.00000 model units, minimum rear travel 14.26153, minimum sampled floor clearance 6.27837.
- Cat locomotion/clipping gate: PASS 17,328 creep/walk/run leg-phase samples; SIT/SWELL and all personality idles remain free of sampled distal torso penetration.
- Cat behavior contract: PASS; transition-only state sync, bounded path refresh, notice/follower hysteresis, interruptible idles.
- Deterministic seated-tail QA: front / 3/4 / side / back plus SIT, tail-wag, loaf and side-lie GIFs. No generative image model used.
- Production-remapped JAR/live Forge client startup remain outside this runtime because the Java-17 ForgeGradle wrapper/toolchain is not available here.
