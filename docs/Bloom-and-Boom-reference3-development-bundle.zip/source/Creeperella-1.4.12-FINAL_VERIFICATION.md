# Creeperella 1.4.12 Final Verification

Target: Minecraft 1.20.1 / Forge 47.4.23 / Java 17.

## Cat horse-rest correction

- `SIT`, `LOAF`, `SIDE_LIE`, and `SPRAWL` remain real synced runtime rest states.
- `SIDE_LIE` is now a grounded horse-style chest-down rest instead of a rolled-over/fallen rig.
- Four variants are implemented: calm, extended foreleg, sleepy, alert.
- The torso is near-horizontal while the head/neck counter-rotate upright.
- All four leg chains are translated and articulated to the same side of the torso.
- Side-rest tail preserves the no-roll source contract; it trails rearward using X/Y rotation only.
- The deterministic QA floor is the normal standing Cat Creeper paw-bottom plane, not a per-pose auto-snap.

## Local verification

- `tools/test_cat_horse_rest_ground.py`: PASS — four variants, true standing-ground clearance, near-horizontal torso, upright head, all legs side-swept.
- `tools/test_cat_behavior_contract.py`: PASS — Cat state/idle sync, stalk/run/follow hysteresis and interruption contract retained.
- `tools/test_cat_secondary_motion.py`: PASS.
- `tools/test_cat_aaa_gait.py`: PASS — 17,328 locomotion samples, seated/swell clipping gates, personality idle gates, tail/paw checks.
- `tools/audit_cat_bedrock_port.py`: PASS — exact Cat source geometry/assets, source animation semantics retained, no Cat tail roll.
- Bare `javac` parser pass: no syntax/parser diagnostics in modified Java sources; expected missing Forge/Minecraft dependency symbols remain because the ForgeGradle classpath is not installed in this runtime.

## Production gate

A real Java 17 ForgeGradle compile/remap and Forge 47.4.23 startup remain the production binary gate. Do not label a JAR production-verified until that gate runs successfully.

