# Spawn Egg Source Map — Creeperella 1.2.3

This release intentionally uses the exact user-supplied 16x16 item sprites instead of Forge `template_spawn_egg` tint approximations.

| Creeperella item | Supplied source pack | Source path | SHA-256 |
|---|---|---|---|
| Female Creeper Spawn Egg | `(Pie's) Female Creeper 1.2.zip` | `assets/minecraft/textures/item/creeper_spawn_egg.png` | `475a5fcfa6138dc00f58f77bbe99813043fbcdee97eda632655f535166251187` |
| Bunny Creeper Spawn Egg | `(Pie's) Female Creeper 1.2.zip` | `assets/minecraft/textures/item/bunny.png` | `81c8c6db0ff013a4ad459ab7856486068e2977922f423ea769f27d779972e23e` |
| Bee Creeper Spawn Egg | `(Pie's) Female Creeper 1.2.zip` | `assets/minecraft/textures/item/bee.png` | `64fe7c8a410a4317f584765afcb98f4397f367a0f0bec6dbeaf0865adf84163d` |
| Cherry Creeper Spawn Egg | `Cherry Creeper 1.0.2.zip` | `assets/minecraft/textures/item/creeper_spawn_egg.png` | `391c89f344f5b286539e696cbff107e0247afbd9e6adabfb1d2a60e26f2ba60f` |
| Blossom Creeper Spawn Egg | `Cherry Creeper 1.0.2.zip` | same exact Cherry-family sprite (no distinct Blossom egg exists in supplied packs) | `391c89f344f5b286539e696cbff107e0247afbd9e6adabfb1d2a60e26f2ba60f` |

`Cherry_Creeper_remake(3.0).zip` supplies the active Cherry-family mob model/texture/emissive assets but contains no spawn-egg PNG.
