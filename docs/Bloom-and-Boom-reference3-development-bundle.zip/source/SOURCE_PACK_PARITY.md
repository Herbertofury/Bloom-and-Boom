# Creeperella source-pack parity contract — 1.4.7

This file defines the non-regression contract for the three user-supplied source packs. The project rule is: **fully preserve the author's intended mob content, converting global resource-pack replacements into standalone `creeperella:` content when needed rather than discarding them or overwriting unrelated vanilla assets.**

## Complete source mirrors

The exact uploaded file inventories are preserved under `reference-assets/source-packs/` and hash-gated by `tools/audit_source_pack_completeness.py`:

- Pie's Female Creeper 1.2: **21/21 files exact**
- Cherry Creeper Remake 3.0: **12/12 files exact**
- FemaleCreeper.mcpack / Cat: **12/12 files exact**
- Total: **45/45 files exact**

The supplied packs contain **0 particle asset files** and **0 sound asset files**. Creeperella's existing personality particles and sounds are mod-native additions, not substitutes for missing source files.

## Pie Female / Bunny / Bee

Actively ported:

- exact Female, Bunny and Bee base textures
- exact shared charged overlay texture
- exact source 2D Female/Bunny/Bee spawn-egg pixels
- all three base CEM geometries and all three charged CEM geometries
- full source CEM animation program: body/head counter-motion, four-leg proxy gait, blink, pupil/gaze, brows, chest, hair, Bunny tail/ears/floppy ear piece, Bee appendages/wings, hurt and aggression response
- source name-selection semantics converted into dedicated standalone Forge entities/items

Permanent checks:

- source animation channel sets: Female 53 / Bunny 61 / Bee 64
- numerical animation parity: **712 sampled source-formula evaluations**
- charged CEMs equal base programs minus exactly ten face-only channels absent from charged geometry
- all Java model layers regenerate byte-identically from the six supplied JEM files

## Cherry Creeper / Blossom rig

The Cherry Creeper Remake 3.0 mob contribution remains fully source-driven:

- exact Cherry base texture and exact emissive texture
- exact CEM geometry, including thin decorative planes
- original Creeper proxy body Y=18 placement
- complete walk/body/head/leg/chest/leaf/hair/hurt animation outputs
- exact source face/blink timing (`floor(time / 2.5) % 21` behavior)
- source English/Russian Cherry mob and spawn-egg names safely remapped to `creeperella:`
- **47 runtime animation channels / 235 sampled source-formula evaluations**

Blossom intentionally reuses the authored Cherry rig with the established Blossom visual treatment. The Cherry pack contains no separate authored charged CEM/charged texture, so Creeperella's powered Cherry/Blossom layer remains the documented Forge adaptation rather than invented source data.

## Cherry Remake sidecars — standalone, not discarded

Starting in 1.4.4, every author-intended visible/gameplay sidecar in the Cherry pack is carried into the mod as its own Cherry-family feature. 1.4.5 additionally locks semantic parity for source-format adapters: author intent/visible output is preserved while target-native vanilla primitives are preferred when they represent the same feature more correctly:

### Cherry Gunpowder

- exact source `textures/item/gunpowder.png` bytes
- registered as `creeperella:cherry_gunpowder`
- Cherry Creeper's normal gunpowder loot is replaced with Cherry Gunpowder while retaining vanilla skeleton music-disc semantics
- participates in the Forge gunpowder tag
- crafts Cherry TNT and is used by the Cherry Bomb Bonbon recipe

### Cherry TNT

- exact source `textures/block/tnt/tnt.png` 64×64 atlas remains byte-identical and hash-gated
- the source Blockbench JSON is preserved **exactly in the source mirror** as provenance; audit proves it is a single vanilla-size 0..16 cube whose custom UVs exist to address tiles inside the 64×64 atlas
- runtime model intentionally uses `minecraft:block/cube_bottom_top`, matching vanilla TNT geometry instead of blindly carrying the source-format UV adapter
- `tools/generate_cherry_tnt_vanilla_faces.py` deterministically evaluates the source UV/rotation semantics into exact 16×16 runtime faces: side `5a63ce2708e5c9d84d39888f2c01ad0502bcdc378675b7fc2dc717ee7323e15f`, top `20a00b1ae4f0644947354f7edc78eb9c9bebf3fd3488928f05d048440aa74317`, bottom `3ba2cdf937b2c1b49d26d1cdf82f9e8f64e7c4171f186212f2a70739df16f015`
- registered as `creeperella:cherry_tnt`
- dedicated `CherryPrimedTntEntity` and renderer ensure primed TNT remains Cherry-themed while using the vanilla TNT block-render path
- redstone, unstable break, flint-and-steel, fire charge, flaming projectile, Forge `onCaughtFire`, explosion chain-reaction, fuse shortening, swell/flash and normal TNT explosion behavior are preserved
- vanilla `minecraft:tnt` is untouched

### Cherry Creeper Head

- generated directly from exact source `head_creeper.jem` (hash `1d41e777eff7deaa839d77f3ce88d95890068191710b35273a719459cf28001a`)
- exact Cherry mob texture remains the head texture
- dedicated standing block, wall block and custom-rendered inventory item
- item uses vanilla skull display transforms
- Cherry Creepers killed by an eligible powered Creeper drop the standalone Cherry Creeper Head under vanilla skull-drop accounting semantics
- source English/Russian head name preserved under the Creeperella namespace
- vanilla `minecraft:creeper_head` is untouched

### Cherry Creebet Painting

- exact source `textures/painting/creebet.png` bytes
- registered as `creeperella:cherry_creebet`, exact authored **32x16** dimensions (2x1 blocks)
- dedicated placement item places only that variant
- vanilla painting registry/art is not globally replaced

There is no active `src/main/resources/assets/minecraft` override directory. Packaging metadata, selector files and backups remain exact archival inputs, but **no authored Cherry gameplay/visual sidecar remains reference-only**.

## Cat Creeper / FemaleCreeper.mcpack

Actively ported:

- exact base and charged armor textures
- exact base Bedrock geometry: **39 cubes**
- exact separate charged geometry: **14 cubes**
- hierarchy, pivots, UVs, dimensions, mirror inheritance, inflate/deformation and thin planes
- source render-controller powered/flash semantics
- source Catmull-Rom/linear channels for Body, Upperbody, Breast, head, ears, tail and tail2
- source four-leg phase formula preserved in provenance/audit; source blink timing remains active at runtime

The animation JSON names 28 targets while shipped base geometry contains 24 bones. Exactly **16 targets are legacy names absent from shipped geometry**, and this mismatch is explicitly audited rather than silently filled with invented geometry. The authored `white/white2` blink pulse is routed to the actual shipped `eye1/eye2` groups. 1.4.7 keeps the exact source idle/secondary curves and bind pose, while movement locomotion intentionally uses the existing authored leg bones in a bounded feline two-link IK gait. A small movement-only tail Y balance channel is allowed for natural feline follow-through; tail roll remains absent. The gait solver collapses to the authored bind leg pose at movement=0.

## Spawn eggs

- all five pre-Cat source-derived 2D spawn-egg sprites remain hash-locked
- Cat's established source-palette derivative remains unchanged
- optional dimensional egg-head mode resolves **24/24 six-variant states**
- 3D egg identity surfaces use the exact source-derived 2D pixels; no image-generation artwork is used

## Permanent release gates

Run before every release:

```text
python3 tools/audit_source_pack_completeness.py
python3 tools/audit_cherry_standalone_assets.py
python3 tools/audit_model_generation_determinism.py
python3 tools/audit_pie_animation_fidelity.py
python3 tools/test_pie_animation_formula_parity.py
python3 tools/test_cherry_animation_formula_parity.py
python3 tools/audit_cat_bedrock_port.py
python3 tools/audit_3d_spawn_eggs.py
python3 -m py_compile tools/*.py
```

Visual review uses the deterministic project renderers, including `tools/render_mobs_visual_qa.py` and `tools/make_cherry_standalone_qa.py`. **No image-generation model is used for Creeperella project QA.**
