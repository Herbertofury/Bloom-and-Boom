# Creeperella 1.4.17 Final Verification

## Change scope
- Cat Creeper **Sit 2 only**: rear-leg IK reach changed from `7.00F` to `8.72F` for both hind legs.
- Hip pivots, torso, forelegs, tail, rest-state IDs/cycle, Side-Lie, Sprawl, and locomotion code remain unchanged by this fix.
- Full 1.4.16 source ZIP is preserved at `pose-history/1.4.16-before/`.

## Deterministic ground QA
Standing Cat paw ground reference: `-24.096318` model-space Y.

Before 1.4.16 Sit 2:
- forepaw ground delta: `0.101815`
- left hind paw ground delta: `1.679559`
- right hind paw ground delta: `1.679559`

After 1.4.17 Sit 2:
- forepaw ground delta: `0.101815`
- left hind paw ground delta: `0.109046`
- right hind paw ground delta: `0.109046`

Both rear paws now sit on the same Minecraft floor plane as the forepaws without moving the hip pivots.

## Tests passed
- `tools/test_cat_rest_pose_polish.py`
- `tools/test_cat_behavior_contract.py`
- `tools/test_cat_horse_rest_ground.py`
- `tools/test_pie_animation_formula_parity.py` (712 sampled evaluations)
- `tools/test_cherry_animation_formula_parity.py` (235 sampled evaluations)

## Build limitation
No Gradle wrapper is present in this source snapshot and no compatible Gradle executable is available in this runtime, so a fresh Forge compile was not claimed here.

## Preview provenance
All QA PNG/GIF files are deterministic renders from the actual Cat Creeper model, texture, hierarchy, and runtime-equivalent pose math. No generative image model was used.
