# Creeperella: Bloom & Boom 1.4.8 — Verification Snapshot

Target: Minecraft 1.20.1 / Forge 47.4.23 / Java 17

## Cat behavior / animation

- Motion states: IDLE, CREEP, WALK, RUN, SWELL, SIT, REFORM.
- Wild: unnoticed -> CREEP 0.62; noticed/hurt/<=4.25 blocks -> RUN 1.45; notice memory 60 ticks; path refresh max every 8 ticks unless path done.
- Follower: WALK 1.00; RUN enters >10 blocks and exits <8 blocks; command targets RUN.
- Personality idles: Paw Lift 58 ticks / 2.9s, Tail Wag 72 / 3.6s, Curious Look 62 / 3.1s, Knead 80 / 4.0s.
- Idles require 24 true-still ticks and yield immediately to movement, target, damage, swelling, sit, or reform.
- Sync is transition-only: motion byte + idle byte + start tick. No per-tick animation packet.
- Client state blending uses exponential convergence; gait phase comes from actual limbSwing delta; limbSwingAmount remains the physical leg-motion gate.

## Verification

- Source inventory: PASS 45/45 exact; supplied particle assets 0; supplied sound assets 0.
- Runtime JSON: PASS 84/84.
- Cherry standalone/TNT: PASS.
- Model generation determinism: PASS.
- Pie: PASS 712 sampled formula evaluations.
- Cherry: PASS 235 sampled formula evaluations / 47 outputs.
- Cat: PASS 39/39 base cubes + 14/14 charged cubes; exact source geometry/texture/blink/secondary semantics retained.
- 3D eggs: PASS 24/24 states.
- Cat behavior contract: PASS.
- Cat gait/clipping: PASS 17,328 creep/walk/run leg-phase samples + SIT/SWELL/all idles both handedness; max adjacent paw delta 0.08127; no sampled distal torso penetration, side crossing, or tail2 tunneling.
- Python tools compile: PASS.
- Raw javac parse: no syntax-shaped diagnostics before expected missing Minecraft/Forge classpath symbols.

## Production boundary

A production-remapped 1.4.8 JAR is **not** claimed verified here. This environment has Java 21 but no Gradle executable/wrapper, and no exact Creeperella GitHub repository resolved through the connected GitHub account. Final production gate remains Java 17 ForgeGradle compile/remap + real Forge 47.4.23 dedicated-server startup.

Deterministic QA uses checked-in project assets and runtime-equivalent animation formulas. **No image generation.**
