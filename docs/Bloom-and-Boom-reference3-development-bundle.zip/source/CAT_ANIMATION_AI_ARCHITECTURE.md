# Cat Creeper animation + AI architecture - 1.4.8

This document is the durable contract for Cat Creeper behavior, movement animation, personality idles, network synchronization, and future animation/AI library decisions. It intentionally preserves the exact supplied Cat geometry/textures and the 1.4.7 clipping-safe IK rig.

## Design goal

Cat Creeper should read as a cat that happens to be a Creeper, not as a normal Creeper with faster legs. Gameplay intent and animation intent are coupled through a small server-owned state machine, while the final paw/joint solution remains procedural and movement-gated on the client.

## State machine

| State | Gameplay owner | Entry | Presentation | Exit/priority |
|---|---|---|---|---|
| IDLE | server | navigation stopped / no higher state | source idle + optional personality clip | movement, target, damage, swell, sit, reform |
| CREEP | server | wild player target is not currently noticed | low crouch, restrained four-beat stalk | noticed, hurt, ambush range, target lost |
| WALK | server | ordinary follower/navigation travel | normal feline walk | catch-up RUN, IDLE, target, sit |
| RUN | server | noticed/hurt/ambush wild chase, command target, far owner catch-up | longer/faster feline drive gait | swell, target lost, follow exit threshold |
| SWELL | server/vanilla Creeper attack | fuse direction > 0 for wild Cat | tense crouch/swell presentation | fuse cancels/explosion |
| SIT | server companion order | owner stay command | conservative folded stay pose | owner toggles stay off |
| REFORM | server companion detonation lifecycle | companion blast reform timer > 0 | locomotion/idles suppressed | reform completes |

Priority is effectively REFORM > SIT > SWELL > targeted/follow locomotion > IDLE. Cosmetic personality clips never outrank gameplay.

## Wild stalk -> chase behavior

Default values are configurable in `CreeperellaConfig.catBehavior`:

- creep navigation speed: **0.62**
- walk navigation speed: **1.00**
- run navigation speed: **1.45**
- ambush distance: **4.25 blocks**
- notice view dot threshold: **0.28**
- notice memory: **60 ticks / 3 seconds**
- pursuit path refresh: **8 ticks** unless path is already done

A player notices Cat when the player's view vector points sufficiently toward Cat and the player has line of sight. If Cat is not noticed and notice memory has expired, she stalks in CREEP. A glance sets the 60-tick memory and forces RUN long enough to avoid flip-flopping. Hurt or ambush distance also forces RUN immediately. Normal Creeper swelling/explosion behavior remains authoritative at attack range.

This is intentionally player-readable stealth, not invisible cheating: Cat reacts to where the player is looking and whether the player can actually see her.

## Tamed follow and command behavior

Follower catch-up uses hysteresis:

- navigation stopped / close follow: IDLE
- ordinary follow: WALK
- enter RUN above **10 blocks**
- remain RUN until inside **8 blocks**
- command target: RUN

The separate 10/8 thresholds prevent speed and animation chatter when the owner hovers around one distance. Existing long-distance safe teleport/reform rules remain unchanged.

## Locomotion timing and gating

The client does not set Cat state from render heuristics. The server synchronizes the state. Presentation then uses:

- CREEP cadence multiplier: **0.56**
- WALK cadence multiplier: **1.00**
- RUN cadence multiplier: **1.58**
- state weight convergence: `1 - exp(-dt * 0.42)` (roughly 90% in 5.5 ticks, 95% in 7 ticks)
- phase advancement from actual `limbSwing` delta
- leg-motion gate from actual `limbSwingAmount`

That last rule is critical: if pathfinding says RUN but collision prevents movement, the legs do not continue a fake run cycle. State determines *how* Cat should move; real movement determines whether the paws advance.

CREEP uses shorter stride, lower lift, longer stance, crouch and restrained secondary motion. WALK uses the natural four-beat feline gait. RUN uses a distinct faster drive/bound blend with longer stride, stronger lift/flex and different diagonal phasing; it is not merely WALK played faster.

## IK and clipping contract

All moving leg states and leg-based idles reuse the exact existing upper/lower/paw chains. Two-link sagittal IK solves target paws with hard anatomical clamps. Distal geometry is numerically checked against Body/Upperbody core volumes. Release QA also rejects:

- paws swapping across the body centerline;
- joint inversion or out-of-range angles;
- discontinuous paw teleports;
- tail-tip torso tunneling;
- locomotion remaining active at exact zero movement.

`tools/test_cat_aaa_gait.py` currently covers **17,328** locomotion leg-phase samples plus SIT, SWELL, and every personality idle for both handedness choices.

## Personality idle scheduler

Personality clips are server-selected so all clients see the same event. Idle qualification requires:

- at least **24 ticks / 1.2 seconds** of true stillness;
- navigation done;
- horizontal movement below the stillness threshold;
- no target;
- not hurt;
- not swelling.

Default random cooldown is **80-220 ticks / 4-11 seconds**. Tamed Cats use a slightly shorter multiplier so they show personality more often. The selector rerolls once when it would immediately repeat the previous clip.

Clips:

1. **Paw Lift (58 ticks)** - one front paw lifts and folds through the existing IK-safe chain, body weight moves to the support side, head tilts, tail answers, then the paw is placed down. Positive owner/taming interaction can trigger this directly.
2. **Tail Wag (72 ticks)** - relaxed root wag with larger lagged tail-tip follow-through plus tiny body/ear response.
3. **Curious Look (62 ticks)** - asymmetric head yaw/roll/pitch, ear twitch, and interested tail tip.
4. **Knead (80 ticks)** - tamed-only alternating front-paw kneading, small bob and secondary tail/head motion.

Every clip has a smooth enter envelope from 0-16% and exit envelope from 82-100% rather than snapping on/off. Handed clips choose left/right deterministically from entity identity. Gameplay interrupts immediately cancel the clip.

## Network and performance contract

Synced entity data contains only:

- motion state byte;
- idle clip byte;
- animation start tick integer.

`setCatMotionState` exits when the state is unchanged. Timers, notice memory, cooldowns, stillness counters and follower run latch remain server-local. The client derives continuous animation locally from synced state + normal render movement inputs. There is no custom per-tick animation packet and wild Cat path refresh is bounded.

## Animation/AI library evaluation

### Recommended now: keep Creeperella's custom controller

The current custom system is the best fit for 1.4.8 because the hardest part of Cat motion is procedural paw placement and clipping-safe IK over an already source-locked Java `ModelPart` rig. Replacing the rig/runtime solely to gain an animation framework would add migration risk without improving the solved problem. The state/idle enums are deliberately simple enough that a future adapter can map them into an external controller if needed.

### GeckoLib 4.8.4 - preferred optional future animation layer

Direct 1.20.1 Forge file: https://www.curseforge.com/minecraft/mc-mods/geckolib/files/8285794
AnimationController docs: https://github.com/bernie-g/geckolib/wiki/The-Animation-Controller-%28Geckolib4%29
Triggered-animation docs: https://github.com/bernie-g/geckolib/wiki/Triggerable-Animations-%28Geckolib4%29

Use GeckoLib if Creeperella later accumulates many Blockbench-authored non-procedural one-shot clips, sounds/particles keyed to animation, or independent animation layers. GeckoLib 4 supports multiple controllers, transition ticks, speed handlers, and server-triggerable animations. A future hybrid should leave procedural locomotion/IK authoritative for the Cat legs and use a separate controller/layer for one-shot personality or special effects only, avoiding multiple controllers fighting over the same bones.

### SmartBrainLib 1.15 - optional future AI framework

Direct 1.20.1 Forge file: https://www.curseforge.com/minecraft/mc-mods/smartbrainlib/files/5654964

Use SmartBrainLib only if Cat AI grows into a large sensor/memory/behavior graph (territory, pouncing, fear, group coordination, complex owner commands, etc.). The current stalk/follow/run/sit/reform decision tree is smaller and clearer as local server logic, so adding an AI dependency today would increase surface area without a concrete benefit.

### AzureLib 3.1.12 - valid Bedrock-first alternative, not a current migration target

Direct 1.20.1 Forge/NeoForge file: https://www.curseforge.com/minecraft/mc-mods/azurelib/files/all?version=1.20.1

AzureLib is designed for Bedrock models/animations and could be attractive for a future Bedrock-first rewrite. The existing Cat, however, already has an audited Bedrock -> Java conversion and exact Java rig used by procedural IK. Migrating now would require re-proving geometry, charged-layer and animation parity, so it is not justified for 1.4.8.

### Yes Steve Model - not the right entity-animation dependency

Project: https://modrinth.com/mod/yes-steve-model?loader=forge&version=1.20.1

Yes Steve Model supports 1.20.1 and Bedrock model/animation files, but its purpose is modifying the vanilla **player model** and it uses GeckoLib internally. It is useful inspiration for Bedrock animation workflows, not the runtime architecture Creeperella needs for a custom Creeper entity.

## Future AAA extensions already supported by this architecture

The state/idle split leaves clean room for future additions without breaking today's network contract: pounce anticipation, landing recovery, grooming, stretch, sleeping/loaf, owner greeting, fear/back-away, charged-electricity reaction, terrain-aware paw lift, or special tail/ear signals. Add them as explicit interruptible states/clips and extend the numerical clipping gate rather than layering arbitrary rotations each tick.

## Release rule

Any new Cat movement or idle must pass `test_cat_behavior_contract.py`, `test_cat_aaa_gait.py`, the Bedrock/source parity audits, and deterministic multi-angle visual QA before release. A visually cute frame is not accepted if it violates joint, clipping, gameplay-priority, or network-performance rules. No image-generation model is used for Creeperella deterministic QA.
