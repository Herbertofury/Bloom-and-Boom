# Creeperella 1.4.20 Final Verification

## Scope

Native Forge client release gate for Creeperella: Bloom & Boom on Minecraft 1.20.1 / Forge 47.4.23 / Java 17, plus correction of defects discovered only by the real renderer.

## Native-render root cause fixed

The 1.4.19 software/deterministic animation tests were green, but the real Forge client exposed a Cat rest-state failure: after entering a seated/rest pose, the visible Cat rig rapidly disappeared while its shadow/particles remained.

The custom Cat `waist` parent is outside vanilla `CreeperModel`'s normal animation reset set. Rest methods intentionally translate/roll that parent; because it was never reset to bind pose, those transforms accumulated once per rendered frame. 1.4.20 resets both `waist` and `body` before applying source/rest animation layers. This preserves the approved 1.4.19 geometry, IK, grounding, tail motion, and personality curves while making the transform stack frame-stable.

Permanent regression gate: `tools/test_cat_native_rest_reset.py` verifies the bind-pose reset and all five waist-mutating rest families.

## Native atlas fixes

The real client also exposed Cherry/Blossom atlas warnings that deterministic JSON/model checks did not reveal:

- Cherry/Blossom 3D egg leaf accents now use deterministic source-derived item-atlas swatches instead of entity-texture atlas references.
- The standalone Cherry Creeper Head uses a dedicated source-derived block-atlas particle texture.
- Final native client warning scan found no Creeperella-specific missing-texture, missing-model, or atlas-stitch failure.

## Deterministic QA-world fix

Cat Creepers are registered as `MobCategory.MONSTER`. The previous Peaceful singleplayer QA copy could accept the spawn command and then immediately remove the test Cats, producing a false-positive harness state. 1.4.20 QA uses Normal difficulty with natural mob spawning disabled. Operator-spawned QA Cats survive while random mobs stay out of the capture.

The native driver now runs the phase sequence from an in-world scheduled datapack rather than chat/X11 typing. The integrated server emits authoritative invisible markers and the runner refuses to pass unless every Cat phase reports a complete 14-entity live grid.

## Final native Forge client gate

Observed against the actual Minecraft client renderer under Xvfb/Mesa software rendering:

- Minecraft 1.20.1
- Forge 47.4.23
- Temurin Java 17.0.20.1
- 7/7 Linux LWJGL native libraries extracted and loaded
- deterministic `Creeperella-QA` singleplayer world entered through Quick Play
- real Cat rest-pose lineup remained fully visible after the per-frame reset fix
- `MMV_QA_CATS idle=NONE spawned=14`
- `MMV_QA_CATS idle=TAIL_WAG spawned=14`
- `MMV_QA_CATS idle=KNEAD spawned=14`
- `MMV_QA_CATS idle=CURIOUS_LOOK spawned=14`
- `MMV_QA_CATS idle=PAW_LIFT spawned=14`
- `MMV_QA_CLEAR removed=14`
- native reel, isolated phase clips, stills, GIFs, early/mid/late motion strips, ordered contact sheet, client log, markers, and SHA-256 receipt produced
- no fatal client exception/crash marker

External Mojang asset-object downloads are unavailable in the network-isolated QA runner. The visual-only doctor proves vanilla model/texture resources from the cached 1.20.1 client JAR; the missing external object index affects vanilla sound/icon resources, not the tested entity/model/texture renderer. This fallback is explicit and can be disabled with `VISUAL_ONLY_OK=0` when a full asset cache is required.

## Visual evidence review

The clean final contact sheet and personality motion strips were inspected from the native capture. The complete rest lineup is visible and grounded, the HUD/chat is hidden, and Tail Wag, Knead, Curious Look, and Paw Lift retain non-zero frame-to-frame motion. Supplemental early-vs-late RMSE values are non-zero for every captured personality phase.

## Static/deterministic regression gates passed

- `test_cat_native_rest_reset.py`
- `test_cat_behavior_contract.py`
- `test_cat_horse_rest_ground.py`
- `test_cat_personality_motion_1419.py`
- `test_cat_rest_pose_polish.py`
- `test_cat_aaa_gait.py` — 17,328 locomotion leg-phase samples
- `test_cat_secondary_motion.py` — 17,328 locomotion leg-phase samples
- `test_cherry_animation_formula_parity.py` — 235 sampled channel evaluations
- `test_pie_animation_formula_parity.py` — 712 sampled channel evaluations
- `audit_3d_spawn_eggs.py` — original 5/5 2D hashes and 24/24 3D models
- `audit_cat_bedrock_port.py`
- `audit_cherry_standalone_assets.py` — 84 runtime JSON resources
- `audit_model_generation_determinism.py`
- `audit_pie_animation_fidelity.py`
- `audit_source_pack_completeness.py` — 45/45 supplied source-pack files accounted for

The former historical `/mnt/data` dependency in `test_cat_rest_pose_polish.py` is eliminated: the 1.4.18 numeric reference is bundled under `tools/fixtures/` and the test passes hermetically.

The exact-sample Cat gait QA now caches repeated inverse matrices and pins BLAS thread counts before NumPy import. Sample coverage is unchanged; runtime drops from multi-minute oversubscription to roughly 17 seconds on this runner.

## Production build

Final production build command:

`gradle --offline --no-daemon clean build`

Observed result: `BUILD SUCCESSFUL` with `compileJava`, `jar`, `reobfJar`, `assemble`, `check`, and `build` complete.

Final production JAR at build time:

- `creeperella-1.20.1-forge-1.4.20.jar`
- 244,958 bytes
- SHA-256 `a29acf3296a10f1fdd15c35484ec2ce53d519b17f9f4fe3e7692cb7aa1285b62`
- ZIP integrity PASS
- manifest `Implementation-Version: 1.4.20`

Compile emits 15 non-blocking 1.20.1 deprecation/removal warnings (`ResourceLocation` constructors and Forge loading-context accessors). These are future-port cleanup, not runtime failures.

## Dedicated server gate

The post-build Forge 47.4.23 dedicated QA server reached:

`Done (2.805s)! For help, type "help"`

No task-related fatal server error replaced the prior successful startup path.

## Release decision

1.4.20 supersedes 1.4.19 as the canonical release. The native renderer gate is now part of the release contract; a deterministic/software-only animation pass is no longer sufficient for Cat rest-pose changes.
