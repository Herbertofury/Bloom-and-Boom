# Cat Creeper — deterministic Bedrock → Java port contract

`FemaleCreeper.mcpack` is treated as the source of truth for the Cat Creeper. The Java model is generated from the supplied files and then independently audited; it is not eyeballed from screenshots.

## Source-of-truth files

- `reference-assets/cat/creeper.geo.json` — base rig and geometry
- `reference-assets/cat/creeper_charged.geo.json` — powered/charged rig and geometry
- `reference-assets/cat/creeper.animation.json` — authored 8.0417-second animation loop
- `reference-assets/cat/creeper.entity.json` — source material/texture/geometry bindings and pre-animation variables
- `reference-assets/cat/creeper.render_controllers.json`
- `reference-assets/cat/creeper_armor.render_controllers.json`
- `reference-assets/cat/creeper.png` / `creeper_armor.png`
- `reference-assets/cat/manifest.json` / `credit.txt`

The packaged Java textures are required to remain byte-identical to the two supplied entity textures.

## Why 1.4.0 produced the protruding tail

The first hand port treated Bedrock→Java as if X/Z rotation signs should be inverted. That is not the transform produced by Blockbench when the two codecs are composed. On the Cat rig, that sign error rotated the long authored `tail`/`tail2` chain forward through the body, making a dark block visibly protrude from the front/side during animation.

## Codec-derived transform

Blockbench's Bedrock geometry importer negates X for pivots/cube X placement and negates X/Y rotations. Its Minecraft Java 1.17+ entity exporter then negates X again for the Java offset and negates X/Y rotations again. With the Y-flipped Java entity layout used here, the net rules are:

- child bone offset: `(bedrock_dx, -bedrock_dy, bedrock_dz)`
- authored root under the Java Y=24 wrapper: `(bedrock_x, -bedrock_y, bedrock_z)`
- bind rotation: **same authored Bedrock X/Y/Z signs**
- local cube origin: `(origin.x-pivot.x, -(origin.y+size.y-pivot.y), origin.z-pivot.z)`
- UV offset, size, deformation/inflate: unchanged
- mirror: cube override if present; otherwise inherit the Bedrock bone's `mirror`

For animation, Blockbench's Bedrock animation importer and Java animation exporter likewise cancel the X/Y rotation sign changes, so authored animation rotations retain their Bedrock signs. Direct Java `ModelPart` position animation inverts Bedrock Y so it matches Java's Y-down model space.

## Source animation behavior retained

`animation.creeper.legs` is 8.0417 seconds long and retains the source channels for:

- `Body` Y bob
- `Upperbody` X/Y position and Catmull-Rom Z sway
- `Breast` X motion
- `head` Catmull-Rom Z sway plus normal target look
- `earL` / `earL2` Z motion
- `tail` X motion
- `tail2` X motion
- source leg override directions preserved in the reference animation/provenance; 1.4.7 intentionally substitutes the movement-time IK gait described below

The animation JSON also references legacy `white`, `white2`, `blink`, `blink2`, and eyebrow bones that are not present in the supplied `creeper.geo.json`. Rather than silently losing the authored blink timing, Creeperella maps those exact pulse windows onto the two eye groups that actually exist (`eye1`, `eye2`). 1.4.7 adds a small bounded movement-only tail yaw for feline balance; tail roll remains absent.

The source `animation.creeper.swelling` corresponds to vanilla Creeper swelling. Creeperella's renderer applies the same swelling/wobble scale logic to the complete Java model, so the whole authored Cat rig swells coherently when fusing.

## Permanent QA gate

Run:

```text
python3 tools/generate_cat_bedrock_model.py
python3 tools/generate_cat_bedrock_animation.py
python3 tools/audit_cat_bedrock_port.py
python3 tools/audit_3d_spawn_eggs.py
```

`audit_cat_bedrock_port.py` checks exact source hashes, base and charged bone/cube parity, pivots, parent offsets, rotations, UVs, mirror inheritance, deformation, packaged texture identity, source animation sign semantics, source leg-override provenance, plus the intentional 1.4.7 IK gait contract and absence of tail roll.

## 1.4.7 locomotion policy

The supplied Bedrock geometry, texture, blink windows and authored idle/secondary channels remain source-faithful. Locomotion is now intentionally **semantic rather than literal**: the source pack's broad parent-leg swing is replaced during movement with a feline four-beat gait / high-speed trot blend because literal full-amplitude swing produced non-cat motion and could visually fold limbs through the torso.

The runtime solves each existing upper/lower/paw chain as a two-link sagittal IK system using the exact generated pivot vectors (`5.25,1.75` upper; `3.0,0.0` front lower; `5.05,-0.25` hind lower). Paws use stance and swing trajectories with smoothstep timing, and hard anatomical clamps backstop the IK reach constraints. At movement=0 the locomotion solver returns immediately after reset, so the authored bind/idle leg pose is preserved. The tail keeps source X animation and adds only small movement-gated Y balance motion; Z roll remains forbidden.

`test_cat_aaa_gait.py` is the release gate for this intentional locomotion upgrade and is paired with deterministic front / three-quarter / side visual QA.
