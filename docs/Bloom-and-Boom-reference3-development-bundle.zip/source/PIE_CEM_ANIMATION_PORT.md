# Pie CEM Animation Port — Native Forge 1.20.1

Version target: **Creeperella 1.4.3**

The supplied Pie pack is the source of truth for Female, Bunny, and Bee geometry and animation intent. The exact reference files in `reference-assets/pie/` are byte-identical to the user's supplied `(Pie's) Female Creeper 1.2.zip`.

## Why 1.4.2 exists

The earlier native port converted Pie's geometry and preserved the distinctive blink pulse, but most of the source CEM animation program was not being executed. Female/Bunny/Bee therefore looked much more vanilla and mechanical than Cherry/Blossom even though Pie's own `.jem` files contain a rich animation rig.

1.4.2 restores that missing motion in `CreeperellaModel.animatePieSource`.

## Source animation coverage

The three supplied base CEMs contain these unique authored channels:

- Female `creeper.jem`: **53**
- Bunny `creeper2.jem`: **61**
- Bee `creeper3.jem`: **64**

The native adaptation covers the same motion families:

- body X/Y/Z translation and X/Y/Z rotation
- chest Y translation plus X/Y rotation
- head Y translation plus X/Y/Z rotation
- left/right hair Y translation plus X/Z rotation
- all four legs: X/Y/Z translation plus X/Y/Z rotation
- eye white scale, pupil X tracking/vertical blink response/visibility, eyebrow Y response
- Bunny/Bee tail X/Y rotation
- Bunny/Bee left/right ear X/Z rotation
- Bunny articulated `right_ear2` X/Z rotation
- Bee left/right wing source rotation channels

## Native hierarchy adaptation

The critical 1.4.2 correction is to preserve **CEM target resolution**, not merely copy the numbers. In OptiFine/EMF, top-level animation keys such as `body.*` and `leg1.*` resolve to the original vanilla model part first; the visible Pie custom mesh with the same ID remains a child of that vanilla part. The generated native Forge hierarchy mirrors that relationship.

That means:

1. `body.tx/ty/tz/rx/ry/rz` are assigned **absolutely to the vanilla body proxy**, including Pie's authored `body.ty = 5 + ...` base coordinate.
2. `leg1..leg4` are assigned **absolutely to the four vanilla leg proxies**. Their visible Pie child meshes keep their generated static bind transforms, so the source lift/stride/turn program is not doubled with vanilla walking.
3. Nested unique CEM IDs such as `breasts`, hair, eyes, pupils, brows, ears, tail, and wings animate their converted custom child parts relative to the source-derived bind pose.

Pie's `head2` is the one deliberate layer-generation exception: its static `body(+20) -> head2(-20)` translation was collapsed when it was detached onto the vanilla head proxy. At runtime 1.4.2 copies the complete animated source `body.*` transform onto that head proxy, then applies only `head2`'s authored local dynamic channels. This recreates the original body/head counter-motion without double-applying the parent transform.

The result is source-faithful CEM hierarchy semantics rather than a visual approximation: authored walk phase, head sway, breathing, turn lean, and secondary motion all land on the same logical targets they did in the supplied pack.

## Preserved source behavior

- The original Pie blink expression remains the timing source:
  `pow(clamp(abs(sin(age/20)*8+cos(age/30)*2+cos(age/20)*6),0,1),2)`.
- Pupil horizontal tracking from the source CEM is restored.
- Source idle/walk blending (`idle = 1 - clamp(limb_speed*3, 0, 1)`) is retained.
- A deterministic UUID-derived phase stands in for CEM `random(id)`, so multiple Creeperellas do not breathe/sway in lockstep.
- The CEM aggression ramp is adapted to the client-synced Creeper swell state and keeps the source easing shapes.
- Hurt recoil uses the source `sin(hurt_time/2)*hurt_time/10` relationship.
- Bunny tail/ears and Bee wings use the supplied CEM equations rather than generic invented motion.

## Non-regression gate

Run:

```text
python3 tools/audit_pie_animation_fidelity.py
python3 tools/test_pie_animation_formula_parity.py
python3 tools/audit_cat_bedrock_port.py
python3 tools/audit_3d_spawn_eggs.py
```

The Pie gate verifies:

- 8/8 locked Pie source hashes
- source channel counts 53 / 61 / 64
- exact CEM target hierarchy: body/legs on vanilla proxy parents, nested IDs on custom children
- exact Pie blink/gaze visibility semantics with no artificial minimum eye scale
- **712 sampled channel evaluations** numerically matched against expressions read directly from the supplied JEM files
- removal of the old invented Bee flap
- byte-identical 1.4.1 Cat animation method body
- byte-identical 1.4.1 Cherry/Blossom animation method body

No image-generation model is part of this QA path. Visual previews, when produced, must be deterministic renders of actual project geometry, textures, and animation values.

## Charged-model parity

The three supplied charged CEM files are treated as first-class source models, not generic overlays. Their Java layer definitions regenerate directly from `creeper_charge.jem`, `creeper_charge2.jem`, and `creeper_charge3.jem`. Their animation programs match the corresponding base CEMs exactly for every channel present in charged geometry. The only ten channels absent in each charged CEM are the left/right eye-white, pupil and eyebrow channels, because those face children are not present in the supplied charged geometry. This exact difference is now an automated gate.
