# Creeperella variant research — 2026-08-23

Curated donor/reference list for future Creeperella expansions. Core 1.1.0 stays focused on the supplied Pie + Cherry families; outside packs are not silently bundled.

| Priority | Pack | MC relevance | License / permission posture | Creeperella use |
|---|---|---|---|---|
| 1 | Anime mob girls | Java 1.20–1.20.4; explicitly lists Creeper | MIT | Best next donor candidate. Inspect its Creeper CEM + texture, then adapt as an optional standalone guest variant with attribution. |
| 2 | Kawaii Cute Mobs (Girls) | Java 1.20.x; explicitly includes a girl Creeper | Apache-2.0 | Strong second donor candidate; inspect visually before integration and retain required notices/attribution. |
| 3 | Creepingly Creeper | Java 1.20.x; Creeper-focused with multiple variants | CC-BY-4.0 | Excellent texture/eyes/spawn-egg inspiration or credited optional texture family; not specifically female. |
| 4 | Cerise's Creeper | 1.14+ including 1.20.x | MIT | Good vanilla-like texture modernization reference/donor. |
| 5 | My Monster Girls | Java 1.20.1 | MIT | Strong style reference; inspect archive before treating it as a Creeper donor. |
| 6 | Cute Mob Models: Resource Pack | Java 1.20–1.20.1 | GPL-3.0-only | High-quality model reference; direct derivatives require deliberate license compatibility. |
| 7 | Human Player Mobs | Java 1.20.x | CC-BY-SA-4.0 | Broad human/girl mob concept reference; share-alike implications for derivatives. |
| 8 | Creeper girl — Pitonixrex | Java 1.20.1 supported | All Rights Reserved | Animation/personality reference only unless author permission is obtained. |
| 9 | Creeper Girls / CreeperChan — RayWhoTraces | Java 1.20.1 supported | All Rights Reserved | Ask author before using assets; useful multi-skin presentation reference. |
| 10 | CuteAnimeMobs / WaifuCraft — RayWhoTraces | Java 1.20.x | All Rights Reserved | Broad anime-girl reference; permission required for reuse. |
| 11 | Female Creeper — omegasyi | Forge 1.20.1 | All Rights Reserved | Compatibility-test target; do not copy assets/code without permission. |
| 12 | Female Creepers — XenParadox / legacy | Old Forge 1.7.x | Legacy/permission unclear | Historical mechanics inspiration only. |

## Recommended 1.2.x direction: Guests & Friends

Keep the five Pie/Cherry entities as the polished default family. Inspect permissively licensed candidates first, add good fits as optional standalone guest variants with per-variant spawn toggles, and preserve upstream author/source/license/hash records. ARR candidates remain compatibility/reference targets unless direct permission is obtained.

## Public project pages

- https://modrinth.com/resourcepack/all-anime-mob-girls
- https://modrinth.com/resourcepack/kawaii-cute-mobs-%28girls%29
- https://modrinth.com/resourcepack/creepingly-creeper
- https://modrinth.com/resourcepack/cerises-creeper
- https://modrinth.com/resourcepack/my-monster-girls
- https://modrinth.com/resourcepack/cute-mob-models-resource-pack
- https://modrinth.com/resourcepack/human-player-mobs
- https://www.curseforge.com/minecraft/texture-packs/creeper-girl
- https://www.curseforge.com/minecraft/texture-packs/creeper-girls
- https://www.curseforge.com/minecraft/texture-packs/cuteanimemobs
- https://www.curseforge.com/minecraft/mc-mods/female-creeper
- https://www.curseforge.com/minecraft/mc-mods/female-creepers
