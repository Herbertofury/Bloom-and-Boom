# Creeper expansion / companion research — 2026-08-23

This is the current inspiration and compatibility shortlist for Creeperella. “Learn from” does not mean copy assets/code; license and version boundaries still apply.

| Project | Current relevance | What Creeperella should learn / test | License note |
|---|---|---|---|
| [Creeper Overhaul](https://modrinth.com/mod/creeper-overhaul) | Forge 1.20.1 release exists; major biome-specific Creeper family | Biome identity, silhouette variety, spawn coexistence, and a direct 1.20.1 compatibility test | ARR |
| [Baby Creeper - Малыш Крипер](https://www.curseforge.com/minecraft/mc-mods/baby-creeper-malysh-kriper) | Actively updated Forge 1.20.1 tameable baby Creeper | Tame/follower UX and pet-Creeper coexistence test | ARR |
| [Happy Creeper](https://www.curseforge.com/minecraft/mc-mods/happy-creeper) | Modern NeoForge/Fabric Creeper companion with UI, armor, fuel, follow/stay, dimensions | Best current companion-UX benchmark: dimension follow, respawn resync, armor/fuel UI, persistent ability data | ARR |
| [Friend Creeper](https://www.curseforge.com/minecraft/mc-mods/friend-creeper) | Active Fabric companion mod; source is MIT | Clean owner/sit/follow/config patterns; its source was inspected as a design reference | MIT |
| [Moldyfishy's Baby Mobs](https://www.curseforge.com/minecraft/mc-mods/moldyfishys-baby-mobs) | Forge 1.20.1 baby Creeper pet | Lightweight gunpowder taming, cute animation, non-exploding follower/talisman role | ARR |
| [Companions!](https://www.curseforge.com/minecraft/mc-mods/companions-mod) | Actively updated Forge 1.20.1; 1.3.2 released Aug 8 2026 | Premium companion state machine, healing resources, abilities, attack cooldown discipline, integration expectations | GPL-3.0 |
| [Vein Creepers](https://modrinth.com/mod/vein-creeper) | Forge 1.20.1 and NeoForge; updated in 2026 | Excellent reference for data-driven Creeper variants and useful explosion effects/recipes/traps | ARR |
| [Ore Creeper](https://modrinth.com/mod/ore-creeper) | Forge 1.20.1 release available | Explosion-as-world-interaction concept and JourneyMap-adjacent compatibility; keep separate from companion combat defaults | ARR |
| [Baby Mobs Rebrushed](https://www.curseforge.com/minecraft/mc-mods/baby-mobs-rebrushed) | Forge 1.20.1, updated Apr 2026, public-domain project | Spawn replacement/rarity design and tiny-hostile ability variety; compatibility test if installed with Creeperella | Public Domain |
| [Creeper Tweaks](https://modrinth.com/mod/creeper-tweaks) | Modern Fabric/Quilt server-side project, not 1.20.1 | Config architecture ideas: variant fuse/power, confetti, lingering effects, block regeneration, reload/debug commands | CC0-1.0 |
| [Nice Creeper Tweaks](https://modrinth.com/datapack/nice-creeper-tweaks) | Archived datapack | Size/fuse/explosion-power correlation as a datapack-friendly design reference only | GPL-3.0-or-later |

## Best ideas to carry forward

1. **Cross-dimension companion continuity** — Happy Creeper is the strongest benchmark here. Creeperella 1.2.0 deliberately waits safely if owner and companion are in different dimensions; a future premium pass can add owner-dimension transfer plus respawn resync with explicit tests.
2. **Ability biscuits / loadouts without power creep** — permanent optional abilities could be a later system, but the base five variants should remain readable and balanced.
3. **Data-driven explosion effects** — Vein Creepers demonstrates why explosions can be more than damage. Future optional utility commands could use datapack-configurable effects without changing the safe default blast.
4. **Better server/operator observability** — Creeper Tweaks' reload/spawn/debug command model is worth adapting into Creeperella admin/debug tooling.
5. **Compatibility matrix** — priority runtime tests: Creeper Overhaul, Baby Creeper, Companions!, Moldyfishy's Baby Mobs, and Baby Mobs Rebrushed on Forge 1.20.1.

## Creeperella's differentiation

Creeperella should stay its own product: five standalone character variants, deterministic biome/personality-themed bonding, an explicit Fuse Whistle command language, reusable safe Boom Runs, owner/pet protection, no default terrain grief, and no random taming tax. It should learn premium UX from other mods without becoming a generic “tame every Creeper” layer.
