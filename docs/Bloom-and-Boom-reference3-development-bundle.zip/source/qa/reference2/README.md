# Reference2 visual reconstruction checkpoint

Target: Minecraft 1.20.1 / Forge 47.4.23. User clarified Froglight variants: Mariglow, Verdalia, Nacrella.

## Canonical reference source
The approved clean reference PNGs remain unchanged in the existing Drive Reference Art collection. Generated visual1 texture samples are not acceptance targets. Source links and SHA256 identifiers are preserved in the reference catalog.

## Implemented
- Full-head flower crown, roof flowers and ten articulated hanging chains.
- Cached curved petal surfaces replace rectangular petal blocks.
- Sparse Froglight-only charged masks preserve the visible face and body.
- Reference eye planes driven by the existing Pie blink/gaze channels.
- Corrected lower-face position, separate pupil/glint geometry.
- High-resolution vanilla-derived body panels, shaded soles and face materials.
- Tinted emissive lanterns with a channel-clipping regression check.
- Original Pie animation formulas and protected Cat assets retained.

## Evidence and limits
Native development-client screenshots are evidence of actual rendered code. They do not establish exact concept-art fidelity or production readiness. Flower silhouette, petal volume and facial resemblance still need acceptance review. This checkpoint retains the user-requested Pie chest and movement, which intentionally differ from the static concept body.

The isolated cloud client reported repeated slow ticks and several UI timeouts during resource reload. No FPS improvement or smooth-play claim is made. The official asset cache is incomplete (previous download returned HTTP403); sound, title panorama and authenticated multiplayer remain unverified.

## Repeatable camera setup
Copy datapack/ into a disposable 1.20.1 test world and reload. Presets bloomqa:day, night, nacrella, verdalia, mariglow, charged and normal are provided. The camera presets assume the documented fixture actors. FOV44 gives a close-up. Capture actual game output with F2. Do not crop or stretch comparison images without labeling the crop.

## Packaged-JAR verification

The exact 486,850-byte reference2 JAR (SHA256 `37e7c9514d241b83d2f7c9b8439b107fb6d9e68e9e8097a125c0f680c5271565`) booted on an isolated Forge 47.4.23 dedicated server, spawned the ten-family fixture, loaded the saved companion fixture, saved and exited zero. These checks do not replace a production-client, multiplayer, full gameplay or fidelity acceptance gate.
