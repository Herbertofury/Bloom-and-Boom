weather clear 999999
time set 18000
say [BloomQA] reference-night-ready
