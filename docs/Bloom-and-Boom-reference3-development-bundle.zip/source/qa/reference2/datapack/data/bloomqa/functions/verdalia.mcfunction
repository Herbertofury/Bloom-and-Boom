tp @a 304.2 -59.2 298.2 37 27
say [BloomQA] verdalia-three-quarter-view
