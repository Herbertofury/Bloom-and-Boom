gamerule doDaylightCycle false
gamerule doWeatherCycle false
weather clear 999999
time set 6000
say [BloomQA] reference-day-ready
