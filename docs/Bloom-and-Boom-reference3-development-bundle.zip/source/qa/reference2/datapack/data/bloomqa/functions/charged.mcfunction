execute as @e[type=creeperella:mariglow_creeper,x=300,y=-60,z=300,distance=..16] run data merge entity @s {powered:1b}
execute as @e[type=creeperella:verdalia_creeper,x=300,y=-60,z=300,distance=..16] run data merge entity @s {powered:1b}
execute as @e[type=creeperella:nacrella_creeper,x=300,y=-60,z=300,distance=..16] run data merge entity @s {powered:1b}
say [BloomQA] charged-state-ready
