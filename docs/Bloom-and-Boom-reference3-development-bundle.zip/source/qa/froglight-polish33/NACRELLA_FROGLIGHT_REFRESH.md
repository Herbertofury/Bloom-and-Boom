# Nacrella Froglight Refresh (dev7 polish33)

## What changed
- Reworked **Nacrella body material** to sample the actual Minecraft **pearlescent froglight** side/top textures instead of relying on a mostly invented pastel ramp.
- Replaced the washed-out near-flat face mask with a restrained pearlescent top-lit material pass.
- Rebuilt Nacrella accessories / iris to keep the flower-girl identity while reading closer to a Minecraft froglight block material.
- Kept dark facial details intact and preserved the protected Boomshroom asset.

## Result
- Stronger vanilla froglight ribbing / panel rhythm.
- Less chalky white washout.
- Better body/face/accessory material cohesion.
- Audits pass after regeneration.

## Validation
- `python tools/generate_froglight_body_palettes.py`
- `python tools/generate_froglight_accessory_palettes.py`
- `python tools/audit_froglight_material_contrast.py` -> PASS
- `python tools/audit_froglight_family.py` -> PASS

## Files touched
- `src/main/resources/assets/creeperella/textures/entity/nacrella_creeper.png`  sha256 `88801b8ad90f41a2180f1f8033dbafc53b198fda425f1c02d453b6b625a055ad`
- `src/main/resources/assets/creeperella/textures/entity/nacrella_face_skin.png`  sha256 `7043e73fefde08a5f4660186471f072dbe27cd41cb19b8db91e509524d3580c6`
- `src/main/resources/assets/creeperella/textures/entity/nacrella_accessories.png`  sha256 `31d521e51f923784c00c5ba78b40a9100b9ae400526bffe982c9afaca621110e`
- `src/main/resources/assets/creeperella/textures/entity/nacrella_accessories_e.png`  sha256 `8fa4df6140334138b19a5b0e59d712995f59b11c03b5dfd89c22e304d29b2ebb`
- `src/main/resources/assets/creeperella/textures/entity/nacrella_face_iris.png`  sha256 `6e96eb0d25cb08ba7b4538094ed22a91047a516f5078151c3c25127bccf6c691`
- `tools/generate_froglight_body_palettes.py`  sha256 `374ec923399a3383fdc09265bb97abe284093361be424866326467b8879eed75`
- `tools/generate_froglight_accessory_palettes.py`  sha256 `8f578bedd47b5fbd50cb8747cf97b2b75caa0c646694f167361b433f80f3a1af`
