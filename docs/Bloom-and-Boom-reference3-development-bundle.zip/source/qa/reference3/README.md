# Reference3 native development checkpoint

Minecraft 1.20.1 / Forge 47.4.23 / Java 17. Official name: Bloom & Boom. Legacy registry/save identity: creeperella.

## Scope and source authority
The user's clarified targets are Mariglow, Verdalia and Nacrella, using the approved clean Froglight concept PNGs in the existing Drive Reference Art collection. Source links and content hashes remain in the delivered concept catalog. No image generation is used for this reconstruction. The user-requested Pie chest, rig and animation are intentionally retained. Cat assets and animation are protected.

## Implemented
- Curved petal normals and narrower individual petals.
- Seven roof blossoms plus five front and seven surrounding blossoms; the rear inspection prompted three additional roof flowers.
- Twelve articulated hanging vines and separately rendered translucent lantern shells.
- High-density jewel-eye UV gradients and swept outer lashes, using the original Pie blink/gaze channels.
- Brighter vanilla-derived panel centers, darker retained foot tips and lighter reference-tinted foliage.
- Reproducible final luminance/foliage bake from hash-pinned inputs; twelve textures match byte-for-byte.
- No duplicate curved-petal submissions in the emissive pass.

## Verification gates
- Offline build and reobfuscation: PASS.
- Eight focused static suites: PASS. Includes 25 protected assets, unchanged Cat animation, 712 Pie formula samples, resource graph, companion ownership/main-hand and Cat rest-reset guards.
- All 27 packaged Froglight material PNGs match source bytes.
- Actual native development-client day/night, front/three-quarter/rear, charged and ordinary state evidence is indexed in native-checks.json.
- Exact packaged-JAR dedicated-server: PASS for startup, ten-family spawn, saved companion loading, world save and clean exit. Results are recorded in production-checks.json.
- Final development-client world save and exit zero: PASS.

## Open acceptance gates
This is a development checkpoint, not a stable or exact-reference release. Crown coverage is fuller but still differs from the densely layered concept; petal/foliage silhouette, facial proportions and finer floral details need art acceptance. Existing ambient particles, especially Verdalia's happy-villager particles, also differ from the reference sparkle style and are not redesigned here.

Production-client, full gameplay, broader save migration, multiplayer and performance acceptance remain open. The cloud runtime has incomplete official vanilla assets (a prior authorized download returned HTTP403), so missing title/sound assets are not a mod-quality PASS. No certificate or network restriction is bypassed. Native frames are actual F2 output; comparison crops preserve aspect ratio and are labeled.

The source/binary bundle is privately delivered. Public redistribution remains pending explicit sharing approval. Do not infer a public release from the documentation hub.
