# Creeperella: Bloom & Boom 1.4.15 — Final Verification

Target: Minecraft 1.20.1 / Forge 47.4.23 / Java 17

## Scope

1.4.15 is a focused Cat Creeper pose-polish release after the approved 1.4.14 upright horse-rest pass.

Changed:
- SIT: rebuilt with static two-link rest IK and fixed-ground calibration.
- LOAF: deeper compact body fold, four tucked paws, alert head/neck.
- SPRAWL: four explicit outward paw targets through static rest IK.
- Rest-idle compatibility: SIDE_LIE/SPRAWL cannot select PAW_LIFT; LOAF knead stays tucked.
- SIT/LOAF/SPRAWL tail bases refined without any Cat tail-roll override.

Regression-locked unchanged:
- approved 1.4.14 `applyCatSideLiePose(...)` runtime method — byte-for-byte identical.
- locomotion `animateCatLegIk(...)` solver — byte-for-byte identical to 1.4.14.
- Cat visual state blender — byte-for-byte identical to 1.4.14.
- source pack assets / Pie / Cherry / Cat generated geometry.

## Fixed-ground deterministic pose QA

Standing Cat paw-bottom reference: `-24.096318` model units.

- SIT delta: `0.002264`
- LOAF delta: `0.002537`
- SPRAWL delta: `0.101815`
- HORSE_REST delta: `0.099994..0.100047`

All are <= 0.15 model units from the fixed standing ground reference. The renderer does not snap each pose to its own floor.

## Gates run in this pass

- PASS `tools/audit_cat_bedrock_port.py`
  - FemaleCreeper source hashes exact.
  - Cat base geometry 39 cubes and charged geometry 14 cubes exact.
  - Authored Cat source animation semantics retained.
  - Cat tail roll override absent.
- PASS `tools/test_cat_rest_pose_polish.py`
  - 1.4.14 horse-rest/SIDE_LIE method byte-identical.
  - locomotion IK + visual state blender byte-identical.
  - 12 solved rest leg chains across SIT/LOAF/SPRAWL.
  - vulnerable rest poses block support-breaking PAW_LIFT.
  - LOAF knead remains tucked.
  - fixed-ground deltas <= 0.15.
- PASS `tools/test_cat_horse_rest_ground.py`
  - four grounded upright horse-rest variants; tiny lean / near-vertical chest-head contract retained.
- PASS `tools/test_cat_behavior_contract.py`
  - transition-only sync, creep/run notice hysteresis, follower tiers, interruptible idles, client state blending/IK contract.
- PASS `tools/audit_source_pack_completeness.py`
  - 45/45 supplied source files accounted for.
- PASS `tools/audit_model_generation_determinism.py`
  - Pie, Cherry/Blossom and Cat model families regenerate byte-identically.
- PASS `tools/audit_pie_animation_fidelity.py`
  - Pie source animation hierarchy/semantics exact.
- PASS `tools/test_pie_animation_formula_parity.py`
  - 712 sampled Pie channel evaluations match supplied formulas.
- PASS `tools/test_cherry_animation_formula_parity.py`
  - 235 sampled Cherry/Blossom channel evaluations match supplied formulas.
- PASS `tools/audit_cherry_standalone_assets.py`
  - 84 runtime JSONs parsed and standalone Cherry sidecars preserved.
- PASS `tools/audit_3d_spawn_eggs.py`
  - exact 2D fallback hashes; 24/24 six-variant 3D models.
- PASS Java parser sanity on the modified model/entity source before expected missing Forge/Minecraft dependency errors.

The heavyweight 17,328-sample `test_cat_aaa_gait.py` exceeded the current container execution window when repeated in this pass. The gait solver and state blender it exercises are byte-for-byte unchanged from the preserved 1.4.14 source, and the focused 1.4.15 rest-pose/behavior/source-parity gates above are green. Do not treat this as a production Forge runtime substitute.

## Rollback / reversibility

`pose-history/1.4.14-before/` inside the 1.4.15 source includes:
- the complete 1.4.14 source ZIP,
- original 1.4.14 `CreeperellaModel.java`,
- original 1.4.14 `CreeperellaEntity.java`,
- baseline deterministic pose QA images.

The canonical Drive also retains 1.4.14 as separate source/QA objects, so rollback does not depend on the nested archive.

## Production gate still pending

This environment has Java 21 and no Gradle executable/wrapper. A Java 17 ForgeGradle compile/remap and a real Forge 47.4.23 client/server startup remain required before claiming a production JAR is runtime-verified.

## Preview provenance

All 1.4.15 visual QA is deterministic rendering from the actual Cat Creeper model hierarchy, exact project texture, and runtime-equivalent pose math. **No image generation was used.**
