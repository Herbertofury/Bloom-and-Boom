Bloom & Boom - reference3 development checkpoint
Minecraft 1.20.1 / Forge 47.4.23 / Java 17

Install only the JAR from mod/ into an isolated matching Forge instance. Remove another Bloom & Boom/Creeperella JAR from that instance first; back up valuable worlds. The technical mod/save identity remains creeperella.

Source, provenance, native screenshots and verification receipts are included. Build with Java 17 and Gradle 8.8. Dependency caches, Minecraft binaries, user worlds, raw runtime logs and authentication files are excluded. Some original material-generation tools require verified local Minecraft texture inputs; ready-to-build runtime assets and hash-pinned finishing inputs are included with provenance.

The final build and exact packaged-JAR dedicated-server checks passed. Eight focused static suites passed. Final native development-client screenshots cover all three Froglights, rear crown, night and charged states. The test world saved and the client exited zero. All 27 packaged Froglight material PNGs match source; twelve final material textures reproduce byte-for-byte from pinned inputs.

NOT a stable release or exact concept-art match. Fuller curved crowns, twelve chains, jewel eyes and translucent lanterns are implemented; denser reference floral silhouette, finer face details and reference-like ambient particles still need acceptance. The original Pie chest and animations remain intentionally retained. Production-client, broader gameplay/save compatibility, multiplayer and performance acceptance remain open. Official vanilla asset cache is incomplete in cloud QA. No zero-issues or FPS claim is made. Historical receipts apply only to their original checkpoints.

This bundle is delivered privately to the owner. Public redistribution awaits explicit sharing approval.
